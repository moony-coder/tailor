// Per-model token buckets (requests/min + tokens/min) with a FIFO queue. Clock and sleep are injected so tests run instantly.
export class RateLimiter {
  /** limits = { model: {rpm, tpm, rpd?, tpd?} } */
  constructor(limits, { now = () => Date.now(), sleep = (ms) => new Promise((r) => setTimeout(r, ms)), safety = 0.9 } = {}) {
    this.limits = limits; this.now = now; this.sleep = sleep; this.safety = safety;
    this.state = new Map(); this.queues = new Map(); this.blockedUntil = new Map();
  }
  _st(model) {
    if (!this.state.has(model)) { const l = this.limits[model] ?? { rpm: 10, tpm: 4000 }; this.state.set(model, { req: l.rpm * this.safety, tok: l.tpm * this.safety, last: this.now(), day: { n: 0, tok: 0, start: this.now() } }); }
    return this.state.get(model);
  }
  _refill(model) {
    const l = this.limits[model] ?? { rpm: 10, tpm: 4000 }, s = this._st(model), t = this.now(), dt = (t - s.last) / 60000;
    s.req = Math.min(l.rpm * this.safety, s.req + dt * l.rpm); s.tok = Math.min(l.tpm * this.safety, s.tok + dt * l.tpm); s.last = t;
    if (t - s.day.start >= 86400000) s.day = { n: 0, tok: 0, start: t };
    return s;
  }
  /** Daily caps reached? Then the caller should skip straight to the next model. */
  dailyExhausted(model, tokens = 0) {
    const l = this.limits[model]; if (!l) return false; const s = this._refill(model);
    return (l.rpd != null && s.day.n + 1 > l.rpd) || (l.tpd != null && s.day.tok + tokens > l.tpd);
  }
  /** Server told us to wait (HTTP 429 retry-after). */
  block(model, ms) { this.blockedUntil.set(model, Math.max(this.blockedUntil.get(model) ?? 0, this.now() + ms)); }
  usedActual(model, tokens) { const s = this._refill(model); s.day.n++; s.day.tok += tokens; }
  /** Resolve when a call costing `tokens` may start. FIFO per model. */
  acquire(model, tokens) {
    const l = this.limits[model] ?? { rpm: 10, tpm: 4000 };
    if (tokens > l.tpm * this.safety) tokens = Math.floor(l.tpm * this.safety);     // a single call can never exceed the bucket
    const prev = this.queues.get(model) ?? Promise.resolve();
    const run = prev.then(async () => {
      for (;;) {
        const wait = Math.max(0, (this.blockedUntil.get(model) ?? 0) - this.now());
        if (wait > 0) { await this.sleep(wait); continue; }
        const s = this._refill(model);
        if (s.req >= 1 && s.tok >= tokens) { s.req -= 1; s.tok -= tokens; return; }
        const needReq = s.req >= 1 ? 0 : (1 - s.req) / l.rpm * 60000, needTok = s.tok >= tokens ? 0 : (tokens - s.tok) / l.tpm * 60000;
        await this.sleep(Math.max(50, Math.ceil(Math.max(needReq, needTok))));
      }
    });
    this.queues.set(model, run.catch(() => {}));
    return run;
  }
}
