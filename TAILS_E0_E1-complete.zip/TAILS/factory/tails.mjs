#!/usr/bin/env node
// TAILS Question Factory CLI. Zero dependencies (Node 18+, Python 3 + sympy for math checks).
//
//   node factory/tails.mjs plan                         what to generate next (coverage vs 5,000 target)
//   node factory/tails.mjs brief RW.CS.WIC [--n 20] [--levels 3,4,5]   -> factory/briefs/<batch>.md  (paste into DeepSeek)
//   node factory/tails.mjs ingest factory/inbox/<file>.txt             parse DeepSeek reply, check everything, stage
//   node factory/tails.mjs blind <batch>                -> factory/blind/<batch>.md  (paste into a NEW DeepSeek chat)
//   node factory/tails.mjs grade <batch> factory/inbox/<answers>.txt   blind answers vs key -> bank or reject
//   node factory/tails.mjs families [--per 40] [--seed 1] [--only lin1-solve]   generate verified math from code (0 tokens)
//   node factory/tails.mjs export [--out factory/out/questions.json] [--into path/to/data.json]
//   node factory/tails.mjs sync path/to/assets/engine/data.json         refresh taxonomy snapshot
//   node factory/tails.mjs stats
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { P, readJson, writeJson, taxonomy, loadBank, saveToBank, loadStaging, makeIdAllocator, extractJson, rng, color, nowIso } from './lib/common.mjs';
import { validateQuestion } from './lib/engine/questions/validate.mjs';
import { expandCompact } from './lib/expand.mjs';
import { rwChecks } from './lib/rwcheck.mjs';
import { DedupIndex } from './lib/dedup.mjs';
import { buildBrief, buildBlindBrief, buildFixBrief, coverage, targets } from './lib/brief.mjs';

const argv = process.argv.slice(2);
const cmd = argv[0];
const flag = (name, def) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : def; };
const pos = argv.filter((a, i) => i > 0 && !a.startsWith('--') && !argv[i - 1]?.startsWith('--'));

function verifyMath(items) {
  if (!items.length) return [];
  const py = spawnSync('python3', [P('lib', 'verify_math.py')], { input: JSON.stringify(items), encoding: 'utf8', maxBuffer: 256 * 1024 * 1024 });
  if (py.status !== 0) throw new Error(`python verifier failed: ${py.stderr}`);
  return JSON.parse(py.stdout);
}

function dedupIndex() {
  const idx = new DedupIndex(Number(flag('sim', 0.55)));
  for (const q of [...loadBank(), ...loadStaging()]) idx.add(q);
  return idx;
}

const batchName = (skill) => `${skill.replace(/\./g, '-')}_${new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '')}`;

// ------------------------------------------------------------------------------------------------
const commands = {
  plan() {
    const cov = coverage(), T = targets(Number(flag('total', 5000)));
    const tax = taxonomy();
    let have = 0, want = 0; const rows = [];
    for (const s of tax.skills) {
      const per = [1, 2, 3, 4, 5].map((d) => [cov.get(`${s.id}|${d}`) ?? 0, T[s.id][d]]);
      const h = per.reduce((a, [x]) => a + x, 0), w = per.reduce((a, [, y]) => a + y, 0);
      have += Math.min(h, w); want += w;
      rows.push({ s, per, h, w, gap: w - h });
    }
    console.log(color.bold(`Bank coverage: ${have}/${want} (${Math.round((100 * have) / want)}%)`));
    console.log(color.dim('skill            d1      d2      d3      d4      d5      total'));
    for (const r of rows) console.log(`${r.s.id.padEnd(15)} ${r.per.map(([x, y]) => (x >= y ? color.green : x ? color.yellow : color.red)(`${x}/${y}`.padEnd(7))).join(' ')} ${r.h}/${r.w}`);
    const next = rows.filter((r) => r.s.section === 'rw').sort((a, b) => b.gap - a.gap)[0];
    if (next) {
      const lv = next.per.map(([x, y], i) => (x < y ? i + 1 : null)).filter(Boolean);
      console.log(`\nNext DeepSeek batch: ${color.bold(`node factory/tails.mjs brief ${next.s.id} --n 20 --levels ${lv.join(',')}`)}`);
    }
    console.log(`Math gaps are filled by code: ${color.bold('node factory/tails.mjs families --per 40')}`);
  },

  brief() {
    const skill = pos[0]; if (!skill) throw new Error('usage: brief <SKILL_ID> [--n 20] [--levels 1,2,3,4,5]');
    const n = Number(flag('n', 20)), levels = String(flag('levels', '1,2,3,4,5')).split(',').map(Number);
    const batch = batchName(skill);
    const text = buildBrief({ skill, n, levels, batch });
    const file = P('briefs', `${batch}.md`);
    fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text);
    console.log(`${color.green('brief written')} ${path.relative(process.cwd(), file)}  (${text.length} chars, ~${Math.round(text.length / 4)} tokens)`);
    console.log(`1. Open chat.deepseek.com (DeepThink ON for d=4-5), paste the whole file.`);
    console.log(`2. Copy the reply into factory/inbox/${batch}.txt  (if it stops, type "continue" and append).`);
    console.log(`3. node factory/tails.mjs ingest factory/inbox/${batch}.txt`);
  },

  ingest() {
    const file = pos[0]; if (!file) throw new Error('usage: ingest <reply.txt>');
    const batch = path.basename(file).replace(/\.(txt|json|md)$/, '');
    const tax = taxonomy();
    const raw = extractJson(fs.readFileSync(file, 'utf8'));
    const specs = readJson(P('specs', 'skills.json')).skills;
    const idx = dedupIndex();
    const alloc = makeIdAllocator([...loadBank(), ...loadStaging()]);
    const staged = [], rejected = [], warn = [];
    const expanded = [];
    for (const c of raw) {
      try { expanded.push({ c, q: expandCompact(c, tax, { batch }) }); }
      catch (e) { rejected.push({ item: c, errors: [e.message] }); }
    }
    for (const e of expanded) { e.q.id = alloc(e.q.skill_id, e.q.section); }
    const math = expanded.filter((e) => e.q.section === 'math');
    const vres = new Map(verifyMath(math.map((e) => e.q)).map((r) => [r.id, r]));
    for (const { c, q } of expanded) {
      const v = validateQuestion(q.section === 'math' ? { ...q, verification: { ...q.verification, result: 'unrun' } } : q, tax, { lessonIds: tax.lessonIds });
      const errors = [...v.errors];
      const warnings = [...v.warnings];
      if (q.section === 'rw') { const r = rwChecks(q, specs[q.skill_id]); errors.push(...r.errors); warnings.push(...r.warnings); }
      else {
        const r = vres.get(q.id);
        if (!r?.ok) errors.push(...(r?.errors ?? ['not verified']));
        else { q.verification.result = 'pass'; q.verification.notes = `computed=${r.computed}; ${r.notes.join('; ')}`; }
      }
      const dup = idx.check(q);
      if (dup) errors.push(`near-duplicate of ${dup.id} (similarity ${dup.sim})`);
      if (errors.length) { rejected.push({ item: c, errors }); continue; }
      q.originality.similarity_checked = true;
      if (warnings.length) warn.push(`${q.id}: ${warnings.join('; ')}`);
      idx.add(q);
      staged.push(q);
    }
    // math with a passing sympy check goes straight to the bank as verified; RW waits for the blind solve
    const mathOk = staged.filter((q) => q.section === 'math').map((q) => ({ ...q, status: 'verified' }));
    const rwOk = staged.filter((q) => q.section === 'rw');
    if (mathOk.length) saveToBank(mathOk);
    if (rwOk.length) writeJson(P('staging', `${batch}.json`), rwOk);
    if (rejected.length) {
      writeJson(P('rejected', `${batch}.json`), rejected);
      fs.writeFileSync(P('briefs', `${batch}_FIX.md`), buildFixBrief(rejected));
    }
    console.log(`${color.bold(batch)}: ${raw.length} parsed  ${color.green(`${staged.length} passed`)}  ${rejected.length ? color.red(`${rejected.length} rejected`) : '0 rejected'}`);
    for (const r of rejected) console.log(color.red(`  x ${r.item.title ?? r.item.stem?.slice(0, 50) ?? '?'}: ${r.errors.slice(0, 3).join(' | ')}`));
    for (const w of warn) console.log(color.yellow(`  ! ${w}`));
    if (mathOk.length) console.log(color.green(`  ${mathOk.length} math items verified by sympy -> bank`));
    if (rwOk.length) console.log(`Next: ${color.bold(`node factory/tails.mjs blind ${batch}`)}  (independent solve in a NEW chat)`);
    if (rejected.length) console.log(`Fix prompt: factory/briefs/${batch}_FIX.md  (paste into the SAME chat, save reply to inbox, ingest again)`);
  },

  blind() {
    const batch = pos[0]; if (!batch) throw new Error('usage: blind <batch>');
    const items = readJson(P('staging', `${batch}.json`));
    // shuffle choice order? No: keep order so letters match. Strip everything except what a student sees.
    const text = buildBlindBrief(items);
    const file = P('blind', `${batch}.md`); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text);
    console.log(`${color.green('blind test written')} factory/blind/${batch}.md  (${items.length} questions)`);
    console.log('Paste into a NEW DeepSeek chat (DeepThink ON). Save the reply as factory/inbox/' + batch + '_answers.txt');
    console.log(`Then: node factory/tails.mjs grade ${batch} factory/inbox/${batch}_answers.txt`);
  },

  grade() {
    const [batch, ansFile] = pos; if (!batch || !ansFile) throw new Error('usage: grade <batch> <answers.txt>');
    const items = readJson(P('staging', `${batch}.json`));
    const ans = new Map();
    for (const line of fs.readFileSync(ansFile, 'utf8').split('\n')) {
      const m = /^[\s#*>-]*([A-Z]+-[A-Z0-9-]+-\d{4})[\s*]*\|[\s*]*\(?([A-D])\)?[\s*]*\|?[\s*]*(\d)?/i.exec(line);
      if (m) ans.set(m[1].toUpperCase(), { letter: m[2].toUpperCase(), conf: Number(m[3] ?? 3) });
    }
    const pass = [], fail = [], missing = [];
    for (const q of items) {
      const a = ans.get(q.id); const key = q.choices.find((c) => c.is_correct).key;
      if (!a) { missing.push(q); continue; }
      if (a.letter === key) {
        q.status = 'verified'; q.verification.result = 'pass'; q.verification.second_solver_agrees = true;
        q.verification.notes = `structural checks pass; blind solve (deepseek, new chat) agrees with key, confidence ${a.conf}/5, ${nowIso().slice(0, 10)}`;
        // calibration hint: a confident blind solve on a "hard" item suggests it is easier than labelled
        if (q.difficulty >= 4 && a.conf === 5) q.tails.calibration_hint = 'blind solver was fully confident; may be easier than labelled';
        pass.push(q);
      } else fail.push({ item: q, errors: [`blind solver chose ${a.letter}, key is ${key}: two defensible answers or a wrong key`] });
    }
    if (pass.length) saveToBank(pass);
    if (fail.length) { const prev = readJson(P('rejected', `${batch}.json`), []); writeJson(P('rejected', `${batch}.json`), [...prev, ...fail]); }
    if (missing.length) writeJson(P('staging', `${batch}.json`), missing); else fs.rmSync(P('staging', `${batch}.json`), { force: true });
    console.log(`${color.green(`${pass.length} verified -> bank`)}  ${fail.length ? color.red(`${fail.length} disagree -> rejected`) : ''}  ${missing.length ? color.yellow(`${missing.length} unanswered (still staged)`) : ''}`);
    for (const f of fail) console.log(color.red(`  x ${f.item.id} ${f.item.tails?.title ?? ''}: ${f.errors[0]}`));
  },

  async families() {
    const per = Number(flag('per', 40)), seed = Number(flag('seed', Date.now() % 100000)), only = flag('only', null);
    const { build, Reject } = await import('./families/_kit.mjs');
    const fams = [];
    for (const f of fs.readdirSync(P('families')).filter((x) => x.endsWith('.mjs') && !x.startsWith('_'))) fams.push(...(await import(`./families/${f}`)).default);
    const tax = taxonomy();
    const idx = dedupIndex();
    const alloc = makeIdAllocator([...loadBank(), ...loadStaging()]);
    const r = rng(seed);
    const made = [];
    const stats = [];
    for (const f of fams) {
      if (only && f.id !== only) continue;
      let ok = 0, tries = 0, dup = 0;
      while (ok < per && tries < per * 12) {
        tries++;
        const d = f.levels[tries % f.levels.length];
        let q;
        try { q = build(r, f.id, f.gen(r, d)); } catch (e) { if (e instanceof Reject) continue; throw new Error(`${f.id}: ${e.stack}`); }
        if (idx.check(q)) { dup++; continue; }
        q.id = alloc(q.skill_id, 'math');
        idx.add(q); made.push(q); ok++;
      }
      stats.push([f.id, ok, dup]);
    }
    const res = new Map(verifyMath(made).map((x) => [x.id, x]));
    const good = [], bad = [];
    for (const q of made) {
      const v = res.get(q.id);
      const ev = validateQuestion({ ...q, verification: { ...q.verification } }, tax, { lessonIds: tax.lessonIds });
      if (v?.ok && !ev.errors.length) {
        q.status = 'verified'; q.verification.result = 'pass'; q.verification.second_solver_agrees = true;
        q.verification.notes = `family generator; sympy re-derived the answer from the parameters: computed=${v.computed}; ${v.notes.join('; ')}`;
        good.push(q);
      } else bad.push({ id: q.id, family: q.tails.family, errors: [...(v?.errors ?? []), ...ev.errors] });
    }
    saveToBank(good);
    for (const [id, ok, dup] of stats) console.log(`  ${id.padEnd(22)} ${String(ok).padStart(4)} made  ${dup} dup-skipped`);
    console.log(color.green(`${good.length} verified math items -> bank`) + (bad.length ? color.red(`  ${bad.length} failed verification (family bug)`) : ''));
    for (const b of bad.slice(0, 10)) console.log(color.red(`  x ${b.family} ${b.id}: ${b.errors.slice(0, 2).join(' | ')}`));
    if (bad.length) { writeJson(P('rejected', `families_${seed}.json`), bad); process.exitCode = 1; }
  },

  async rwfamilies() {
    const per = Number(flag('per', 40)), seed = Number(flag('seed', Date.now() % 100000));
    const { generateRW } = await import('./lib/rwgen.mjs');
    const tax = taxonomy(), idx = dedupIndex(), alloc = makeIdAllocator([...loadBank(), ...loadStaging()]), r = rng(seed);
    const made = generateRW(r, per, tax), good = [], bad = [], by = {};
    for (const q of made) {
      const ev = validateQuestion({ ...q, id: 'RW-TMP-0001'.replace('TMP', q.skill_id.replace('RW.', '').replace(/\./g, '-')) }, tax, { lessonIds: tax.lessonIds });
      const rc = rwChecks(q); const errs = [...ev.errors.filter((e) => !/bad id format|does not match skill/.test(e)), ...rc.errors];
      if (errs.length) { bad.push({ f: q.tails.family, errs }); continue; }
      if (idx.check(q)) { by[q.tails.family + ':dup'] = (by[q.tails.family + ':dup'] ?? 0) + 1; continue; }
      q.id = alloc(q.skill_id, 'rw'); idx.add(q);
      q.status = 'verified'; q.verification = { method: 'construction-rule', code: null, result: 'pass', second_solver_agrees: true, teacher_review: 'pending', notes: 'rule-based family: the right choice obeys the stated rule, each wrong choice breaks it in a named way; structural + dedup checks passed. Teacher spot-check recommended.' };
      good.push(q); by[q.tails.family] = (by[q.tails.family] ?? 0) + 1;
    }
    saveToBank(good);
    console.log(by); console.log(color.green(`${good.length} RW items -> bank`) + (bad.length ? color.red(`  ${bad.length} rejected`) : ''));
    const g = {}; for (const b of bad) { const k = b.f + ': ' + b.errs[0]; g[k] = (g[k] ?? 0) + 1; } console.log(g);
  },

  export() {
    const out = flag('out', P('out', 'questions.json'));
    const tax = taxonomy();
    const bank = loadBank().filter((q) => q.status === 'verified' || q.status === 'approved');
    const clean = bank.map(({ tails, ...q }) => ({ ...q, ...(tails ? { tails } : {}) }));
    let errs = 0;
    for (const q of clean) { const v = validateQuestion(q, tax, { lessonIds: tax.lessonIds }); if (v.errors.length) { errs++; console.log(color.red(`  ${q.id}: ${v.errors[0]}`)); } }
    writeJson(out, clean, false);
    console.log(`${clean.length} questions -> ${out}${errs ? color.red(`  (${errs} invalid!)`) : ''}`);
    const into = flag('into', null);
    if (into) {
      const data = readJson(into);
      const have = new Set(data.questions.map((q) => q.id));
      const add = clean.filter((q) => !have.has(q.id));
      data.questions.push(...add);
      writeJson(into, data, false);
      console.log(`merged ${add.length} new questions into ${into} (now ${data.questions.length})`);
    }
  },

  sync() {
    const file = pos[0]; if (!file) throw new Error('usage: sync <assets/engine/data.json>');
    const d = readJson(file);
    writeJson(P('taxonomy.json'), {
      _note: 'Snapshot of TAILS taxonomy from assets/engine/data.json. Regenerate with: node factory/tails.mjs sync <path/to/data.json>',
      skills: d.skills, microskills: d.microskills, traps: d.traps, lesson_ids: d.lessons.lessons.map((l) => l.id),
      lessons: d.lessons.lessons.map((l) => ({ id: l.id, title: l.title, skill_id: l.skill_id, kind: l.kind, trap_code: l.trap_code, target_minutes: l.target_minutes, wave: l.wave })),
    });
    console.log('taxonomy refreshed');
  },

  stats() {
    const bank = loadBank();
    const by = (f) => bank.reduce((m, q) => m.set(f(q), (m.get(f(q)) ?? 0) + 1), new Map());
    console.log(`bank: ${bank.length} items`);
    console.log('by section:', Object.fromEntries(by((q) => q.section)));
    console.log('by difficulty:', Object.fromEntries([...by((q) => q.difficulty)].sort()));
    console.log('by source:', Object.fromEntries(by((q) => (q.originality?.generated_by ?? '?').split(':')[0])));
    console.log('answer position:', Object.fromEntries([...by((q) => q.choices?.find((c) => c.is_correct)?.key ?? 'spr')].sort()));
  },
};

const fn = commands[cmd];
if (!fn) { console.log(fs.readFileSync(new URL(import.meta.url)).toString().split('\n').slice(1, 13).map((l) => l.replace(/^\/\/ ?/, '')).join('\n')); process.exit(cmd ? 1 : 0); }
Promise.resolve().then(() => fn()).catch((e) => { console.error(color.red(e.message)); process.exit(1); });
