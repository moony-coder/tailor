// The SIMULATED STUDENT ("world"). Ground truth the engine can never see directly.
// Everything here is an ASSUMPTION about how students behave; the point is not that these numbers are right,
// it is that the engine is judged against a fixed, explicit, repeatable reality, and that we can vary that reality
// (faster/slower learners, harsher scoring curve) to see how robust the engine is. All tunables are in WORLD.
import { rng } from '../src/util/misc.mjs';
import { sha256 } from '../src/util/hash.mjs';
import { sectionScore } from '../src/engine/score.mjs';

export const WORLD = {
  slope: 1.1,                       // item response steepness (logit per logit)
  floor: { mcq: 0.25, spr: 0.02 },  // guessing floors
  b_per_level: 0.9,                 // true difficulty b = (label - 3) * 0.9 + per-item offset
  item_noise_sd: 0.3,               // the bank's 1..5 labels are only roughly right
  std_mix: { 1: 0.15, 2: 0.15, 3: 0.4, 4: 0.15, 5: 0.15 },   // blueprint "std": 30% easy, 40% medium, 30% hard
  // learning
  learn_per_q: 0.03,                // logit gain per practised question in the zone of proximal development (x persona.learn)
  lesson_gain: 0.30,                // logit gain from the first concept/examples/traps lesson on a skill
  fixit_gain: 0.12,
  ceiling: 1.8,                     // gains saturate around here (logit)
  // forgetting: learned gain halves every `stability` days; spaced practice lengthens it
  stability0: 40, stability_mult: 1.25, stability_cap: 300, spacing_min_days: 3, touch_min_q: 6,
  // other steps
  vocab_gain: 0.012, timed_stamina_gain: 0.04, timed_speed_gain: 0.004, checking_slip_decay: 0.985,
  // test-day / mock
  scale: { slope: 0.95, shift: -15 },   // TRUE score curve = engine anchors * slope + shift. {1,0} = the engine's curve is exactly right.
  mock_time_sd: 0.25,
};

const sig = (x) => 1 / (1 + Math.exp(-x));
const itemOffset = (id) => { const h = parseInt(sha256(String(id)).slice(0, 8), 16) / 0xffffffff; const g = parseInt(sha256('g' + id).slice(0, 8), 16) / 0xffffffff; return Math.sqrt(-2 * Math.log(Math.max(1e-9, h))) * Math.cos(2 * Math.PI * g) * WORLD.item_noise_sd; };
export const trueB = (q) => (q.difficulty - 3) * WORLD.b_per_level + itemOffset(q.id);

/**
 * persona: { learn, speed, careless, stamina_drop, stability0, skill_profile:{skillId: offset}, plateau_after, plateau_decay, curve? }
 * Starting ability is solved so the TRUE score at day 0 equals persona.start_score.
 */
export function createWorld({ persona, tax, seed = 1 }) {
  const W = { ...WORLD, scale: persona.curve ?? WORLD.scale }, rand = rng(seed * 7919 + 13);
  const theta = new Map(), theta0 = new Map(), stab = new Map(), touched = new Map(), todayQ = new Map();
  const skills = tax.skills;
  const prof = persona.skill_profile ?? {};
  const jitter = new Map(skills.map((s) => [s.id, (rand() - 0.5) * 2 * (persona.skill_jitter ?? 0.45)]));
  const floorOf = (sec) => (sec === 'rw' ? W.floor.mcq : W.floor.mcq * 0.75 + W.floor.spr * 0.25);
  const accSkill = (th, sec) => { let a = 0; for (const [d, w] of Object.entries(W.std_mix)) a += w * (floorOf(sec) + (1 - floorOf(sec)) * sig(W.slope * (th - (Number(d) - 3) * W.b_per_level))); return a; };
  const curve = (acc) => 200 + (sectionScore(acc) - 200) * W.scale.slope + W.scale.shift;
  const st = { stamina: persona.stamina_drop ?? 0.25, speed: persona.speed ?? 1, slip: persona.careless ?? 0.03 };
  // TRUE expected performance on a standard-mix test: ability, minus careless slips, minus late-module fatigue, minus running out of time.
  const MEAN_T = { rw: 60, math: Object.entries(W.std_mix).reduce((a, [d, w]) => a + w * [0, 35, 45, 70, 90, 105][d], 0) }, N_Q = { rw: 27, math: 22 }, LIMIT = { rw: 1920, math: 2100 };
  const perfSkill = (th, sec) => { let a = 0, fl = floorOf(sec); for (const [d, w] of Object.entries(W.std_mix)) for (const f of [0.1, 0.3, 0.5, 0.7, 0.9]) a += w * 0.2 * (fl + (1 - fl) * sig(W.slope * (th - st.stamina * Math.max(0, (f - 0.6) / 0.4) - (Number(d) - 3) * W.b_per_level))) * (1 - st.slip * (Number(d) <= 2 ? 1 : 0.5)); return a; };
  const unanswered = (sec) => Math.max(0, 1 - LIMIT[sec] / (N_Q[sec] * MEAN_T[sec] * st.speed * 1.03));
  const secAcc = (th) => { const out = {}; for (const sec of ['rw', 'math']) { let w = 0, s = 0; for (const sk of skills) if (tax.sectionOf(sk.id) === sec) { w += sk.weight_on_test; s += sk.weight_on_test * perfSkill(th.get(sk.id), sec); } const u = unanswered(sec); out[sec] = (s / w) * (1 - u) + 0.25 * u; } return out; };
  const trueScore = (th = theta) => { const a = secAcc(th), rw = curve(a.rw), m = curve(a.math); return { rw: Math.round(rw), math: Math.round(m), total: Math.round(rw + m), acc: a }; };
  // solve base ability so the start score matches
  let lo = -4, hi = 4;
  for (let i = 0; i < 40; i++) { const mid = (lo + hi) / 2, th = new Map(skills.map((s) => [s.id, mid + (prof[s.id] ?? 0) + jitter.get(s.id)])); (trueScore(th).total < persona.start_score ? (lo = mid) : (hi = mid)); }
  const base = (lo + hi) / 2;
  for (const s of skills) { const v = base + (prof[s.id] ?? 0) + jitter.get(s.id); theta.set(s.id, v); theta0.set(s.id, v); stab.set(s.id, persona.stability0 ?? W.stability0); }
  const lessonSeen = new Set();

  const eff = (skill, ctx = {}) => theta.get(skill) - (ctx.fatigue ?? 0);
  function pCorrect(q, ctx = {}) {
    const fl = q.format === 'spr' ? W.floor.spr : W.floor.mcq;
    let p = fl + (1 - fl) * sig(W.slope * (eff(q.skill_id, ctx) - (q.b ?? trueB(q))));
    p *= 1 - st.slip * (q.difficulty <= 2 ? 1 : 0.5);                 // careless slips hit easy items hardest
    return p;
  }
  function answer(q, ctx = {}) {
    const p = pCorrect(q, ctx), correct = rand() < p;
    let choice = null, trap = null;
    if (q.choices?.length) {
      const key = q.choices.find((c) => c.is_correct)?.key;
      if (correct) choice = key; else { const wrong = q.choices.filter((c) => !c.is_correct); const c = wrong[Math.floor(rand() * wrong.length)]; choice = c.key; trap = c.trap_code ?? null; }
    }
    const est = q.est_time_sec ?? 75, ms = Math.round(est * st.speed * Math.exp((rand() - 0.5) * 2 * W.mock_time_sd * 1.7) * 1000);
    return { correct, p, choice, trap_code: trap, total_ms: ms };
  }
  const zone = (th, b) => Math.max(0, 1 - Math.abs(b - (th + 0.2)) / 1.8);
  const sat = (th) => 1 / (1 + Math.exp(1.4 * (th - W.ceiling)));
  function plateauFactor(day) { return persona.plateau_after != null && day > persona.plateau_after ? Math.max(0.04, Math.exp(-(day - persona.plateau_after) / (persona.plateau_decay ?? 8))) : 1; }
  /** a question was practised with feedback: small gain if it sat in the learning zone */
  function learnFrom(q, correct, day) {
    const th = theta.get(q.skill_id), g = W.learn_per_q * (persona.learn ?? 1) * plateauFactor(day) * zone(th, q.b ?? trueB(q)) * (correct ? 1 : 1.2) * sat(th);
    theta.set(q.skill_id, th + g); todayQ.set(q.skill_id, (todayQ.get(q.skill_id) ?? 0) + 1);
  }
  function lesson(skill, kind, day, id) {
    if (lessonSeen.has(id)) return; lessonSeen.add(id);
    theta.set(skill, theta.get(skill) + (kind === 'fixit' ? W.fixit_gain : W.lesson_gain) * (persona.learn ?? 1) * plateauFactor(day) * sat(theta.get(skill)));
    todayQ.set(skill, (todayQ.get(skill) ?? 0) + W.touch_min_q);
  }
  function generic(kind, day) {
    if (kind === 'vocab') for (const s of skills) if (s.id === 'RW.CS.WIC') theta.set(s.id, theta.get(s.id) + W.vocab_gain * (persona.learn ?? 1) * plateauFactor(day) * sat(theta.get(s.id)));
    if (kind === 'timed') { st.stamina = Math.max(0, st.stamina - W.timed_stamina_gain); st.speed = Math.max(0.8 * (persona.speed ?? 1), st.speed - W.timed_speed_gain); }
    if (kind === 'mistakes') st.slip *= W.checking_slip_decay;
  }
  /** end of day: apply spacing bonus to stability, then forget what was not touched */
  function endDay(day) {
    for (const s of skills) {
      const q = todayQ.get(s.id) ?? 0, gain = theta.get(s.id) - theta0.get(s.id), last = touched.get(s.id) ?? -99;
      if (q >= W.touch_min_q) { if (day - last >= W.spacing_min_days) stab.set(s.id, Math.min(W.stability_cap, stab.get(s.id) * W.stability_mult)); touched.set(s.id, day); }
      else if (gain > 0) theta.set(s.id, theta0.get(s.id) + gain * Math.pow(0.5, 1 / stab.get(s.id)));
    }
    todayQ.clear();
  }
  const mockMapping = (acc) => Math.round(curve(acc));
  return { theta, theta0, st, pCorrect, answer, learnFrom, lesson, generic, endDay, trueScore, mockMapping, accSkill, rand, floorOf, curveFn: curve,
    trueP: (skill) => accSkill(theta.get(skill), tax.sectionOf(skill)), W };
}
