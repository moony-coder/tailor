// Module / drill / mock assembly from the bank. Refuses to build what it cannot fill and says exactly what is missing.
import { groupBy, makeId, iso } from '../util/misc.mjs';
import { weightedScore, isCorrect } from './score.mjs';

export class AssemblyError extends Error {
  constructor(message, missing) { super(message); this.name = 'AssemblyError'; this.missing = missing; }
}
const BANDS = ['easy', 'medium', 'hard'];
const BAND_RANK = { easy: 0, medium: 1, hard: 2 };

/** Largest-remainder rounding of fractions to integer counts summing to n. */
export function apportion(fractions, n) {
  const raw = BANDS.map((b) => ({ b, x: (fractions[b] ?? 0) * n }));
  const out = Object.fromEntries(raw.map((r) => [r.b, Math.floor(r.x)]));
  let left = n - Object.values(out).reduce((s, x) => s + x, 0);
  for (const r of raw.slice().sort((a, b) => (b.x - Math.floor(b.x)) - (a.x - Math.floor(a.x)))) { if (left <= 0) break; out[r.b]++; left--; }
  return out;
}

const usable = (q, excludeIds) => (q.status === 'verified' || q.status === 'approved') && !excludeIds.has(q.id);

/**
 * Build one module. Returns { questions, warnings }. Throws AssemblyError listing every missing domain.
 * opts: { exclude:Set<id>, weakness:Map<skill_id, 0..1> (prefer weak skills), rand }
 */
export function buildModule(ctx, blueprintId, level = 'std', opts = {}) {
  const bp = ctx.config.blueprints.modules[blueprintId];
  if (!bp) throw new AssemblyError(`unknown blueprint ${blueprintId}`, []);
  const mix = ctx.config.blueprints.difficulty_mix[level];
  const exclude = opts.exclude ?? new Set();
  const rand = opts.rand ?? ctx.rand;
  const pool = ctx.bank.filter((q) => q.section === bp.section && usable(q, exclude));
  const byDomain = groupBy(pool, (q) => q.domain);
  const missing = [];
  for (const [d, n] of Object.entries(bp.domains)) {
    const have = (byDomain.get(d) ?? []).length;
    if (have < n) missing.push({ domain: d, need: n, have, short: n - have });
  }
  if (missing.length) throw new AssemblyError(`cannot fill ${blueprintId}: ${missing.map((m) => `${m.domain} needs ${m.need}, bank has ${m.have}`).join('; ')}`, missing);

  const target = apportion(mix, bp.size);
  const chosen = [], used = new Set(), skillCount = new Map(), warnings = [];
  const sprTarget = bp.spr_share ? Math.round(bp.size * bp.spr_share) : 0;
  let sprCount = 0;
  // fill domain by domain; inside a domain walk through slots, picking the band with the most remaining target
  for (const [d, n] of Object.entries(bp.domains)) {
    for (let i = 0; i < n; i++) {
      const cands = (byDomain.get(d) ?? []).filter((q) => !used.has(q.id));
      const bandOrder = BANDS.slice().sort((a, b) => (target[b] - target[a]) || (rand() - 0.5));
      let pick = null;
      for (const band of bandOrder) {
        if (target[band] <= 0) continue;
        const inBand = cands.filter((q) => q.difficulty_band === band);
        if (inBand.length) { pick = pickBest(inBand, skillCount, opts.weakness, rand, sprCount < sprTarget, opts.seen); break; }
      }
      if (!pick) { // nearest band with anything left
        const want = bandOrder.find((b) => target[b] > 0) ?? 'medium';
        const sorted = cands.slice().sort((a, b) => Math.abs(BAND_RANK[a.difficulty_band] - BAND_RANK[want]) - Math.abs(BAND_RANK[b.difficulty_band] - BAND_RANK[want]));
        pick = sorted[0];
        warnings.push(`difficulty: wanted ${want} in ${d}, used ${pick.difficulty_band} (${pick.id})`);
      }
      used.add(pick.id); chosen.push(pick); skillCount.set(pick.skill_id, (skillCount.get(pick.skill_id) ?? 0) + 1);
      if (pick.format === 'spr') sprCount++;
      if (target[pick.difficulty_band] > 0) target[pick.difficulty_band]--;
    }
  }
  if (sprTarget && sprCount < sprTarget) warnings.push(`spr: wanted ${sprTarget} student-produced-response, bank gave ${sprCount}`);
  // order inside the module: easier first within each domain block is how Bluebook feels; keep domain blocks, sort by difficulty inside
  const order = Object.keys(bp.domains);
  chosen.sort((a, b) => (order.indexOf(a.domain) - order.indexOf(b.domain)) || (a.difficulty - b.difficulty));
  return { questions: chosen, warnings, blueprint: bp };
}

function pickBest(cands, skillCount, weakness, rand, wantSpr, seen) {
  let best = null, bestScore = -Infinity;
  for (const q of cands) {
    const s = -(skillCount.get(q.skill_id) ?? 0) * 2 + (weakness?.get(q.skill_id) ?? 0) * 1.5 + (wantSpr && q.format === 'spr' ? 1 : 0) - (seen?.has(q.id) ? 1.2 : 0) + rand() * 0.5;
    if (s > bestScore) { bestScore = s; best = q; }
  }
  return best;
}

/** Skill drill: easy->medium when p is low, medium->hard when high. Throws if fewer than min_size questions exist. */
export function buildDrill(ctx, { skill_id, domain = null, size, p_mastery = 0.5, exclude = new Set(), kind = 'skill-drill', seen = null }) {
  const conf = ctx.config.blueprints.tests[kind] ?? ctx.config.blueprints.tests['skill-drill'];
  const want = size ?? conf.default_size;
  // domain scope: the skill's own questions first, topped up from the rest of the domain (used when the bank is thin)
  let pool = skill_id ? ctx.bank.filter((q) => q.skill_id === skill_id && usable(q, exclude)) : [];
  if (domain) pool = [...pool, ...ctx.bank.filter((q) => q.domain === domain && (!skill_id || q.skill_id !== skill_id) && usable(q, exclude))];
  if (pool.length < (conf.min_size ?? 3)) {
    throw new AssemblyError(`not enough questions for ${skill_id ?? domain}: have ${pool.length}, need at least ${conf.min_size ?? 3}`, [{ skill_id: skill_id ?? domain, have: pool.length, need: conf.min_size ?? 3 }]);
  }
  const lowMastery = p_mastery < 0.55;
  const ideal = lowMastery ? { easy: 0.45, medium: 0.45, hard: 0.1 } : { easy: 0.1, medium: 0.45, hard: 0.45 };
  const n = Math.min(want, pool.length);
  const target = apportion(ideal, n);
  const picked = [];
  const left = pool.slice().sort((a, b) => ((seen?.has(a.id) ? 1 : 0) - (seen?.has(b.id) ? 1 : 0)) || (ctx.rand() - 0.5));
  for (const band of BANDS) {
    for (let i = 0; i < target[band]; i++) { const k = left.findIndex((q) => q.difficulty_band === band); if (k >= 0) picked.push(left.splice(k, 1)[0]); }
  }
  while (picked.length < n && left.length) picked.push(left.shift());
  picked.sort((a, b) => a.difficulty - b.difficulty);
  return { questions: picked, warnings: n < want ? [`only ${n} of ${want} questions available for ${skill_id ?? domain}`] : [], short: n < want };
}

/** Routing for adaptive tests (our own approximation; real algorithm is not public). */
export function routeFromModule(ctx, questions, answers) {
  const cfg = ctx.config.thresholds.routing; // NB: ctx.config.routing is the LLM model routing, not this
  const items = questions.map((q) => ({ band: q.difficulty_band, correct: isCorrect(q, answers[q.id]) }));
  const score = weightedScore(items, cfg.weights);
  return { score, route: score >= cfg.hard_route_threshold ? 'hard' : 'easy' };
}

/** Pick the question to serve for a second chance: unseen sibling first (same micro-skill, then same skill), else the same question. */
export function pickSecondChance(ctx, original, seenIds = new Set()) {
  const sibs = ctx.bank.filter((q) => q.id !== original.id && q.skill_id === original.skill_id && usable(q, new Set()) && !seenIds.has(q.id));
  const rank = (q) => (q.micro_skills.some((m) => original.micro_skills.includes(m)) ? 0 : 1) * 10 + Math.abs(q.difficulty - original.difficulty);
  sibs.sort((a, b) => rank(a) - rank(b));
  return sibs.length ? { question: sibs[0], kind: 'sibling' } : { question: original, kind: 'same' };
}

/** Persist a test + its modules + module_questions. modules = [{section, level, blueprint, questions, time_limit_sec, ordinal}] */
export async function persistTest(ctx, { name, kind, blueprint_id = null, modules }) {
  const { db } = ctx;
  const test = { id: makeId('t_', ctx.now()), name, kind, blueprint_id, created_at: iso(ctx.now()) };
  await db.insert('tests', test);
  const out = [];
  for (const m of modules) out.push(await persistModule(ctx, test.id, m));
  return { test, modules: out };
}
export async function persistModule(ctx, testId, m) {
  const { db } = ctx;
  const row = { id: makeId('m_', ctx.now()), test_id: testId, section: m.section, module_index: m.module_index ?? m.ordinal ?? 1, ordinal: m.ordinal ?? 1, difficulty_level: m.level ?? 'std', time_limit_sec: m.time_limit_sec ?? null };
  await db.insert('test_modules', row);
  let pos = 1;
  for (const q of m.questions) await db.insert('module_questions', { module_id: row.id, position: pos++, question_id: q.id });
  return { ...row, questions: m.questions };
}
export const timeLimitFor = (ctx, bp, questions) => bp.time_limit_sec ?? Math.round(questions.reduce((s, q) => s + q.est_time_sec, 0) * 1.3);
