// Node loader. Reads the single data bundle (data.json) and returns the shape createContext() expects.
// data.json is the one source of truth for the engine; the factory writes into it with `node factory/tails.mjs export --into data.json`.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fromBundle } from './bundle.mjs';

export const DEFAULT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

/** Raw bundle, exactly as stored on disk. */
export function readBundle(root = DEFAULT_ROOT) {
  const file = root.endsWith('.json') ? root : path.join(root, 'data.json');
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

export { fromBundle };

export async function loadAll(root = DEFAULT_ROOT) { return fromBundle(readBundle(root)); }
