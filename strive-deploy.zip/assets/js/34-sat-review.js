/* ============================================================
   TAILORED PRACTICE: Mistake review (interview) and second chances.
   #sat/review/<sessionId>   one question at a time: why did you miss it? -> solution -> did you get it? -> one-line takeaway
   #sat/review/second-chance a fresh question on the same skill, answered without the solution
   ============================================================ */
(function(){
  'use strict';
  const A = window.SATAPI, SAT = window.SAT; if(!A || !SAT) return;
  const P = SAT.pages;
  const WHY = { wrong: 'You answered this one wrong', unanswered: 'You left this blank', flagged_not_sure: 'You flagged it as unsure', changed_answer: 'You changed your answer', suspiciously_fast: 'You answered very quickly' };
  const mathNote = '<span class="sr">Math is shown with symbols.</span>';

  function qBlock(q, o){
    o = o || {};
    let h = '';
    if(q.passage) h += '<div class="sat-pass">' + SAT.passage(q.passage) + '</div>';
    if(q.visual) h += SAT.visual(q.visual);
    h += '<div class="sat-stem">' + SAT.fmt(q.stem) + '</div>';
    if(q.choices){
      h += '<div class="sat-ch">' + q.choices.map(c => {
        const cls = [o.reveal && c.key === q.correct ? 'ok' : '', o.reveal && c.key === q.chosen && c.key !== q.correct ? 'no' : '', !o.reveal && c.key === q.chosen ? 'mine' : ''].join(' ');
        const tag = o.reveal ? (c.key === q.correct ? '<em>Correct answer</em>' : c.key === q.chosen ? '<em>Your answer</em>' : '') : (c.key === q.chosen ? '<em>Your answer</em>' : '');
        return '<div class="sat-choice ' + cls + '"><b>' + esc(c.key) + '</b><span>' + SAT.fmt(c.text) + '</span>' + tag + '</div>';
      }).join('') + '</div>';
    } else if(o.reveal || q.chosen != null){
      h += '<div class="sat-spr">' + (q.chosen != null ? 'Your answer: <b>' + SAT.fmt(String(q.chosen)) + '</b>' : 'Your answer: <b>blank</b>') + (o.reveal ? ' · Correct: <b>' + SAT.fmt(String(q.correct)) + '</b>' : '') + '</div>';
    }
    return h + mathNote;
  }
  function solution(q){
    let h = '<div class="sat-sol"><h4><i class="ph ph-lightbulb"></i>How to solve it</h4><div>' + SAT.fmt(q.solution || '').replace(/\n/g, '<br>') + '</div>';
    if(q.chosen_why_wrong) h += '<p class="sat-trap"><i class="ph ph-warning"></i><span><b>Why your choice was tempting, and wrong:</b> ' + SAT.fmt(q.chosen_why_wrong) + '</span></p>';
    if(q.choices_explained) h += '<details class="sat-more"><summary>Every answer choice explained</summary>' + q.choices_explained.map(c => '<p><b>' + esc(c.key) + (c.is_correct ? ' (correct)' : '') + '.</b> ' + SAT.fmt(c.note || '') + '</p>').join('') + '</details>';
    return h + '</div>';
  }

  /* ============================================================ REVIEW */
  P.review = async function(body, r, alive){
    if(r.id === 'second-chance') return secondChance(body, alive);
    if(!A.session()){ body.innerHTML = '<div class="card sat-gate"><i class="ph ph-chat-circle-text"></i><div><h3>Nothing to review yet</h3><p class="muted">Finish a mini-mock first. Then you can tell us why you missed each question.</p><button class="btn acc" id="satRvGo">Take a mini-mock<i class="ph ph-arrow-right"></i></button></div></div>'; $('#satRvGo').onclick = () => SAT.open('start'); return; }
    let sid = r.id;
    if(!sid){
      const ss = (await A.get('/api/sessions')).sessions.filter(s => s.status === 'finished' && /mock|drill|retest/.test(s.kind));
      if(!alive()) return;
      if(!ss.length){ body.innerHTML = '<div class="card muted">No finished tests yet. After your first one, the questions you missed show up here.</div>'; return; }
      body.innerHTML = '<p class="muted mb-12">Pick a test to review.</p><div class="sat-list">' + ss.slice(0, 12).map(s => '<div class="card sat-row"><div class="grow"><b>' + esc(SAT.KIND[s.kind] || s.kind) + '</b><div class="muted fs-13">' + esc(SAT.when(s.started_at)) + '</div></div><button class="btn sm acc" data-open="review" data-id="' + esc(s.id) + '">Review</button></div>').join('') + '</div>';
      body.querySelectorAll('[data-open]').forEach(b => b.onclick = () => SAT.open('review', b.dataset.id));
      return;
    }
    const d = await A.get('/api/sessions/' + encodeURIComponent(sid) + '/review-queue');
    if(!alive()) return;
    if(!d.queue.length){
      body.innerHTML = '<div class="card sat-gate"><i class="ph ph-check-circle"></i><div><h3>Nothing to review here</h3><p class="muted">' + esc(d.note || 'No mistakes or shaky answers in this test.') + '</p><button class="btn acc" id="satRvAu">See the audit<i class="ph ph-arrow-right"></i></button></div></div>';
      $('#satRvAu').onclick = () => SAT.open('audit', sid); return;
    }
    const Q = d.queue; let i = Q.findIndex(x => !x.done); if(i < 0) i = 0;
    const answered = () => Q.filter(x => x.done).length;

    function head(it){
      return '<div class="sat-rvhead"><div class="sat-dots" role="progressbar" aria-valuemin="0" aria-valuemax="' + Q.length + '" aria-valuenow="' + answered() + '">' + Q.map((x, k) => '<button type="button" data-k="' + k + '" class="' + (x.done ? 'done ' : '') + (k === i ? 'on' : '') + '" aria-label="Question ' + (k + 1) + (x.done ? ' reviewed' : '') + '"></button>').join('') + '</div>' +
        '<span class="muted fs-13">' + answered() + ' of ' + Q.length + ' reviewed' + (d.auto && d.auto.length ? ' · ' + d.auto.length + ' more mistakes are counted automatically' : '') + '</span></div>';
    }
    function draw(){
      const it = Q[i], q = it.question; let step = it.done ? 2 : 1, reason = it.review && it.review.self_reason || null, und = it.review && it.review.understood_after_solution || null;
      const wrapId = 'satRvCard';
      const paint = () => {
        let h = head(it) + '<div class="card sat-rv" id="' + wrapId + '"><div class="row jc-between wrap"><span class="tag"><i class="ph ph-hash"></i>Question ' + (it.position || i + 1) + ' · ' + esc(it.skill.name) + '</span><span class="tag ' + (it.is_correct ? 'warn' : 'bad') + '">' + esc(WHY[it.why] || it.why) + '</span></div>';
        h += '<div class="sat-q mt-12">' + qBlock(q, { reveal: step >= 2 }) + '</div>';
        if(step === 1){
          h += '<h3 class="mt-16">' + (it.is_correct ? 'What made you unsure?' : 'Why do you think you missed it?') + '</h3><p class="muted fs-13">Pick the closest one. There is no wrong answer; this makes your audit more accurate.</p><div class="sat-chips" role="group" aria-label="Reason">' +
            it.chips.map(c => '<button type="button" class="chip' + (reason === c.code ? ' on' : '') + '" data-c="' + esc(c.code) + '" aria-pressed="' + (reason === c.code) + '">' + esc(c.label) + '</button>').join('') +
            '<button type="button" class="chip dis' + (reason === 'DISAGREE' ? ' on' : '') + '" data-c="DISAGREE" aria-pressed="' + (reason === 'DISAGREE') + '"><i class="ph ph-flag"></i>I think the answer key is wrong</button></div>' +
            '<div class="row mt-16"><button class="btn acc" id="satRvNext"' + (reason ? '' : ' disabled') + '>' + (reason === 'DISAGREE' ? 'Flag this question' : 'Show the solution') + '<i class="ph ph-arrow-right"></i></button><button class="btn ghost" id="satRvSkip">Skip this one</button></div>';
        } else {
          h += solution(q);
          h += '<h3 class="mt-16">Does it make sense now?</h3><div class="sat-chips" role="group" aria-label="Understood">' + [['yes', 'Yes, I get it'], ['partly', 'Partly'], ['no', 'No, still lost']].map(o => '<button type="button" class="chip' + (und === o[0] ? ' on' : '') + '" data-u="' + o[0] + '" aria-pressed="' + (und === o[0]) + '">' + o[1] + '</button>').join('') + '</div>' +
            '<div class="field mt-12"><label for="satTk">One line to remember <span class="muted">(optional, only you see it)</span></label><input class="inp" id="satTk" maxlength="280" placeholder="e.g. Read the question again before choosing" value="' + esc(it.review && it.review.takeaway_text || '') + '"></div>' +
            '<div class="row mt-16 wrap"><button class="btn acc" id="satRvSave"' + (und ? '' : ' disabled') + '>' + (i < Q.length - 1 ? 'Save and next' : 'Save and finish') + '<i class="ph ph-arrow-right"></i></button><button class="btn ghost sm" id="satRvRep"><i class="ph ph-flag"></i>Report a problem with this question</button></div>';
        }
        h += '</div>';
        body.innerHTML = h;
        body.querySelectorAll('.sat-dots button').forEach(b => b.onclick = () => { i = +b.dataset.k; draw(); });
        body.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { reason = b.dataset.c; paint(); });
        body.querySelectorAll('[data-u]').forEach(b => b.onclick = () => { und = b.dataset.u; paint(); const t = $('#satTk'); });
        if($('#satRvSkip')) $('#satRvSkip').onclick = () => advance();
        if($('#satRvNext')) $('#satRvNext').onclick = async () => {
          if(reason === 'DISAGREE') return save(true);
          step = 2; paint(); const c = $('#' + wrapId); if(c && c.scrollIntoView) c.scrollIntoView({ block: 'start', behavior: 'smooth' });
        };
        if($('#satRvSave')) $('#satRvSave').onclick = () => save(false);
        if($('#satRvRep')) $('#satRvRep').onclick = () => report(it);
      };
      const save = async dis => {
        const btn = $('#satRvNext') || $('#satRvSave'); SAT.busy(btn, true, 'Saving');
        const tk = $('#satTk') ? $('#satTk').value.trim() : '';
        try{
          const res = await A.post('/api/reviews/' + encodeURIComponent(it.attempt_id), { self_reason: reason, understood_after_solution: dis ? null : und, takeaway_text: tk || null });
          it.done = true; it.review = { self_reason: reason, understood_after_solution: und, takeaway_text: tk };
          if(dis) toast('Flagged. Thank you.', 'ph-flag');
          else if(res.second_chance) toast('Saved. A fresh try at this skill is waiting in Practice.', 'ph-arrows-clockwise');
          else toast('Saved.', 'ph-check-circle');
          advance();
        }catch(e){ toast(SAT.errText(e), 'ph-warning-circle'); SAT.busy(btn, false); }
      };
      paint();
    }
    function advance(){
      const nx = Q.findIndex((x, k) => k > i && !x.done);
      if(nx >= 0){ i = nx; draw(); return; }
      const any = Q.findIndex(x => !x.done);
      if(any >= 0){ i = any; draw(); return; }
      body.innerHTML = '<div class="card sat-gate"><i class="ph ph-check-circle"></i><div><h3>Review done</h3><p class="muted">Your audit and plan were updated with what you told us.</p><div class="row"><button class="btn acc" id="satRvAu">See the updated audit<i class="ph ph-arrow-right"></i></button><button class="btn line" id="satRvPl">Open my plan</button></div></div></div>';
      $('#satRvAu').onclick = () => SAT.open('audit', sid); $('#satRvPl').onclick = () => SAT.open('plan');
    }
    draw();
  };

  function report(it){
    const m = openModal('<h2>Report a problem</h2><p>Tell us what looks wrong with this question (max 280 characters).</p><div class="field"><label for="satRp">What is wrong?</label><input class="inp" id="satRp" maxlength="280" placeholder="e.g. Two answers seem correct"></div><div class="acts"><button class="btn ghost" data-x="0">Cancel</button><button class="btn acc" data-x="1">Send</button></div>');
    const inp = m.querySelector('#satRp'); setTimeout(() => inp.focus(), 50);
    m.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
      if(b.dataset.x === '0') return m.remove();
      const v = inp.value.trim(); if(!v){ inp.setAttribute('aria-invalid', 'true'); inp.focus(); return; }
      SAT.busy(b, true, 'Sending');
      try{ await A.post('/api/questions/' + encodeURIComponent(it.question.id) + '/report', { reason: v, attempt_id: it.attempt_id }); m.remove(); toast('Thanks, noted.', 'ph-flag'); }
      catch(e){ SAT.busy(b, false); toast(SAT.errText(e), 'ph-warning-circle'); }
    });
  }

  /* ============================================================ SECOND CHANCE */
  async function secondChance(body, alive){
    if(!A.session()){ body.innerHTML = '<div class="card muted">Second chances appear after you review a test.</div>'; return; }
    const d = await A.get('/api/second-chance');
    if(!alive()) return;
    const items = d.items || []; let i = 0, fixed = 0, still = 0;
    if(!items.length){ body.innerHTML = '<div class="card sat-gate"><i class="ph ph-check-circle"></i><div><h3>No second chances waiting</h3><p class="muted">After you review a mistake, a similar question is saved here so you can check it really stuck.</p><button class="btn acc" id="satScBack">Back to practice</button></div></div>'; $('#satScBack').onclick = () => SAT.open('start'); return; }
    function draw(){
      if(i >= items.length){
        body.innerHTML = '<div class="card sat-gate"><i class="ph ph-trophy"></i><div><h3>Done for now</h3><p class="muted">' + fixed + ' fixed, ' + still + ' still to work on. Anything not fixed is in your plan.</p><div class="row"><button class="btn acc" id="satScPl">Open my plan</button><button class="btn line" id="satScBack">Back to practice</button></div></div></div>';
        $('#satScPl').onclick = () => SAT.open('plan'); $('#satScBack').onclick = () => SAT.open('start'); return;
      }
      const it = items[i], q = it.question; let pick = null;
      const paint = () => {
        let h = '<div class="sat-rvhead"><span class="muted fs-13">' + (i + 1) + ' of ' + items.length + '</span></div><div class="card sat-rv"><div class="row jc-between wrap"><span class="tag"><i class="ph ph-arrows-clockwise"></i>Second chance · ' + esc(it.skill) + '</span><span class="tag">' + (it.serve_kind === 'same' ? 'Same question' : 'Similar question') + '</span></div><div class="sat-q mt-12">';
        if(q.passage) h += '<div class="sat-pass">' + SAT.passage(q.passage) + '</div>';
        if(q.visual) h += SAT.visual(q.visual);
        h += '<div class="sat-stem">' + SAT.fmt(q.stem) + '</div>';
        if(q.choices) h += '<div class="sat-ch" role="radiogroup">' + q.choices.map(c => '<button type="button" class="sat-choice pick' + (pick === c.key ? ' mine' : '') + '" role="radio" aria-checked="' + (pick === c.key) + '" data-k="' + esc(c.key) + '"><b>' + esc(c.key) + '</b><span>' + SAT.fmt(c.text) + '</span></button>').join('') + '</div>';
        else h += '<div class="field mt-12"><label for="satScIn">Your answer</label><input class="inp" id="satScIn" inputmode="decimal" autocomplete="off" value="' + esc(pick || '') + '"></div>';
        h += '</div><div class="row mt-16"><button class="btn acc" id="satScGo"' + (pick ? '' : ' disabled') + '>Check my answer</button></div></div>';
        body.innerHTML = h;
        body.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { pick = b.dataset.k; paint(); });
        const inp = $('#satScIn'); if(inp){ inp.oninput = () => { pick = inp.value.trim() || null; $('#satScGo').disabled = !pick; }; inp.focus(); }
        $('#satScGo').onclick = async () => {
          const btn = $('#satScGo'); SAT.busy(btn, true, 'Checking');
          try{ const res = await A.post('/api/second-chance/' + encodeURIComponent(it.id) + '/answer', { chosen: pick }); res.correct ? fixed++ : still++; result(res); }
          catch(e){ SAT.busy(btn, false); toast(SAT.errText(e), 'ph-warning-circle'); }
        };
      };
      const result = res => {
        const ex = res.explanation;
        body.innerHTML = '<div class="card sat-rv"><div class="sat-res ' + (res.correct ? 'ok' : 'no') + '"><i class="ph ' + (res.correct ? 'ph-check-circle' : 'ph-x-circle') + '"></i><div><b>' + (res.correct ? 'Correct' : 'Not yet') + '</b><p>' + esc(res.meaning || '') + '</p></div></div><div class="sat-q mt-12">' + qBlock(ex, { reveal: true }) + '</div>' + solution(ex) + '<div class="row mt-16"><button class="btn acc" id="satScNx">' + (i < items.length - 1 ? 'Next' : 'Finish') + '<i class="ph ph-arrow-right"></i></button></div></div>';
        $('#satScNx').onclick = () => { i++; draw(); };
      };
      paint();
    }
    draw();
  }
})();
