// node test/daily.sim.mjs   -> simulates three students on the REAL data (taxonomy, 122 lessons, merged bank)
import fs from 'node:fs';
import { createTaxonomy } from '../src/taxonomy/index.mjs';
import { buildDay, feasibility, scheduleReview } from '../src/engine/daily.mjs';
import { keyOf } from '../src/engine/mastery.mjs';
const data = JSON.parse(fs.readFileSync(new URL('../data.json', import.meta.url)));
const tax = createTaxonomy({ skills: data.skills, microskills: data.microskills, traps: data.traps, reasons: data.reasons });
const lessons = data.lessons.lessons, bank = data.questions, NOW = Date.parse('2026-10-22T18:00:00Z');
const mk = (pBySkill, dflt) => new Map(tax.skills.map((s) => { const p = pBySkill[s.id] ?? dflt, n = 30; return [keyOf(s.id), { skill_id: s.id, level: 'skill', p, variance: p * (1 - p) / (n + 1), n, insufficient: false }]; }));
const show = (title, day, feas) => {
  console.log(`\n=== ${title} ===`); if (feas) console.log('feasibility:', JSON.stringify(feas));
  console.log(`mode=${day.mode} total=${day.minutes_total} min  (2h minimum met: ${day.minimum_met})`);
  day.steps.forEach((s, i) => console.log(` ${String(i + 1).padStart(2)}. [${s.kind.padEnd(10)}] ${String(s.minutes).padStart(3)}m  ${s.label}${s.tag ? '  <' + s.tag + '>' : ''}`));
  day.why.forEach((w) => console.log(' note:', w)); day.pool_alerts.forEach((a) => console.log(` POOL ALERT: ${a.skill_id} only ${a.available_unseen} unseen`));
};
// A: new student, no test, wants 1400
show('Student A: no test yet, target 1400', buildDay({ tax, mastery: new Map(), lessons, bank, settings: { target_score: 1400, current_score: null, days_until_test: 45, minutes_per_day: 120 }, now: NOW }),
  feasibility({ current: null, target: 1400, days_until_test: 45, minutes_per_day: 120 }));
// B: 1200 student, wants 1500
const weak = { 'M.ALG.SYS': 0.48, 'M.ADV.NLEQ': 0.52, 'M.GT.TRIG': 0.4, 'RW.CS.WIC': 0.5, 'RW.SEC.BND': 0.55 };
const mB = mk(weak, 0.66), sB = { target_score: 1500, current_score: 1200, days_until_test: 45, minutes_per_day: 130 };
show('Student B: 1200 -> 1500', buildDay({ tax, mastery: mB, lessons, bank, settings: sB, progress: { vocabDue: 20 }, now: NOW }), feasibility({ current: 1200, target: 1500, days_until_test: 45, minutes_per_day: 130 }));
// C: B after failing a checkpoint, with spaced items due
const dueSkill = 'M.ALG.INEQ';
show('Student B, after failed checkpoint (sign error) + spaced review due', buildDay({ tax, mastery: mB, lessons, bank, settings: sB, now: NOW,
  progress: { checkpointFailed: [{ skill_id: 'M.ALG.SYS', trap_code: 'SIGN-ERROR' }], due: [{ skill_id: dueSkill, due_at: NOW - 3600e3 }], lessonDone: new Set(['L-M-ALG-SYS-C']) } }));
console.log('\nspaced repetition: right x3 ->', [0, 1, 2].map((i) => Math.round((scheduleReview({ stage: i - 1 }, true, 0).due_at) / 86400000) + 'd').join(', '), '| wrong -> back to', scheduleReview({ stage: 3 }, false, 0));
console.log('\nbank by section:', bank.reduce((a, q) => (a[q.section] = (a[q.section] ?? 0) + 1, a), {}), '| lessons with video:', lessons.filter((l) => l.video_ref).length, '/', lessons.length);
// ---- v2: score model, path, calibration ----
import { predictScore, requiredMastery, hoursNeeded, calibrateHpp, calibrateBias, scoreAfterHours } from '../src/engine/score.mjs';
import { buildPath } from '../src/engine/path.mjs';
console.log('\n=== v2 score model ===');
console.log('required mastery 1200/1400/1500:', [1200, 1400, 1500].map((t) => JSON.stringify(requiredMastery(t))).join(' '));
console.log('hours 1200->1400:', Math.round(hoursNeeded(1200, 1400)), '| 1200->1500:', Math.round(hoursNeeded(1200, 1500)), '| 1400->1500:', Math.round(hoursNeeded(1400, 1500)), '(prior 0.35 h/pt, saturating)');
const pr = predictScore(tax, mB, keyOf); console.log('Student B predicted:', pr.total, `(${pr.low}-${pr.high})`, JSON.stringify(pr.sections));
const pa = buildPath({ tax, mastery: mB, settings: { target_score: 1500, current_score: null, days_until_test: 45, minutes_per_day: 130 }, now: NOW });
console.log('path B:', pa.status, `need ${pa.hours_needed}h have ${pa.hours_available}h`, 'forecast@test', pa.forecast_at_test, '| phases', pa.phases.map((p) => `${p.name} d${p.from_day}-${p.to_day}`).join(', '), '| mocks day', pa.mock_days.join(','));
const pn = buildPath({ tax, mastery: new Map(), settings: { target_score: 1400, current_score: null, days_until_test: 45, minutes_per_day: 120 }, now: NOW }); console.log('path A:', pn.status, pn.phases.map((p) => p.name).join(' > '));
// synthetic calibration check: students with different true learning speeds; personal hours/point should converge, forecast error should shrink
function rnd(seed) { let a = seed; return () => (a = (a * 1664525 + 1013904223) % 4294967296) / 4294967296; }
const R = rnd(7); let errPrior = 0, errCal = 0, N = 400;
for (let i = 0; i < N; i++) { const trueHpp = 0.2 + R() * 0.5, start = 1000 + R() * 350, week = 14 * 2 * 1; // two measured fortnights, then predict the third
  const obs = []; let cur = start; for (let k = 0; k < 2; k++) { const h = 28, nxt = scoreAfterHours(cur, h, trueHpp) + (R() - 0.5) * 30; obs.push({ hours: h, points: nxt - cur }); cur = nxt; }
  const truth = scoreAfterHours(cur, 28, trueHpp), cal = calibrateHpp(obs).hpp; errPrior += Math.abs(scoreAfterHours(cur, 28) - truth); errCal += Math.abs(scoreAfterHours(cur, 28, cal) - truth); }
console.log(`synthetic check (${N} students, true speed varies): forecast error prior-only ${(errPrior / N).toFixed(1)} pts -> after 2 measured fortnights ${(errCal / N).toFixed(1)} pts`);
console.log('bias after mocks [pred vs actual]:', JSON.stringify(calibrateBias([{ predicted: 1250, actual: 1200 }, { predicted: 1300, actual: 1270 }])));
