// Audit digest: the ONLY thing the LLM ever sees. Built by code, <= ~400 tokens, no raw student text, no question text.
import { round, estimateTokens, groupBy } from '../util/misc.mjs';
import { keyOf } from './mastery.mjs';
import { behaviorStats, pacing, lateDecay } from './behaviors.mjs';
import { topTrapsOf } from './levers.mjs';

const accOf = (rows) => (rows.length ? round(rows.reduce((s, a) => s + a.is_correct, 0) / rows.length) : null);

/** input: { attempts (this audit's session), allAttempts (history), levers, mastery, previous (previous digest|null), modules[], tax, cfg, behaviorsTop[] } */
export function buildDigest(inp) {
  const { attempts, levers, mastery, previous = null, modules = [], tax, cfg, behaviorsTop = [] } = inp;
  const D = cfg.digest;
  const section_scores = {};
  for (const sec of ['rw', 'math']) {
    const rows = attempts.filter((a) => a.section === sec); if (!rows.length) continue;
    const by = {};
    for (const [d, list] of groupBy(rows.filter((a) => a.domain), (a) => a.domain)) by[d] = { acc: accOf(list), n: list.length };
    section_scores[sec] = { acc: accOf(rows), n: rows.length, by_domain: by };
  }
  const wrong = attempts.filter((a) => !a.is_correct);
  const mixRaw = {}; for (const a of wrong) { const k = a.root_cause ?? 'UNKNOWN'; mixRaw[k] = (mixRaw[k] ?? 0) + 1; }
  const error_mix = {}; let other = 0;
  for (const [k, v] of Object.entries(mixRaw).sort((a, b) => b[1] - a[1])) { const share = v / Math.max(1, wrong.length); if (share < D.other_bucket_below) other += share; else error_mix[k] = round(share); }
  if (other > 0) error_mix.OTHER = round(other);
  const pc = pacing(modules, attempts, cfg), ld = lateDecay(attempts, cfg), bs = behaviorStats(attempts, cfg);
  const top_levers = levers.slice(0, D.max_levers).map((l) => ({ skill: l.skill_id, name: l.name, p: l.p, main_cause: l.main_cause, gain: l.gain, ...(l.insufficient ? { low_data: true } : {}) }));
  const top_traps = topTrapsOf(wrong, D.max_traps).map((t) => ({ code: t.code, share: t.share }));
  const low_data_skills = [...mastery.values()].filter((m) => m.level === 'skill' && m.insufficient).map((m) => m.skill_id).slice(0, 6);
  const lowConf = wrong.filter((a) => a.root_cause_conf != null && a.root_cause_conf < 0.55).length;
  const digest = {
    section_scores, top_levers, error_mix,
    pacing: { avg_time_vs_target: pc.avg_time_vs_target, unanswered: Object.values(pc.unanswered_by_module).reduce((s, x) => s + x, 0), late_decay: ld.flagged, rushes_late: pc.rushes_late },
    behaviors: { changed_right_to_wrong: bs.changed_right_to_wrong, guess_rate: bs.guess_rate, top: behaviorsTop.map((b) => b.code) },
    top_traps,
    trend: trendOf(previous, section_scores, cfg),
    data_quality: { n_attempts: attempts.length, n_wrong: wrong.length, low_data_skills, low_confidence_share: wrong.length ? round(lowConf / wrong.length) : 0, has_telemetry: attempts.some((a) => a.telemetry), source: [...new Set(attempts.map((a) => a.source))].join('+') },
  };
  return fitBudget(digest, D.max_tokens);
}

function trendOf(prev, now, cfg) {
  if (!prev?.section_scores) return { vs_previous: 'first audit' };
  const parts = [];
  for (const sec of ['rw', 'math']) for (const [d, v] of Object.entries(now[sec]?.by_domain ?? {})) {
    const p = prev.section_scores?.[sec]?.by_domain?.[d];
    if (p && p.n >= cfg.trend.min_questions && v.n >= cfg.trend.min_questions) { const delta = Math.round((v.acc - p.acc) * 100); if (Math.abs(delta) >= cfg.trend.min_change_points) parts.push({ domain: d, delta }); }
  }
  parts.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
  return parts.length ? { vs_previous: parts.slice(0, 2).map((x) => `${x.delta > 0 ? '+' : ''}${x.delta} points accuracy in ${x.domain}`).join('; ') } : { vs_previous: 'no clear change' };
}

/** Trim lowest-value fields until the digest fits the token budget. */
export function fitBudget(digest, maxTokens) {
  const d = JSON.parse(JSON.stringify(digest));
  const steps = [
    () => { for (const s of Object.values(d.section_scores)) for (const v of Object.values(s.by_domain)) delete v.n; },
    () => { d.data_quality.low_data_skills = d.data_quality.low_data_skills.slice(0, 3); },
    () => { d.top_traps = d.top_traps.slice(0, 2); },
    () => { for (const l of d.top_levers) delete l.name; },
    () => { d.data_quality.low_data_skills = []; delete d.data_quality.source; },
  ];
  let i = 0;
  while (estimateTokens(d) > maxTokens && i < steps.length) steps[i++]();
  d._tokens = estimateTokens(d);
  return d;
}

/** Every number the LLM is allowed to quote. */
export function digestNumbers(digest) {
  const nums = new Set();
  const walk = (v) => { if (typeof v === 'number') { nums.add(String(v)); nums.add(String(Math.round(v * 100))); nums.add(String(Math.round(v))); nums.add(String(Math.abs(v))); } else if (typeof v === 'string') (v.match(/\d+(\.\d+)?/g) ?? []).forEach((x) => nums.add(x)); else if (v && typeof v === 'object') Object.values(v).forEach(walk); };
  walk(digest); return nums;
}
