/* ============================================================
   CLIMB TRACK: LUXURY MOUNTAIN ELEVATION & SCORE TRAIL
   Renders student position, goal summit, and smooth elevation glow.
   ============================================================ */
(function(){
  'use strict';
  var LO = 400, HI = 1600;

  // Mountain ridge profile: organic curve with gentle foothills and steep summit climb
  var ridgeY = function(t){
    return 84 - 64 * Math.pow(t, 1.25) - 4 * Math.sin(t * 8) * (1 - t * 0.35);
  };

  function pathTo(t1){
    var d = '', n = Math.max(2, Math.round(70 * t1));
    for(var i = 0; i <= n; i++){
      var t = t1 * i / n;
      d += (i ? ' L' : 'M') + (t * 1000).toFixed(1) + ' ' + ridgeY(t).toFixed(1);
    }
    return d;
  }

  function areaTo(t1){
    var p = pathTo(t1);
    var endX = (t1 * 1000).toFixed(1);
    return p + ' L' + endX + ' 100 L0 100 Z';
  }

  function frac(score){ return Math.max(0, Math.min(1, (score - LO) / (HI - LO))); }

  function place(el, t){
    if(!el) return;
    el.style.left = (t * 100) + '%';
    el.style.top = ridgeY(t) + '%';
  }

  function renderClimb(){
    var track = document.getElementById('clTrack'); if(!track) return;
    var goal = (state.profile && state.profile.goal) || 1400;
    var startScore = (state.profile && state.profile.startScore) ? +state.profile.startScore : null;
    var pr = estPredicted();
    if((pr == null || pr <= 400) && startScore && startScore >= 400){
      pr = startScore;
    }
    var base = state.base ? (state.base.rw + state.base.m) : (startScore || null);

    var g = frac(goal), f = pr == null ? 0 : frac(pr);

    var ridgeEl = document.getElementById('clRidge');
    var doneEl = document.getElementById('clDone');
    var areaEl = document.getElementById('clArea');
    if(ridgeEl) ridgeEl.setAttribute('d', pathTo(1));
    if(doneEl) doneEl.setAttribute('d', pathTo(Math.max(f, .004)));
    if(areaEl) areaEl.setAttribute('d', areaTo(Math.max(f, .004)));

    place(document.getElementById('clGoal'), g);
    var gn = document.getElementById('clGoalN');
    if(gn) gn.textContent = goal;

    var me = document.getElementById('clMe');
    place(me, f);

    var meBadge = document.getElementById('clMeBadge');
    if(meBadge){
      place(meBadge, f);
      meBadge.textContent = pr ? pr + ' pts' : 'Base';
    }

    var to = document.getElementById('clTo'), sub = document.getElementById('clToSub'), note = document.getElementById('clNote');
    if(pr == null){
      if(to) to.textContent = '-';
      if(sub) sub.textContent = 'Starts after your diagnostic';
      if(note) note.textContent = 'Base camp';
    } else {
      var left = Math.max(0, goal - pr);
      if(to) to.textContent = left ? left + ' pts' : 'Goal reached';
      if(sub) sub.textContent = left ? 'to reach ' + goal : 'Summit conquered';
      if(note) note.textContent = base != null && pr > base
        ? '+' + (pr - base) + ' pts since starting'
        : (pr >= goal ? 'Goal reached' : (left + ' pts to target'));
    }
    var ring = document.getElementById('pcRing');
    if(ring && ring.firstElementChild) ring.firstElementChild.style.width = 'calc(var(--v,0) * 1%)';
  }

  var prev = animateDash;
  animateDash = function(){ prev(); renderClimb(); };
  if(document.getElementById('progCard') && typeof state !== 'undefined') renderClimb();
  addEventListener('resize', renderClimb);
})();
