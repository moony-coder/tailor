/* Strive landing v2. No scroll listeners: IntersectionObserver and CSS scroll-driven animation only. */
(function(){
  'use strict';
  var reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  var $ = function(s, r){ return (r||document).querySelector(s); };
  var $$ = function(s, r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); };
  var esc = function(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); };

  /* ---- returning students go straight into the app ---- */
  try{
    var st = JSON.parse(localStorage.getItem('strive_sat_v3') || 'null');
    if(st && st.profile && st.profile.onboarded){
      ['navCta','heroCta','finalCta'].forEach(function(id){
        var el = document.getElementById(id); if(!el) return;
        el.href = 'app.html?skip_intro=1'; var l = $('.lbl', el); if(l) l.textContent = 'Open app';
      });
    }
  }catch(e){}

  /* ---- reveal on enter (state: hidden to shown) ---- */
  var rv = $$('.rv'), cells = $$('.cell');
  function show(el){ el.classList.add('in'); }
  if(reduce || !('IntersectionObserver' in window)){ rv.forEach(show); cells.forEach(show); }
  else {
    var io = new IntersectionObserver(function(es){
      es.forEach(function(e){ if(e.isIntersecting){ show(e.target); io.unobserve(e.target); } });
    }, { threshold:.14, rootMargin:'0px 0px -6% 0px' });
    rv.forEach(function(e){ io.observe(e); });
  }

  /* ---- count-up (feedback: numbers are real counts) ---- */
  var counters = $$('[data-count]');
  function run(el){
    var to = +el.dataset.count, t0 = null, dur = 1100;
    if(reduce){ el.textContent = to; return; }
    el.textContent = '0';
    function tick(t){ if(t0 === null) t0 = t; var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(to * e); if(p < 1) requestAnimationFrame(tick); }
    requestAnimationFrame(tick);
  }
  if('IntersectionObserver' in window && !reduce){
    var cio = new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ run(e.target); cio.unobserve(e.target); } }); }, { threshold:.6 });
    counters.forEach(function(c){ cio.observe(c); });
  }

  /* ================= TRY A REAL QUESTION =================
     Three questions from the Strive bank, copied as written. */
  var QS = [
    { tab:'Reading', skill:'Words in Context', diff:'Medium',
      passage:"Although the mayor's speech was brief, its effect on the council was ______: within a week, three members who had opposed the budget reversed their positions.",
      q:'Which choice completes the text with the most logical and precise word?',
      opts:['negligible','profound','predictable','ceremonial'], a:1,
      why:"Three opponents changing their minds shows a major effect. 'Profound' means deep and far-reaching. 'Negligible' contradicts the evidence." },
    { tab:'Grammar', skill:'Form, Structure, and Sense', diff:'Medium',
      passage:'The collection of rare manuscripts, along with several antique maps, ______ housed on the third floor of the library.',
      q:'Which choice completes the text so that it conforms to the conventions of Standard English?',
      opts:['is','are','were','have been'], a:0,
      why:"The subject is the singular noun 'collection'. The phrase 'along with several antique maps' does not make the subject plural, so the singular verb 'is' is correct." },
    { tab:'Math', skill:'Equivalent expressions', diff:'Medium', passage:'',
      q:'For x ≠ 2 and x ≠ −2, which expression is equivalent to (x² − 5x + 6)/(x² − 4)?',
      opts:['(x − 3)/(x + 2)','(x + 3)/(x − 2)','(x − 3)/(x − 2)','(x − 6)/(x + 2)'], a:0,
      why:'Factor top and bottom. x² − 5x + 6 = (x − 2)(x − 3) and x² − 4 = (x − 2)(x + 2). Cancel the common factor (x − 2) to get (x − 3)/(x + 2).' }
  ];
  var quiz = $('#quiz');
  if(quiz){
    var cur = 0, picked = QS.map(function(){ return null; });
    var L = ['A','B','C','D'];
    function answered(){ return picked.filter(function(p){ return p !== null; }).length; }
    function rightCount(){ return picked.filter(function(p, i){ return p === QS[i].a; }).length; }
    function render(){
      var q = QS[cur], p = picked[cur], done = p !== null;
      var tabs = QS.map(function(x, i){
        return '<button type="button" role="tab" id="qt'+i+'" aria-selected="'+(i===cur)+'" data-i="'+i+'" class="'+(picked[i]!==null?'done':'')+'">'+x.tab+'<i class="ph ph-check tick" aria-hidden="true"></i></button>';
      }).join('');
      var opts = q.opts.map(function(o, i){
        var cls = 'opt', icon = '';
        if(done){ if(i === q.a){ cls += ' is-ok'; } else if(i === p){ cls += ' is-no'; } else { cls += ' dim'; } }
        return '<button type="button" role="radio" aria-checked="'+(done && i===p)+'" class="'+cls+'" data-o="'+i+'"'+(done?' disabled':'')+'><span class="ltr">'+L[i]+'</span><span>'+esc(o)+'</span></button>';
      }).join('');
      var fb = '';
      if(done){
        var ok = p === q.a;
        fb = ok
          ? '<div class="fb ok" role="status"><div class="tile"><img src="assets/img/mark.png" alt="" width="140" height="104"></div><div><b>Correct</b><p>'+esc(q.why)+'</p></div></div>'
          : '<div class="fb no" role="status"><img src="assets/img/err.webp" alt="" width="720" height="620"><div><b>Not quite</b><p>'+esc(q.why)+'</p><small>Saved to your review list. It comes back until you get it right.</small></div></div>';
      }
      var all = answered() === QS.length;
      var foot;
      if(all){
        foot = '<span class="tally">You got '+rightCount()+' of '+QS.length+'. There are 253 more waiting.</span><a class="btn pri" href="'+$('#heroCta').getAttribute('href')+'"><span>Start free</span><i class="ph ph-arrow-right" aria-hidden="true"></i></a>';
      } else {
        foot = '<span class="tally">'+answered()+' of '+QS.length+' answered</span><button type="button" class="btn pri" id="qNext"'+(done?'':' hidden')+'><span>Next question</span><i class="ph ph-arrow-right" aria-hidden="true"></i></button>';
      }
      quiz.innerHTML =
        '<div class="quiz-top"><div class="tabs" role="tablist" aria-label="Question type">'+tabs+'</div><span class="quiz-meta">Question '+(cur+1)+' of '+QS.length+'</span></div>'+
        '<div class="quiz-body'+(q.passage?'':' solo')+'">'+
          (q.passage ? '<div class="q-pass">'+esc(q.passage)+'</div>' : '')+
          '<div class="q-main"><div class="q-skill"><span>'+esc(q.skill)+'</span><span>'+q.diff+'</span></div>'+
          '<p class="q-text">'+esc(q.q)+'</p><div class="opts" role="radiogroup" aria-label="Answer choices">'+opts+'</div>'+fb+'</div>'+
        '</div><div class="quiz-foot">'+foot+'</div>';
    }
    quiz.addEventListener('click', function(e){
      var t = e.target.closest('[data-i]'); if(t){ cur = +t.dataset.i; render(); return; }
      var o = e.target.closest('[data-o]'); if(o && picked[cur] === null){ picked[cur] = +o.dataset.o; render(); var n = $('#qNext'); if(n) n.focus({preventScroll:true}); return; }
      if(e.target.closest('#qNext')){ var nx = picked.findIndex(function(p, i){ return p === null && i !== cur; }); cur = nx >= 0 ? nx : (cur + 1) % QS.length; render(); }
    });
    render();
  }

  /* ================= STORY: which step is centred ================= */
  var story = $('#how'), steps = $$('.step', story);
  if(story && 'IntersectionObserver' in window){
    var sio = new IntersectionObserver(function(es){
      es.forEach(function(e){ if(e.isIntersecting){
        var i = steps.indexOf(e.target);
        story.dataset.active = i;
        story.style.setProperty('--p', ((i + 1) / steps.length).toFixed(2));
        var rail = $('.rail i', story); if(rail) rail.style.setProperty('--p', ((i + 1) / steps.length).toFixed(2));
      } });
    }, { rootMargin:'-45% 0px -45% 0px', threshold:0 });
    steps.forEach(function(s){ sio.observe(s); });
  }

  /* ================= BENTO A: live filter ================= */
  var COUNTS = { rw:{ all:107, Easy:30, Medium:35, Hard:42 }, m:{ all:149, Easy:46, Medium:91, Hard:12 } };
  var DOMS = { rw:['Craft and Structure','Information and Ideas','Standard English Conventions','Expression of Ideas'],
               m:['Algebra','Advanced Math','Problem-Solving and Data Analysis','Geometry and Trigonometry'] };
  var fs = { sec:'rw', diff:'all' }, fCount = $('#fCount'), fChips = $('#fChips'), shown = 107;
  function tween(to){
    if(reduce){ fCount.textContent = to; shown = to; return; }
    var from = shown, t0 = null; shown = to;
    function tk(t){ if(t0 === null) t0 = t; var p = Math.min(1, (t - t0) / 420), e = 1 - Math.pow(1 - p, 3); fCount.textContent = Math.round(from + (to - from) * e); if(p < 1) requestAnimationFrame(tk); }
    requestAnimationFrame(tk);
  }
  function paintFilter(){
    tween(COUNTS[fs.sec][fs.diff]);
    fChips.innerHTML = DOMS[fs.sec].map(function(d){ return '<span>'+d+'</span>'; }).join('');
  }
  function bindSeg(id, key){
    var box = $(id); if(!box) return;
    box.addEventListener('click', function(e){
      var b = e.target.closest('button'); if(!b) return;
      $$('button', box).forEach(function(x){ x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
      fs[key] = b.dataset.v; paintFilter();
    });
  }
  bindSeg('#fSec', 'sec'); bindSeg('#fDiff', 'diff'); if(fCount) paintFilter();

  /* ================= WATCH: lesson row ================= */
  var IDS = ['xpCnbwAwBl4','hdinjjgAv_s','04Ve8nBKxiA','ILYR0MBPHkM','1j99x9k2F2A','AGvINkfLq_0','0ask9HrOJMo','O4yOC6vJ6jA'];
  var track = $('#track');
  if(track){
    track.innerHTML = IDS.map(function(id, i){
      return '<article class="vid sk" data-id="'+id+'"><button type="button" class="thumb" aria-label="Play lesson '+(i+1)+'"><img alt="" loading="lazy" src="https://i.ytimg.com/vi/'+id+'/hqdefault.jpg" onerror="this.remove()"><span class="play"><i class="ph-fill ph-play" aria-hidden="true"></i></span></button><h3>Lesson '+(i+1)+'</h3><p>Jamal Edu</p></article>';
    }).join('');
    IDS.forEach(function(id){
      var card = $('[data-id="'+id+'"]', track);
      fetch('https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + id))
        .then(function(r){ if(!r.ok){ var err = new Error('blocked'); err.status = r.status; throw err; } return r.json(); })
        .then(function(j){ if(j && j.title){ $('h3', card).textContent = j.title; if(j.author_name) $('p', card).textContent = j.author_name; } card.classList.remove('sk'); })
        .catch(function(err){ if(err && err.status){ card.remove(); edge(); } else { card.classList.remove('sk'); } });
    });
    track.addEventListener('click', function(e){
      var b = e.target.closest('.thumb'); if(!b || b.querySelector('iframe')) return;
      var id = b.closest('.vid').dataset.id;
      b.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/'+id+'?autoplay=1&rel=0&playsinline=1&modestbranding=1" title="Video lesson" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
    });
    var prev = $('#vPrev'), next = $('#vNext');
    function edge(){ if(!prev) return; prev.disabled = track.scrollLeft < 8; next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 8; }
    function by(d){ var c = $('.vid', track); if(!c) return; track.scrollBy({ left: d * (c.getBoundingClientRect().width + 18), behavior: reduce ? 'auto' : 'smooth' }); }
    if(prev){ prev.addEventListener('click', function(){ by(-1); }); next.addEventListener('click', function(){ by(1); }); track.addEventListener('scrollend', edge); track.addEventListener('scroll', function(){ clearTimeout(edge.t); edge.t = setTimeout(edge, 80); }, { passive:true }); edge(); }
    track.addEventListener('keydown', function(e){ if(e.key === 'ArrowRight'){ by(1); } if(e.key === 'ArrowLeft'){ by(-1); } });
  }
})();
