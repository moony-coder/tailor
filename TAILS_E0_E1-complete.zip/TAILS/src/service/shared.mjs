// Shared service helpers: typed errors (mapped to HTTP codes by the API layer), row loaders.
export class ApiError extends Error { constructor(status, code, message, details) { super(message); this.status = status; this.code = code; this.details = details; } }
export const notFound = (what) => new ApiError(404, 'not_found', `${what} not found`);
export const invalid = (message, details) => new ApiError(400, 'invalid_request', message, details);
export const forbidden = (message = 'not allowed') => new ApiError(403, 'forbidden', message);
export const conflict = (message, details) => new ApiError(409, 'conflict', message, details);

export const loadAttempts = (db, where) => db.select('attempts', where, { orderBy: ['created_at', 'position'] });
export async function getSession(db, id) { const s = await db.get('sessions', id); if (!s) throw notFound('session'); return s; }
export function assertOwner(row, actor) { if (actor && row.profile_id !== actor) throw forbidden('this belongs to another profile'); }
export async function assertProfile(db, id) { if (!id) throw invalid('profile_id is required'); const p = await db.get('profiles', id); if (!p) throw notFound('profile'); return p; }
export const bool = (x) => (x ? 1 : 0);
