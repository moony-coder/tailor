// Study plan persistence: build from the latest audit inputs, store, read, update item status.
import { makeId, iso } from '../util/misc.mjs';
import { buildPlan } from '../engine/plan.mjs';
import { buildAuditInputs } from './analysis.mjs';
import { invalid, notFound, forbidden, assertProfile } from './shared.mjs';
import { vocabularyGaps } from './vocab.mjs';

const usable = (q) => q.status === 'verified' || q.status === 'approved';

export async function buildPlanForProfile(ctx, profileId, sessionId, inp = null, { replace = null } = {}) {
  const { db } = ctx, cfg = ctx.config.thresholds;
  const profile = await assertProfile(db, profileId);
  inp ??= await buildAuditInputs(ctx, profileId, sessionId);
  const done = new Set((await db.select('lesson_progress', { profile_id: profileId })).filter((r) => r.completed_at).map((r) => r.lesson_id));
  const bankCount = (skill) => ctx.bank.filter((q) => q.skill_id === skill && usable(q)).length;
  const domainBankCount = (domain) => ctx.bank.filter((q) => q.domain === domain && usable(q)).length;
  const plan = buildPlan({ levers: inp.levers, behaviors: inp.behaviorsTop, lessons: ctx.lessons, cfg, mastery: inp.mastery, bankCount, domainBankCount, settings: profile.settings_json ?? {}, lessonProgress: done, vocabulary_terms: vocabularyGaps(ctx, inp.all ?? []) });
  const id = makeId('p_', ctx.now());
  // carry over what the student already ticked off, matched by (kind, ref, stage)
  const keyOf = (it) => `${it.kind}|${it.ref_id}|${it.meta_json?.stage ?? it.meta?.stage ?? ''}`;
  const carried = new Map();
  if (replace) for (const it of await db.select('plan_items', { plan_id: replace })) if (it.status !== 'todo') carried.set(keyOf(it), it.status);
  await db.transaction(async (tx) => {
    if (replace) { await tx.delete('plan_items', { plan_id: replace }); await tx.delete('study_plans', { id: replace }); }
    await tx.insert('study_plans', { id, profile_id: profileId, session_id: sessionId, created_at: iso(ctx.now()), horizon_days: plan.horizon_days, json: { notes: plan.notes, minutes_per_day: plan.minutes_per_day, total_minutes: plan.total_minutes, levers: inp.levers.map((l) => ({ skill_id: l.skill_id, level: l.level, name: l.name, main_cause: l.main_cause })) } });
    let n = 0;
    for (const it of plan.items) await tx.insert('plan_items', { id: `${id}_${++n}`, plan_id: id, day_index: it.day_index, kind: it.kind, ref_id: it.ref_id, label: it.label, minutes: it.minutes, status: carried.get(keyOf(it)) ?? 'todo', meta_json: it.meta ?? {}, sort_order: it.sort_order });
  });
  return { plan_id: id, ...plan };
}

/** GET /api/plan?profile_id= : latest plan with items grouped by day. */
export async function getPlan(ctx, profileId, actor) {
  const { db } = ctx;
  await assertProfile(db, profileId);
  if (actor && actor !== profileId) throw forbidden('this plan belongs to another profile');
  const plans = await db.select('study_plans', { profile_id: profileId }, { orderBy: 'created_at', desc: true, limit: 1 });
  if (!plans.length) return { plan: null, message: 'No plan yet. Finish a test to get one.' };
  const p = plans[0], items = await db.select('plan_items', { plan_id: p.id }, { orderBy: ['day_index', 'sort_order'] });
  const days = Array.from({ length: p.horizon_days }, (_, i) => ({ day_index: i + 1, minutes: 0, items: [] }));
  for (const it of items) { const d = days[it.day_index - 1]; if (d) { d.items.push(it); d.minutes += it.minutes; } }
  const done = items.filter((i) => i.status === 'done').length;
  return { plan: { id: p.id, session_id: p.session_id, created_at: p.created_at, horizon_days: p.horizon_days, notes: p.json?.notes ?? [], minutes_per_day: p.json?.minutes_per_day, levers: p.json?.levers ?? [], progress: { done, total: items.length }, days } };
}

/** PATCH /api/plan-items/:id  body {status:'todo'|'done'|'skipped'} */
export async function patchPlanItem(ctx, itemId, body, actor) {
  const { db } = ctx;
  const it = await db.get('plan_items', itemId); if (!it) throw notFound('plan item');
  const plan = await db.get('study_plans', it.plan_id);
  if (actor && plan.profile_id !== actor) throw forbidden('this plan belongs to another profile');
  if (!['todo', 'done', 'skipped'].includes(body?.status)) throw invalid("status must be 'todo', 'done' or 'skipped'");
  await db.update('plan_items', { id: itemId }, { status: body.status });
  if (it.kind === 'lesson') await db.upsert('lesson_progress', { profile_id: plan.profile_id, lesson_id: it.ref_id, watched_pct: body.status === 'done' ? 100 : 0, completed_at: body.status === 'done' ? iso(ctx.now()) : null });
  return { ...it, status: body.status };
}

/** Re-derive the current plan from the latest evidence (after a mistake review or second chance). Keeps done/skipped marks. No-op without a plan. */
export async function refreshPlan(ctx, profileId) {
  const plans = await ctx.db.select('study_plans', { profile_id: profileId }, { orderBy: 'created_at', desc: true, limit: 1 });
  if (!plans.length || !plans[0].session_id) return null;
  return buildPlanForProfile(ctx, profileId, plans[0].session_id, null, { replace: plans[0].id });
}
