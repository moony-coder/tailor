// TAILS score model v2. PURE. Replaces the hand-set "target_p = 0.45 + (score-1000)*0.00095" with an explicit
// accuracy -> section-score curve, per-section required mastery, and a saturating study-hours model with
// per-student self-calibration. Every constant below is a PRIOR, marked for calibration against real mocks.
export const SCORE_CFG = {
  // Digital SAT section accuracy -> 200..800 (APPROXIMATE anchors; the real test is adaptive. Calibrate with mock results.)
  anchors: [[0.25, 220], [0.40, 340], [0.55, 460], [0.65, 540], [0.75, 620], [0.85, 700], [0.93, 770], [1.0, 800]],
  questions: { rw: 54, math: 44 },
  hours_per_point_prior: 0.35,    // study hours per point when far from the ceiling (prior, shrinks toward each student's own rate)
  study_efficiency: 0.9,          // share of planned hours really studied (used by the forecast curve in path.mjs)
  prior_strength_pts: 40,         // how many points of personal evidence outweigh the prior
};
const A = SCORE_CFG.anchors;
export function sectionScore(acc, cfg = SCORE_CFG) {
  const a = cfg.anchors; if (acc <= a[0][0]) return a[0][1]; if (acc >= a.at(-1)[0]) return a.at(-1)[1];
  for (let i = 1; i < a.length; i++) if (acc <= a[i][0]) { const [x0, y0] = a[i - 1], [x1, y1] = a[i]; return y0 + (y1 - y0) * (acc - x0) / (x1 - x0); }
}
export function accuracyFor(score, cfg = SCORE_CFG) { // inverse
  const a = cfg.anchors; if (score <= a[0][1]) return a[0][0]; if (score >= a.at(-1)[1]) return 1;
  for (let i = 1; i < a.length; i++) if (score <= a[i][1]) { const [x0, y0] = a[i - 1], [x1, y1] = a[i]; return x0 + (x1 - x0) * (score - y0) / (y1 - y0); }
}
/** Required average mastery in EACH section for a total target (split evenly unless a split is given). */
export function requiredMastery(target, split = null) { const rw = split?.rw ?? target / 2, m = split?.math ?? target - rw; return { rw: +accuracyFor(rw).toFixed(3), math: +accuracyFor(m).toFixed(3) }; }

/** Predict total score + range from skill mastery. mastery: Map(key->{skill_id,p,variance,insufficient}); bias from calibration. */
export function predictScore(tax, mastery, keyOf, bias = 0) {
  const sec = { rw: { w: 0, s: 0, v: 0 }, math: { w: 0, s: 0, v: 0 } };
  for (const s of tax.skills) { const m = mastery.get(keyOf(s.id)), sc = tax.sectionOf(s.id), w = s.weight_on_test; const p = m && !m.insufficient ? m.p : 0.5, v = m && !m.insufficient ? m.variance : 0.08; sec[sc].w += w; sec[sc].s += w * p; sec[sc].v += w * w * v; }
  const out = {}; let tot = 0, varTot = 0;
  for (const k of ['rw', 'math']) { const acc = sec[k].w ? sec[k].s / sec[k].w : 0.5, sd = sec[k].w ? Math.sqrt(sec[k].v) / sec[k].w : 0.1; const sc = sectionScore(acc), spread = (sectionScore(Math.min(1, acc + sd)) - sectionScore(Math.max(0, acc - sd))) / 2; out[k] = { accuracy: +acc.toFixed(3), score: Math.round(sc), sd: Math.round(spread) }; tot += sc; varTot += spread * spread; }
  const total = Math.round((tot + bias) / 10) * 10, sd = Math.max(30, Math.round(Math.sqrt(varTot)));
  return { total, low: total - Math.round(1.28 * sd), high: total + Math.round(1.28 * sd), sections: out, evidence: [...mastery.values()].filter((m) => !m.insufficient).length };
}

/** Hours to climb from `current` to `target`: saturating returns, headroom shrinks near 1600. hpp = personal hours/point (calibrated). */
export function hoursNeeded(current, target, hpp = SCORE_CFG.hours_per_point_prior) {
  const head = 1600 - current, g = Math.max(0, target - current); if (g <= 0) return 0; if (g >= head) return Infinity;
  return hpp * head * -Math.log(1 - g / head);
}
/** Personal hours-per-point: shrinkage between prior and observed (hours studied, points gained between measured mocks). */
export function calibrateHpp(obs, cfg = SCORE_CFG) {
  let h = 0, p = 0; for (const o of obs) if (o.points > 0 && o.hours > 0) { h += o.hours; p += o.points; }
  const k = cfg.prior_strength_pts, prior = cfg.hours_per_point_prior;
  return { hpp: +((prior * k + h) / (k + p)).toFixed(3), points_seen: p, hours_seen: Math.round(h) };
}
/** Forecast bias from mocks: how far predicted was from actual, shrunk until there are several mocks. */
export function calibrateBias(pairs) { if (!pairs.length) return { bias: 0, n: 0 }; const e = pairs.reduce((s, x) => s + (x.actual - x.predicted), 0) / pairs.length; return { bias: Math.max(-60, Math.min(60, Math.round(e * pairs.length / (pairs.length + 2)))), n: pairs.length }; }
/** Study-hours forecast of score at day t given hpp (inverse of hoursNeeded). */
export function scoreAfterHours(current, hours, hpp = SCORE_CFG.hours_per_point_prior) { const head = 1600 - current; return Math.round(current + head * (1 - Math.exp(-hours / (hpp * head)))); }
