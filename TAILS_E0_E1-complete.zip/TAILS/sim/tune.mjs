#!/usr/bin/env node
// Measure how noisy each metric is, so the regression gate's tolerances are evidence, not guesses.
//   node sim/tune.mjs [--batches 6] [--size 4] [--write]
// Runs `batches` disjoint groups of `size` seeds (same size as the gate uses), takes each group's mean per persona/metric,
// and reports the standard deviation of those group means. A gate tolerance of 3 x that sd (worst persona) means a pure-noise
// re-run fails a given cell with probability ~0.3%. --write stores the result in sim/tolerances.json, which the gate reads.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadAll } from '../src/loaders/node.mjs';
import { runMatrix } from './run.mjs';
import { METRICS } from './metrics.mjs';
import current from './engines/current.mjs';
const HERE = path.dirname(fileURLToPath(import.meta.url)), argv = process.argv.slice(2), opt = (f, d) => { const i = argv.indexOf(`--${f}`); return i >= 0 ? Number(argv[i + 1]) : d; };
const batches = opt('batches', 6), size = opt('size', 4), K = 3;
const data = await loadAll(), sd = (a) => { const m = a.reduce((s, x) => s + x, 0) / a.length; return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const acc = {}, pool = {}; // acc: world -> metric -> persona -> [batch means]; pool: world -> metric -> [batch means of the persona-average]
for (const exposure of ['never', 'unlimited']) for (let b = 0; b < batches; b++) {
  const m = await runMatrix({ data, engine: current, seeds: size, seedOffset: b * size, exposure });
  for (const [persona, a] of Object.entries(m.agg)) for (const me of METRICS) if (a[me.key] != null) (((acc[exposure] ??= {})[me.key] ??= {})[persona] ??= []).push(a[me.key]);
  for (const me of METRICS) { const v = Object.values(m.agg).map((a) => a[me.key]).filter((x) => x != null); if (v.length) (((pool[exposure] ??= {})[me.key] ??= [])).push(v.reduce((x, y) => x + y, 0) / v.length); }
  process.stderr.write(`.`);
}
const out = {}, rows = [];
for (const me of METRICS) {
  let worst = 0, who = '';
  for (const ex of Object.keys(acc)) for (const [p, v] of Object.entries(acc[ex][me.key] ?? {})) if (v.length >= 3) { const s = sd(v); if (s > worst) { worst = s; who = `${ex}/${p}`; } }
  const cell = +Math.max(K * worst, me.floor ?? 0).toPrecision(2);
  let pw = 0; for (const ex of Object.keys(pool)) { const v = pool[ex][me.key]; if (v?.length >= 3) pw = Math.max(pw, sd(v)); }
  const pooled = +Math.max(K * pw, (me.floor ?? 0) / 2).toPrecision(2);
  out[me.key] = { sd_cell_worst: +worst.toPrecision(3), cell, sd_pooled: +pw.toPrecision(3), pooled, worst_cell: who };
  rows.push(`${me.key.padEnd(18)} cell sd=${String(+worst.toPrecision(3)).padEnd(7)} cell tol=${String(cell).padEnd(7)} pooled sd=${String(+pw.toPrecision(3)).padEnd(7)} pooled tol=${String(pooled).padEnd(7)} worst cell: ${who}`);
}
console.log(`\n${batches} batches x ${size} seeds, tolerance = ${K} x sd of a ${size}-seed mean (cell = worst single persona/world, pooled = average over personas)\n` + rows.join('\n'));
if (argv.includes('--write')) { fs.writeFileSync(path.join(HERE, 'tolerances.json'), JSON.stringify({ seeds: size, batches, k: K, tolerances: out }, null, 1)); console.log('\nwritten sim/tolerances.json'); }
