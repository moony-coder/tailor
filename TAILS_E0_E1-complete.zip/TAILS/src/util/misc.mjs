// Small shared helpers: ids, seeded RNG, numbers, answer checking. No dependencies.

/** Deterministic PRNG (mulberry32). */
export function rng(seed = 1) {
  let a = seed >>> 0;
  const f = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  f.int = (n) => Math.floor(f() * n);
  f.pick = (arr) => arr[f.int(arr.length)];
  f.shuffle = (arr) => { const o = arr.slice(); for (let i = o.length - 1; i > 0; i--) { const j = f.int(i + 1); [o[i], o[j]] = [o[j], o[i]]; } return o; };
  return f;
}

let counter = 0;
/** Sortable unique id. Pass the injected clock for tests. */
export function makeId(prefix = '', now = Date.now()) {
  counter = (counter + 1) % 1679616;
  return `${prefix}${now.toString(36)}${counter.toString(36).padStart(4, '0')}${Math.floor(Math.random() * 46656).toString(36).padStart(3, '0')}`;
}

export const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
export const round = (x, d = 2) => { const m = 10 ** d; return Math.round(x * m) / m; };
export const sum = (a) => a.reduce((s, x) => s + x, 0);
export const mean = (a) => (a.length ? sum(a) / a.length : 0);
export function median(a) { if (!a.length) return 0; const s = a.slice().sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
export const uniq = (a) => [...new Set(a)];
export const iso = (ms) => new Date(ms).toISOString();
export const DAY_MS = 86400000;

export function groupBy(arr, fn) {
  const m = new Map();
  for (const x of arr) { const k = fn(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
  return m;
}

/** Parse "12", "-3.5", "18/5", "1,000". Returns a [num, den] fraction or null. */
export function parseNumber(s) {
  if (typeof s === 'number') return Number.isFinite(s) ? toFraction(s) : null;
  const t = String(s).replace(/[\s,]/g, '').replace(/−/g, '-');
  let m = /^(-?)(\d+)\/(\d+)$/.exec(t);
  if (m) return Number(m[3]) === 0 ? null : reduce([Number(m[1] + m[2]), Number(m[3])]);
  m = /^-?\d*\.?\d+$/.exec(t);
  if (m) return toFraction(Number(t), t);
  return null;
}
function toFraction(n, text) {
  const s = text ?? String(n);
  const dot = s.indexOf('.');
  const decimals = dot < 0 ? 0 : s.length - dot - 1;
  const den = 10 ** Math.min(decimals, 9);
  return reduce([Math.round(n * den), den]);
}
const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
function reduce([n, d]) { const g = gcd(n, d) || 1; return [n / g, d / g]; }

/** Student-produced-response check: any accepted equivalent value counts. */
export function checkSpr(input, accepted) {
  const a = parseNumber(input);
  if (!a) return false;
  return accepted.some((x) => { const b = parseNumber(x); return b && a[0] === b[0] && a[1] === b[1]; });
}

export function deepClone(o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); }

/** Rough token estimate (chars / 4). Good enough for budget checks. */
export const estimateTokens = (text) => Math.ceil((typeof text === 'string' ? text : JSON.stringify(text)).length / 4);
