// Sessions: create, telemetry ingest (idempotent), module submit (+routing), finish (scores -> root causes -> mastery -> digest -> plan), recovery.
import { makeId, iso, median, round } from '../util/misc.mjs';
import { buildModule, buildDrill, routeFromModule, persistTest, persistModule, timeLimitFor, AssemblyError } from '../questions/assembler.mjs';
import { isCorrect, trapOf, publicView } from '../questions/score.mjs';
import { sanitizeBatch } from '../session/events.mjs';
import { deriveModule } from '../session/derive.mjs';
import { computeMastery, skillP } from '../engine/mastery.mjs';
import { recomputeRootCauses, recomputeMastery, buildAuditInputs } from './analysis.mjs';
import { buildPlanForProfile } from './plan.mjs';
import { ApiError, invalid, conflict, getSession, assertOwner, assertProfile, bool } from './shared.mjs';

export const SESSION_KINDS = ['mini-mock', 'native-mock', 'skill-drill', 'spaced-retest'];

const usableBank = (ctx) => ctx.bank.filter((q) => q.status === 'verified' || q.status === 'approved');

/** Stages for a test kind. Each stage = one module. */
function stagesFor(ctx, kind, params) {
  const T = ctx.config.blueprints.tests;
  if (kind === 'mini-mock') return T['mini-mock'].modules.map((m, i) => ({ blueprint: m.blueprint, level: m.level, section: ctx.config.blueprints.modules[m.blueprint].section, module_index: 1, adaptive: false }));
  if (kind === 'native-mock') return T['native-mock'].stages.flatMap((s) => [{ blueprint: s.blueprint, section: s.section, module_index: 1, adaptive: false, level: 'std' }, { blueprint: s.blueprint, section: s.section, module_index: 2, adaptive: true }]);
  if (kind === 'skill-drill' || kind === 'spaced-retest') return [{ blueprint: null, drill: { skill_id: params.skill_id ?? null, domain: params.domain ?? null, size: params.size ?? null }, section: params.skill_id || params.domain ? ctx.tax.sectionOf(params.skill_id ?? params.domain) : 'rw', module_index: 1, adaptive: false, level: 'std' }];
  throw invalid(`kind must be one of ${SESSION_KINDS.join(', ')}`);
}

/** Which test kinds the current bank can fill (shown by /api/health so the UI can grey out a full mock instead of failing on click). */
export function feasibleKinds(ctx) {
  const out = {};
  for (const kind of ['mini-mock', 'native-mock']) { try { assertFeasible(ctx, stagesFor(ctx, kind, {})); out[kind] = true; } catch { out[kind] = false; } }
  return out;
}

/** Fail early (before the student starts) if the bank cannot fill every module of the test. */
function assertFeasible(ctx, stages) {
  const need = new Map();   // domain -> questions needed
  for (const st of stages.filter((s) => s.blueprint)) for (const [d, n] of Object.entries(ctx.config.blueprints.modules[st.blueprint].domains)) need.set(d, (need.get(d) ?? 0) + n);
  const have = new Map(); for (const q of usableBank(ctx)) have.set(q.domain, (have.get(q.domain) ?? 0) + 1);
  const missing = [...need].filter(([d, n]) => (have.get(d) ?? 0) < n).map(([d, n]) => ({ domain: d, need: n, have: have.get(d) ?? 0, short: n - (have.get(d) ?? 0) }));
  if (missing.length) throw new AssemblyError(`the question bank is too small for this test: ${missing.map((m) => `${m.domain} needs ${m.need}, has ${m.have}`).join('; ')}. Use a mini-mock or a skill drill, or add questions.`, missing);
}

async function profileContext(ctx, profileId) {
  const attempts = await ctx.db.select('attempts', { profile_id: profileId });
  const mastery = computeMastery(attempts, ctx.config.thresholds, ctx.now());
  const weakness = new Map();
  for (const m of mastery.values()) if (m.level === 'skill') weakness.set(m.skill_id, 1 - m.p);
  return { attempts, mastery, weakness, seen: new Set(attempts.map((a) => a.question_id).filter(Boolean)) };
}

const moduleView = (mod, questions) => ({ module_id: mod.id, section: mod.section, module_index: mod.module_index, difficulty_level: mod.difficulty_level, time_limit_sec: mod.time_limit_sec, size: questions.length, questions: questions.map((q, i) => publicView(q, i + 1)) });

async function moduleQuestions(ctx, moduleId) {
  const rows = await ctx.db.select('module_questions', { module_id: moduleId }, { orderBy: 'position' });
  return rows.map((r) => ctx.qById.get(r.question_id));
}

/** Build + persist the module for stage `idx` of a session. */
async function buildStage(ctx, session, meta, idx, level) {
  const st = meta.stages[idx], pc = await profileContext(ctx, session.profile_id);
  const exclude = new Set(meta.used_ids ?? []);
  let questions, bp = null;
  if (st.blueprint) {
    bp = ctx.config.blueprints.modules[st.blueprint];
    ({ questions } = buildModule(ctx, st.blueprint, level ?? st.level ?? 'std', { exclude, weakness: pc.weakness, seen: pc.seen }));
  } else {
    const d = st.drill, scopeKey = d.skill_id ?? d.domain;
    const p = d.skill_id ? skillP(pc.mastery, d.skill_id) ?? 0.5 : 0.5;
    const domain = d.domain ?? (d.skill_id ? d.skill_id.split('.').slice(0, 2).join('.') : null);
    // a skill with a thin bank is topped up from its domain (said openly in `warnings`)
    const thin = d.skill_id && ctx.bank.filter((q) => q.skill_id === d.skill_id && (q.status === 'verified' || q.status === 'approved')).length < Math.max(3, d.size ?? 0);
    ({ questions } = buildDrill(ctx, { skill_id: d.skill_id, domain: thin ? domain : d.domain, size: d.size ?? undefined, p_mastery: p, exclude, kind: session.kind, seen: pc.seen }));
    if (!scopeKey) throw invalid('a drill needs skill_id or domain');
  }
  const { modules: [mod] } = await persistTest(ctx, { name: `${session.kind} ${st.section} m${st.module_index}`, kind: session.kind, blueprint_id: st.blueprint, modules: [{ section: st.section, module_index: st.module_index, ordinal: idx + 1, level: level ?? st.level ?? 'std', questions, time_limit_sec: bp ? bp.time_limit_sec : timeLimitFor(ctx, {}, questions) }] }).then((r) => ({ modules: r.modules }));
  await ctx.db.insert('session_modules', { session_id: session.id, module_id: mod.id, started_at: iso(ctx.now()), ended_at: null, routed_to: null, score_json: null });
  meta.used_ids = [...exclude, ...questions.map((q) => q.id)]; meta.stage = idx + 1;
  await ctx.db.update('sessions', { id: session.id }, { meta_json: meta });
  return moduleView(mod, questions);
}

/** POST /api/sessions */
export async function createSession(ctx, body, actor) {
  const profile = await assertProfile(ctx.db, body?.profile_id ?? actor);
  assertOwner({ profile_id: profile.id }, actor);
  const kind = body.kind ?? 'mini-mock';
  const params = { skill_id: body.skill_id ?? null, domain: body.domain ?? null, size: body.size ?? null };
  if ((kind === 'skill-drill' || kind === 'spaced-retest')) {
    if (!params.skill_id && !params.domain) throw invalid('skill_id or domain is required for a drill');
    if (params.skill_id && !ctx.tax.skillById.has(params.skill_id)) throw invalid(`unknown skill ${params.skill_id}`);
    if (params.domain && !ctx.tax.domainById.has(params.domain)) throw invalid(`unknown domain ${params.domain}`);
    if (params.size != null && !(Number.isInteger(params.size) && params.size >= 1 && params.size <= 30)) throw invalid('size must be 1..30');
  }
  const stages = stagesFor(ctx, kind, params);
  assertFeasible(ctx, stages);
  const session = { id: makeId('s_', ctx.now()), profile_id: profile.id, test_id: null, started_at: iso(ctx.now()), ended_at: null, status: 'active', source: 'native', kind, meta_json: null };
  const meta = { stages, stage: 0, used_ids: [], plan_item_id: body.plan_item_id ?? null };
  await ctx.db.insert('sessions', { ...session, meta_json: meta });
  const first = await buildStage(ctx, session, meta, 0);
  return { session_id: session.id, kind, status: 'active', total_modules: stages.length, adaptive: kind === 'native-mock', module: first, warnings: [] };
}

/** GET /api/sessions/:id : everything a client needs to resume after closing the browser. */
export async function getSessionState(ctx, sessionId, actor) {
  const s = await getSession(ctx.db, sessionId); assertOwner(s, actor);
  const meta = s.meta_json ?? {}, mods = await ctx.db.select('session_modules', { session_id: sessionId }, { orderBy: 'started_at' });
  const open = mods.find((m) => !m.ended_at);
  let module = null, answers = {}, last_seq = 0, elapsed_ms = null;
  const evs = await ctx.db.select('events', { session_id: sessionId }, { orderBy: 'seq' });
  last_seq = evs.length ? evs[evs.length - 1].seq : 0;
  if (open) {
    const mrow = await ctx.db.get('test_modules', open.module_id), qs = await moduleQuestions(ctx, open.module_id);
    module = moduleView(mrow, qs);
    const d = deriveModule(evs.filter((e) => e.module_id === open.module_id).map(toEvent), qs, (qid, c) => isCorrect(ctx.qById.get(qid), c));
    for (const [qid, v] of d.perQuestion) if (v.final_choice != null) answers[qid] = v.final_choice;
    elapsed_ms = d.module.started_at != null ? Math.max(0, evs[evs.length - 1].t_ms - d.module.started_at) : null;
  }
  return { session_id: s.id, kind: s.kind, status: s.status, source: s.source, started_at: s.started_at, ended_at: s.ended_at, modules_total: meta.stages?.length ?? mods.length, modules_built: mods.length, modules_submitted: mods.filter((m) => m.ended_at).length, module, answers, last_seq, elapsed_ms };
}
const toEvent = (r) => ({ seq: r.seq, type: r.type, t_ms: r.t_ms, module_id: r.module_id, question_id: r.question_id, payload: r.payload_json ?? {} });

/** POST /api/sessions/:id/events : idempotent by (session_id, seq). */
export async function ingestEvents(ctx, sessionId, body, actor) {
  const s = await getSession(ctx.db, sessionId); assertOwner(s, actor);
  if (s.status === 'finished') throw conflict('session is finished; events are no longer accepted');
  const { good, bad } = sanitizeBatch(body?.events);
  const have = new Set((await ctx.db.select('events', { session_id: sessionId })).map((e) => e.seq));
  let accepted = 0, duplicates = 0;
  await ctx.db.transaction(async (tx) => {
    for (const e of good) {
      if (have.has(e.seq)) { duplicates++; continue; }
      await tx.insert('events', { id: `e_${sessionId}_${e.seq}`, session_id: sessionId, seq: e.seq, module_id: e.module_id, question_id: e.question_id, question_ref: null, type: e.type, t_ms: e.t_ms, payload_json: e.payload });
      have.add(e.seq); accepted++;
    }
  });
  return { accepted, duplicates, rejected: bad, last_seq: have.size ? Math.max(...have) : 0 };
}

/** POST /api/sessions/:id/modules/:m/submit */
export async function submitModule(ctx, sessionId, moduleId, body, actor, { buildNext = true } = {}) {
  const s = await getSession(ctx.db, sessionId); assertOwner(s, actor);
  const sm = await ctx.db.get('session_modules', { session_id: sessionId, module_id: moduleId });
  if (!sm) throw new ApiError(404, 'not_found', 'module is not part of this session');
  const meta = s.meta_json ?? {};
  if (sm.ended_at) {   // idempotent re-submit
    const st = await getSessionState(ctx, sessionId, actor);
    return { already_submitted: true, summary: sm.score_json, routing: { route: sm.routed_to, score: sm.score_json?.route_score ?? null }, next_module: st.module, done: !st.module && (st.modules_built >= st.modules_total) };
  }
  const mod = await ctx.db.get('test_modules', moduleId), qs = await moduleQuestions(ctx, moduleId);
  const evs = (await ctx.db.select('events', { session_id: sessionId, module_id: moduleId }, { orderBy: 'seq' })).map(toEvent);
  const correctFn = (qid, c) => isCorrect(ctx.qById.get(qid), c);
  const d = deriveModule(evs, qs, correctFn), telemetry = evs.some((e) => e.type === 'module_started');
  const sent = body?.answers && typeof body.answers === 'object' ? body.answers : {};
  const expired = d.module.expired || body?.expired === true;
  const nowIso = iso(ctx.now()), rows = [];
  const answers = {};
  qs.forEach((q, i) => {
    const m = d.perQuestion.get(q.id) ?? {};
    const given = Object.prototype.hasOwnProperty.call(sent, q.id) ? sent[q.id] : m.final_choice;
    const chosen = given === '' || given === undefined ? null : given;
    if (chosen != null && !(typeof chosen === 'string' || typeof chosen === 'number')) throw invalid(`answer for ${q.id} must be a string`);
    answers[q.id] = chosen;
    const unanswered = chosen == null;
    rows.push({
      id: `a_${moduleId}_${i + 1}`, session_id: sessionId, profile_id: s.profile_id, question_id: q.id, question_ref: null, position: i + 1, module_id: moduleId, module_index: mod.module_index, module_size: qs.length,
      section: q.section, domain: q.domain, skill_id: q.skill_id, micro_skill_ids_json: q.micro_skills, difficulty: q.difficulty, est_time_sec: q.est_time_sec,
      chosen: chosen == null ? null : String(chosen), is_correct: bool(isCorrect(q, chosen)), unanswered: bool(unanswered), trap_code: trapOf(q, chosen),
      first_response_ms: telemetry ? m.first_response_ms ?? null : null, total_ms: telemetry ? m.total_ms ?? 0 : null, active_ms: telemetry ? m.active_ms ?? 0 : null, visits: telemetry ? m.visits ?? 0 : null,
      answer_changes: m.answer_changes ?? 0, changed_right_to_wrong: m.changed_right_to_wrong ?? 0, flagged: m.flagged ?? 0, eliminated_json: m.eliminated ?? [], calc_opened: m.calc_opened ?? 0, highlights_used: m.highlights_used ?? 0,
      time_remaining_ms: m.time_remaining_ms ?? null, telemetry: bool(telemetry), domain_estimated: 0, ran_out_of_time: bool(unanswered && expired), source: 'native', created_at: nowIso,
    });
  });
  const correct = rows.filter((r) => r.is_correct).length, unanswered = rows.filter((r) => r.unanswered).length;
  const limitMs = (mod.time_limit_sec ?? 0) * 1000;
  const usedFraction = expired ? 1 : d.module.used_ms != null && limitMs ? round(Math.min(1.5, d.module.used_ms / limitMs)) : null;
  const stageIdx = (meta.stages ?? []).findIndex((st, i) => st.section === mod.section && st.module_index === mod.module_index && i === (meta.stage ?? 1) - 1);
  const st = meta.stages?.[stageIdx >= 0 ? stageIdx : (meta.stage ?? 1) - 1];
  let routing = { route: null, score: null };
  const nextStage = st && meta.stages[meta.stages.indexOf(st) + 1];
  if (nextStage?.adaptive && st.section === nextStage.section) { const r = routeFromModule(ctx, qs, answers); routing = { route: r.route, score: round(r.score) }; }
  const summary = { section: mod.section, module_index: mod.module_index, size: qs.length, correct, unanswered, accuracy: round(correct / Math.max(1, qs.length)), used_fraction: usedFraction, expired, telemetry, difficulty_level: mod.difficulty_level, route_score: routing.score };
  await ctx.db.transaction(async (tx) => {
    for (const r of rows) { if (!(await tx.get('attempts', r.id))) await tx.insert('attempts', r); }
    await tx.update('session_modules', { session_id: sessionId, module_id: moduleId }, { ended_at: nowIso, routed_to: routing.route, score_json: summary });
  });
  let next = null;
  const idx = meta.stages ? meta.stages.indexOf(st) : -1;
  if (buildNext && idx >= 0 && idx + 1 < meta.stages.length) {
    const ns = meta.stages[idx + 1];
    next = await buildStage(ctx, s, meta, idx + 1, ns.adaptive ? routing.route ?? 'std' : ns.level);
  }
  return { already_submitted: false, summary, routing, next_module: next, done: !next && idx + 1 >= (meta.stages?.length ?? 1) };
}

const scoreBySection = (attempts) => {
  const out = {};
  for (const sec of ['rw', 'math']) { const r = attempts.filter((a) => a.section === sec); if (r.length) { const c = r.filter((a) => a.is_correct).length; out[sec] = { correct: c, total: r.length, accuracy: round(c / r.length), unanswered: r.filter((a) => a.unanswered).length }; } }
  return out;
};

/** Shared by finishSession and the Bluebook import: derive everything from the attempt log. */
export async function finalizeAnalysis(ctx, session, { rebuildPlan = true } = {}) {
  await recomputeRootCauses(ctx, session.profile_id);
  await recomputeMastery(ctx, session.profile_id, { sessionId: session.id });
  const inp = await buildAuditInputs(ctx, session.profile_id, session.id);
  await ctx.db.upsert('error_profile_snapshots', { id: `snap_${session.id}`, profile_id: session.profile_id, session_id: session.id, json: inp.digest, created_at: iso(ctx.now()) });
  let plan = null;
  if (rebuildPlan) plan = await buildPlanForProfile(ctx, session.profile_id, session.id, inp);
  return { inp, plan };
}

/** POST /api/sessions/:id/finish */
export async function finishSession(ctx, sessionId, body, actor) {
  const s = await getSession(ctx.db, sessionId); assertOwner(s, actor);
  const mods = await ctx.db.select('session_modules', { session_id: sessionId });
  const meta = s.meta_json ?? {}, open = mods.filter((m) => !m.ended_at), total = meta.stages?.length ?? mods.length;
  const incomplete = open.length || mods.length < total;
  if (incomplete && !body?.force) throw conflict(`${open.length + Math.max(0, total - mods.length)} module(s) not submitted yet; submit them or finish with {"force": true}`, { open_modules: open.map((m) => m.module_id) });
  for (const m of open) await submitModule(ctx, sessionId, m.module_id, { expired: !!body?.expired }, actor, { buildNext: false });   // abandoned module: score what was answered
  const attempts = await ctx.db.select('attempts', { session_id: sessionId });
  const wasFinished = s.status === 'finished';
  if (!wasFinished) await ctx.db.update('sessions', { id: sessionId }, { status: 'finished', ended_at: iso(ctx.now()) });
  const isMock = ['mini-mock', 'native-mock'].includes(s.kind);
  const { inp, plan } = await finalizeAnalysis(ctx, { ...s, id: sessionId }, { rebuildPlan: isMock });
  if (meta.plan_item_id) { const it = await ctx.db.get('plan_items', meta.plan_item_id); if (it) await ctx.db.update('plan_items', { id: it.id }, { status: 'done' }); }
  const scores = scoreBySection(attempts), wrong = attempts.filter((a) => !a.is_correct);
  return { session_id: sessionId, status: 'finished', already_finished: wasFinished, forced: !!incomplete, scores, n_attempts: attempts.length, n_wrong: wrong.length, review_available: wrong.length > 0, top_levers: inp.levers.map((l) => ({ skill_id: l.skill_id, name: l.name, main_cause: l.main_cause, gain: l.gain })), digest_tokens: inp.digest._tokens, plan_id: plan?.plan_id ?? null,
    note: 'Scores are raw correct counts for this practice test. This tool does not predict an official SAT score.' };
}

export { scoreBySection, moduleView };
