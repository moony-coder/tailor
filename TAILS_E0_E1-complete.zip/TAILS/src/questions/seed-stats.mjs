// Seed-bank statistics and the E1 distribution spec. Pure functions; used by validate-all and the report.
export const E1_SPEC = {
  skills: {
    'RW.CS.WIC': 5, 'RW.CS.TSP': 3, 'RW.CS.CTC': 1, 'RW.II.CID': 3, 'RW.II.CEV.T': 2, 'RW.II.CEV.Q': 1, 'RW.II.INF': 2,
    'RW.SEC.BND': 4, 'RW.SEC.FSS': 4, 'RW.EOI.RS': 3, 'RW.EOI.TRN': 2,
    'M.ALG.LIN1': 2, 'M.ALG.LIN2': 2, 'M.ALG.LFUNC': 2, 'M.ALG.SYS': 2, 'M.ALG.INEQ': 2, 'M.ADV.EQUIV': 3, 'M.ADV.NLEQ': 4, 'M.ADV.NLFUNC': 3,
    'M.PSDA.RATIO': 1, 'M.PSDA.PCT': 1, 'M.PSDA.ONEVAR': 1, 'M.PSDA.TWOVAR': 1, 'M.PSDA.PROB': 1,
    'M.GT.AREAVOL': 1, 'M.GT.LINES': 2, 'M.GT.TRIG': 1, 'M.GT.CIRCLE': 1,
  },
  domains: { 'RW.CS': 9, 'RW.II': 8, 'RW.SEC': 8, 'RW.EOI': 5, 'M.ALG': 10, 'M.ADV': 10, 'M.PSDA': 5, 'M.GT': 5 },
  sections: { rw: 30, math: 30 },
  formats: { mcq4: 52, spr: 8 },
  sprByDomain: { 'M.ALG': 3, 'M.ADV': 3, 'M.PSDA': 1, 'M.GT': 1 },
  difficultyPerSection: { easy: 9, medium: 12, hard: 9 },
  minTags: { 'H.ASK-DIFFERENT': 3, 'H.PARAMETRIC-K': 2, 'H.DESMOS-FAST': 2, 'H.WEAKENER': 2 },
  keyShareRange: [0.2, 0.3],
};

const count = (arr, f) => { const m = {}; for (const x of arr) { const k = f(x); m[k] = (m[k] ?? 0) + 1; } return m; };

export function seedStats(questions, tax) {
  const mcq = questions.filter((q) => q.format === 'mcq4');
  const keys = count(mcq, (q) => q.choices.find((c) => c.is_correct).key);
  const diff = {};
  for (const sec of ['rw', 'math']) diff[sec] = count(questions.filter((q) => q.section === sec), (q) => q.difficulty_band);
  const coveredMicro = new Set(questions.flatMap((q) => q.micro_skills));
  const bandsBySkill = {};
  for (const q of questions) (bandsBySkill[q.skill_id] ??= new Set()).add(q.difficulty_band);
  const tags = count(questions.flatMap((q) => q.hypothesis_tags), (t) => t);
  return {
    total: questions.length,
    bySkill: count(questions, (q) => q.skill_id),
    byDomain: count(questions, (q) => q.domain),
    bySection: count(questions, (q) => q.section),
    byFormat: count(questions, (q) => q.format),
    sprByDomain: count(questions.filter((q) => q.format === 'spr'), (q) => q.domain),
    difficulty: diff,
    keyHistogram: { A: keys.A ?? 0, B: keys.B ?? 0, C: keys.C ?? 0, D: keys.D ?? 0 },
    tags,
    bandsBySkill: Object.fromEntries(Object.entries(bandsBySkill).map(([k, v]) => [k, [...v].sort()])),
    coveredMicro: [...coveredMicro].sort(),
    uncoveredMicro: tax.microskills.map((m) => m.id).filter((id) => !coveredMicro.has(id)),
    byStatus: count(questions, (q) => q.status),
  };
}

/** Returns a list of human-readable mismatches vs the E1 spec (empty = exact match). */
export function checkAgainstE1(stats, questions, spec = E1_SPEC) {
  const issues = [];
  const cmp = (label, got, want) => {
    for (const k of new Set([...Object.keys(want), ...Object.keys(got)])) if ((got[k] ?? 0) !== (want[k] ?? 0)) issues.push(`${label} ${k}: have ${got[k] ?? 0}, want ${want[k] ?? 0}`);
  };
  cmp('skill', stats.bySkill, spec.skills);
  cmp('domain', stats.byDomain, spec.domains);
  cmp('section', stats.bySection, spec.sections);
  cmp('format', stats.byFormat, spec.formats);
  cmp('spr in domain', stats.sprByDomain, spec.sprByDomain);
  for (const sec of ['rw', 'math']) cmp(`${sec} difficulty`, stats.difficulty[sec], spec.difficultyPerSection);
  for (const [t, n] of Object.entries(spec.minTags)) if ((stats.tags[t] ?? 0) < n) issues.push(`tag ${t}: have ${stats.tags[t] ?? 0}, want >= ${n}`);
  const mcqN = stats.byFormat.mcq4 ?? 0;
  for (const [k, n] of Object.entries(stats.keyHistogram)) {
    const share = n / mcqN;
    if (share < spec.keyShareRange[0] || share > spec.keyShareRange[1]) issues.push(`answer key ${k} share ${(share * 100).toFixed(0)}% outside 20-30%`);
  }
  for (const [sid, n] of Object.entries(stats.bySkill)) if (n >= 2 && stats.bandsBySkill[sid].length < 2) issues.push(`skill ${sid} has ${n} questions but only one difficulty band`);
  return issues;
}
