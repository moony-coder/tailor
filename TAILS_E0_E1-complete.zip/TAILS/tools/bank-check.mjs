#!/usr/bin/env node
// Bank integrity + coverage audit.  node tools/bank-check.mjs [--json] [--strict-coverage]
//  FAILS (exit 1) on integrity problems: bad ids, schema errors, exact duplicates, near duplicates, unusable items.
//  REPORTS (never fails, unless --strict-coverage): thin skills, empty bands, template saturation, answer-position skew.
import { loadAll, readBundle } from '../src/loaders/node.mjs';
import { checkIds } from '../src/ids.mjs';
import { validateQuestion } from '../src/questions/validate.mjs';
import { fingerprint, templateKey } from '../src/questions/fingerprint.mjs';
import { DedupIndex } from '../factory/lib/dedup.mjs';

export const TARGET_PER_BAND = 40;      // blueprint: 40 to 60 verified items per skill per band (E5 raises this for heavy skills)
export const BAND_OF = (d) => (d <= 2 ? 'easy' : d === 3 ? 'medium' : 'hard');

export async function auditBank(root) {
  const bundle = readBundle(root), d = await loadAll(root), q = d.questions, tax = d.taxonomy;
  const integrity = [], report = {};

  for (const p of checkIds(bundle)) integrity.push(`id: ${p}`);
  for (const x of q) { const r = validateQuestion(x, tax); for (const e of r.errors) integrity.push(`schema ${x.id}: ${e}`); }

  // exact duplicates: same full content (passage + stem + visual data + choices + answer)
  const byFp = new Map();
  for (const x of q) { const f = fingerprint(x); (byFp.get(f) ?? byFp.set(f, []).get(f)).push(x.id); }
  for (const ids of byFp.values()) if (ids.length > 1) integrity.push(`exact duplicate: ${ids.join(' = ')}`);

  // near duplicates (shingle similarity; parametric family items are compared by parameter signature)
  const ix = new DedupIndex(); const near = [];
  for (const x of q) { const c = ix.check(x); if (c) near.push(`${x.id} ~ ${c.id} (${c.sim})`); ix.add(x); }
  for (const n of near) integrity.push(`near duplicate: ${n}`);

  // distractor sanity: no two choices equal, answer key resolvable
  for (const x of q) if (x.format === 'mcq4' && x.choices.filter((c) => c.is_correct).length !== 1) integrity.push(`key: ${x.id} has no unique correct choice`);
  const usable = q.filter((x) => ['verified', 'approved'].includes(x.status));
  if (usable.length !== q.length) integrity.push(`${q.length - usable.length} item(s) are not verified/approved`);

  // ---- coverage (report) ----
  const cov = {};
  for (const s of tax.skills) cov[s.id] = { easy: 0, medium: 0, hard: 0, total: 0, name: s.name, section: s.section, weight: s.weight_on_test };
  for (const x of usable) { const c = cov[x.skill_id]; c[BAND_OF(x.difficulty)]++; c.total++; }
  const rows = Object.entries(cov).map(([id, c]) => ({ id, ...c, short: Math.max(0, TARGET_PER_BAND * 3 - c.total), empty_bands: ['easy', 'medium', 'hard'].filter((b) => c[b] === 0) }));
  report.coverage = rows;
  report.totals = { items: usable.length, rw: rows.filter((r) => r.section === 'rw').reduce((s, r) => s + r.total, 0), math: rows.filter((r) => r.section === 'math').reduce((s, r) => s + r.total, 0), target_low: tax.skills.length * 3 * TARGET_PER_BAND };
  report.thin_skills = rows.filter((r) => r.total < 20).map((r) => `${r.id} (${r.total})`);
  report.empty_skills = rows.filter((r) => r.total === 0).map((r) => r.id);
  report.empty_bands = rows.filter((r) => r.empty_bands.length && r.total > 0).map((r) => `${r.id}: no ${r.empty_bands.join('/')}`);

  // template saturation: many items sharing one wording with different numbers
  const tmpl = new Map();
  for (const x of usable) { const k = x.skill_id + '|' + templateKey(x); (tmpl.get(k) ?? tmpl.set(k, []).get(k)).push(x.id); }
  report.template_clones = [...tmpl.entries()].filter(([, v]) => v.length >= 5).map(([k, v]) => ({ skill: k.split('|')[0], count: v.length, sample: v[0] })).sort((a, b) => b.count - a.count);
  const distinct = {}; for (const [k, v] of tmpl) { const s = k.split('|')[0]; distinct[s] = (distinct[s] ?? 0) + 1; }
  report.distinct_templates = distinct;

  const pos = { A: 0, B: 0, C: 0, D: 0 }; for (const x of usable) if (x.format === 'mcq4') pos[x.choices.find((c) => c.is_correct).key]++;
  report.answer_positions = pos;
  const used = new Set(usable.flatMap((x) => x.choices.map((c) => c.trap_code).filter(Boolean)));
  report.unused_traps = tax.traps.map((t) => t.code).filter((c) => !used.has(c));
  return { integrity, report, near };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const { integrity, report } = await auditBank();
  if (process.argv.includes('--json')) console.log(JSON.stringify({ integrity, report }, null, 1));
  else {
    const R = report;
    console.log(`BANK: ${R.totals.items} usable items (RW ${R.totals.rw}, Math ${R.totals.math}) vs blueprint floor ${R.totals.target_low}`);
    console.log(`INTEGRITY: ${integrity.length ? integrity.length + ' problem(s)' : 'clean (ids, schema, exact + near duplicates, answer keys)'}`);
    integrity.slice(0, 40).forEach((p) => console.log('  ✗', p));
    console.log('\nCOVERAGE (easy/medium/hard, target ' + TARGET_PER_BAND + ' each)');
    for (const r of R.coverage.slice().sort((a, b) => a.total - b.total)) console.log(`  ${r.id.padEnd(13)} ${String(r.easy).padStart(3)}/${String(r.medium).padStart(3)}/${String(r.hard).padStart(3)}  total ${String(r.total).padStart(3)}  tmpl ${String(R.distinct_templates[r.id] ?? 0).padStart(3)}  ${r.empty_bands.length ? 'MISSING ' + r.empty_bands.join(',') : ''}`);
    console.log('\nempty skills:', R.empty_skills.join(', ') || 'none');
    console.log('template clones (>=5 items, same wording):', R.template_clones.map((t) => `${t.skill} x${t.count}`).join(', ') || 'none');
    console.log('answer positions:', JSON.stringify(R.answer_positions), '| traps never used:', R.unused_traps.join(', ') || 'none');
  }
  process.exit(integrity.length || (process.argv.includes('--strict-coverage') && (report.empty_skills.length || report.empty_bands.length)) ? 1 : 0);
}
