// Family kit: turns a family's raw parameters into a full TAILS question object.
// A "family" is a parametric generator: one piece of code -> thousands of unique, computer-verified questions.
// Every instance carries Python verification code that RE-DERIVES the answer from the parameters with sympy
// (independently of the JS that wrote the choices). factory `families` runs that verifier on every item.
import { bandOf, nowIso } from '../lib/common.mjs';

export class Reject extends Error {}
export const reject = (why) => { throw new Reject(why); };

// ---------- exact rationals ----------
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
export class Q {
  constructor(n, d = 1) { if (d === 0) throw new Reject('zero denominator'); if (d < 0) { n = -n; d = -d; } const g = gcd(n, d); this.n = n / g; this.d = d / g; }
  static of(x) { return x instanceof Q ? x : new Q(x, 1); }
  add(o) { o = Q.of(o); return new Q(this.n * o.d + o.n * this.d, this.d * o.d); }
  sub(o) { o = Q.of(o); return new Q(this.n * o.d - o.n * this.d, this.d * o.d); }
  mul(o) { o = Q.of(o); return new Q(this.n * o.n, this.d * o.d); }
  div(o) { o = Q.of(o); return new Q(this.n * o.d, this.d * o.n); }
  neg() { return new Q(-this.n, this.d); }
  eq(o) { o = Q.of(o); return this.n === o.n && this.d === o.d; }
  get isInt() { return this.d === 1; }
  valueOf() { return this.n / this.d; }
  tex() { return this.d === 1 ? `${this.n}` : `${this.n < 0 ? '-' : ''}\\frac{${Math.abs(this.n)}}{${this.d}}`; }
  py() { return this.d === 1 ? `${this.n}` : `sp.Rational(${this.n}, ${this.d})`; }
  spr() { return this.d === 1 ? `${this.n}` : `${this.n}/${this.d}`; }
  dec() { return this.n / this.d; }
}
export const q = (n, d = 1) => new Q(n, d);

// ---------- formatting ----------
/** "3x - 5", "-x + 2", "x" ... from coefficient list [[coef, 'x'], [const, '']] */
export function lin(terms) {
  let s = '';
  for (const [c0, v] of terms) {
    const c = Q.of(c0); if (c.n === 0) continue;
    const neg = c.n < 0, abs = neg ? c.neg() : c;
    const body = v ? (abs.eq(1) ? v : `${abs.tex()}${v}`) : abs.tex();
    s += s ? (neg ? ` - ${body}` : ` + ${body}`) : (neg ? `-${body}` : body);
  }
  return s || '0';
}
export const num = (x) => { const v = Number(x); return Number.isInteger(v) ? v.toLocaleString('en-US').replace(/,/g, ',') : String(+v.toFixed(4)); };
export const money = (x) => `\\$${Number(x).toFixed(Number.isInteger(+x) ? 0 : 2)}`;
export const pyNum = (x) => (x instanceof Q ? x.py() : Number.isInteger(x) ? String(x) : `sp.nsimplify(${JSON.stringify(String(x))})`);

// ---------- the builder ----------
const SKILL_LESSONS = (skill) => { const b = 'L-' + skill.replace(/\./g, '-'); return [`${b}-C`, `${b}-E`, `${b}-T`]; };
const FIXIT = { 'SIGN-ERROR': 'F-SIGN-ERROR', 'ASKED-DIFFERENT': 'F-ASKED-DIFFERENT', 'UNIT-ERROR': 'F-UNIT-ERROR', 'STOPPED-EARLY': 'F-STOPPED-EARLY', 'EXTRANEOUS-KEPT': 'F-EXTRANEOUS-KEPT', 'DOUBLE-HALF': 'F-DOUBLE-HALF' };
const EST = { easy: [35, 50], medium: [60, 90], hard: [95, 140] };


/**
 * spec:
 *  skill, micro[], difficulty(1..5), drivers[], context, stem, visual?, hypothesis?[]
 *  answer: { value: Q|number, tex: 'shown text' }   (value used for uniqueness; tex shown)
 *  wrong:  [{ value, tex, trap, why, think, trapPy? }] x3   (trapPy = python expr reproducing the mistake)
 *  solvePy: python that computes `computed` FROM THE PROBLEM'S PARAMETERS (independent derivation)
 *  choicePy?: python dict body for choices if values aren't plain numbers (e.g. sympy expressions)
 *  steps[], insight, fast, desmos?, plug?
 *  spr: true -> grid-in (no choices). accepted computed from answer.value
 */
export function build(r, family, spec) {
  const band = bandOf(spec.difficulty);
  const [lo, hi] = EST[band];
  const est = spec.est ?? r.int(lo, hi);
  const base = {
    id: null, version: 1, section: 'math', domain: spec.skill.split('.').slice(0, 2).join('.'), skill_id: spec.skill,
    micro_skills: spec.micro, hypothesis_tags: spec.hypothesis ?? [], difficulty: spec.difficulty, difficulty_band: band,
    difficulty_drivers: spec.drivers ?? [], format: spec.spr ? 'spr' : 'mcq4', est_time_sec: Math.min(hi, Math.max(lo, est)), context: spec.context ?? 'none',
    stem: spec.stem, passage: null, visual: spec.visual ?? null, choices: [], spr: null,
    solution: { key_insight: spec.insight, steps: spec.steps.slice(0, 6), fast_method: spec.fast ?? spec.insight, desmos_method: spec.desmos ?? null, plug_in_method: spec.plug ?? null },
    evidence_map: null, vocabulary_terms: [], grammar_rule_id: null, common_misreads: spec.misreads ?? [], prerequisite_skill_ids: spec.prereq ?? [],
    lesson_ids: [], originality: { generated_by: `family:${family}`, source_text: 'original', similarity_checked: true },
    status: 'draft', verification: { method: 'python-sympy', code: '', result: 'unrun', second_solver_agrees: false, teacher_review: 'pending', notes: '' },
    created_at: nowIso(), tails: { family, sig: spec.sig ?? null },
  };
  const traps = new Set();
  if (spec.spr) {
    const v = Q.of(spec.answer.value);
    const acc = [v.spr()];
    if (!v.isInt) { const d = v.dec(); const s = d.toFixed(4).replace(/0+$/, ''); if (s.replace('-', '').length <= 6) acc.push(s.replace(/^(-?)0\./, '$1.')); else acc.push(d.toFixed(4).slice(0, d < 0 ? 6 : 5).replace(/^(-?)0\./, '$1.')); }
    base.spr = { accepted: [...new Set(acc)], accepted_equivalents_note: 'Any equivalent value (fraction or decimal) is accepted.' };
    base.choices = [];
    base.verification.code = `${spec.solvePy.trim()}\n`;
    for (const w of spec.wrong ?? []) traps.add(w.trap);
    base.common_misreads = [...base.common_misreads, ...(spec.wrong ?? []).map((w) => `${w.think} -> ${w.tex.replace(/\$/g, '')}`)].slice(0, 3);
  } else {
    if ((spec.wrong ?? []).length !== 3) reject('need 3 distractors');
    const all = [{ ...spec.answer, correct: true }, ...spec.wrong];
    const vals = all.map((c) => (c.key_value ?? (c.value instanceof Q ? `${c.value.n}/${c.value.d}` : String(c.value))));
    if (new Set(vals).size !== 4) reject('distractor collides with another choice');
    if (new Set(all.map((c) => c.tex.trim().toLowerCase())).size !== 4) reject('duplicate choice text');
    const order = spec.keepOrder ? all : r.shuffle(all);
    const keys = ['A', 'B', 'C', 'D'];
    base.choices = order.map((c, i) => c.correct
      ? { key: keys[i], text: c.tex, is_correct: true, trap_code: null, why_right: spec.answer.why ?? spec.insight }
      : { key: keys[i], text: c.tex, is_correct: false, trap_code: c.trap, why_wrong: c.why, student_thinking: c.think });
    for (const c of spec.wrong) traps.add(c.trap);
    const cp = order.map((c, i) => `'${keys[i]}': ${c.py ?? pyNum(c.value)}`).join(', ');
    const tc = order.map((c, i) => (!c.correct && c.trapPy ? `'${keys[i]}': ${c.trapPy}` : null)).filter(Boolean).join(', ');
    base.verification.code = `${spec.solvePy.trim()}\nchoices = {${cp}}\ntrap_checks = {${tc}}\n`;
  }
  const fix = [...traps].map((t) => FIXIT[t]).filter(Boolean);
  base.lesson_ids = [...SKILL_LESSONS(spec.skill), ...new Set(fix)];
  return base;
}

/** Choose difficulty-dependent value: pick(d, [easyVal, medVal, hardVal]) */
export const byBand = (d, arr) => arr[d <= 2 ? 0 : d === 3 ? 1 : 2];
export const nz = (r, lo, hi) => { let v = 0; while (v === 0) v = r.int(lo, hi); return v; };
export const CONTEXT_NAMES = ['Ava', 'Bilal', 'Chen', 'Dilnoza', 'Elena', 'Farrukh', 'Grace', 'Hiro', 'Isabel', 'Jamshid', 'Kemal', 'Leila', 'Malik', 'Nadia', 'Omar', 'Priya', 'Ravshan', 'Sofia', 'Timur', 'Yuki', 'Zara', 'Mateo', 'Amara', 'Kofi', 'Lucia'];
