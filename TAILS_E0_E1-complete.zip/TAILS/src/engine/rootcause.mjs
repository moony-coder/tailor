// Root-cause inference. PURE and deterministic. The LLM never touches this.
// Fusion priority: facts > second-chance result > trap code of the chosen distractor > self-reported chip > telemetry rules > skill context.
//
// attempt: { is_correct, unanswered, trap_code, est_time_sec, total_ms, first_response_ms, position, module_size,
//            changed_right_to_wrong, ran_out_of_time, telemetry (1/0), flagged }
// ev:      { trapHint, skillP, skillN, self: {root_cause, code, understood}|null, secondChance: {result:'passed'|'failed', same_question}|null }
const TIER = { fact: 0, second_chance: 1, trap: 2, self: 3, telemetry: 4, context: 5 };

/** Telemetry heuristics (C5). Order matters on ties: a fast answer in the last quarter is TIMING (rushing) before it is GUESS. */
export function telemetryRules(a, ev, cfg) {
  const t = cfg.telemetry, f = cfg.fusion, out = [];
  if (!a.telemetry || a.is_correct) return out;
  const est = a.est_time_sec;
  const lastQuarter = a.module_size && a.position > a.module_size * (1 - t.rushed_last_fraction);
  if (a.total_ms != null && a.total_ms < t.rushed_ratio * est * 1000 && lastQuarter) out.push({ cause: 'TIMING', conf: f.telemetry_conf, rule: 'rushed_late' });
  if (a.first_response_ms != null && a.first_response_ms < t.fast_guess_ratio * est * 1000) out.push({ cause: 'GUESS', conf: f.telemetry_conf, rule: 'fast_guess' });
  if (a.total_ms != null && a.total_ms > t.stuck_ratio * est * 1000) out.push({ cause: 'CONTENT_GAP', conf: f.telemetry_conf, rule: 'stuck' });
  if (ev.skillP != null && ev.skillP >= t.careless_mastery_p && a.total_ms != null && a.total_ms <= t.careless_time_ratio * est * 1000) out.push({ cause: 'CARELESS', conf: f.telemetry_conf, rule: 'careless_candidate' });
  return out;
}

function candidates(a, ev, cfg, { includeSelf }) {
  const f = cfg.fusion, c = [];
  if (a.is_correct) return c;
  // 1. facts
  if (a.changed_right_to_wrong) c.push({ cause: 'OVERTHINK', conf: f.overthought_conf, source: 'fact', rule: 'changed_right_to_wrong', tier: TIER.fact });
  if (a.unanswered) {
    if (a.ran_out_of_time) c.push({ cause: 'TIMING', conf: f.unanswered_timing_conf, source: 'fact', rule: 'unanswered_ran_out_of_time', tier: TIER.fact });
    else c.push({ cause: 'TIMING', conf: f.unanswered_skipped_conf, source: 'fact', rule: 'unanswered_skipped', tier: TIER.fact });
  }
  // 2. second chance: pass => execution error (CARELESS); fail => knowledge/strategy gap
  if (ev.secondChance) {
    if (ev.secondChance.result === 'passed') {
      const k = ev.secondChance.same_question ? f.same_question_pass_conf_factor : 1;
      c.push({ cause: 'CARELESS', conf: f.second_chance_pass_conf * k, source: 'second_chance', rule: 'second_chance_passed', tier: TIER.second_chance });
    } else {
      const h = ev.trapHint;
      const keep = f.strategy_trap_second_chance_fail_keep_hint && ['STRATEGY', 'VOCAB', 'COMPREHENSION'].includes(h);
      c.push({ cause: keep ? h : 'CONTENT_GAP', conf: f.second_chance_fail_conf, source: 'second_chance', rule: 'second_chance_failed', tier: TIER.second_chance });
    }
  }
  // 3. trap code of the chosen distractor
  if (ev.trapHint && ev.trapHint !== 'REPORT') c.push({ cause: ev.trapHint, conf: f.trap_conf, source: 'trap', rule: `trap:${a.trap_code}`, tier: TIER.trap });
  // 4. self-report
  if (includeSelf && ev.self) {
    if (ev.self.root_cause && ev.self.root_cause !== 'REPORT') c.push({ cause: ev.self.root_cause, conf: f.chip_conf, source: 'self', rule: `chip:${ev.self.code ?? ''}`, tier: TIER.self });
    else if (!ev.self.root_cause && ev.self.understood === 'no') c.push({ cause: 'CONTENT_GAP', conf: f.understood_no_conf, source: 'self', rule: 'understood_no', tier: TIER.self });
  }
  // 5. telemetry
  for (const r of telemetryRules(a, ev, cfg)) c.push({ ...r, source: 'telemetry', tier: TIER.telemetry });
  // 6. context
  if (ev.skillP != null && ev.skillN >= cfg.mastery.context_min_attempts && ev.skillP < 0.4) c.push({ cause: 'CONTENT_GAP', conf: f.context_conf, source: 'context', rule: 'low_mastery', tier: TIER.context });
  return c;
}

function fuse(cands, a, cfg) {
  const f = cfg.fusion;
  if (!cands.length) return { root_cause: 'UNKNOWN', confidence: 0.2, evidence: ['no evidence'] };
  const ordered = cands.slice().sort((x, y) => x.tier - y.tier || y.conf - x.conf);
  const top = ordered[0];
  const agreeing = ordered.filter((x) => x !== top && x.cause === top.cause && x.source !== top.source);
  const disagreeing = ordered.filter((x) => x.cause !== top.cause && x.tier <= TIER.self);
  const agreeSources = new Set(agreeing.map((x) => x.source));
  let conf = top.conf + f.agree_bonus * Math.min(agreeSources.size, f.max_agree_bonuses) - 0.1 * new Set(disagreeing.map((x) => x.source)).size;
  conf = Math.max(f.disagree_floor, Math.min(f.max_conf, conf));
  if (!a.telemetry && top.source !== 'second_chance') conf = Math.min(conf, f.no_telemetry_conf_cap);
  return { root_cause: top.cause, confidence: Math.round(conf * 100) / 100, evidence: [top.rule, ...agreeing.map((x) => `+${x.rule}`), ...disagreeing.map((x) => `!${x.rule}`)] };
}

/**
 * Returns { root_cause, confidence, evidence, independent:{root_cause,confidence}, self_root_cause, agreement, low_confidence }
 * - root_cause: fused including the self-report (what the audit uses)
 * - independent: fused WITHOUT the self-report (what the system believes on its own)
 * - agreement: 1/0 if the student gave a cause, else null
 */
export function inferRootCause(a, ev, cfg) {
  if (a.is_correct) return { root_cause: null, confidence: null, evidence: [], independent: { root_cause: null, confidence: null }, self_root_cause: null, agreement: null, low_confidence: false };
  const withSelf = fuse(candidates(a, ev, cfg, { includeSelf: true }), a, cfg);
  const indep = fuse(candidates(a, ev, cfg, { includeSelf: false }), a, cfg);
  const self = ev.self?.root_cause && ev.self.root_cause !== 'REPORT' ? ev.self.root_cause : null;
  return {
    ...withSelf, independent: { root_cause: indep.root_cause, confidence: indep.confidence }, self_root_cause: self,
    agreement: self ? (self === indep.root_cause ? 1 : 0) : null, low_confidence: !a.telemetry || withSelf.confidence < 0.55,
  };
}

/** Correct but suspicious: flagged + fast (guessed). Counts 0.3 in mastery. */
export function isGuessedCorrect(a, cfg) {
  return !!(a.is_correct && a.flagged && a.telemetry && a.total_ms != null && a.total_ms < cfg.fusion.guessed_correct_total_ratio * a.est_time_sec * 1000);
}
