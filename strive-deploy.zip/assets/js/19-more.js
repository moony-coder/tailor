/* Mobile "More" sheet: the destinations that do not fit in the 5-slot tab bar. */
(function(){
  'use strict';
  var btn = document.querySelector('#tabbar [data-more]'), sheet = document.getElementById('moreSheet');
  if(!btn || !sheet) return;
  function open(){ sheet.hidden = false; requestAnimationFrame(function(){ sheet.classList.add('in'); }); btn.setAttribute('aria-expanded','true'); var f = sheet.querySelector('button'); if(f) f.focus({preventScroll:true}); }
  function close(){ sheet.classList.remove('in'); btn.setAttribute('aria-expanded','false'); setTimeout(function(){ if(!sheet.classList.contains('in')) sheet.hidden = true; }, 260); }
  btn.addEventListener('click', function(){ sheet.hidden ? open() : close(); });
  sheet.addEventListener('click', function(e){
    var b = e.target.closest('button');
    if(!b){ if(e.target === sheet) close(); return; }
    close();
    if(b.dataset.v) go(b.dataset.v); else if(b.hasAttribute('data-settings')) openSettings();
  });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape' && !sheet.hidden){ close(); btn.focus(); } });
})();
