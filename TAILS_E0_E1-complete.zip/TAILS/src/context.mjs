// Context = everything the engine needs, passed explicitly (no globals, no fs).
// ctx = { db, tax, bank, qById, lessons, config:{thresholds,blueprints,routing}, now(), rand() }
import { rng } from './util/misc.mjs';

export function createContext({ db, data, now = () => Date.now(), seed = 1 }) {
  const bank = data.questions;
  const rand = rng(seed);
  return {
    db, tax: data.taxonomy, bank, qById: new Map(bank.map((q) => [q.id, q])), lessons: data.lessons,
    config: data.config, now, rand,
  };
}

/** Node convenience: load data from disk. */
export async function loadContext({ db, now, seed, root } = {}) {
  const { loadAll } = await import('./loaders/node.mjs');
  return createContext({ db, data: await loadAll(root), now, seed });
}

/** Copy taxonomy/questions/lessons into the DB tables (idempotent). */
export async function seedDb(ctx) {
  const { db, tax, bank, lessons } = ctx;
  await db.transaction(async (tx) => {
    for (const s of tax.skills) await tx.upsert('skills', { id: s.id, section: tax.sectionOf(s.id), domain: s.domain, name: s.name, domain_share: tax.domainById.get(s.domain).share, skill_share_within_domain: s.skill_share_within_domain, weight_on_test: s.weight_on_test ?? null });
    for (const m of tax.microskills) await tx.upsert('micro_skills', { id: m.id, skill_id: m.skill_id, name: m.name });
    for (const t of tax.traps) await tx.upsert('trap_codes', { code: t.code, section: t.section, name: t.name, description: t.description, root_cause_hint: t.root_cause_hint });
    for (const r of tax.reasons) await tx.upsert('reasons', { code: r.code, section: r.section, label: r.label, root_cause: r.root_cause });
    for (const q of bank) {
      // a status the teacher already set in the DB (approved / rejected) must survive a re-seed
      const existing = await tx.get('questions', q.id);
      if (existing && existing.status !== q.status && existing.version === q.version) q.status = existing.status;
      await tx.upsert('questions', { id: q.id, version: q.version, section: q.section, domain: q.domain, skill_id: q.skill_id, difficulty: q.difficulty, format: q.format, est_time_sec: q.est_time_sec, status: q.status, json: q });
      for (const m of q.micro_skills) await tx.upsert('question_micro_skills', { question_id: q.id, micro_skill_id: m });
    }
    for (const l of lessons) await tx.upsert('lessons', { id: l.id, title: l.title, skill_id: l.skill_id, micro_skill_id: l.micro_skill, kind: l.kind, duration_sec: l.duration_sec, video_ref: l.video_ref, transcript_ref: l.transcript_ref, status: l.status, wave: l.wave });
  });
  return { skills: tax.skills.length, questions: bank.length, lessons: lessons.length };
}
