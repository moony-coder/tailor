// Mastery map + admin question management + profiles (local profile switcher).
import { makeId, iso, round, mean, median } from '../util/misc.mjs';
import { readinessBand } from '../engine/mastery.mjs';
import { invalid, notFound, forbidden } from './shared.mjs';

/** GET /api/skills/mastery?profile_id= */
export async function getMasteryMap(ctx, profileId, actor) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  if (actor && actor !== profileId) throw forbidden();
  const rows = await db.select('skill_mastery', { profile_id: profileId });
  const by = new Map(rows.filter((r) => r.micro_skill_id === '').map((r) => [r.skill_id, r]));
  const cuts = cfg.mastery.readiness_band_cutpoints;
  const mk = (id, name, section, domain, r, level) => ({ id, name, section, domain, level, p_mastery: r ? round(r.p_mastery) : null, n_attempts: r?.n_attempts ?? 0, band: r ? readinessBand(r.p_mastery, cuts) : null, enough_data: r ? r.n_attempts >= (level === 'skill' ? cfg.mastery.min_attempts_skill : cfg.mastery.domain_only_min_attempts) : false, last_attempt_at: r?.last_attempt_at ?? null });
  const domains = tax.domains.map((d) => ({ ...mk(d.id, d.name, d.section, d.id, by.get(d.id), 'domain'), skills: tax.skillsByDomain.get(d.id).map((s) => mk(s.id, s.name, d.section, d.id, by.get(s.id), 'skill')) }));
  return { profile_id: profileId, domains, note: 'Bands 1-7 describe readiness for the skill, not a score. "enough_data: false" means too few answers to trust the number.' };
}

export const isStaff = async (ctx, actor) => { if (!actor) return true; const p = await ctx.db.get('profiles', actor); return p && (p.role === 'teacher' || p.role === 'admin'); };
export async function requireStaff(ctx, actor) { if (!(await isStaff(ctx, actor))) throw forbidden('teacher or admin only'); }

/** GET /api/admin/questions?status=&section=&domain=&skill_id=&reported=1 */
export async function listAdminQuestions(ctx, query, actor) {
  await requireStaff(ctx, actor);
  const { db } = ctx, attempts = await db.select('attempts', {}), reports = await db.select('question_reports', {});
  const stat = new Map();
  for (const a of attempts) if (a.question_id) { const s = stat.get(a.question_id) ?? { n: 0, c: 0, t: [] }; s.n++; s.c += a.is_correct; if (a.total_ms) s.t.push(a.total_ms); stat.set(a.question_id, s); }
  const open = new Map(); for (const r of reports.filter((r) => r.status === 'open')) open.set(r.question_id, (open.get(r.question_id) ?? 0) + 1);
  let items = ctx.bank.map((q) => { const s = stat.get(q.id); return { id: q.id, section: q.section, domain: q.domain, skill_id: q.skill_id, difficulty: q.difficulty, format: q.format, status: q.status, version: q.version, verification: q.verification ?? null,
    stats: { n_attempts: s?.n ?? 0, accuracy: s ? round(s.c / s.n) : null, median_time_s: s?.t.length ? Math.round(median(s.t) / 1000) : null, est_time_sec: q.est_time_sec }, open_reports: open.get(q.id) ?? 0 }; });
  for (const k of ['status', 'section', 'domain', 'skill_id']) if (query?.[k]) items = items.filter((i) => i[k] === query[k]);
  if (query?.reported) items = items.filter((i) => i.open_reports > 0);
  return { total: items.length, items, reports: reports.filter((r) => r.status === 'open') };
}

/** GET /api/admin/questions/:id : the full question (key, traps, explanations, verification) for the teacher's review screen. */
export async function getAdminQuestion(ctx, id, actor) {
  await requireStaff(ctx, actor);
  const q = ctx.qById.get(id); if (!q) throw notFound('question');
  const reports = (await ctx.db.select('question_reports', { question_id: id })).map((r) => ({ id: r.id, reason: r.reason, status: r.status, created_at: r.created_at }));
  const rows = (await ctx.db.select('attempts', { question_id: id }));
  const dist = {}; for (const a of rows) { const k = a.chosen ?? '(blank)'; dist[k] = (dist[k] ?? 0) + 1; }
  return { question: q, reports, answer_distribution: dist, n_attempts: rows.length };
}

/** PATCH /api/admin/questions  body {id, status?: 'approved'|'verified'|'draft', note?, resolve_reports?: 'accepted'|'dismissed'} */
export async function patchAdminQuestion(ctx, body, actor) {
  await requireStaff(ctx, actor);
  const { db } = ctx, q = ctx.qById.get(body?.id); if (!q) throw notFound('question');
  if (body.status != null && !['approved', 'verified', 'draft'].includes(body.status)) throw invalid("status must be 'approved', 'verified' or 'draft'");
  if (body.resolve_reports != null && !['accepted', 'dismissed'].includes(body.resolve_reports)) throw invalid("resolve_reports must be 'accepted' or 'dismissed'");
  if (body.status === 'approved' && q.verification?.result !== 'pass') throw invalid('only machine-verified questions can be approved (verification.result must be pass)');
  let status = body.status ?? q.status;
  if (body.resolve_reports === 'accepted' && body.status == null) status = 'draft';      // an accepted report pulls the question from tests
  if (status !== q.status || body.note) {
    q.status = status; q.verification = { ...(q.verification ?? {}), teacher_review: status === 'approved' ? 'approved' : status === 'draft' ? 'rejected' : 'pending', ...(body.note ? { teacher_note: String(body.note).slice(0, 280) } : {}) };
    await db.update('questions', { id: q.id }, { status, json: q });
  }
  let resolved = 0;
  if (body.resolve_reports) for (const r of await db.select('question_reports', { question_id: q.id, status: 'open' })) { await db.update('question_reports', { id: r.id }, { status: body.resolve_reports, resolved_at: iso(ctx.now()) }); resolved++; }
  return { id: q.id, status: q.status, resolved_reports: resolved };
}

/** Profiles for the local switcher (testing phase only: no real auth). */
export async function listProfiles(ctx) { return { profiles: (await ctx.db.select('profiles', {}, { orderBy: 'created_at' })).map((p) => ({ id: p.id, display_name: p.display_name, role: p.role })) }; }
export async function createProfile(ctx, body) {
  const name = typeof body?.display_name === 'string' ? body.display_name.trim().slice(0, 40) : '';
  if (!name) throw invalid('display_name is required');
  const role = body.role ?? 'student'; if (!['student', 'teacher', 'admin'].includes(role)) throw invalid('role must be student, teacher or admin');
  const p = { id: makeId('p_', ctx.now()), display_name: name, role, settings_json: { minutes_per_day: 45, horizon_days: 7 }, created_at: iso(ctx.now()) };
  await ctx.db.insert('profiles', p); return p;
}
export async function ensureLocalProfiles(ctx) {
  if (await ctx.db.count('profiles', {})) return;
  for (const [id, display_name, role] of [['student-1', 'Student 1', 'student'], ['student-2', 'Student 2', 'student'], ['teacher-1', 'Teacher', 'teacher']])
    await ctx.db.insert('profiles', { id, display_name, role, settings_json: { minutes_per_day: 45, horizon_days: 7 }, created_at: iso(ctx.now()) });
}
