// Advanced Math families (M.ADV.*).
import { q, Q, lin, nz, byBand, reject, CONTEXT_NAMES } from './_kit.mjs';

const sgn = (v) => (v < 0 ? `- ${Math.abs(v)}` : `+ ${v}`);
const quad = (a, b, c) => lin([[a, 'x^2'], [b, 'x'], [c, '']]);

export default [
  {
    id: 'equiv-expand', skill: 'M.ADV.EQUIV', levels: [1, 2, 3, 4],
    gen(r, d) {
      // (px + s)(qx + t) -> A x^2 + B x + C ; ask full expression
      const p = byBand(d, [1, r.int(1, 4), r.int(2, 6)]), qq = byBand(d, [1, r.int(1, 3), r.int(2, 5)]);
      const s = nz(r, -9, 9), t = nz(r, -9, 9);
      const A = p * qq, B = p * t + s * qq, C = s * t;
      if (B === 0) reject('B0');
      const L = `(${lin([[p, 'x'], [s, '']])})(${lin([[qq, 'x'], [t, '']])})`;
      const w1 = quad(A, B, -C), w2 = quad(A, 0, C), w3 = quad(A, -B, C);
      const W = [[w1, 'SIGN-ERROR', 'The constant term has the wrong sign.', `${s} times ${t} is ${-C}.`, `${A}*x**2 + ${B}*x - (${C})`],
        [w2, 'PARTIAL', 'The middle (outer + inner) terms were dropped.', 'Multiply firsts and lasts only.', `${A}*x**2 + ${C}`],
        [w3, 'SIGN-ERROR', 'The middle term has the wrong sign.', 'Subtract the cross terms.', `${A}*x**2 - (${B})*x + ${C}`]];
      return {
        skill: this.skill, micro: ['M.ADV.EQUIV#EXPAND', 'M.ADV.EQUIV#POLYNOMIAL-OPS'], difficulty: d, drivers: d >= 4 ? ['MULTI-STEP'] : [],
        sig: `${p},${s},${qq},${t}`,
        stem: `Which expression is equivalent to $${L}$?`,
        answer: { value: quad(A, B, C), key_value: quad(A, B, C), tex: `$${quad(A, B, C)}$`, py: `${A}*x**2 + ${B}*x + ${C}` },
        wrong: W.map(([tex, trap, why, think, py]) => ({ value: tex, key_value: tex, tex: `$${tex}$`, trap: trap === 'PARTIAL' ? 'PARTIAL-CREDIT-SOLUTION' : trap, why, think, py, trapPy: py })),
        solvePy: `x = sp.Symbol('x')\ncomputed = sp.expand((${p}*x + (${s}))*(${qq}*x + (${t})))`,
        steps: [`First: ${A}x². Outer + inner: ${p * t}x ${sgn(s * qq)}x = ${B}x. Last: ${C}.`, `Result: ${quad(A, B, C)}.`],
        insight: 'FOIL: four products, then combine the two middle terms.', plug: 'Plug in x = 1 into the original and each choice; only the equivalent one matches.',
      };
    },
  },
  {
    id: 'nleq-sum-roots', skill: 'M.ADV.NLEQ', levels: [2, 3, 4, 5],
    gen(r, d) {
      const r1 = nz(r, -9, 9), r2 = nz(r, -9, 9); if (r1 === r2 || r1 === -r2) reject('same');
      const a = byBand(d, [1, r.int(1, 3), r.int(2, 4)]);
      const B = -a * (r1 + r2), C = a * r1 * r2;
      const ask = byBand(d, ['larger', 'sum', r.pick(['product', 'sum'])]);
      const ans = ask === 'larger' ? Math.max(r1, r2) : ask === 'sum' ? r1 + r2 : r1 * r2;
      const cand = { larger: Math.max(r1, r2), smaller: Math.min(r1, r2), sum: r1 + r2, negsum: -(r1 + r2), product: r1 * r2, negprod: -r1 * r2, negLarger: -Math.max(r1, r2) };
      const meta = { larger: ['ASKED-DIFFERENT', 'That is one solution, not what was asked.', 'Find a root, done.', 'max(sols)'], smaller: ['ASKED-DIFFERENT', 'That is the smaller solution.', 'Pick the first root I found.', 'min(sols)'], sum: ['ASKED-DIFFERENT', 'That is the sum of the solutions.', 'Add the roots.', 'sum(sols)'], negsum: ['SIGN-ERROR', 'Sum of roots is -b/a; the sign was missed.', 'Sum of roots = b/a.', '-sum(sols)'], product: ['ASKED-DIFFERENT', 'That is the product of the solutions.', 'Multiply the roots.', 'sols[0]*sols[1]'], negprod: ['SIGN-ERROR', 'Product of roots is c/a, not -c/a.', 'Product = -c/a.', '-sols[0]*sols[1]'], negLarger: ['SIGN-ERROR', 'The factor (x - r) gives root r, not -r.', '(x - 3) means x = -3.', '-max(sols)'] };
      const pool = r.shuffle(Object.keys(cand).filter((k) => k !== ask && cand[k] !== ans));
      const picks = []; const usedV = new Set([ans]);
      for (const k of pool) { if (!usedV.has(cand[k])) { usedV.add(cand[k]); picks.push(k); } if (picks.length === 3) break; }
      if (picks.length < 3) reject('few');
      const what = { larger: 'the greater of the two solutions', sum: 'the sum of the solutions', product: 'the product of the solutions' }[ask];
      return {
        skill: this.skill, micro: ['M.ADV.NLEQ#QUADRATIC-SOLVE'], difficulty: d, drivers: ask !== 'larger' ? ['ASK-DIFFERENT-THING'] : [],
        sig: `${a},${B},${C},${ask}`,
        stem: `$${quad(a, B, C)} = 0$\n\nWhat is ${what} to the given equation?`,
        answer: { value: ans, tex: `$${ans}$` },
        wrong: picks.map((k) => ({ value: cand[k], tex: `$${cand[k]}$`, trap: meta[k][0], why: meta[k][1], think: meta[k][2], trapPy: meta[k][3] })),
        solvePy: `x = sp.Symbol('x')\nsols = sorted(sp.solve(${a}*x**2 + (${B})*x + (${C}), x))\nassert len(sols) == 2\ncomputed = ${meta[ask][3]}`,
        steps: [a > 1 ? `Divide by ${a}: ${quad(1, B / a, C / a)} = 0.` : 'Factor the quadratic.', `(x ${sgn(-r1)})(x ${sgn(-r2)}) = 0, so x = ${r1} or x = ${r2}.`, `${what[0].toUpperCase() + what.slice(1)}: ${ans}.`],
        insight: ask === 'sum' ? 'Sum of roots = -b/a; no need to solve.' : ask === 'product' ? 'Product of roots = c/a; no need to solve.' : 'Factor, set each factor to zero.',
        desmos: `Graph y = ${quad(a, B, C)} and read the x-intercepts.`,
      };
    },
  },
  {
    id: 'nleq-discriminant', skill: 'M.ADV.NLEQ', levels: [3, 4, 5],
    gen(r, d) {
      // a x^2 + b x + c = 0 has exactly one real solution, b > 0  ->  b^2 = 4ac, b = 2n where ac = n^2
      const n = r.int(2, 18);
      const divs = []; for (let a = 1; a <= 12; a++) if ((n * n) % a === 0) divs.push(a);
      const a = d <= 3 ? 1 : r.pick(divs.filter((x) => x > 1).length ? divs.filter((x) => x > 1) : divs);
      const c = (n * n) / a, bAns = 2 * n;
      const flipSign = d >= 5 && r.int(0, 1) === 1;      // ask for negative b
      const ans = flipSign ? -bAns : bAns;
      const w = [[flipSign ? -n : n, 'DOUBLE-HALF', 'One solution needs b² = 4ac; this used b² = ac.', 'b is the square root of a times c.', `${flipSign ? '-' : ''}sp.sqrt(${a}*${c})`],
        [4 * n * n, 'STOPPED-EARLY', 'This is b², not b.', 'Discriminant zero gives 4ac.', `4*${a}*${c}`],
        [flipSign ? bAns : 2 * c === bAns ? bAns + 4 : 2 * c, flipSign ? 'SIGN-ERROR' : 'WRONG-FORMULA', flipSign ? 'b was stated to be negative.' : 'Doubling c is not the condition; b² - 4ac must be 0.', flipSign ? 'Take the positive square root.' : 'Perfect square: b = 2c.', flipSign ? `${bAns}` : `${2 * c === bAns ? bAns + 4 : 2 * c}`]];
      if (new Set([ans, ...w.map((x) => x[0])]).size < 4) reject('coll');
      return {
        skill: this.skill, micro: ['M.ADV.NLEQ#DISCRIMINANT-CONDITION'], difficulty: d, drivers: ['PARAMETRIC', ...(flipSign ? ['HIDDEN-CONSTRAINT'] : [])],
        sig: `${a},${c},${flipSign}`,
        stem: `$${a === 1 ? '' : a}x^2 + bx + ${c} = 0$\n\nIn the given equation, $b$ is a ${flipSign ? 'negative' : 'positive'} constant. If the equation has exactly one real solution, what is the value of $b$?`,
        answer: { value: ans, tex: `$${ans}$` },
        wrong: w.map(([v, trap, why, think, py]) => ({ value: v, tex: `$${v}$`, trap, why, think, trapPy: py })),
        solvePy: `b = sp.Symbol('b', ${flipSign ? 'negative' : 'positive'}=True)\nsols = sp.solve(sp.Eq(b**2 - 4*${a}*${c}, 0), b)\nassert len(sols) == 1\ncomputed = sols[0]`,
        steps: ['Exactly one real solution means the discriminant b² - 4ac = 0.', `b² = 4(${a})(${c}) = ${4 * n * n}.`, `b is ${flipSign ? 'negative' : 'positive'}, so b = ${ans}.`],
        insight: 'One real solution ⇔ b² - 4ac = 0 (the parabola just touches the x-axis).',
      };
    },
  },
  {
    id: 'nleq-extraneous', skill: 'M.ADV.NLEQ', levels: [4, 5],
    gen(r, d) {
      // sqrt(x + a) = x - b  -> square: x + a = (x-b)^2
      const s = r.int(1, 7), b = r.int(-3, 6), xg = s + b;        // good root: sqrt(xg + a) = s
      const a = s * s - xg;
      // other root of x^2 - (2b+1)x + (b^2 - a) = 0
      const sum = 2 * b + 1, xb = sum - xg;
      if (xb === xg) reject('double');
      if (xb - b >= 0 && xb + a >= 0) reject('both valid');
      return {
        skill: this.skill, micro: ['M.ADV.NLEQ#EXTRANEOUS-SOLUTION'], difficulty: d, drivers: ['HIDDEN-CONSTRAINT', 'MULTI-STEP'], hypothesis: ['H.EXTRANEOUS'],
        sig: `${a},${b}`,
        stem: `$\\sqrt{x ${sgn(a)}} = x ${sgn(-b)}$\n\nWhat is the solution to the given equation?`,
        answer: { value: xg, tex: `$${xg}$` },
        wrong: [
          { value: xb, tex: `$${xb}$`, trap: 'EXTRANEOUS-KEPT', why: `Checking x = ${xb} makes the right side negative, but a square root is never negative.`, think: 'Both roots of the quadratic work.', trapPy: `${xb}` },
          { value: sum, tex: `$${sum}$`, trap: 'ASKED-DIFFERENT', why: 'This is the sum of both quadratic roots.', think: 'Add the roots together.', trapPy: `${sum}` },
          { value: -xg === xb || -xg === sum ? xg + 1 : -xg, tex: `$${-xg === xb || -xg === sum ? xg + 1 : -xg}$`, trap: 'SIGN-ERROR', why: 'A sign was lost when factoring.', think: 'The factor (x - r) gives -r.', trapPy: `${-xg === xb || -xg === sum ? xg + 1 : -xg}` },
        ],
        solvePy: `x = sp.Symbol('x', real=True)\nsols = [v for v in sp.solve(sp.Eq(sp.sqrt(x + (${a})), x - (${b})), x)]\nassert len(sols) == 1\ncomputed = sols[0]`,
        steps: [`Square both sides: x ${sgn(a)} = (x ${sgn(-b)})².`, `Solve the quadratic: x = ${Math.min(xg, xb)} or x = ${Math.max(xg, xb)}.`, `Check each in the ORIGINAL: only x = ${xg} works.`],
        insight: 'Squaring can create fake solutions. Always check in the original equation.',
      };
    },
  },
  {
    id: 'nlfunc-exp', skill: 'M.ADV.NLFUNC', levels: [2, 3, 4, 5],
    gen(r, d) {
      const P0 = r.pick([200, 500, 800, 1200, 1500, 2400, 3000, 5000]);
      const pct = r.pick([2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25]);
      const grow = d <= 3 ? true : r.int(0, 1) === 1;
      const thing = r.pick([['bacteria in a sample', 'hour'], ['followers of an account', 'month'], ['trees in a reforestation project', 'year'], ['users of an app', 'week']]);
      const f = grow ? 1 + pct / 100 : 1 - pct / 100;
      const F = (x) => +x.toFixed(2);
      const ans = `${P0}(${F(f)})^t`;
      const ww = [
        [`${P0}(${F(pct / 100)})^t`, 'PERCENT-OF-VS-CHANGE', `${F(pct / 100)} keeps only ${pct}% each ${thing[1]}; the base must be ${F(f)}.`, `${pct}% means multiply by ${F(pct / 100)}.`],
        [`${P0}(${F(grow ? 1 - pct / 100 : 1 + pct / 100)})^t`, 'SIGN-ERROR', grow ? 'This base shrinks the amount; the quantity grows.' : 'This base grows the amount; the quantity decreases.', 'The base just involves 1 and the percent.'],
        [`${P0}(1 ${grow ? '+' : '-'} ${pct}t)`.replace('(1 ', '(1 '), 'WRONG-FORMULA', 'This is linear change; a fixed percent per period is exponential.', `${pct}% per ${thing[1]} means add ${pct} each time.`],
      ];
      const py = (s) => s.replace(/\^/g, '**').replace(/(\d)\(/g, '$1*(').replace(/(\d)t/g, '$1*t');
      return {
        skill: this.skill, micro: ['M.ADV.NLFUNC#EXP-GROWTH-DECAY'], difficulty: d, context: 'science', drivers: d >= 4 ? ['REPRESENTATION-SWITCH'] : [],
        sig: `${P0},${pct},${grow}`,
        stem: `The number of ${thing[0]} was ${P0.toLocaleString('en-US')} at the start of a study and ${grow ? 'increased' : 'decreased'} by ${pct}% each ${thing[1]}. Which function $N$ gives the number of ${thing[0]} $t$ ${thing[1]}s after the start of the study?`,
        answer: { value: ans, key_value: ans, tex: `$N(t) = ${ans}$`, py: py(ans) },
        wrong: ww.map(([e, trap, why, think]) => ({ value: e, key_value: e, tex: `$N(t) = ${e}$`, trap, why, think, py: py(e) })),
        solvePy: `t = sp.Symbol('t')\ncomputed = ${P0}*(sp.nsimplify('${F(f)}'))**t`,
        steps: [`A ${pct}% ${grow ? 'increase' : 'decrease'} multiplies by 1 ${grow ? '+' : '-'} ${F(pct / 100)} = ${F(f)} each ${thing[1]}.`, `Start at ${P0}: N(t) = ${ans}.`],
        insight: 'Percent change per period → exponential: start × (1 ± rate)^t.',
      };
    },
  },
  {
    id: 'nlfunc-vertex', skill: 'M.ADV.NLFUNC', levels: [3, 4, 5],
    gen(r, d) {
      const h = nz(r, -8, 8), k = r.int(-20, 20), a = byBand(d, [1, r.pick([1, 2, -1]), r.pick([2, 3, -2, -3])]);
      const B = -2 * a * h, C = a * h * h + k;
      const ask = d >= 5 ? 'min' : 'x';
      const extreme = a > 0 ? 'minimum' : 'maximum';
      const ans = ask === 'x' ? h : k;
      const cand = [[-h, 'SIGN-ERROR', 'The vertex x-coordinate is -b/(2a); the sign was dropped.', 'x-vertex = b/(2a).', `${-h}`], [C, 'ASKED-DIFFERENT', 'That is the y-intercept f(0), not the vertex value.', 'The constant is the minimum.', `${C}`], [ask === 'x' ? k : h, 'ASKED-DIFFERENT', ask === 'x' ? 'That is the y-coordinate of the vertex.' : 'That is the x-coordinate of the vertex.', 'The vertex has two numbers; pick one.', `${ask === 'x' ? k : h}`], [B, 'WRONG-VARIABLE', 'That is the coefficient b, not a vertex coordinate.', 'Read b off the equation.', `${B}`]];
      const seen = new Set([ans]); const picks = [];
      for (const c of r.shuffle(cand)) { if (!seen.has(c[0])) { seen.add(c[0]); picks.push(c); } if (picks.length === 3) break; }
      if (picks.length < 3) reject('few');
      return {
        skill: this.skill, micro: ['M.ADV.NLFUNC#QUADRATIC-FORMS'], difficulty: d, drivers: ['REPRESENTATION-SWITCH'],
        sig: `${a},${B},${C},${ask}`,
        stem: ask === 'x' ? `The function $f$ is defined by $f(x) = ${quad(a, B, C)}$. For what value of $x$ does $f(x)$ reach its ${extreme}?` : `The function $f$ is defined by $f(x) = ${quad(a, B, C)}$. What is the ${extreme} value of $f(x)$?`,
        answer: { value: ans, tex: `$${ans}$` },
        wrong: picks.map(([v, trap, why, think, py]) => ({ value: v, tex: `$${v}$`, trap, why, think, trapPy: py })),
        solvePy: `x = sp.Symbol('x')\nf = ${a}*x**2 + (${B})*x + (${C})\nxv = sp.solve(sp.diff(f, x), x)[0]\ncomputed = ${ask === 'x' ? 'xv' : 'f.subs(x, xv)'}`,
        steps: [`x-vertex = -b/(2a) = ${-B}/${2 * a} = ${h}.`, ...(ask === 'x' ? [] : [`f(${h}) = ${k}.`])],
        insight: 'Vertex x = -b/(2a); plug it back in for the extreme value.', desmos: `Graph y = ${quad(a, B, C)} and click the vertex.`,
      };
    },
  },
];
