/* ============================================================
   NAV, CHROME, INTERACTION POLISH & PRACTICE STUDIO
   ============================================================ */
const VIEWS = ['dash','practice','test','lessons','progress','review','bank','plan','rewards','watch','profile','settings'];
let currentView = 'dash';
function go(name){
  if(!$('#v-'+name)) name = 'dash';
  currentView = name;
  try{ sessionStorage.setItem('strive_view', name); }catch(e){}
  if(name==='lessons' && typeof closeLesson === 'function') closeLesson(true);

  /* The fade out / fade in is handled by 17-motion.js (one system, interruptible).
     Here we only swap which view is visible. */
  const newV = $('#v-'+name);
  $$('.view').forEach(v => v.classList.add('hidden'));
  newV.classList.remove('hidden');
  const v = newV;
  $$('#nav button, #tabbar button').forEach(b => b.classList.toggle('active', b.dataset.v===name || (b.dataset.more!==undefined && MORE_VIEWS.indexOf(name)>-1)));
  $$('#nav button, #tabbar button').forEach(b => { if(b.classList.contains('active')) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
  placePill();
  scrollTo({top:0, behavior:'instant'});
  if(name==='dash') animateDash();
  if(name==='practice') renderPractice();
  if(name==='test') renderTestStart();
  if(name==='lessons') renderLessons();
  if(name==='progress') renderProgress();
  if(name==='review') renderReview();
  if(name==='bank' && typeof renderBank === 'function') renderBank();
  if(name==='plan' && typeof renderPlan === 'function') renderPlan();
  if(name==='rewards' && typeof renderRewards === 'function') renderRewards();
  if(name==='profile' && typeof renderProfile === 'function') renderProfile();
  if(name==='settings' && typeof renderSettings === 'function') renderSettings();
  observeReveals();
}
$$('#nav button[data-v], #tabbar button[data-v]').forEach(b => b.addEventListener('click', () => go(b.dataset.v)));
function placePill(){}
addEventListener('resize', placePill);

const MORE_VIEWS = ['plan','test','lessons','progress','review','rewards','profile','settings'];
const SUPPORTS_VT = CSS.supports('animation-timeline','view()');
let revealIO = null;
function observeReveals(){
  if(SUPPORTS_VT || REDUCED) return;
  if(!revealIO) revealIO = new IntersectionObserver(es => es.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); revealIO.unobserve(e.target); } }), {threshold:.12});
  $$('.rv:not(.in)').forEach(el => revealIO.observe(el));
}
(function sticky(){
  const s = document.createElement('div'); s.style.cssText='position:absolute;top:0;left:0;width:1px;height:8px;pointer-events:none';
  document.body.prepend(s);
  new IntersectionObserver(e => { const tb=$('#topbar'); if(tb) tb.classList.toggle('stuck', !e[0].isIntersecting); }).observe(s);
})();
// card spotlight + magnetic buttons (pointer events, no scroll listeners)
document.addEventListener('pointermove', e => {
  const c = e.target.closest && e.target.closest('.card');
  if(c){ const r=c.getBoundingClientRect(); c.style.setProperty('--mx',(e.clientX-r.left)+'px'); c.style.setProperty('--my',(e.clientY-r.top)+'px'); }
});
document.addEventListener('pointerout', e => { const m = e.target.closest && e.target.closest('[data-mag]'); if(m && !m.contains(e.relatedTarget)){ m.style.setProperty('--tx','0px'); m.style.setProperty('--ty','0px'); } });

/* ============================================================
   DASHBOARD (CLEAN, FOCUS-FIRST SURFACE)
   ============================================================ */
function daysLeft(){ const d=state.profile.testDate; if(!d) return 0; return Math.max(0, Math.ceil((new Date(d+'T00:00:00') - new Date())/DAY)); }
function fmtDate(s){ return s ? new Date(s+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : '—'; }
function refreshChrome(){
  ['streakN','streakM'].forEach(id=>{ const e=$('#'+id); if(e) e.textContent = state.streak; });
  const n=$('#sideName'); if(n) n.textContent = state.profile.name || 'You';
  if(typeof applyAvatar==='function') applyAvatar();
}
function greeting(){ const h=new Date().getHours(); return h<5?'Late night':h<12?'Good morning':h<18?'Good afternoon':'Good evening'; }
function nextLesson(){ return LESSONS.find(l=>!state.lessonDone[l.id]) || null; }
function animateDash(){
  refreshChrome();
  const pr = estPredicted(), goal = state.profile.goal || 1400, d = daysLeft(), name = state.profile.name || 'there';
  $('#greet').innerHTML = esc(greeting())+', <em>Future '+String(goal||1600)+'.</em>';
  $('#dashsub').innerHTML = pr==null
    ? 'Small steps every day lead to big results. <b>'+esc(name)+'</b>, your goal is <b>'+goal+'</b> with <b>'+d+'</b> days to go. Answer a few questions in each section and we will estimate where you stand.'
    : 'Small steps every day lead to big results. <b>'+esc(name)+'</b>, you are <b>'+Math.max(0,goal-pr)+'</b> points from <b>'+goal+'</b>, with <b>'+d+'</b> days to go.';
  if($('#sGoal')) $('#sGoal').textContent = goal;
  if($('#sDate')) $('#sDate').textContent = fmtDate(state.profile.testDate).replace(/, \d{4}/,'');
  if($('#sDays')) $('#sDays').textContent = d+' days left';
  const prev = state.trend.length>1 ? state.trend[state.trend.length-2].score : null;
  if(pr==null){ $('#sPred').textContent='—'; $('#sPredDelta').textContent='Needs '+MIN_ATTEMPTS+'+ answers per section'; }
  else { countTo($('#sPred'), pr, 1600); const dl = prev==null?0:pr-prev; $('#sPredDelta').textContent = prev==null ? 'First estimate' : (dl>=0?'+':'')+dl+' since last session'; }
  const ready = state.answered ? Math.min(100, Math.round(accuracy()*.9+10)) : 0, pc=$('#pcRing'), t0 = performance.now();
  if(pc) (function tick(now){ const p = REDUCED?1:Math.min((now-t0)/1500,1), e=1-Math.pow(1-p,3), v=Math.round(e*ready); pc.style.setProperty('--v',v); $('#pcN').textContent=v+'%'; if(p<1) requestAnimationFrame(tick); })(t0);
  if($('#pcTests')) $('#pcTests').textContent = state.testsDone||0;
  renderSpark();
  const mins = state.studyMin.reduce((a,b)=>a+b,0);
  if($('#sTime')) countTo($('#sTime'), mins/60, 1200, '', 1, '<span class="unit">hr</span>');
  if($('#sQs')) countTo($('#sQs'), state.answered, 1400);
  if($('#sAcc')) countTo($('#sAcc'), accuracy(), 1200, '', 0, '<span class="unit">%</span>');
  const rwA = Math.round(secAcc('rw')*100), mA = Math.round(secAcc('m')*100);
  const rwS = sectionScore('rw'), mS = sectionScore('m');
  $('#rwScore').textContent = rwS==null?'—':rwS; $('#mScore').textContent = mS==null?'—':mS;
  $('#rwAcc').textContent = secAttempts('rw') ? rwA+'%' : 'No data'; $('#mAcc').textContent = secAttempts('m') ? mA+'%' : 'No data';
  const dr = (rwS!=null && state.base) ? rwS-state.base.rw : null, dm = (mS!=null && state.base) ? mS-state.base.m : null;
  $('#rwDelta').textContent = dr==null?'New':(dr>=0?'+':'')+dr; $('#mDelta').textContent = dm==null?'New':(dm>=0?'+':'')+dm;
  const nl = nextLesson(), doneN = LESSONS.filter(l=>state.lessonDone[l.id]).length;
  setTimeout(()=>{ if($('#rwBar')) $('#rwBar').style.width = rwS==null?'0%':(rwS-200)/6+'%'; if($('#mBar')) $('#mBar').style.width = mS==null?'0%':(mS-200)/6+'%'; if($('#dashBar1')) $('#dashBar1').style.width=Math.round(doneN/LESSONS.length*100)+'%'; },300);
  const w = weakest();
  if(w){
    $('#weakName').textContent = TOPICS[w.key].short;
    $('#weakSub').textContent = Math.round(w.acc*100)+'% accuracy, '+w.attempts+' attempts';
    setTimeout(()=>{ if($('#weakBar')) $('#weakBar').style.width = Math.round(w.acc*100)+'%'; },300);
    $('#planT1').textContent = 'Fix '+TOPICS[w.key].short.toLowerCase();
    $('#planP1').textContent = 'This is your weakest topic at '+Math.round(w.acc*100)+'%. One focused set is the quickest way to move your '+(TOPICS[w.key].sec==='m'?'math':'reading and writing')+' score.';
    $('#planN1').textContent = '8';
  } else {
    $('#weakName').textContent = 'Not enough data yet'; $('#weakSub').textContent = 'Answer '+MIN_ATTEMPTS+'+ questions in a topic'; if($('#weakBar')) $('#weakBar').style.width='0%';
    $('#planT1').textContent = 'Start with a mixed set';
    $('#planP1').textContent = 'A short mixed set across all topics shows us where you stand and what to work on first.';
    $('#planN1').textContent = '10';
  }
  if(nl){ $('#planT2').textContent = (doneN?'Next lesson: ':'Start a lesson: ')+nl.t; $('#planP2').textContent = 'A short read with a worked example, then practice on the same topic.'; $('#planN2').textContent = (nl.s.match(/(\d+) min/)||[0,'8'])[1]; }
  else { $('#planT2').textContent = 'All lessons complete'; $('#planP2').textContent = 'You have finished every lesson. Keep the skills fresh with practice sets.'; $('#planN2').textContent = '0'; }
  if($('#recTitle')) $('#recTitle').textContent = nl ? (doneN?'Next up: ':'Start with: ')+nl.t : 'All lessons complete';
  if($('#recDesc')) $('#recDesc').textContent = nl ? doneN+' of '+LESSONS.length+' lessons complete.' : 'You finished all '+LESSONS.length+' lessons.';
  $('#planN3').textContent = state.missed.length;
  $('#planP3').textContent = state.missed.length ? 'Missed questions stay here until you answer them correctly. That is where most of the learning happens.' : 'Nothing to re-try yet. Missed questions will queue up here.';
  if($('#weeklyDash')) renderWeekly('#weeklyDash', state.studyMin);
  if($('#weekTag')) $('#weekTag').textContent = mins+' min';
}
function renderSpark(){
  const sp = $('#pcSpark'); if(!sp) return;
  if(!state.trend.length){ sp.innerHTML='<div class="muted" style="font-size:12.5px;padding-top:10px">Your score trend appears after your first scored session.</div>'; return; }
  const pts=state.trend.slice(-10).map(p=>p.score), W=300,H=70,lo=Math.min(...pts)-20,hi=Math.max(...pts)+20;
  const X=i=>pts.length>1?i/(pts.length-1)*W:W/2, Y=v=>4+(1-(v-lo)/(hi-lo))*(H-8);
  let d=''; pts.forEach((v,i)=>{ d+=(i?'L':'M')+X(i).toFixed(1)+' '+Y(v).toFixed(1); });
  sp.innerHTML='<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" aria-label="Score trend"><defs><linearGradient id="spg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22c55e" stop-opacity=".28"/><stop offset="1" stop-color="#22c55e" stop-opacity="0"/></linearGradient></defs><path class="sa" d="'+d+' L'+W+' '+H+' L0 '+H+' Z"/><path class="sl" id="slLine" d="'+d+'"/></svg>';
  const ln=$('#slLine'), len=Math.ceil(ln.getTotalLength?ln.getTotalLength():600); ln.style.setProperty('--len',len);
  const card=$('#progCard'); card.classList.remove('on'); void card.offsetWidth; setTimeout(()=>card.classList.add('on'),150);
}
function hydrate(root=document){
  root.querySelectorAll('[data-img]').forEach(el => { const k=el.dataset.img; if(IMG[k]) el.src=IMG[k]; });
  root.querySelectorAll('[data-bg]').forEach(el => { const k=el.dataset.bg; if(IMG[k]) el.style.backgroundImage='url('+IMG[k]+')'; });
}
function renderWeekly(sel, arr){
  const el=$(sel); if(!el) return;
  const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], mx=Math.max(45,...arr), ti=todayIdx();
  el.innerHTML = arr.map((v,i)=>{
    const h = v ? Math.max(12, Math.round(v/mx*110)) : 6;
    return '<div class="wcol'+(i===ti?' today':'')+'"><div class="wval mono">'+(v?v+'m':'')+'</div><div class="wbar"><i data-h="'+h+'px"></i></div><div class="wd">'+days[i]+'</div></div>';
  }).join('');
  requestAnimationFrame(()=>el.querySelectorAll('.wbar>i').forEach(b=>b.style.height=b.dataset.h));
}
function drillWeak(){ const w = weakest(); startPractice(w ? w.key : 'mixed'); }

/* ============================================================
   PRACTICE STUDIO (R&W + MATH + STICKY SESSION BUILDER SIDE PANEL)
   ============================================================ */
const PR_STATE = {
  sec: 'rw',
  dom: 'all',
  skill: '',
  diff: 'all',
  pool: 'all',
  count: 10,
  timed: false
};

const PR_DOMAINS = {
  rw: [
    { key: 'rw_craft', name: 'Craft & Structure', icon: 'ph-compass-tool', desc: 'Words in context, text structure, purpose, and cross-text connections.' },
    { key: 'rw_info', name: 'Information & Ideas', icon: 'ph-magnifying-glass', desc: 'Central ideas, command of evidence (textual & quantitative), and inferences.' },
    { key: 'rw_conv', name: 'Standard English Conventions', icon: 'ph-text-aa', desc: 'Boundaries, punctuation, verb tense, subject-verb agreement, and modifiers.' },
    { key: 'rw_expr', name: 'Expression of Ideas', icon: 'ph-pen-nib', desc: 'Rhetorical synthesis and logical transitions between ideas.', mapTopic: 'rw_craft' }
  ],
  m: [
    { key: 'math_algebra', name: 'Algebra', icon: 'ph-function', desc: 'Linear equations, linear functions, systems of two linear equations, and inequalities.' },
    { key: 'math_adv', name: 'Advanced Math', icon: 'ph-chart-scatter', desc: 'Nonlinear functions, quadratic/exponential equations, and equivalent expressions.' },
    { key: 'math_psda', name: 'Problem-Solving & Data Analysis', icon: 'ph-chart-bar', desc: 'Ratios, rates, percentages, probability, scatterplots, and margin of error.', mapTopic: 'math_algebra' },
    { key: 'math_geom', name: 'Geometry & Trigonometry', icon: 'ph-triangle', desc: 'Area & volume, lines, angles, triangles, right-triangle trig, and circles.', mapTopic: 'math_adv' }
  ]
};

function getPracticePool(){
  const all = typeof allQ === 'function' ? allQ() : [];
  const e = typeof E === 'function' ? E() : { seen: {} };
  return all.filter(it => {
    if (it.sec !== PR_STATE.sec) return false;
    if (PR_STATE.dom !== 'all') {
      const domObj = PR_DOMAINS[PR_STATE.sec].find(d => d.key === PR_STATE.dom);
      if (domObj) {
        const matchDom = (it.dom || '').toLowerCase().includes(domObj.name.split(' ')[0].toLowerCase()) || it.t === domObj.key || it.t === domObj.mapTopic;
        if (!matchDom) return false;
      }
    }
    if (PR_STATE.skill && it.skill !== PR_STATE.skill) return false;
    if (PR_STATE.diff !== 'all' && it.diff !== PR_STATE.diff) return false;
    const seen = e.seen && e.seen[it.q.id || it.q.q];
    if (PR_STATE.pool === 'unseen' && seen) return false;
    if (PR_STATE.pool === 'missed' && seen !== 'miss') return false;
    return true;
  });
}

/* ---------- Practice studio: built once, then updated in place so toggles glide ---------- */
function pxDomItems(d, secItems){
  const first = d.name.split(' ')[0].toLowerCase();
  return secItems.filter(it => (it.dom || '').toLowerCase().includes(first) || it.t === d.key || it.t === d.mapTopic);
}
function pxLabel(acc){ return acc == null ? 'New' : acc >= 80 ? 'Strong' : acc >= 60 ? 'Solid' : 'Needs work'; }

function pxBuild(root){
  root.innerHTML = `
    <div class="px" data-sec="rw" data-timed="0">
      <header class="px-hero">
        <div class="px-hero-copy">
          <span class="px-eyebrow"><i class="ph-fill ph-seal-check"></i>SAT practice</span>
          <h1>Practice studio</h1>
          <p>Pick a domain to drill, or start a sprint and let the studio balance the set for you.</p>
        </div>
        <figure class="px-quote">
          <blockquote>Small steps every day <em>lead to big results.</em></blockquote>
          <figcaption>Jamals Academy</figcaption>
        </figure>
        <img class="px-art" src="assets/img/practice-hero.webp" width="1000" height="1000" alt="" decoding="async">
      </header>

      <div class="px-bar">
        <div class="px-seg lg" data-seg="solid" role="group" aria-label="Section">
          <button type="button" class="on" data-pr-sec="rw"><i class="ph-bold ph-book-open-text"></i>Reading &amp; Writing</button>
          <button type="button" data-pr-sec="m"><i class="ph-bold ph-function"></i>Math</button>
        </div>
        <div class="px-ctl"><span>Drill length</span>
          <div class="px-seg" data-seg role="group" aria-label="Drill length">
            ${[5, 10, 15, 20].map(n => `<button type="button" data-pr-cnt="${n}">${n}</button>`).join('')}
          </div>
        </div>
        <div class="px-ctl"><span>Pacing</span>
          <div class="px-seg" data-seg role="group" aria-label="Pacing">
            <button type="button" data-pr-time="0">Untimed</button>
            <button type="button" data-pr-time="1">Timed</button>
          </div>
        </div>
      </div>

      <section class="px-quick" aria-label="Quick starts">
        <article class="px-sprint">
          <span class="px-ico"><i class="ph-fill ph-lightning"></i></span>
          <h3>Mixed adaptive sprint</h3>
          <p>A fast <b class="px-n" id="pxSprintN">10</b>-question set that balances every <span id="pxSprintSec">Reading &amp; Writing</span> domain.</p>
          <div class="px-sprint-foot">
            <button type="button" class="btn acc lg" id="prSprintBtn">Start sprint<i class="ph ph-arrow-right"></i></button>
            <span class="px-mode"><i class="ph ph-timer"></i><b id="pxMode">Untimed</b></span>
          </div>
        </article>
        <button type="button" class="px-row" id="prWeakBtn">
          <span class="px-ico sm"><i class="ph-fill ph-target"></i></span>
          <span class="px-row-t"><b>Focus on weakest area</b><small id="pxWeakSub">Finds the topic costing you the most points.</small></span>
          <i class="ph ph-arrow-right"></i>
        </button>
        <button type="button" class="px-row" id="prRetryBtn">
          <span class="px-ico sm"><i class="ph-fill ph-arrows-clockwise"></i></span>
          <span class="px-row-t"><b>Re-try missed questions</b><small id="pxRetrySub">Nothing missed yet.</small></span>
          <i class="ph ph-arrow-right"></i>
        </button>
      </section>

      <section class="px-domains" id="pxDomains" aria-live="polite"></section>
    </div>`;

  root.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.prSec) return pxSetSection(b.dataset.prSec);
    if (b.dataset.prCnt) { PR_STATE.count = +b.dataset.prCnt; return pxSync(true); }
    if (b.dataset.prTime) { PR_STATE.timed = b.dataset.prTime === '1'; return pxSync(true); }
    if (b.id === 'prSprintBtn') {
      const pool = shuffle((typeof allQ === 'function' ? allQ() : []).filter(i => i.sec === PR_STATE.sec)).slice(0, PR_STATE.count || 10);
      if (!pool.length) { toast('No questions available', 'ph-warning'); return; }
      return startList(pool, { timed: PR_STATE.timed });
    }
    if (b.id === 'prWeakBtn') return drillWeak();
    if (b.id === 'prRetryBtn') { if (!b.disabled) startRetry(); return; }
    if (b.dataset.startDom) {
      const all = typeof allQ === 'function' ? allQ() : [];
      const secItems = all.filter(i => i.sec === PR_STATE.sec);
      const domObj = PR_DOMAINS[PR_STATE.sec].find(d => d.key === b.dataset.startDom);
      const match = domObj ? pxDomItems(domObj, secItems) : [];
      const set = shuffle(match.length ? match : secItems).slice(0, PR_STATE.count || 10);
      if (!set.length) { toast('No questions in this domain', 'ph-warning'); return; }
      startList(set, { timed: PR_STATE.timed });
    }
  });
}

/* keep every control, label and counter in step with PR_STATE (no re-render) */
function pxSync(animate){
  const px = $('#practiceRoot .px'); if (!px) return;
  px.dataset.sec = PR_STATE.sec; px.dataset.timed = PR_STATE.timed ? '1' : '0';
  px.querySelectorAll('[data-pr-sec]').forEach(b => b.classList.toggle('on', b.dataset.prSec === PR_STATE.sec));
  px.querySelectorAll('[data-pr-cnt]').forEach(b => b.classList.toggle('on', +b.dataset.prCnt === PR_STATE.count));
  px.querySelectorAll('[data-pr-time]').forEach(b => b.classList.toggle('on', (b.dataset.prTime === '1') === PR_STATE.timed));
  const set = (el, txt) => { if (el && el.textContent !== txt) { el.textContent = txt; if (animate && window.Motion) Motion.tick(el); } };
  set($('#pxSprintN', px), String(PR_STATE.count));
  set($('#pxMode', px), PR_STATE.timed ? 'Timed' : 'Untimed');
  px.querySelectorAll('.px-go .px-n').forEach(el => set(el, String(PR_STATE.count)));
}

function pxPaintDomains(){
  const host = $('#pxDomains'); if (!host) return;
  const all = typeof allQ === 'function' ? allQ() : [];
  const e = typeof E === 'function' ? E() : { seen: {} };
  const secItems = all.filter(i => i.sec === PR_STATE.sec);
  const domList = PR_DOMAINS[PR_STATE.sec];
  const attempted = secItems.filter(it => e.seen[keyOf(it.q)]).length;
  const solved = secItems.filter(it => e.seen[keyOf(it.q)] === 'ok').length;
  const secAcc = attempted ? Math.round(solved / attempted * 100) : null;
  const score = sectionScore(PR_STATE.sec);
  const isRW = PR_STATE.sec === 'rw';

  host.innerHTML = `
    <div class="px-dhead">
      <span class="px-dicon"><i class="ph ph-${isRW ? 'book-open-text' : 'function'}"></i></span>
      <div><h2>${isRW ? 'Reading &amp; Writing' : 'Math'} domains</h2><p>Work one domain at a time and get feedback after every question.</p></div>
      <div class="px-score" title="Section score estimate and accuracy"><b>${score || '-'}</b><span>/ 800</span><em>${secAcc == null ? 'No answers yet' : secAcc + '% accuracy'}</em></div>
    </div>
    <div class="px-dgrid">
      ${domList.map(d => {
        const key = d.mapTopic || d.key;
        const st = state.byTopic[key] || { attempts: 0, correct: 0 };
        const acc = st.attempts ? Math.round(st.correct / st.attempts * 100) : null;
        const items = pxDomItems(d, secItems);
        const skills = [...new Set(items.map(i => i.skill).filter(Boolean))].slice(0, 3);
        return `
        <article class="px-dcard">
          <div class="px-ring" data-p="${acc || 0}" role="img" aria-label="${acc == null ? 'Not started' : acc + '% mastery'}">${acc == null ? '<b class="new">New</b>' : '<b>' + acc + '<small>%</small></b>'}</div>
          <div class="px-dbody">
            <div class="px-dtitle"><h3>${esc(d.name)}</h3><span class="px-state">${pxLabel(acc)}</span></div>
            <span class="px-count">${items.length} questions</span>
            <p>${esc(d.desc)}</p>
            ${skills.length ? `<ul class="px-skills">${skills.map(k => `<li>${esc(k)}</li>`).join('')}</ul>` : ''}
          </div>
          <button type="button" class="btn acc px-go" data-start-dom="${d.key}">
            <i class="ph-fill ph-play"></i><span>Practice <b class="px-n">${PR_STATE.count}</b> questions</span>
            <span class="px-t"><i class="ph ph-timer"></i></span><i class="ph ph-arrow-right px-arr"></i>
          </button>
        </article>`;
      }).join('')}
    </div>`;
  /* rings fill after first paint so the number sweeps instead of popping */
  requestAnimationFrame(() => requestAnimationFrame(() => host.querySelectorAll('.px-ring').forEach(r => r.style.setProperty('--p', r.dataset.p))));
}

function pxPaintQuick(){
  const w = typeof weakest === 'function' ? weakest() : null;
  const missed = state.missed.length;
  const ws = $('#pxWeakSub'), rs = $('#pxRetrySub'), rt = $('#prRetryBtn'), sec = $('#pxSprintSec');
  if (ws) ws.textContent = w ? TOPICS[w.key].short + ' is at ' + Math.round(w.acc * 100) + '% accuracy.' : 'Finds the topic costing you the most points.';
  if (rs) rs.textContent = missed ? missed + ' question' + (missed === 1 ? '' : 's') + ' waiting to be mastered.' : 'Nothing missed yet. Nice.';
  if (rt) { rt.disabled = !missed; rt.classList.toggle('is-off', !missed); }
  if (sec) sec.innerHTML = PR_STATE.sec === 'rw' ? 'Reading &amp; Writing' : 'Math';
}

function pxSetSection(sec){
  if (sec === PR_STATE.sec) return;
  PR_STATE.sec = sec; PR_STATE.dom = 'all'; PR_STATE.skill = '';
  pxSync(false);
  pxPaintQuick();
  const host = $('#pxDomains');
  if (window.Motion) Motion.swap(host, pxPaintDomains); else pxPaintDomains();
}

function renderPractice(){
  const root = $('#practiceRoot'); if (!root) return;
  if (!root.querySelector('.px')) { pxBuild(root); pxSync(false); pxPaintQuick(); pxPaintDomains(); }
  else { pxSync(false); pxPaintQuick(); pxPaintDomains(); }
}

function renderTestStart(){
  const P = testPlan();
  $('#tRWh').textContent = '2 modules, '+(P.rw1+P.rw2)+' questions';
  $('#tMh').textContent  = '2 modules, '+(P.m1+P.m2)+' questions';
  $('#tTotal').textContent = 'Total time: '+(P.rwMin*2+P.mMin*2)+' minutes ('+(P.rw1+P.rw2+P.m1+P.m2)+' questions)';
  const lt = state.lastTest;
  $('#lastTestWrap').innerHTML = lt ? '<div class="card" style="margin-top:18px"><div class="row" style="justify-content:space-between"><div><span class="tag good">Last full test</span><h3 style="font-size:24px;margin-top:8px;letter-spacing:-.03em">'+(lt.score||lt.total)+' <span class="muted" style="font-size:14px;font-weight:500">('+lt.rw+' R&W · '+lt.m+' Math)</span></h3><p class="muted" style="font-size:13px;margin-top:4px">Taken '+fmtDate(lt.date||ymd(lt.ts))+'</p></div><button class="btn line" onclick="go(\'review\')">Review missed</button></div></div>' : '';
}
