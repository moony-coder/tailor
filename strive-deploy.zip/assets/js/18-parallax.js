/* Hero pointer depth. One rAF loop, writes two CSS variables on .herocard only (no page-wide style invalidation).
   Fine pointers only; stops under reduced motion, live. Scroll depth is CSS-only (animation-timeline in app.css). */
(function(){
  'use strict';
  var rm = matchMedia('(prefers-reduced-motion:reduce)');
  if(!matchMedia('(hover:hover) and (pointer:fine)').matches) return;
  var tx = 0, ty = 0, mx = 0, my = 0, raf = 0;
  function hero(){ return document.querySelector('.herocard'); }
  function frame(){
    raf = 0; var h = hero(); if(!h) return;
    if(rm.matches){ h.style.removeProperty('--mx'); h.style.removeProperty('--my'); return; }
    mx += (tx - mx) * .08; my += (ty - my) * .08;
    h.style.setProperty('--mx', mx.toFixed(3)); h.style.setProperty('--my', my.toFixed(3));
    if(Math.abs(tx - mx) > .002 || Math.abs(ty - my) > .002) req();
  }
  function req(){ if(!raf) raf = requestAnimationFrame(frame); }
  addEventListener('pointermove', function(e){
    var h = hero(); if(!h || h.offsetParent === null || rm.matches) return;
    tx = e.clientX / innerWidth * 2 - 1; ty = e.clientY / innerHeight * 2 - 1; req();
  }, { passive:true });
  document.addEventListener('visibilitychange', function(){ if(document.hidden){ tx = ty = 0; } });
})();
