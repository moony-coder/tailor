/* ============================================================
   STRIVE · LUXURY DEEP EMERALD THEME (Signature Dark Palette)
   Locked to Deep Emerald Green for Jamal's International Academy
   ============================================================ */
(function(){
  'use strict';
  const THEME_KEY = 'strive_theme_v1';

  function applyTheme(){
    const root = document.documentElement;
    root.setAttribute('data-theme', 'dark');
    try { localStorage.setItem(THEME_KEY, 'dark'); } catch(e){}
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', '#02150f');
  }

  applyTheme();
  window.StriveTheme = {
    get: () => 'dark',
    set: applyTheme,
    toggle: () => applyTheme()
  };

  // Remove any obsolete theme toggle buttons
  document.addEventListener('DOMContentLoaded', () => {
    applyTheme();
    document.querySelectorAll('[data-theme-toggle]').forEach(b => b.remove());
  });
})();
