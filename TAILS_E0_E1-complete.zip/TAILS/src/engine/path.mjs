// TAILS path planner: the whole journey from today to test day (phases, weekly focus, mock dates, forecast curve). PURE.
import { keyOf } from './mastery.mjs';
import { predictScore, requiredMastery, hoursNeeded, scoreAfterHours, SCORE_CFG } from './score.mjs';
export function buildPath({ tax, mastery, settings, hpp, bias = 0, now = Date.now() }) {
  const { target_score: target, days_until_test: days, minutes_per_day: mpd = 120 } = settings, DAY = 86400000;
  const pred = predictScore(tax, mastery, keyOf, bias), hasEv = pred.evidence >= 4, current = settings.current_score ?? (hasEv ? pred.total : null);
  const req = requiredMastery(target), hrsDay = mpd / 60, hrsAvail = days * hrsDay;
  const need = current == null ? null : hoursNeeded(current, target, hpp), ratio = need ? hrsAvail / need : null;
  const status = current == null ? 'unknown' : ratio >= 1.15 ? 'on_track' : ratio >= 0.8 ? 'tight' : 'at_risk';
  const d = (f) => Math.max(1, Math.round(days * f));
  const diag = hasEv ? 0 : Math.min(3, d(0.07)), found = d(hasEv ? 0.25 : 0.2), mockCycle = d(0.25), polish = Math.max(3, d(0.1)), build = Math.max(1, days - diag - found - mockCycle - polish);
  let start = 1; const phases = [];
  for (const [id, name, len, goal] of [['diagnose', 'Diagnose', diag, 'One honest starting point'], ['foundations', 'Foundations', found, 'Close the biggest gaps with lessons + checkpoints'], ['build', 'Build', build, 'Targeted practice on the highest-value skills'], ['mock', 'Mock cycle', mockCycle, 'Full mocks every 5 to 7 days, each followed by a re-plan'], ['polish', 'Polish', polish, 'Timing, test-day routine, last reviews']]) { if (!len) continue; phases.push({ id, name, goal, from_day: start, to_day: start + len - 1 }); start += len; }
  // weekly focus: rank skills by (headroom to required) * weight, rotate top skills across weeks of Foundations+Build
  const rank = tax.skills.map((s) => { const m = mastery.get(keyOf(s.id)), p = m && !m.insufficient ? m.p : 0.5, r = req[tax.sectionOf(s.id)]; return { id: s.id, name: tax.skillName(s.id), p, gain: s.weight_on_test * Math.max(0, r - p) * (tax.sectionOf(s.id) === 'rw' ? 54 : 44) }; }).filter((x) => x.gain > 0.05).sort((a, b) => b.gain - a.gain);
  const weeks = Math.ceil(days / 7), focus = [], per = Math.max(2, Math.ceil(rank.length / Math.max(1, Math.ceil((found + build) / 7))));
  for (let w = 0; w < weeks; w++) { const day = w * 7 + 1, ph = phases.find((p) => day >= p.from_day && day <= p.to_day) ?? phases.at(-1); focus.push({ week: w + 1, phase: ph.id, skills: ['mock', 'polish'].includes(ph.id) ? rank.slice(0, 3).map((x) => x.name) : rank.slice(w * per % Math.max(1, rank.length), w * per % Math.max(1, rank.length) + 3).map((x) => x.name) }); }
  const mocks = []; const m0 = phases.find((p) => p.id === 'mock'); if (m0) for (let x = m0.from_day; x <= m0.to_day; x += 6) mocks.push(x);
  if (hasEv || days > 14) mocks.unshift(Math.min(days, hasEv ? 7 : diag + 1)); 
  const curve = []; for (let w = 0; w <= weeks; w++) curve.push({ day: Math.min(days, w * 7), score: current == null ? null : scoreAfterHours(current, w * 7 * hrsDay * SCORE_CFG.study_efficiency, hpp) });
  return { current, predicted: pred, target, days, hours_per_day: hrsDay, hours_needed: need == null ? null : Math.round(need), hours_available: Math.round(hrsAvail), ratio: ratio == null ? null : +ratio.toFixed(2), status, required_mastery: req, phases, weekly_focus: focus, mock_days: [...new Set(mocks)].sort((a, b) => a - b), forecast: curve, forecast_at_test: curve.at(-1).score,
    note: status === 'on_track' ? 'Enough time at your daily pace.' : status === 'tight' ? 'Possible, but missed days will cost you.' : status === 'at_risk' ? 'The hours do not cover the gap. Options: more hours a day, a later test date, or a lower target.' : 'No evidence yet. The diagnostic sets the starting point.' };
}
