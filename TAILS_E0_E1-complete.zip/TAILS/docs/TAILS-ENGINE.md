# TAILS Engine: aim, architecture, status

## Aim
Take one student from where they are to the score they want, with a personal plan that keeps adapting. Success is measured only by the score the student reaches. The engine decides; AI only explains and suggests, and every AI output is checked by code. If AI is off, the product still works.

## Principles (enforced in code)
1. **Engine is the brain.** `daily.mjs`, `path.mjs`, `adapt.mjs` are pure functions: same inputs, same plan, no network, no randomness.
2. **AI is bounded.** `advisor.mjs` validates every suggestion (known skill/lesson, no invented numbers, no removing prerequisites). Fallback ladder: full -> cached -> template text.
3. **The log is the truth.** `eventlog.mjs`: append-only events, replay to rebuild state after a bug fix, shadow diff between engine versions.
4. **Honest forecasts.** `score.mjs` gives a range, `path.mjs` says on track / tight / at risk, and the model corrects itself from real results.
5. **Expect failures, contain them.** `test/engine.test.mjs` is the release gate (fake students must produce sensible plans).

## Modules (assets/engine/src/engine/)
| File | Job |
|---|---|
| `mastery.mjs`, `rootcause.mjs`, `levers.mjs`, `plan.mjs` | v1 core (kept): mastery with decay, why-missed, point levers, 7-day plan after a test |
| `score.mjs` | accuracy -> section score curve, required mastery per target, predicted score + range, saturating hours model, `calibrateHpp`, `calibrateBias` |
| `path.mjs` | whole journey: phases, weekly focus, mock days, forecast, feasibility |
| `daily.mjs` | today's checklist (>= 120 min): diagnostic-first, spaced review, lesson -> checkpoint -> practice, fix-it after a failed checkpoint, pool alerts |
| `adapt.mjs` | the adaptation table: mock done, plateau diagnosis, missed days (compress), ahead of schedule, checkpoint pass/fail, settings changed |
| `eventlog.mjs` | event log, replay, shadow diff |
| `advisor.mjs` | AI contract + degradation + template explanations |
| `itemcal.mjs` | measured item difficulty from attempts, flags ambiguous/broken keys and too-easy items |
| `adaptive.mjs` | item-level adaptive testing (3PL-lite IRT): picks the most informative next question, balances skill coverage, stops at 10-20 items, maps ability to section scores with a range |
| `vocab.mjs` | vocabulary spaced repetition (stages 0/1/3/7/14/30 days), daily queue (due first, 10 new), multiple-choice question builder |

## App wiring (assets/js/)
- `36-tails-today.js`: Today page. Builds the day from live mastery, starts real sessions, receives results (`sat:finished`), schedules spaced reviews, handles failed checkpoints, detects missed days, plays lesson videos (85% watched ticks the lesson).
- `37-tails-path.js`: My path page, score history, and a box to add an official/Bluebook score.
- `38-tails-adaptive.js`: the adaptive diagnostic (Reading & Writing, then Math). Replaces the 70-minute mini-mock as the first step for a student with no results.
- `39-tails-vocab.js`: Vocabulary page; words from `assets/data/vocab.json` (59 seed words; add more with `factory/vocab-ingest.mjs`).
- Mock scores flow in automatically: every finished mock/mini-mock estimates a score, runs the plateau check and corrects the forecast bias (capped at +-60).
- Hub renamed **Audit & skills** (Audit, Review, Skills, Bluebook import). Practice and 7-day plan now redirect to Today / My path.
- Progress store: localStorage `strive_tails_v1` (move to a server database before launch).

## Content
- Bank: 630 math + 205 Reading & Writing verified items (`assets/engine/data.json`). Generators live in the separate factory (`node factory/tails.mjs families | rwfamilies`).
- Still thin: Central Ideas, Inferences, Command of Evidence, Text Structure, Cross-Text, Rhetorical Synthesis (1 to 3 items each). Use the DeepSeek briefs in `factory/briefs/`, then `node factory/tails.mjs ingest <file>`.
- Videos: fill `youtube_id` in `assets/data/lesson-videos.json` (122 lessons, includes title, kind and target minutes as the filming checklist). Upload as **Unlisted**, start the title with the lesson id.

## Calibration (what is a guess)
Priors, to be replaced by real data: 0.35 study hours per point, the score-curve anchors, mastery targets per section. The app logs predicted score and minutes studied per day and learns each student's own speed (`calibrateHpp`); mocks correct the forecast bias (`calibrateBias`); `itemcal.mjs` replaces guessed item difficulty once attempts exist. A synthetic test (assumptions are ours) showed forecast error 18 -> 6 points after two measured fortnights.

## Run the checks
```
node assets/engine/test/engine.test.mjs   # 33 release-gate checks
node assets/engine/test/daily.sim.mjs     # printed day plans for sample students
```

## Status vs blueprint
Done: score model, path, daily planner, adaptation table, event log + replay + shadow diff, AI guardrails, item calibration, Today + My path pages, video player, test suite.
Decided not to build (single user, local storage is enough): server accounts/database, teacher dashboard.
Not done: calibrating adaptive item difficulty from real attempts (uses the 1-5 labels until attempts exist), more vocabulary words and reading questions (DeepSeek prompts in DEEPSEEK-PROMPTS.md), key rotation (Groq key still in `config.js`).
Note: adaptive/mock scores from the accuracy curve are estimates. An official or Bluebook score typed into My path is the strongest signal.
