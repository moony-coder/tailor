// Node loader. Reads the single data bundle (data.json) and returns the shape createContext() expects.
// data.json is the one source of truth for the engine; the factory writes into it with `node factory/tails.mjs export --into data.json`.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createTaxonomy } from '../taxonomy/index.mjs';

export const DEFAULT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

/** Raw bundle, exactly as stored on disk. */
export function readBundle(root = DEFAULT_ROOT) {
  const file = root.endsWith('.json') ? root : path.join(root, 'data.json');
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

/** Bundle -> { taxonomy, questions, lessons, config } (same shape the browser path builds in local.mjs). */
export function fromBundle(b) {
  return {
    taxonomy: createTaxonomy({ skills: b.skills, microskills: b.microskills, traps: b.traps, reasons: b.reasons }),
    questions: b.questions,
    lessons: b.lessons.lessons,
    config: { thresholds: b.thresholds, blueprints: b.blueprints, routing: b.routing },
  };
}

export async function loadAll(root = DEFAULT_ROOT) { return fromBundle(readBundle(root)); }
