/* Fit: one consistent on-screen size on every laptop.
   The pages are designed for a ~1745px-wide window (what most people see at their default zoom).
   On a wider window (for example a 1920px screen at 100% browser zoom) everything is scaled up smoothly by the
   same ratio, so it looks exactly like the 110%-zoom view. At 110% browser zoom the ratio is 1, so nothing doubles.
   Landing and onboarding scale the whole page; the intro scales only its own layer (the app is never touched). */
(function(){
  'use strict';
  var REF = 1745, MAX = 1.3;
  function calc(){ return Math.max(1, Math.min(MAX, Math.round(innerWidth / REF * 100) / 100)); }
  window.__fitZ = calc;
  var root = document.documentElement;
  if(!root.hasAttribute('data-fit')) return;
  function apply(){ var z = calc(); root.style.zoom = z === 1 ? '' : String(z); root.style.setProperty('--z', z); window.__z = z; }
  apply();
  var t = 0; addEventListener('resize', function(){ clearTimeout(t); t = setTimeout(apply, 80); });
})();
