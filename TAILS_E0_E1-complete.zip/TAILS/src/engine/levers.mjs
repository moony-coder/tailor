// Levers: what to fix first. PURE.
//   expected_questions(skill) = domain_share * questions_in_section * skill_share_within_domain
//   gain = expected_questions * (target_p - p)+ * recoverability(root-cause mix)
//   rank = gain / cost(minutes)
import { keyOf } from './mastery.mjs';
import { round, groupBy } from '../util/misc.mjs';

export const expectedQuestions = (tax, skillId, cfg) => {
  const s = tax.skillById.get(skillId); if (!s) return 0;
  const d = tax.domainById.get(s.domain);
  return d.share * cfg.levers.questions_in_section[d.section] * s.skill_share_within_domain;
};

/** Root-cause mix of wrong attempts for one skill -> {cause: share}. */
export function causeMix(wrongAttempts) {
  const n = wrongAttempts.length; if (!n) return {};
  const c = {}; for (const a of wrongAttempts) { const k = a.root_cause ?? 'UNKNOWN'; c[k] = (c[k] ?? 0) + 1; }
  return Object.fromEntries(Object.entries(c).map(([k, v]) => [k, v / n]));
}
export const mainCause = (mix) => Object.entries(mix).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0] ?? 'UNKNOWN';

export function computeLevers(attempts, mastery, tax, cfg) {
  const L = cfg.levers;
  const bySkill = groupBy(attempts.filter((a) => a.skill_id && !a.domain_estimated), (a) => a.skill_id);
  const out = [];
  for (const [skillId, rows] of bySkill) {
    const m = mastery.get(keyOf(skillId)); if (!m) continue;
    const wrong = rows.filter((a) => !a.is_correct);
    if (wrong.length < L.min_attempts) continue;
    const mix = causeMix(wrong), main = mainCause(mix);
    const recov = Object.entries(mix).reduce((s, [c, share]) => s + share * (L.recoverability[c] ?? L.recoverability.UNKNOWN), 0);
    const cost = Object.entries(mix).reduce((s, [c, share]) => s + share * (L.fix_cost_minutes[c] ?? L.fix_cost_minutes.UNKNOWN), 0);
    const exp = expectedQuestions(tax, skillId, cfg);
    const gain = exp * Math.max(0, L.target_p - m.p) * recov;
    out.push({ skill_id: skillId, name: tax.skillName(skillId), section: tax.sectionOf(skillId), p: round(m.p), n: m.n, insufficient: m.insufficient, main_cause: main,
      cause_mix: Object.fromEntries(Object.entries(mix).map(([k, v]) => [k, round(v)])), expected_questions: round(exp), recoverability: round(recov), cost_minutes: round(cost, 0),
      gain: round(gain), rank: round(gain / Math.max(1, cost), 4), traps: topTrapsOf(wrong, 2) });
  }
  out.sort((a, b) => b.rank - a.rank || b.gain - a.gain || a.skill_id.localeCompare(b.skill_id));
  return out;
}
/**
 * Domain-level levers: used when wrong answers cannot be pinned to a skill (Bluebook imports, thin mini-mocks).
 * Counts only wrong attempts NOT already covered by a skill lever, and needs levers.domain_min_wrong of them.
 */
export function computeDomainLevers(attempts, mastery, tax, cfg, skillLevers = [], { minWrong = null } = {}) {
  const L = cfg.levers, covered = new Set(skillLevers.map((l) => l.skill_id));
  const out = [];
  for (const [domain, rows] of groupBy(attempts.filter((a) => a.domain), (a) => a.domain)) {
    const d = tax.domainById.get(domain), m = mastery.get(keyOf(domain)); if (!d || !m) continue;
    const wrong = rows.filter((a) => !a.is_correct && !(a.skill_id && covered.has(a.skill_id)));
    if (wrong.length < (minWrong ?? L.domain_min_wrong ?? 3)) continue;
    const mix = causeMix(wrong), main = mainCause(mix);
    const recov = Object.entries(mix).reduce((s, [c, share]) => s + share * (L.recoverability[c] ?? L.recoverability.UNKNOWN), 0);
    const cost = Object.entries(mix).reduce((s, [c, share]) => s + share * (L.fix_cost_minutes[c] ?? L.fix_cost_minutes.UNKNOWN), 0);
    const exp = d.share * L.questions_in_section[d.section];
    // a domain-wide fix covers many skills, so it is slower than a single-skill fix
    const gain = exp * Math.max(0, L.target_p - m.p) * recov * (wrong.length / Math.max(1, rows.filter((a) => !a.is_correct).length));
    out.push({ skill_id: domain, level: 'domain', name: d.name, section: d.section, p: round(m.p), n: m.n, insufficient: m.insufficient, main_cause: main,
      cause_mix: Object.fromEntries(Object.entries(mix).map(([k, v]) => [k, round(v)])), expected_questions: round(exp), recoverability: round(recov), cost_minutes: round(cost * 1.5, 0),
      gain: round(gain), rank: round(gain / Math.max(1, cost * 1.5), 4), traps: topTrapsOf(wrong, 2) });
  }
  return out;
}

export function topLevers(attempts, mastery, tax, cfg) {
  const skillLevers = computeLevers(attempts, mastery, tax, cfg);
  const all = [...skillLevers.map((l) => ({ ...l, level: 'skill' })), ...computeDomainLevers(attempts, mastery, tax, cfg, skillLevers)]
    .sort((a, b) => b.rank - a.rank || b.gain - a.gain || a.skill_id.localeCompare(b.skill_id));
  // Skills with too little data may still show, but flagged; real-evidence skills first
  const solid = all.filter((l) => !l.insufficient), thin = all.filter((l) => l.insufficient);
  const out = [...solid, ...thin].slice(0, cfg.levers.top_levers);
  if (out.length) return out;
  // First-audit fallback: a single 22-question mock spreads misses thinly, so no skill (2 misses) or domain (3 misses) qualifies.
  // Show the weakest domains anyway, but flagged provisional/low-data so the report and the narrative say it is a first guess.
  const pm = cfg.levers.provisional_min_wrong ?? 2;
  return computeDomainLevers(attempts, mastery, tax, cfg, [], { minWrong: pm })
    .map((l) => ({ ...l, insufficient: true, provisional: true }))
    .sort((a, b) => b.rank - a.rank || b.gain - a.gain || a.skill_id.localeCompare(b.skill_id))
    .slice(0, cfg.levers.top_levers);
}
export function topTrapsOf(wrongAttempts, k = 3) {
  const c = {}; let n = 0;
  for (const a of wrongAttempts) if (a.trap_code) { c[a.trap_code] = (c[a.trap_code] ?? 0) + 1; n++; }
  return Object.entries(c).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, k).map(([code, count]) => ({ code, count, share: round(count / Math.max(1, n)) }));
}
