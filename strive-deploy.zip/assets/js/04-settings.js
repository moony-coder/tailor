/* ============================================================
   DEDICATED FULL-PAGE SCHOLAR PROFILE & SETTINGS VIEWS
   ============================================================ */
function openModal(html){
  const bg=document.createElement('div'); bg.className='modal-bg'; bg.innerHTML='<div class="modal" role="dialog" aria-modal="true">'+html+'</div>';
  bg.addEventListener('pointerdown', e=>{ if(e.target===bg) bg.remove(); });
  document.body.appendChild(bg); return bg;
}

function openProfile(){ go('profile'); }
function openSettings(){ go('settings'); }

/* ---- mascot / avatar: the profile picture is one of the coach poses ---- */
const MASCOTS = [
  ['m_welcome','Welcome'], ['m_cheer','Cheer'], ['m_listen','Listen'], ['m_study','Study'],
  ['m_think','Think'], ['m_trophy','Champion'], ['m_confused','Curious'], ['m_headache','Tough day']
];
const MASCOT_DEFAULT = 'm_welcome';
function mascotKey(){
  const k = state.profile && state.profile.mascot;
  return MASCOTS.some(m => m[0] === k) ? k : MASCOT_DEFAULT;   /* old picks (logo, thumbs up) fall back to the default */
}
function mascotOf(k){ return 'assets/img/' + k + '.webp'; }
function mascotSrc(){ return mascotOf(mascotKey()); }
function applyAvatar(){
  const src = mascotSrc();
  if (typeof IMG !== 'undefined') IMG.avatar = src;   /* anything that re-applies data-img="avatar" keeps the chosen coach */
  document.querySelectorAll('[data-img="avatar"], #clMe, .prof-hero-av').forEach(el => {
    if (el.getAttribute('src') !== src) el.src = src;
    el.classList.add('is-mascot');
  });
}

const VERSION = { app: '1.0.0', build: 'v10', date: 'October 2026' };

function renderProfile(){
  const root = $('#profileBody');
  if (!root) return;
  const p = state.profile;
  const e = typeof E === 'function' ? E() : { xp: 0, goal: 10 };
  const lv = Math.floor((e.xp || 0) / 300) + 1;
  const xpInLv = (e.xp || 0) % 300;
  const sel = mascotKey();

  const mascotTiles = MASCOTS.map(m => `
    <button type="button" class="mas-opt${sel === m[0] ? ' on' : ''}" data-mascot="${m[0]}" aria-pressed="${sel === m[0]}" aria-label="${esc(m[1])}">
      <span class="mas-img"><img src="${mascotOf(m[0])}" alt="" loading="lazy"></span>
      <small>${esc(m[1])}</small>
      <i class="ph-fill ph-check-circle mas-tick"></i>
    </button>`).join('');

  root.innerHTML = `
    <div class="pagehead">
      <div>
        <h1>Profile</h1>
        <p>Who you are on Strive: your name, your coach and your goals.</p>
      </div>
    </div>

    <div class="prof-wrap">
      <div class="card prof-hero">
        <img class="prof-hero-av" src="${mascotSrc()}" alt="">
        <div class="prof-id">
          <div class="row" style="gap:10px;flex-wrap:wrap">
            <h2 id="pfNameH" style="font-size:26px;letter-spacing:-.03em">${esc(p.name || 'Scholar')}</h2>
            <span class="tag acc">Level ${lv}</span>
            <span class="tag good"><i class="ph-fill ph-fire"></i>${state.streak}-day streak</span>
          </div>
          <div class="prof-xp">
            <div class="bar thin"><i style="width:${Math.round(xpInLv / 3)}%"></i></div>
            <span class="muted mono">${e.xp || 0} XP · ${300 - xpInLv} to Level ${lv + 1}</span>
          </div>
        </div>
      </div>

      <div class="card">
        <h3 class="pf-h">Choose your coach</h3>
        <p class="muted pf-sub">Pick the pose that shows up as your picture around the app.</p>
        <div class="mas-grid">${mascotTiles}</div>
      </div>

      <div class="card">
        <h3 class="pf-h">About you</h3>
        <p class="muted pf-sub">Your plan, countdown and dashboard all calibrate from these.</p>
        <div class="pf-fields">
          <div class="fld">
            <label for="sName">First name</label>
            <input class="inp" id="sName" value="${esc(p.name || '')}" maxlength="24" autocomplete="given-name">
          </div>
          <div class="fld">
            <label for="sGoalI">Target SAT score (400 to 1600)</label>
            <input class="inp" id="sGoalI" type="number" min="400" max="1600" step="10" value="${p.goal || 1500}">
          </div>
          <div class="fld">
            <label for="sDateI">Official SAT test date</label>
            <select id="sDateI">
              ${satUpcoming().map(d => `<option value="${d.d}"${d.d === p.testDate ? ' selected' : ''}>${satLong(d.d)}${d.est ? ' (anticipated)' : ''}</option>`).join('')}
            </select>
          </div>
          <div class="fld">
            <label>Daily question goal</label>
            <div class="pr-pills">
              ${[5, 10, 15, 20, 30].map(g => `<button type="button" class="pr-pill mono${e.goal === g ? ' on' : ''}" data-set-dgoal="${g}">${g} / day</button>`).join('')}
            </div>
          </div>
        </div>
        <button type="button" class="btn acc lg" id="sSaveBtn" style="width:100%;margin-top:6px"><i class="ph ph-check-circle"></i>Save changes</button>
      </div>
    </div>
  `;

  if (window.UI && typeof UI.enhance === 'function') UI.enhance(root);

  root.querySelectorAll('[data-mascot]').forEach(b => b.onclick = () => {
    p.mascot = b.dataset.mascot;
    saveState();
    root.querySelectorAll('[data-mascot]').forEach(x => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-pressed', on); });
    const av = $('.prof-hero-av', root);
    if (av) { av.classList.remove('pop'); void av.offsetWidth; av.classList.add('pop'); }
    applyAvatar();
    toast('Coach updated', 'ph-check-circle');
  });

  root.querySelectorAll('[data-set-dgoal]').forEach(b => b.onclick = () => {
    e.goal = +b.dataset.setDgoal;
    saveState();
    root.querySelectorAll('[data-set-dgoal]').forEach(x => x.classList.toggle('on', x === b));
    toast('Daily goal set to ' + e.goal + ' questions', 'ph-target');
  });

  const saveBtn = $('#sSaveBtn', root);
  if (saveBtn) saveBtn.onclick = () => {
    p.name = ($('#sName', root).value || '').trim() || p.name || 'Scholar';
    p.goal = Math.min(1600, Math.max(400, parseInt($('#sGoalI', root).value, 10) || p.goal || 1500));
    p.testDate = $('#sDateI', root).value || p.testDate;
    saveState();
    refreshChrome();
    animateDash();
    const h = $('#pfNameH', root); if (h) h.textContent = p.name;
    toast('Profile saved', 'ph-check-circle');
  };
  applyAvatar();
}

function renderSettings(){
  const root = $('#settingsBody');
  if (!root) return;
  const prefs = state.prefs = state.prefs || { coach: true, showTimer: true, autoScrollExp: true };
  const row = (key, title, sub) => `
    <div class="set-row">
      <div><b style="font-size:14px;display:block">${title}</b><span class="muted" style="font-size:12.5px">${sub}</span></div>
      <button type="button" class="sw-btn${prefs[key] !== false ? ' on' : ''}" data-pref-toggle="${key}" role="switch" aria-checked="${prefs[key] !== false}" aria-label="${title}"></button>
    </div>`;

  root.innerHTML = `
    <div class="pagehead">
      <div>
        <h1>Settings</h1>
        <p>How Strive behaves, your data, and about the app.</p>
      </div>
    </div>

    <div class="set-stack">
      <div class="card">
        <h3 class="pf-h">Study experience</h3>
        <p class="muted pf-sub">Coach messages, the timer and how explanations appear.</p>
        ${row('coach', 'Coach reactions', 'Show encouragement messages during practice drills.')}
        ${row('showTimer', 'Show timer by default', 'Display the countdown clock at the top of timed modules.')}
        ${row('autoScrollExp', 'Auto-scroll to explanation', 'Smoothly scroll to the step-by-step explanation after checking an answer.')}
        <div class="set-row">
          <div><b style="font-size:14px;display:block">Replay the intro</b><span class="muted" style="font-size:12.5px">Watch the opening animation again next time you open the app.</span></div>
          <button type="button" class="btn line sm" id="sIntroBtn"><i class="ph ph-play"></i>Replay</button>
        </div>
      </div>

      <div class="card">
        <h3 class="pf-h">Data and backup</h3>
        <p class="muted pf-sub">Your progress is stored on this device. Export a snapshot anytime, or start fresh.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button type="button" class="btn line sm" id="sExportBtn"><i class="ph ph-download-simple"></i>Export backup</button>
          <label class="btn ghost sm" style="cursor:pointer"><i class="ph ph-upload-simple"></i>Import backup<input type="file" id="sImportInp" accept=".json,application/json" hidden></label>
          <button type="button" class="btn danger sm" id="sResetBtn" style="margin-left:auto"><i class="ph ph-trash"></i>Reset all data</button>
        </div>
      </div>

      <div class="card about">
        <h3 class="pf-h">About</h3>
        <div class="about-row"><span>Version</span><b class="mono">${VERSION.app}</b></div>
        <div class="about-row"><span>Build</span><b class="mono">${VERSION.build} · ${VERSION.date}</b></div>
        <div class="about-row"><span>Made by</span><b>Jamal's International Academy</b></div>
        <div class="about-links">
          <a class="about-link" href="terms.html?from=app"><span>Terms of use</span><i class="ph ph-arrow-up-right"></i></a>
          <a class="about-link" href="privacy.html?from=app"><span>Privacy</span><i class="ph ph-arrow-up-right"></i></a>
        </div>
        <p class="muted" style="font-size:12px;margin-top:14px">SAT is a registered trademark of the College Board, which is not affiliated with Strive.</p>
      </div>
    </div>
  `;

  if (window.UI && typeof UI.enhance === 'function') UI.enhance(root);

  root.querySelectorAll('[data-pref-toggle]').forEach(b => b.onclick = () => {
    const k = b.dataset.prefToggle;
    prefs[k] = !(prefs[k] !== false);
    saveState();
    b.classList.toggle('on', prefs[k]);
    b.setAttribute('aria-checked', prefs[k]);
  });

  const introBtn = $('#sIntroBtn', root);
  if (introBtn) introBtn.onclick = () => {
    try { E().introSeen = 0; saveState(); sessionStorage.removeItem('strive_ld'); } catch(err) {}
    toast('Intro will play next time you open the app', 'ph-play');
  };

  const expBtn = $('#sExportBtn', root);
  if (expBtn) expBtn.onclick = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'strive-sat-backup-' + ymd(Date.now()) + '.json';
    a.click();
    toast('Progress backup downloaded', 'ph-download-simple');
  };

  const impInp = $('#sImportInp', root);
  if (impInp) impInp.onchange = ev => {
    const f = ev.target.files && ev.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const data = JSON.parse(r.result);
        if (data && data.profile) {
          localStorage.setItem(STORE_KEY, JSON.stringify(data));
          location.reload();
        }
      } catch(err) { toast('Invalid backup file', 'ph-warning'); }
    };
    r.readAsText(f);
  };

  const rstBtn = $('#sResetBtn', root);
  if (rstBtn) rstBtn.onclick = () => {
    const doReset = () => { localStorage.removeItem(STORE_KEY); location.href = 'onboarding.html'; };
    if (window.UI) UI.confirm({ title: 'Reset all progress?', text: 'This deletes ALL your progress and settings on this device. It cannot be undone.', ok: 'Yes, reset', cancel: 'Keep my progress', danger: true }).then(y => { if (y) doReset(); });
    else if (confirm('Delete ALL your progress and settings on this device?')) doReset();
  };
}

loadState();
