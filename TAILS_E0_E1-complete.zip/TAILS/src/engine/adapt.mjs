// TAILS adaptation table (blueprint section 3, layer 5). PURE: (state, event) -> { state, notes, flags }.
// Each rule is a named reaction with a visible reason, so the student always sees "plan changed because...".
export const ADAPT_CFG = { plateau_pts: 15, plateau_mocks: 2, missed_compress_days: 2, ahead_ratio: 1.25, careless_share: 0.4, stamina_drop: 0.12, time_share: 0.25, checkpoint_pass_ratio: 0.75 };

export function adapt(state, ev, cfg = ADAPT_CFG) {
  const s = structuredClone(state ?? {}); s.mocks ??= []; s.flags ??= {}; const notes = [];
  switch (ev.type) {
    case 'mock_done': { // { day, actual, predicted, signals:{ stamina_drop, careless_share, time_share, per_skill_gain } }
      s.mocks.push({ day: ev.day, actual: ev.actual, predicted: ev.predicted });
      const m = s.mocks, n = cfg.plateau_mocks;
      if (m.length >= n + 1) {
        const gain = m.at(-1).actual - m.at(-1 - n).actual;
        if (gain <= cfg.plateau_pts) { const dx = diagnosePlateau(ev.signals ?? {}, cfg); s.flags.plateau = dx; notes.push(`Score has not moved (${gain >= 0 ? '+' : ''}${gain}) across ${n} mocks. Most likely cause: ${dx.label}. The plan switches to ${dx.fix}.`); }
        else delete s.flags.plateau;
      } else notes.push(m.length === 1 ? 'One mock is a snapshot. Treat the numbers as a first estimate.' : 'Two mocks give a first trend; consistent weaknesses are now separated from one-off slips.');
      const err = ev.actual - ev.predicted; if (Math.abs(err) >= 40) notes.push(`The forecast was off by ${Math.abs(err)} points, so the score model was corrected.`);
      break; }
    case 'days_missed': {
      if (ev.n >= cfg.missed_compress_days) { s.flags.compress = true; notes.push(`${ev.n} days missed. Instead of piling up a backlog, today keeps only the highest-value work.`); } else delete s.flags.compress;
      break; }
    case 'progress_check': { // { done_units, planned_units }
      const r = ev.done_units / Math.max(1, ev.planned_units);
      if (r >= cfg.ahead_ratio) { s.flags.ahead = true; notes.push('You are ahead of schedule, so harder material is pulled forward.'); } else delete s.flags.ahead;
      break; }
    case 'settings_changed': notes.push(`${ev.what ?? 'Target or test date'} changed, so the whole path was rebuilt.`); s.flags = {}; break;
    case 'checkpoint': { // { skill_id, correct, total, trap_code }
      const pass = ev.correct / ev.total >= cfg.checkpoint_pass_ratio; s.checkpointFailed ??= [];
      s.checkpointFailed = s.checkpointFailed.filter((f) => f.skill_id !== ev.skill_id);
      if (!pass) { s.checkpointFailed.unshift({ skill_id: ev.skill_id, trap_code: ev.trap_code ?? 'UNKNOWN' }); notes.push(`Checkpoint ${ev.correct}/${ev.total}. A short review lesson and fresh items replace repeating the whole lesson.`); }
      else notes.push(`Checkpoint passed (${ev.correct}/${ev.total}). Moving on; a spaced review is scheduled.`);
      break; }
    default: throw new Error(`unknown event ${ev.type}`);
  }
  return { state: s, notes, flags: s.flags };
}
/** Plateau diagnosis: which signal is strongest decides the strategy change. */
export function diagnosePlateau(sig, cfg = ADAPT_CFG) {
  const c = [
    { k: 'careless', v: (sig.careless_share ?? 0) / cfg.careless_share, label: 'careless errors rather than missing knowledge', fix: 'checking-habit drills and slower, cleaner work on easy items' },
    { k: 'stamina', v: (sig.stamina_drop ?? 0) / cfg.stamina_drop, label: 'accuracy falling late in each module (stamina)', fix: 'longer timed sets and pacing practice' },
    { k: 'timing', v: (sig.time_share ?? 0) / cfg.time_share, label: 'running out of time', fix: 'speed drills and a skip-and-return routine' },
  ].sort((a, b) => b.v - a.v);
  return c[0].v >= 1 ? { kind: c[0].k, label: c[0].label, fix: c[0].fix } : { kind: 'content', label: 'the wrong skills being trained', fix: 'a fresh skill ranking from the newest mock' };
}
