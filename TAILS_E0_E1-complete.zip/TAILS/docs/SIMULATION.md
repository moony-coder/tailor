# TAILS simulation and backtest harness (E1)

`sim/` runs fake students through 60 to 90 simulated days against an engine and scores the result. Purpose: prove that each later change (E2 to E7) makes the engine better, and stop it getting worse without anyone noticing.

## Commands

| Command | What it does |
|---|---|
| `node sim/run.mjs` | all personas, 3 seeds, today's bank |
| `node sim/run.mjs --exposure all` | three worlds side by side: `never`, `recycle`, `unlimited` |
| `node sim/run.mjs --persona B_1200_1500 --seeds 8` | one persona, more seeds |
| `node sim/run.mjs --compare sim/engines/naive.mjs` | engine vs the no-intelligence control |
| `node sim/run.mjs --report` | writes `sim/out/report.md` and `summary.json` |
| `node sim/tune.mjs --write` | measures seed-to-seed noise, writes `sim/tolerances.json` |
| `node sim/run.mjs --update-baseline` | accept current numbers as the baseline (only after an intended improvement); also archived in `sim/baselines/<engine version>.json` |
| `npm run sim:ci` | the gate. Also runs inside `npm test` |

## What is simulated

- **Personas** (`personas.mjs`): A (no test, 1400), B (1200 to 1500, weak in systems/nonlinear/trig/words/boundaries), plateau, skipper (attends ~55%, in streaks), careless (15% slips), slow (1.4x time, learns slower), busy (75 min/day), busy60 (60 min/day, no test yet), fast, oracle (engine's score curve exact, no mock noise: a validity check on the harness itself).
- **World** (`world.mjs`): per-skill ability, item response curve, learning from practised questions and lessons, forgetting with spacing, stamina, careless slips, a true score curve. Mocks have realistic noise (about +-55 points).
- **Driver** (`driver.mjs`): attendance, runs the engine's day plan, answers questions, schedules reviews, reacts to checkpoints and mocks, rebuilds the path weekly and after each mock. It re-implements the platform glue from `docs/TAILS-ENGINE.md` because that glue was not in the extract.
- **Three exposure worlds**: `never` (a question served once is gone: today's behaviour), `recycle` (blueprint rule: wrong after 14 days, right after 45), `unlimited` (infinite fresh items: isolates planner and score model from content volume).

## Assumptions (these are NOT data)

Learning speed, forgetting rate, the scoring curve and every persona parameter are my assumptions (`WORLD` in `world.mjs`). The harness judges the engine against a fixed, explicit world so versions can be compared; it does not predict real students. E7 replaces these with fitted values from real attempts. Treat absolute numbers as relative.

## The gate

`--gate` fails (exit 1) on any of:
1. **Hard invariants**, every run: no question twice in one day, no unknown ids in a plan, replaying the event log rebuilds the same state, two identical runs are byte-identical, and in the oracle world the mature score error stays under 90.
2. **Pooled regression**: the average over personas of every metric must not worsen by more than its pooled tolerance (tight; catches small across-the-board loss).
3. **Per-persona regression**: no single persona may worsen by more than its cell tolerance (loose; stops one broken persona hiding in a good average).

Tolerances come from `sim/tune.mjs`: 3 x the standard deviation of a 4-seed mean over 8 batches. The first hand-set tolerances were far too tight (score-error tolerance 8 against noise sd ~21). Gate checked against a worse engine (the control planner) and a re-introduced bug: both fail as they should.

## Bug found by the gate

`buildDay` could serve the same question twice in one day (checkpoint set and later practice blocks drew from the same pool). Fixed in `tails-2.2.1` (`taken` set in `daily.mjs`).

## Findings on tails-2.2.1 (4 seeds, average over personas)

| Finding | today's bank | recycle rule | unlimited |
|---|---|---|---|
| true score gain (pts) | 60 | 87 | 117 |
| days shorter than the 2h promise | 64% | 53% | 0% |
| skills whose pool ran dry | 17 | 14 | 0 |
| score error before day 14 (pts) | 228 | 228 | 247 |
| score error from day 14 (pts) | 75 | 64 | 57 |

1. **Content volume caps the engine.** With today's bank the 2-hour day collapses once high-value skills are exhausted. Unlimited items nearly double the gain. (E3 recycle + pool alerts, E5 content.)
2. **The real planner loses to rotation when items are scarce.** With today's bank the no-intelligence control out-gains the engine in all 9 personas (about 14 points); with the recycle rule still 8 of 9. With unlimited items the engine wins 8 of 9 (+34 points). The planner concentrates on a few skills and exhausts their pools. This is the main E3 target.
3. **Early forecast is badly off.** Before day 14 the first predictions ignore the score the student already told us (known-1200 student predicted ~940). After day 14 error is 15 to 60. (E4 score prior.)
4. **Diagnostic comes back on day 2** for every persona (too few skills reach 5 attempts after one diagnostic). (E3 hand-off.)
5. **busy60 never starts**: a 60-minute student cannot finish the 70-minute diagnostic and sits in diagnostic mode ~50 days, gain 0. (E3.)
6. **Stated minutes are ignored**: plans are floored at 120 min, so 26% of days exceed the time the student has. (E3.)
7. **Oracle world still lags** by ~55 points mature error although the engine curve is exact. Suspected cause (not confirmed): item difficulty is not adjusted for as students improve. (E4.)
8. Empty bank skills (`M.PSDA.INF`, `M.PSDA.CLAIMS`) and 4 near-empty ones, template saturation, unused trap `TOO-NARROW`: from the bank audit, feed E5.

Targets for each metric are in `sim/metrics.mjs` (`METRICS[].target`); the report shows which are met.
