// Browser loader (plain fetch). `base` is the URL of the sat-audit-core folder on your static host.
// data/questions/index.json (list of file names) is produced by `node scripts/build-index.mjs`.
import { createTaxonomy } from '../taxonomy/index.mjs';

export async function loadAllBrowser(base = './sat-audit-core/') {
  const j = async (p) => { const r = await fetch(base + p); if (!r.ok) throw new Error(`${p}: ${r.status}`); return r.json(); };
  const [skills, microskills, traps, reasons, thresholds, blueprints, routing, lessons, index] = await Promise.all([
    j('data/taxonomy/skills.json'), j('data/taxonomy/microskills.json'), j('data/taxonomy/trap_codes.json'), j('data/taxonomy/reasons.json'),
    j('config/thresholds.json'), j('config/blueprints.json'), j('config/model-routing.json'), j('data/lessons/lessons.skeleton.json'), j('data/questions/index.json')]);
  const questions = await Promise.all(index.files.map((f) => j('data/questions/' + f)));
  return { taxonomy: createTaxonomy({ skills, microskills, traps, reasons }), questions, lessons: lessons.lessons, config: { thresholds, blueprints, routing } };
}
