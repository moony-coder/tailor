/* ============================================================
   TAILORED PRACTICE: Bluebook import wizard (labels only).
   The student types WHICH question numbers they missed and the domain label Bluebook shows. Never question text.
   ============================================================ */
(function(){
  'use strict';
  const A = window.SATAPI, SAT = window.SAT; if(!A || !SAT) return;
  const TESTS = ['4', '5', '6', '7', '8', '9', '10', '11', 'other'];
  const SIZE = { rw: 27, math: 22 };

  SAT.pages.import = async function(body, r, alive){
    const tax = await A.get('/api/taxonomy', { public: true });
    if(!alive()) return;
    const st = { test_number: '4', section: 'rw', module: 1, wrong: {}, unsure: new Set(), levels: {}, notes: '', replace: false };
    const doms = sec => tax.domains.filter(d => d.section === sec);

    function paint(){
      const size = SIZE[st.section], ds = doms(st.section);
      const nums = Array.from({ length: size }, (_, k) => k + 1);
      const nWrong = Object.keys(st.wrong).length;
      let h = '<div class="card sat-note mb-12"><i class="ph ph-shield-check"></i><div><b>Labels only</b><p class="muted">Do not paste or type question text. You only need the question numbers you got wrong and the domain name Bluebook shows next to them (in Bluebook: Score Report, then Score Details). The audit is a little less certain than one from a test taken here, because there is no timing.</p></div></div>';
      h += '<div class="card"><div class="grid g3"><div class="field"><label for="bbT">Practice test</label><select class="inp" id="bbT">' + TESTS.map(t => '<option value="' + t + '"' + (st.test_number === t ? ' selected' : '') + '>' + (t === 'other' ? 'Other / older test' : 'Bluebook test ' + t) + '</option>').join('') + '</select></div>' +
        '<div class="field"><label for="bbS">Section</label><select class="inp" id="bbS"><option value="rw"' + (st.section === 'rw' ? ' selected' : '') + '>Reading and Writing (27 questions)</option><option value="math"' + (st.section === 'math' ? ' selected' : '') + '>Math (22 questions)</option></select></div>' +
        '<div class="field"><label for="bbM">Module</label><select class="inp" id="bbM"><option value="1"' + (st.module === 1 ? ' selected' : '') + '>Module 1</option><option value="2"' + (st.module === 2 ? ' selected' : '') + '>Module 2</option></select></div></div></div>';
      h += '<div class="card mt-16"><h3 class="card-h">Which questions did you miss?</h3><p class="muted fs-13">Tap the numbers you got wrong' + (nWrong ? ' (' + nWrong + ' selected)' : '') + '. Tap again to undo.</p><div class="sat-nums" role="group" aria-label="Wrong questions">' + nums.map(n => '<button type="button" class="sat-num' + (st.wrong[n] ? ' bad' : '') + '" data-n="' + n + '" aria-pressed="' + !!st.wrong[n] + '">' + n + '</button>').join('') + '</div></div>';
      if(nWrong){
        h += '<div class="card mt-16"><h3 class="card-h">Tell us about each one</h3><p class="muted fs-13">Choose the domain Bluebook listed. The other fields are optional.</p><div class="sat-wl">' +
          Object.keys(st.wrong).map(Number).sort((a, b) => a - b).map(n => { const w = st.wrong[n];
            return '<div class="sat-wrow" data-w="' + n + '"><b class="sat-wn">' + n + '</b><div class="field"><label class="sr" for="bbd' + n + '">Domain for question ' + n + '</label><select class="inp" id="bbd' + n + '" data-f="domain"><option value="">Domain…</option>' + ds.map(d => '<option value="' + esc(d.id) + '"' + (w.domain === d.id ? ' selected' : '') + '>' + esc(d.name) + '</option>').join('') + '</select></div>' +
              '<div class="field"><label class="sr" for="bbk' + n + '">Skill for question ' + n + '</label><select class="inp" id="bbk' + n + '" data-f="skill_id"' + (w.domain ? '' : ' disabled') + '><option value="">Skill (if you know)</option>' + (w.domain ? (ds.find(d => d.id === w.domain) || { skills: [] }).skills.map(s => '<option value="' + esc(s.id) + '"' + (w.skill_id === s.id ? ' selected' : '') + '>' + esc(s.name) + '</option>').join('') : '') + '</select></div>' +
              '<div class="field"><label class="sr" for="bbc' + n + '">Your answer for question ' + n + '</label><select class="inp" id="bbc' + n + '" data-f="chosen"><option value="">Answer I chose</option>' + (st.section === 'rw' || true ? ['A', 'B', 'C', 'D'].map(k => '<option' + (w.chosen === k ? ' selected' : '') + '>' + k + '</option>').join('') : '') + '</select></div>' +
              '<label class="sat-chk"><input type="checkbox" data-f="ran" ' + (w.ran ? 'checked' : '') + '> ran out of time</label></div>'; }).join('') + '</div></div>';
      }
      h += '<div class="card mt-16"><h3 class="card-h">Questions you got right but guessed</h3><p class="muted fs-13">Optional. These count as shaky, not solid.</p><div class="sat-nums" role="group" aria-label="Unsure but right">' +
        nums.filter(n => !st.wrong[n]).map(n => '<button type="button" class="sat-num' + (st.unsure.has(n) ? ' warn' : '') + '" data-u="' + n + '" aria-pressed="' + st.unsure.has(n) + '">' + n + '</button>').join('') + '</div></div>';
      h += '<div class="card mt-16"><h3 class="card-h">Domain levels from Bluebook</h3><p class="muted fs-13">Optional. Bluebook shows a level from 1 to 7 for each domain.</p><div class="grid g2">' +
        ds.map(d => '<div class="field"><label for="bbl' + esc(d.id) + '">' + esc(d.name) + '</label><select class="inp" id="bbl' + esc(d.id) + '" data-l="' + esc(d.id) + '"><option value="">Not shown</option>' + [1, 2, 3, 4, 5, 6, 7].map(x => '<option' + (String(st.levels[d.id]) === String(x) ? ' selected' : '') + '>' + x + '</option>').join('') + '</select></div>').join('') + '</div>' +
        '<div class="field mt-12"><label for="bbN">One short note <span class="muted">(optional, one line, no question text)</span></label><input class="inp" id="bbN" maxlength="40" value="' + esc(st.notes) + '" placeholder="e.g. rushed module 2"></div></div>';
      h += '<div class="row mt-16 wrap"><button class="btn acc" id="bbGo"' + (nWrong ? '' : ' disabled') + '>Import and build my audit<i class="ph ph-arrow-right"></i></button>' + (nWrong ? '' : '<span class="muted fs-13">Select at least one missed question. A perfect module has nothing to import.</span>') + '</div><div id="bbErr"></div>';
      body.innerHTML = h;
      bind();
    }
    const keepScroll = fn => { const y = window.scrollY; fn(); window.scrollTo(0, y); };
    function bind(){
      $('#bbT').onchange = e => { st.test_number = e.target.value; };
      $('#bbS').onchange = e => { st.section = e.target.value; st.wrong = {}; st.unsure = new Set(); st.levels = {}; paint(); };
      $('#bbM').onchange = e => { st.module = +e.target.value; };
      body.querySelectorAll('[data-n]').forEach(b => b.onclick = () => keepScroll(() => { const n = +b.dataset.n; if(st.wrong[n]) delete st.wrong[n]; else { st.wrong[n] = {}; st.unsure.delete(n); } paint(); }));
      body.querySelectorAll('[data-u]').forEach(b => b.onclick = () => keepScroll(() => { const n = +b.dataset.u; st.unsure.has(n) ? st.unsure.delete(n) : st.unsure.add(n); paint(); }));
      body.querySelectorAll('[data-w]').forEach(row => {
        const n = +row.dataset.w;
        row.querySelectorAll('[data-f]').forEach(el => el.onchange = () => {
          const f = el.dataset.f, w = st.wrong[n];
          if(f === 'ran') w.ran = el.checked; else w[f] = el.value || undefined;
          if(f === 'domain'){ w.skill_id = undefined; keepScroll(paint); }
        });
      });
      body.querySelectorAll('[data-l]').forEach(el => el.onchange = () => { if(el.value) st.levels[el.dataset.l] = +el.value; else delete st.levels[el.dataset.l]; });
      $('#bbN').oninput = e => { st.notes = e.target.value; };
      $('#bbGo').onclick = submit;
    }
    async function submit(){
      const btn = $('#bbGo'), err = $('#bbErr'); err.innerHTML = '';
      const miss = Object.keys(st.wrong).filter(n => !st.wrong[n].domain);
      if(miss.length){ err.innerHTML = '<div class="card sat-err mt-12" role="alert"><i class="ph ph-warning-circle"></i><div><b>Choose a domain for question' + (miss.length > 1 ? 's ' : ' ') + miss.join(', ') + '.</b></div></div>'; return; }
      const prof = await A.ensureProfile(); if(!prof) return;
      const payload = {
        profile_id: prof.id, test_number: st.test_number, section: st.section, module: st.module, replace: st.replace || undefined,
        wrong: Object.keys(st.wrong).map(Number).sort((a, b) => a - b).map(n => { const w = st.wrong[n], o = { n, domain: w.domain }; if(w.skill_id) o.skill_id = w.skill_id; if(w.chosen) o.chosen = w.chosen; if(w.ran) o.ran_out_of_time = true; return o; }),
        unsure_right: [...st.unsure].sort((a, b) => a - b), domain_levels: Object.keys(st.levels).length ? st.levels : undefined, notes: st.notes.trim() || undefined
      };
      SAT.busy(btn, true, 'Importing');
      try{
        const res = await A.post('/api/import/bluebook', payload);
        if(!alive()) return;
        done(res);
      }catch(e){
        SAT.busy(btn, false);
        if(e.code === 'conflict' || e.status === 409){
          if(await SAT.confirm('Already imported', 'You already imported this test, section and module. Replace it with these answers?', 'Replace', true)){ st.replace = true; return submit(); }
          return;
        }
        const det = e.details && e.details.length ? '<ul>' + e.details.map(x => '<li>' + esc(String(x)) + '</li>').join('') + '</ul>' : '';
        err.innerHTML = '<div class="card sat-err mt-12" role="alert"><i class="ph ph-warning-circle"></i><div><b>' + esc(SAT.errText(e)) + '</b>' + det + '</div></div>';
      }
    }
    function done(res){
      const L = res.study_links || {};
      body.innerHTML = '<div class="card sat-hero"><span class="tag acc"><i class="ph ph-check-circle"></i>Imported</span><h2 class="sat-h">Your Bluebook audit is ready</h2><p class="sat-snap">' + esc(res.n_wrong + ' missed question' + (res.n_wrong === 1 ? '' : 's') + ' recorded.') + '</p>' +
        '<p class="muted fs-13"><i class="ph ph-info"></i> ' + esc(res.confidence_note || '') + '</p>' + ((res.warnings || []).length ? '<ul class="muted fs-13">' + res.warnings.map(w => '<li>' + esc(w) + '</li>').join('') + '</ul>' : '') +
        (res.top_levers && res.top_levers.length ? '<h3 class="mt-16">Where to look first</h3><div class="sat-traps">' + res.top_levers.map(l => '<span class="chip">' + esc(l.name) + '</span>').join('') + '</div>' : '') +
        '<div class="row mt-16 wrap"><button class="btn acc" id="bbAu">Open the audit<i class="ph ph-arrow-right"></i></button><button class="btn line" id="bbPl">See my plan</button><button class="btn ghost" id="bbMore">Import another module</button></div></div>' +
        '<div class="card sat-note mt-16"><i class="ph ph-link"></i><div><b>Study the questions themselves</b><p class="muted">' + esc(L.note || '') + '</p><div class="row wrap">' +
        (L.college_board_question_bank ? '<a class="btn line sm" href="' + esc(L.college_board_question_bank) + '" target="_blank" rel="noopener">College Board practice</a>' : '') + (L.khan_academy_sat ? '<a class="btn line sm" href="' + esc(L.khan_academy_sat) + '" target="_blank" rel="noopener">Khan Academy SAT</a>' : '') + '</div></div></div>';
      $('#bbAu').onclick = () => SAT.open('audit', res.session_id); $('#bbPl').onclick = () => SAT.open('plan'); $('#bbMore').onclick = () => SAT.render();
    }
    paint();
  };
})();
