// Content fingerprints. PURE, no dependencies.
//  fingerprint(q)  = identity of the FULL item (passage + stem + visual data + choices + key). Two items with the same fingerprint are real duplicates.
//  templateKey(q)  = the wording with every number masked. Many items sharing one templateKey are variants of one template
//                    (fine as parametric practice, but they count as ONE scenario when we judge variety).
import { sha256, canonicalJson } from '../util/hash.mjs';

const clean = (s) => String(s ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
const answerOf = (q) => (q.format === 'spr' ? (q.spr?.accepted ?? []).map(clean).sort() : (q.choices ?? []).filter((c) => c.is_correct).map((c) => clean(c.text)));

export function fingerprint(q) {
  return sha256(canonicalJson({
    p: clean(q.passage?.text), s: clean(q.stem), v: q.visual?.data ?? null,
    c: (q.choices ?? []).map((c) => clean(c.text)).sort(), a: answerOf(q), spr: q.format === 'spr',
  })).slice(0, 16);
}

export function templateKey(q) {
  const mask = (s) => clean(s).replace(/\$/g, '').replace(/-?\d+(\.\d+)?/g, '#').replace(/\b[a-z]\b/g, 'v');
  return sha256(mask(q.passage?.text) + '|' + mask(q.stem)).slice(0, 12);
}
