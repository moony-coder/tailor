// Mistake Interview: which questions to ask about (cap 12), reason chips, second-chance scheduling. PURE selection + small helpers.
import { skillP } from '../engine/mastery.mjs';
import { expectedQuestions } from '../engine/levers.mjs';

/**
 * attempts: rows of ONE session. Returns { queue: [{attempt_id, priority, why, ...}], auto: [attempt_ids not asked], cap }
 * priority = skill_weakness x test_weight x (wrong ? 1 : correct_weight)
 */
export function selectInterview(attempts, mastery, tax, cfg) {
  const I = cfg.interview, cands = [];
  for (const a of attempts) {
    let why = null;
    if (!a.is_correct) why = a.unanswered ? 'unanswered' : 'wrong';
    else if (a.flagged) why = 'flagged_not_sure';
    else if (a.answer_changes > 0) why = 'changed_answer';
    else if (a.telemetry && a.first_response_ms != null && a.first_response_ms < I.shaky_correct_fast_ratio * a.est_time_sec * 1000) why = 'suspiciously_fast';
    if (!why) continue;
    const p = a.skill_id ? (skillP(mastery, a.skill_id) ?? 0.5) : 0.5;
    const weakness = 1 - p;
    const weight = a.skill_id ? expectedQuestions(tax, a.skill_id, cfg) : 1;
    const priority = weakness * Math.max(weight, 0.05) * (a.is_correct ? I.correct_weight : 1) * (a.unanswered ? 0.6 : 1);   // unanswered = timing, little to learn per item
    cands.push({ attempt_id: a.id, question_id: a.question_id, question_ref: a.question_ref, skill_id: a.skill_id, domain: a.domain, position: a.position, is_correct: !!a.is_correct, why, priority: Math.round(priority * 1e4) / 1e4, section: a.section });
  }
  cands.sort((x, y) => y.priority - x.priority || String(x.attempt_id).localeCompare(String(y.attempt_id)));
  const queue = cands.slice(0, I.cap), asked = new Set(queue.map((c) => c.attempt_id));
  return { queue, auto: attempts.filter((a) => !a.is_correct && !asked.has(a.id)).map((a) => a.id), cap: I.cap, total_candidates: cands.length };
}

/** Chips shown for a section: reasons with section == that section or 'both'. */
export const chipsFor = (tax, section) => tax.reasons.filter((r) => r.section === section || r.section === 'both').map((r) => ({ code: r.code, label: r.label }));

/** Validate a review submission. Returns {ok, errors, reason, rootCause}. Free text is stored only as a short takeaway and is NEVER sent to an LLM. */
export function validateReview(body, tax, section) {
  const errors = [];
  let reason = null;
  if (body.self_reason != null) {
    reason = tax.reasonByCode.get(body.self_reason);
    if (!reason) errors.push(`unknown reason ${body.self_reason}`);
    else if (reason.section !== 'both' && reason.section !== section) errors.push(`reason ${body.self_reason} does not apply to ${section}`);
  }
  if (body.understood_after_solution != null && !['yes', 'partly', 'no'].includes(body.understood_after_solution)) errors.push('understood_after_solution must be yes|partly|no');
  if (body.takeaway_text != null && (typeof body.takeaway_text !== 'string' || body.takeaway_text.length > 280)) errors.push('takeaway_text must be a string of at most 280 characters');
  return { ok: !errors.length, errors, reason, rootCause: reason?.root_cause ?? null };
}

/** Second-chance schedule: stage 0 -> +2 days, 1 -> +7, 2 -> +21 (only moves forward after a failure). */
export function nextDueDays(stage, cfg) { const d = cfg.interview.second_chance_days; return d[Math.min(stage, d.length - 1)]; }
