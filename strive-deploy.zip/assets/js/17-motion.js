/* ============================================================
   MOTION: the single system behind every transition in the app.

   1. Page changes   go() leaves the old view (150ms), swaps, then lets the new view
                     rise in with a short stagger (about 500ms). Interruptible: click
                     another tab mid-way and it retargets from where it is.
   2. Toggles        any `.sg` / `[data-seg]` / `.segs` container gets a thumb that
                     glides to the active button (no more instant colour jumps).
   3. Panels         Motion.swap(el, fn) repaints a panel in place and eases it in (never blanks it).
   4. Boot           returning visits fade in instead of popping.

   Only transform and opacity are animated. Everything honours prefers-reduced-motion.
   ============================================================ */
(function(){
  'use strict';
  const $ = (s, r) => (r||document).querySelector(s);
  const $$ = (s, r) => Array.from((r||document).querySelectorAll(s));
  const REDUCED = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const EASE = 'cubic-bezier(.23,1,.32,1)';
  const can = el => !REDUCED && !!el && typeof el.animate === 'function';

  /* ---------------------------------------------------------- stagger targets */
  function flat(el, depth){
    const out = [];
    Array.from(el.children).forEach(c => {
      if(c.classList.contains('hidden') || c.hidden) return;
      const cs = getComputedStyle(c);
      if(cs.display === 'none' || cs.position === 'fixed') return;
      const many = c.children.length > 1;
      if(depth > 0 && many && (cs.display === 'grid' || cs.display === 'flex') && !c.classList.contains('card') && !c.classList.contains('rv')){ out.push(...flat(c, depth-1)); }
      else if(depth > 0 && c.children.length === 1 && !c.classList.contains('card')){ out.push(...flat(c, depth-1)); }
      else out.push(c);
    });
    return out;
  }
  function targets(root){
    const vh = innerHeight * 1.05;
    return flat(root, 2).filter(k => !k.classList.contains('rv') && k.getBoundingClientRect().top < vh && k.getBoundingClientRect().height > 0);
  }
  function rise(kids, base){
    kids.forEach((k, i) => {
      k.animate([{ opacity:0, transform:'translateY(14px)' }, { opacity:1, transform:'none' }],
        { duration:520, delay:(base||0) + Math.min(i, 9) * 42, easing:EASE, fill:'backwards' });
    });
  }

  /* ---------------------------------------------------------- enter / leave */
  function enter(view){
    if(!can(view)) return;
    view.animate([{ opacity:0 }, { opacity:1 }], { duration:240, easing:'linear', fill:'backwards' });
    rise(targets(view));
  }
  function leave(view){
    return new Promise(res => {
      if(!can(view)) return res();
      const o = parseFloat(getComputedStyle(view).opacity);
      const a = view.animate([{ opacity: isNaN(o) ? 1 : o, transform:'translateY(0)' }, { opacity:0, transform:'translateY(-6px)' }],
        { duration:150, easing:EASE, fill:'forwards' });
      a.onfinish = a.oncancel = () => res();
    });
  }
  function killAnims(el){ if(el && el.getAnimations) el.getAnimations({ subtree:true }).forEach(a => a.cancel()); }

  /* ---------------------------------------------------------- panel swap */
  /* The panel is repainted in the same frame as the click and then eased in from a
     soft, still-visible state. It is never faded to empty first (that blank beat was the
     "appears, disappears, comes back" glitch), and a second click cancels the first cleanly. */
  function swap(el, fn){
    if(!can(el) || !el.isConnected || !el.getClientRects().length){ fn(); return Promise.resolve(); }
    if(el._swapAnim) el._swapAnim.cancel();
    el.getAnimations({ subtree:true }).forEach(x => { if(x !== el._swapAnim) x.cancel(); });
    fn();
    const a = el._swapAnim = el.animate([{ opacity:.55 }, { opacity:1 }], { duration:220, easing:EASE });
    flat(el, 1).filter(k => !k.classList.contains('rv')).slice(0, 10).forEach((k, i) => {
      k.animate([{ opacity:.4, transform:'translateY(8px)' }, { opacity:1, transform:'none' }],
        { duration:320, delay:i * 20, easing:EASE, fill:'backwards' });
    });
    return new Promise(res => { a.onfinish = a.oncancel = () => { if(el._swapAnim === a) el._swapAnim = null; res(); }; });
  }
  /* a number or label that just changed: a short, quiet tick */
  function tick(el){
    if(!can(el)) return;
    el.animate([{ opacity:0, transform:'translateY(5px)' }, { opacity:1, transform:'none' }], { duration:280, easing:EASE });
  }

  /* ---------------------------------------------------------- sliding toggle thumb */
  const SEG = '.sg, [data-seg], .segs, .pill-opts';
  function activeOf(c){ return c.querySelector(':scope > button.on, :scope > button[aria-pressed="true"], :scope > button.active'); }
  function place(c, animate){
    const t = c._thumb; if(!t) return;
    if(!t.isConnected) c.prepend(t); /* innerHTML re-renders (Watch filters, etc.) wipe the thumb */
    const a = activeOf(c);
    if(!a || !a.offsetWidth){ t.style.opacity = '0'; return; }
    if(!animate){ t.classList.add('no-anim'); }
    t.style.opacity = '1';
    t.style.width = a.offsetWidth + 'px';
    t.style.height = a.offsetHeight + 'px';
    t.style.setProperty('--sg-x', a.offsetLeft + 'px');
    t.style.setProperty('--sg-y', a.offsetTop + 'px');
    if(!animate){ void t.offsetWidth; t.classList.remove('no-anim'); }
    c._tw = a.offsetWidth;
  }
  function mount(c){
    if(c._thumb || c.closest('#exam')) return;
    c.classList.add('sg');
    const t = document.createElement('i'); t.className = 'sg-thumb'; t.setAttribute('aria-hidden','true');
    c.prepend(t); c._thumb = t;
    let raf = 0;
    const re = anim => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => place(c, anim)); };
    new MutationObserver(m => { if(m.some(x => x.type !== 'childList' || Array.from(x.addedNodes).some(n => n !== t))){ cancelAnimationFrame(raf); place(c, true); } })
      .observe(c, { attributes:true, attributeFilter:['class','aria-pressed'], subtree:true, childList:true });
    if('ResizeObserver' in window) new ResizeObserver(() => { const a = activeOf(c); re(!!(c._tw && a && a.offsetWidth && c._tw > 0)); }).observe(c);
    place(c, false);
  }
  function scan(root){
    if(root.nodeType !== 1) return;
    if(root.matches && root.matches(SEG)) mount(root);
    if(root.querySelectorAll) root.querySelectorAll(SEG).forEach(mount);
  }
  let pend = [], scheduled = false;
  new MutationObserver(ms => {
    ms.forEach(m => m.addedNodes.forEach(n => { if(n.nodeType === 1 && n.className !== 'sg-thumb') pend.push(n); }));
    if(pend.length && !scheduled){ scheduled = true; requestAnimationFrame(() => { const p = pend; pend = []; scheduled = false; p.forEach(n => n.isConnected && scan(n)); }); }
  }).observe(document.body, { childList:true, subtree:true });
  scan(document.body);

  /* ---------------------------------------------------------- nav pill */
  const nav = $('#nav');
  let pill = null;
  function placePill(){
    if(!nav) return;
    const a = $('button.active', nav);
    if(!a || !a.offsetHeight){ nav.classList.remove('has-pill'); return; }
    if(!pill){ pill = document.createElement('i'); pill.className = 'nx-pill'; nav.prepend(pill); }
    pill.style.height = a.offsetHeight + 'px';
    pill.style.setProperty('--y', a.offsetTop + 'px');
    nav.classList.add('has-pill');
  }
  function markActive(name){
    const more = typeof MORE_VIEWS !== 'undefined' ? MORE_VIEWS : [];
    $$('#nav button, #tabbar button').forEach(b => b.classList.toggle('active', b.dataset.v === name || (b.dataset.more !== undefined && more.indexOf(name) > -1)));
    placePill();
  }
  addEventListener('resize', placePill);
  document.fonts && document.fonts.ready.then(placePill);

  /* ---------------------------------------------------------- go() */
  const _go = go;
  let token = 0;
  function settle(name){ scrollTo({ top:0, behavior:'instant' }); placePill(); const v = $('#v-' + name); return v; }

  go = function(name){
    const cur = typeof currentView !== 'undefined' ? currentView : null;
    const ready = document.body.classList.contains('done');
    if(!ready || REDUCED || !name || name === cur){ _go(name); settle(name); return; }

    markActive(name);                       // the pill starts moving the instant you click
    const my = ++token;
    const oldV = $('#v-' + cur);
    const out = oldV && !oldV.classList.contains('hidden') ? leave(oldV) : Promise.resolve();
    out.then(() => {
      if(my !== token) return;              // a newer click took over
      _go(name);                            // hide old, show new, render (one task, no paint in between)
      killAnims(oldV);
      const v = settle(name);
      if(v){ killAnims(v); enter(v); }
    });
  };

  /* ---------------------------------------------------------- boot */
  function boot(){
    document.documentElement.classList.remove('booting');
    const app = $('#app');
    if(!can(app)) return;
    app.animate([{ opacity:0 }, { opacity:1 }], { duration:420, easing:'linear', fill:'backwards' });
    $$('#nav button').forEach((b, i) => b.animate([{ opacity:0, transform:'translateX(-10px)' }, { opacity:1, transform:'none' }], { duration:520, delay:80 + i*32, easing:EASE, fill:'backwards' }));
    const v = $('.view:not(.hidden)'); if(v) rise(targets(v), 120);
    placePill();
  }

  addEventListener('load', () => { placePill(); });
  setTimeout(placePill, 400); setTimeout(placePill, 1500);
  window.Motion = { swap, tick, enter, rise, targets, mount, place, boot, reduced: REDUCED };
})();
