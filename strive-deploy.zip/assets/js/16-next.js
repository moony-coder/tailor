/* ============================================================
   NEXT: replaces browser-default controls with Strive-made ones.
   Works on anything already in the page and on anything added later.
     <select>            -> searchable listbox / mobile bottom sheet
     input[type=date]    -> calendar popover (SAT Saturdays marked)
     input[type=number]  -> stepper with hold-to-repeat
     input[type=range]   -> live fill + value bubble
     title="..."         -> styled tooltip with key caps
     overflow-x areas    -> edge fades, drag-to-scroll, wheel, arrows
     confirm()           -> UI.confirm() modal
     Cmd/Ctrl+K          -> command palette (app only)
   Works without any other script: safe on onboarding.html too.
   ============================================================ */
(function(){
  'use strict';
  const $ = (s, r) => (r||document).querySelector(s);
  const $$ = (s, r) => Array.from((r||document).querySelectorAll(s));
  const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const REDUCED = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const SHEET = () => matchMedia('(max-width:640px)').matches;
  const topLayer = () => document.fullscreenElement || document.webkitFullscreenElement || document.body;
  const IC = {
    chev:'<svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    check:'<svg class="ck" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m3.5 8.5 3 3 6-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    cal:'<svg width="18" height="18" viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="3" y="4.5" width="14" height="12.5" rx="3" stroke="currentColor" stroke-width="1.6"/><path d="M3 8.5h14M7 2.8v3.2M13 2.8v3.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    minus:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 8h9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    plus:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 8h9M8 3.5v9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    search:'<svg width="18" height="18" viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="9" cy="9" r="5.5" stroke="currentColor" stroke-width="1.8"/><path d="m13.5 13.5 3.5 3.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    left:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M10 3.5 5.5 8l4.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    right:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M6 3.5 10.5 8 6 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    x:'<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 4 8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    ret:'<svg class="ret" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M13 3.5v4.2a1.8 1.8 0 0 1-1.8 1.8H3.5m0 0L6.3 6.7M3.5 9.5l2.8 2.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    warn:'<svg width="30" height="30" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 8.5v4.5M12 16.5v.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M10.3 3.9 2.7 17.2A2 2 0 0 0 4.4 20.2h15.2a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    ask:'<svg width="30" height="30" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.6 2.2c-.8.4-1.2.9-1.2 1.8M12 16.6v.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
  };

  /* ---------- one floating panel at a time ---------- */
  let openPop = null;
  function closePop(instant){
    const p = openPop; if(!p) return; openPop = null;
    document.removeEventListener('pointerdown', p.onDown, true);
    window.removeEventListener('resize', p.onRe); window.removeEventListener('scroll', p.onRe, true);
    const done = () => { p.el.remove(); p.back && p.back.remove(); };
    if(instant || REDUCED) done(); else { p.el.classList.add('out'); setTimeout(done, 150); }
    p.onClose && p.onClose();
  }
  function place(pop, anchor, wMin){
    const r = anchor.getBoundingClientRect(), vw = innerWidth, vh = innerHeight;
    const w = Math.max(wMin ? r.width : 0, pop.offsetWidth || 0);
    pop.style.width = wMin ? Math.max(r.width, wMin)+'px' : '';
    const cap = pop.classList.contains('cal') ? 440 : 340, h = Math.min(pop.scrollHeight, cap);
    const below = vh - r.bottom - 12, above = r.top - 12;
    const up = below < h && above > below;
    const maxH = Math.max(160, Math.min(cap, up ? above : below));
    pop.style.maxHeight = maxH+'px';
    const ph = Math.min(pop.scrollHeight, maxH);
    let left = clamp(r.left, 10, Math.max(10, vw - (pop.offsetWidth || w) - 10));
    pop.style.left = left+'px';
    pop.style.top = (up ? r.top - ph - 8 : r.bottom + 8)+'px';
    pop.classList.toggle('up', up);
    pop.style.setProperty('--ox', clamp(r.left + r.width/2 - left, 0, pop.offsetWidth)+'px');
  }
  function mountPop(el, anchor, opts){
    closePop(true);
    const sheet = SHEET();
    let back = null;
    if(sheet){ back = document.createElement('div'); back.className = 'nx-back'; topLayer().appendChild(back); el.classList.add('sheet'); el.insertAdjacentHTML('afterbegin','<div class="nx-grab"></div>'); }
    topLayer().appendChild(el);
    if(!sheet) place(el, anchor, opts && opts.minW);
    const p = openPop = { el, back, onClose: opts && opts.onClose };
    p.onDown = e => { if(el.contains(e.target) || anchor.contains(e.target)) return; closePop(); };
    p.onRe = e => { if(e && e.type === 'scroll' && el.contains(e.target)) return; if(sheet) return; if(e && e.type==='resize') place(el, anchor, opts && opts.minW); else place(el, anchor, opts && opts.minW); };
    document.addEventListener('pointerdown', p.onDown, true);
    window.addEventListener('resize', p.onRe); window.addEventListener('scroll', p.onRe, true);
    return p;
  }

  /* ============================================================
     SELECT
     ============================================================ */
  function enhanceSelect(sel){
    if(sel._ns || sel.multiple || sel.size > 1 || sel.closest('.nx-pop')) return;
    sel._ns = 1;
    const w = document.createElement('div'); w.className = 'ns'+(sel.classList.contains('sm') ? ' sm' : '');
    sel.parentNode.insertBefore(w, sel); w.appendChild(sel);
    sel.classList.add('ns-native'); sel.tabIndex = -1; sel.setAttribute('aria-hidden','true');
    const b = document.createElement('button'); b.type = 'button'; b.className = 'ns-btn';
    b.setAttribute('aria-haspopup','listbox'); b.setAttribute('aria-expanded','false');
    b.innerHTML = '<span class="ns-val"></span><span class="ns-chev">'+IC.chev+'</span>';
    w.appendChild(b);
    const lab = sel.id && document.querySelector('label[for="'+sel.id+'"]');
    if(lab){ if(!lab.id) lab.id = sel.id+'-l'; b.setAttribute('aria-labelledby', lab.id); lab.addEventListener('click', e => { e.preventDefault(); b.focus(); b.click(); }); }
    else if(sel.getAttribute('aria-label')) b.setAttribute('aria-label', sel.getAttribute('aria-label'));
    const val = b.firstChild;
    const sync = () => {
      const o = sel.options[sel.selectedIndex];
      const t = o ? o.textContent.trim() : '';
      val.textContent = t || sel.getAttribute('placeholder') || 'Select';
      val.classList.toggle('ph', !t || (o && o.value === '' && !!o.disabled));
      w.classList.toggle('dis', sel.disabled);
    };
    sync();
    sel.addEventListener('change', sync);
    new MutationObserver(sync).observe(sel, { childList:true, subtree:true, attributes:true, characterData:true });

    function open(){
      if(sel.disabled) return;
      const items = []; // {o, i}
      const frag = [];
      const pushOpt = (o, i) => { items.push({ o, i, label:o.textContent.trim() }); };
      Array.from(sel.children).forEach(c => {
        if(c.tagName === 'OPTGROUP'){ items.push({ grp:c.label }); Array.from(c.children).forEach(o => pushOpt(o, sel.options.length && Array.prototype.indexOf.call(sel.options, o))); }
        else if(c.tagName === 'OPTION') pushOpt(c, Array.prototype.indexOf.call(sel.options, c));
      });
      const count = items.filter(x => x.o).length;
      const pop = document.createElement('div'); pop.className = 'nx-pop'+(sel.classList.contains('sm') ? ' sm' : ''); pop.tabIndex = -1;
      pop.innerHTML = (count > 12 ? '<div class="nx-search">'+IC.search+'<input type="text" placeholder="Search" aria-label="Search options" autocomplete="off" spellcheck="false"></div>' : '')+'<div class="nx-list" role="listbox"></div>';
      const list = $('.nx-list', pop), input = $('input', pop);
      let act = -1, query = '', typed = '', typedT = 0;
      const render = () => {
        const q = query.trim().toLowerCase(); let shown = 0, lastGrp = null;
        list.innerHTML = '';
        items.forEach(it => {
          if(it.grp != null){ lastGrp = it; return; }
          if(q && it.label.toLowerCase().indexOf(q) < 0) return;
          if(lastGrp && !lastGrp.done){ const g = document.createElement('div'); g.className = 'nx-grp'; g.textContent = lastGrp.grp; list.appendChild(g); lastGrp.done = 1; }
          const d = document.createElement('div'); d.className = 'nx-opt'+(it.o.selected ? ' sel' : '')+(it.o.disabled ? ' dis' : '');
          d.setAttribute('role','option'); d.setAttribute('aria-selected', it.o.selected ? 'true' : 'false'); d._it = it;
          let html = esc(it.label);
          if(q){ const k = it.label.toLowerCase().indexOf(q); html = esc(it.label.slice(0,k))+'<mark>'+esc(it.label.slice(k,k+q.length))+'</mark>'+esc(it.label.slice(k+q.length)); }
          d.innerHTML = '<span>'+html+'</span>'+IC.check;
          list.appendChild(d); shown++;
        });
        items.forEach(it => { if(it.grp != null) delete it.done; });
        if(!shown) list.innerHTML = '<div class="nx-empty">Nothing matches "'+esc(query)+'"</div>';
        const opts = $$('.nx-opt:not(.dis)', list);
        setAct(Math.max(0, opts.findIndex(o => o.classList.contains('sel'))), false);
      };
      const setAct = (i, scroll) => {
        const opts = $$('.nx-opt:not(.dis)', list); if(!opts.length){ act = -1; return; }
        act = (i + opts.length) % opts.length;
        opts.forEach((o, k) => o.classList.toggle('act', k === act));
        if(scroll !== false) opts[act].scrollIntoView({ block:'nearest' });
        else { const o = opts[act]; list.scrollTop = Math.max(0, o.offsetTop - list.clientHeight/2 + o.offsetHeight/2); }
      };
      const choose = d => {
        if(!d || !d._it) return; const o = d._it.o;
        if(sel.selectedIndex !== d._it.i){ sel.selectedIndex = d._it.i; sel.dispatchEvent(new Event('input', { bubbles:true })); sel.dispatchEvent(new Event('change', { bubbles:true })); }
        close(); b.focus();
      };
      list.addEventListener('pointermove', e => { const d = e.target.closest('.nx-opt'); if(d && !d.classList.contains('dis')){ const opts = $$('.nx-opt:not(.dis)', list), k = opts.indexOf(d); opts.forEach((o, j) => o.classList.toggle('act', j === k)); act = k; } });
      list.addEventListener('click', e => choose(e.target.closest('.nx-opt')));
      pop.addEventListener('keydown', e => {
        const opts = $$('.nx-opt:not(.dis)', list);
        if(e.key === 'ArrowDown'){ e.preventDefault(); setAct(act+1); }
        else if(e.key === 'ArrowUp'){ e.preventDefault(); setAct(act-1); }
        else if(e.key === 'Home'){ e.preventDefault(); setAct(0); }
        else if(e.key === 'End'){ e.preventDefault(); setAct(opts.length-1); }
        else if(e.key === 'PageDown'){ e.preventDefault(); setAct(Math.min(opts.length-1, act+6)); }
        else if(e.key === 'PageUp'){ e.preventDefault(); setAct(Math.max(0, act-6)); }
        else if(e.key === 'Enter' || (e.key === ' ' && !input)){ e.preventDefault(); choose(opts[act]); }
        else if(e.key === 'Escape'){ e.preventDefault(); e.stopPropagation(); close(); b.focus(); }
        else if(e.key === 'Tab'){ close(); }
        else if(!input && e.key.length === 1 && !e.ctrlKey && !e.metaKey){
          clearTimeout(typedT); typed += e.key.toLowerCase(); typedT = setTimeout(() => typed = '', 600);
          const k = opts.findIndex(o => o._it.label.toLowerCase().startsWith(typed)); if(k >= 0) setAct(k);
        }
      });
      if(input) input.addEventListener('input', () => { query = input.value; render(); });
      render();
      b.setAttribute('aria-expanded','true'); w.classList.add('open');
      const close = () => { if(openPop && openPop.el === pop) closePop(); };
      mountPop(pop, b, { minW:200, onClose(){ b.setAttribute('aria-expanded','false'); w.classList.remove('open'); } });
      setAct(Math.max(0, $$('.nx-opt:not(.dis)', list).findIndex(o => o.classList.contains('sel'))), false);
      (input && !SHEET() ? input : pop).focus({ preventScroll:true });
    }
    b.addEventListener('click', () => { w.classList.contains('open') ? closePop() : open(); });
    b.addEventListener('keydown', e => { if(e.key === 'ArrowDown' || e.key === 'ArrowUp'){ e.preventDefault(); open(); } });
  }

  /* ============================================================
     NUMBER
     ============================================================ */
  function enhanceNumber(inp){
    if(inp._nn || inp.closest('.nn')) return; inp._nn = 1;
    const w = document.createElement('div'); w.className = 'nn'+(inp.classList.contains('sm') ? ' sm' : '');
    inp.parentNode.insertBefore(w, inp);
    const mk = (cls, label, ic) => { const x = document.createElement('button'); x.type = 'button'; x.className = 'nn-b '+cls; x.tabIndex = -1; x.setAttribute('aria-label', label); x.innerHTML = ic; return x; };
    const dn = mk('dn', 'Decrease', IC.minus), up = mk('up', 'Increase', IC.plus);
    w.append(dn, inp, up);
    const num = () => { const n = parseFloat(inp.value); return isNaN(n) ? null : n; };
    const lim = () => ({ min: inp.min !== '' ? +inp.min : -Infinity, max: inp.max !== '' ? +inp.max : Infinity, step: parseFloat(inp.step) > 0 ? parseFloat(inp.step) : 1 });
    const dis = () => { const { min, max } = lim(), n = num(); dn.disabled = n != null && n <= min; up.disabled = n != null && n >= max; };
    const bump = dir => {
      const { min, max, step } = lim(); let n = num();
      if(n == null) n = dir > 0 ? (isFinite(min) ? min : 0) : (isFinite(max) ? max : 0);
      else { n = Math.round((n + dir*step) / step) * step; }
      n = clamp(n, min, max); inp.value = String(Math.round(n*1e6)/1e6);
      inp.dispatchEvent(new Event('input', { bubbles:true })); dis();
    };
    [[dn, -1], [up, 1]].forEach(([btn, dir]) => {
      let t1 = 0, t2 = 0, n = 0;
      const stop = () => { clearTimeout(t1); clearInterval(t2); };
      btn.addEventListener('pointerdown', e => { e.preventDefault(); inp.focus(); bump(dir); n = 0; t1 = setTimeout(() => { t2 = setInterval(() => { n++; bump(dir * (n > 12 ? 5 : 1)); }, 70); }, 420); });
      ['pointerup','pointerleave','pointercancel'].forEach(ev => btn.addEventListener(ev, stop));
      btn.addEventListener('keydown', e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); bump(dir); } });
    });
    inp.addEventListener('input', dis);
    inp.addEventListener('change', () => { const { min, max } = lim(), n = num(); if(n != null){ inp.value = String(clamp(n, min, max)); } dis(); });
    dis();
  }

  /* ============================================================
     DATE
     ============================================================ */
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
  const parseYmd = s => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s||''); return m ? new Date(+m[1], +m[2]-1, +m[3]) : null; };
  const fmtLong = d => d.toLocaleDateString(undefined, { weekday:'short', month:'short', day:'numeric', year:'numeric' });
  const MONTHS = Array.from({ length:12 }, (_, i) => new Date(2000, i, 1).toLocaleDateString(undefined, { month:'long' }));
  const WD = Array.from({ length:7 }, (_, i) => new Date(2023, 0, 1+i).toLocaleDateString(undefined, { weekday:'narrow' }));
  const satSet = () => { try{ return new Set((typeof SAT_DATES !== 'undefined' ? SAT_DATES : []).map(x => x.d)); }catch(e){ return new Set(); } };

  function enhanceDate(inp){
    if(inp._nd || inp.closest('.nd')) return; inp._nd = 1;
    const w = document.createElement('div'); w.className = 'nd'+(inp.classList.contains('sm') ? ' sm' : '');
    inp.parentNode.insertBefore(w, inp); w.appendChild(inp);
    inp.classList.add('nd-native'); inp.tabIndex = -1; inp.setAttribute('aria-hidden','true');
    const b = document.createElement('button'); b.type = 'button'; b.className = 'nd-btn'; b.setAttribute('aria-haspopup','dialog');
    b.innerHTML = IC.cal+'<span class="nd-val"></span>'; w.appendChild(b);
    if(inp.getAttribute('aria-label')) b.setAttribute('aria-label', inp.getAttribute('aria-label'));
    const lab = inp.id && document.querySelector('label[for="'+inp.id+'"]'); if(lab) lab.addEventListener('click', e => { e.preventDefault(); b.focus(); b.click(); });
    const vEl = $('.nd-val', b);
    const sync = () => { const d = parseYmd(inp.value); vEl.textContent = d ? fmtLong(d) : (inp.getAttribute('placeholder') || 'Pick a date'); vEl.classList.toggle('ph', !d); };
    sync(); inp.addEventListener('change', sync); inp.addEventListener('input', sync);

    function open(){
      const min = parseYmd(inp.min), max = parseYmd(inp.max), today = new Date(); today.setHours(0,0,0,0);
      const sel = parseYmd(inp.value);
      let view = new Date((sel || today).getFullYear(), (sel || today).getMonth(), 1), focus = sel || (min && today < min ? min : today), dir = 1;
      const sats = satSet();
      const pop = document.createElement('div'); pop.className = 'nx-pop cal'; pop.tabIndex = -1; pop.setAttribute('role','dialog'); pop.setAttribute('aria-label','Choose a date');
      const off = d => (min && d < min) || (max && d > max);
      const draw = () => {
        const y = view.getFullYear(), m = view.getMonth(), first = new Date(y, m, 1), lead = first.getDay(), dim = new Date(y, m+1, 0).getDate();
        let cells = '';
        for(let i = 0; i < 42; i++){
          const d = new Date(y, m, 1 - lead + i), s = ymd(d), o = d.getMonth() !== m;
          cells += '<button type="button" class="cal-d'+(o ? ' o' : '')+(sel && s === ymd(sel) ? ' s' : '')+(s === ymd(today) ? ' t' : '')+(sats.has(s) ? ' sat' : '')+(s === ymd(focus) ? ' f' : '')+'" data-d="'+s+'"'+(off(d) ? ' disabled' : '')+' aria-label="'+esc(fmtLong(d))+(sats.has(s) ? ', SAT test day' : '')+'"'+(sel && s === ymd(sel) ? ' aria-pressed="true"' : '')+'>'+d.getDate()+'</button>';
        }
        const canPrev = !min || new Date(y, m, 0) >= min, canNext = !max || new Date(y, m+1, 1) <= max;
        pop.innerHTML = '<div class="cal-h"><b>'+MONTHS[m]+'<small>'+y+'</small></b><button type="button" class="cal-n" data-n="-1" aria-label="Previous month"'+(canPrev ? '' : ' disabled')+'>'+IC.left+'</button><button type="button" class="cal-n" data-n="1" aria-label="Next month"'+(canNext ? '' : ' disabled')+'>'+IC.right+'</button></div>'+
          '<div class="cal-w" aria-hidden="true">'+WD.map(x => '<span>'+x+'</span>').join('')+'</div><div class="cal-g" style="--dir:'+dir+'">'+cells+'</div>'+
          '<div class="cal-f">'+(sats.size ? '<span class="lg"><i></i>SAT test day</span>' : '<span></span>')+'<button type="button" data-t="1">Today</button></div>';
      };
      const pick = s => { inp.value = s; inp.dispatchEvent(new Event('input', { bubbles:true })); inp.dispatchEvent(new Event('change', { bubbles:true })); closePop(); b.focus(); };
      const moveFocus = d => {
        const n = new Date(focus.getFullYear(), focus.getMonth(), focus.getDate() + d); if(off(n)) return;
        const ch = n.getMonth() !== view.getMonth() || n.getFullYear() !== view.getFullYear();
        dir = n > focus ? 1 : -1; focus = n; if(ch) view = new Date(n.getFullYear(), n.getMonth(), 1);
        draw(); if(!ch){ const g = $('.cal-g', pop); if(g) g.style.animation = 'none'; }
      };
      pop.addEventListener('click', e => {
        const n = e.target.closest('[data-n]'); if(n){ dir = +n.dataset.n; view = new Date(view.getFullYear(), view.getMonth() + dir, 1); focus = new Date(view.getFullYear(), view.getMonth(), Math.min(focus.getDate(), 28)); draw(); return; }
        const d = e.target.closest('[data-d]'); if(d){ pick(d.dataset.d); return; }
        if(e.target.closest('[data-t]')){ let t = today; if(off(t)){ t = min && t < min ? min : (max || t); } view = new Date(t.getFullYear(), t.getMonth(), 1); focus = t; dir = 1; draw(); }
      });
      pop.addEventListener('keydown', e => {
        const k = e.key, map = { ArrowLeft:-1, ArrowRight:1, ArrowUp:-7, ArrowDown:7 };
        if(map[k]){ e.preventDefault(); moveFocus(map[k]); }
        else if(k === 'PageUp' || k === 'PageDown'){ e.preventDefault(); const n = new Date(focus.getFullYear(), focus.getMonth() + (k === 'PageUp' ? -1 : 1), focus.getDate()); if(!off(n)){ dir = k === 'PageUp' ? -1 : 1; focus = n; view = new Date(n.getFullYear(), n.getMonth(), 1); draw(); } }
        else if(k === 'Enter' || k === ' '){ if(e.target.closest('[data-n],[data-t]')) return; e.preventDefault(); if(!off(focus)) pick(ymd(focus)); }
        else if(k === 'Escape'){ e.preventDefault(); e.stopPropagation(); closePop(); b.focus(); }
      });
      draw(); b.setAttribute('aria-expanded','true'); w.classList.add('open');
      mountPop(pop, b, { onClose(){ b.setAttribute('aria-expanded','false'); w.classList.remove('open'); } });
      pop.focus({ preventScroll:true });
    }
    b.addEventListener('click', () => { w.classList.contains('open') ? closePop() : open(); });
    b.addEventListener('keydown', e => { if(e.key === 'ArrowDown'){ e.preventDefault(); open(); } });
  }

  /* ============================================================
     RANGE: live fill + value bubble
     ============================================================ */
  function enhanceRange(r){
    if(r._nr || r.closest('.vp')) return; r._nr = 1;
    const fill = () => { const mn = +r.min || 0, mx = r.max === '' ? 100 : +r.max; r.style.setProperty('--p', ((+r.value - mn) / (mx - mn || 1) * 100)+'%'); };
    fill(); r.addEventListener('input', fill);
    let tip = null;
    const show = () => {
      if(!tip){ tip = document.createElement('div'); tip.className = 'nx-tip on'; tip.style.cssText = 'pointer-events:none;font-variant-numeric:tabular-nums;font-weight:700;padding:5px 10px'; document.body.appendChild(tip); }
      const rc = r.getBoundingClientRect(), mn = +r.min || 0, mx = r.max === '' ? 100 : +r.max, f = (+r.value - mn) / (mx - mn || 1);
      tip.textContent = r.value; const x = rc.left + 14 + f * (rc.width - 28);
      tip.style.left = (x - tip.offsetWidth/2)+'px'; tip.style.top = (rc.top - tip.offsetHeight - 14)+'px'; tip.style.setProperty('--tx','50%');
    };
    const hide = () => { if(tip){ tip.remove(); tip = null; } };
    r.addEventListener('pointerdown', show); r.addEventListener('input', () => { if(tip) show(); });
    ['pointerup','pointercancel','blur'].forEach(ev => r.addEventListener(ev, hide));
  }

  /* ============================================================
     TOOLTIPS (title -> styled, with key caps)
     ============================================================ */
  let tipEl = null, tipT = 0, tipLast = 0, tipFor = null;
  function hideTip(){ clearTimeout(tipT); if(tipEl){ tipEl.classList.remove('on'); const t = tipEl; setTimeout(() => t.remove(), 180); tipEl = null; } tipFor = null; }
  function showTip(el){
    const raw = el.getAttribute('data-tip'); if(!raw) return;
    hideTip(); tipFor = el;
    const m = /^(.*?)\s*\(([A-Za-z0-9<>\/\\ +←→↑↓,.\-]{1,10})\)$/.exec(raw);
    const t = document.createElement('div'); t.className = 'nx-tip'; t.setAttribute('role','tooltip');
    t.innerHTML = '<span>'+esc(m ? m[1] : raw)+'</span>'+(m ? '<kbd>'+esc(m[2])+'</kbd>' : '');
    topLayer().appendChild(t); tipEl = t;
    const r = el.getBoundingClientRect(), w = t.offsetWidth, h = t.offsetHeight;
    let left = clamp(r.left + r.width/2 - w/2, 8, innerWidth - w - 8), top = r.top - h - 10, below = false;
    if(top < 8){ top = r.bottom + 10; below = true; }
    t.style.left = left+'px'; t.style.top = top+'px'; t.classList.toggle('below', below);
    t.style.setProperty('--tx', (r.left + r.width/2 - left)+'px');
    requestAnimationFrame(() => t.classList.add('on')); tipLast = Date.now();
  }
  function armTip(el){
    if(el.hasAttribute('title') && !el.closest('svg')){
      const v = el.getAttribute('title'); if(v){ el.setAttribute('data-tip', v); if(!el.hasAttribute('aria-label') && !el.textContent.trim()) el.setAttribute('aria-label', v.replace(/\s*\([^)]*\)$/, '')); }
      el.removeAttribute('title');
    }
  }
  document.addEventListener('pointerover', e => {
    if(e.pointerType === 'touch') return;
    const el = e.target.closest && e.target.closest('[title],[data-tip]'); if(!el) return;
    armTip(el); if(el === tipFor) return;
    clearTimeout(tipT); tipT = setTimeout(() => showTip(el), Date.now() - tipLast < 600 ? 40 : 380);
  }, true);
  document.addEventListener('pointerout', e => { const el = e.target.closest && e.target.closest('[data-tip]'); if(el && !el.contains(e.relatedTarget)) hideTip(); }, true);
  document.addEventListener('focusin', e => { const el = e.target.closest && e.target.closest('[title],[data-tip]'); if(el && e.target.matches(':focus-visible')){ armTip(el); showTip(el); } });
  document.addEventListener('focusout', hideTip);
  document.addEventListener('pointerdown', hideTip, true); document.addEventListener('scroll', hideTip, true);
  document.addEventListener('keydown', e => { if(e.key === 'Escape') hideTip(); });

  /* ============================================================
     HORIZONTAL SCROLLERS
     ============================================================ */
  function enhanceScroller(el){
    if(el._hs || el.closest('.vp') || el.closest('.nx-pop')) return; el._hs = 1;
    el.classList.add('hs');
    const wrap = document.createElement('div'); wrap.className = 'hs-wrap';
    if(getComputedStyle(el).display.indexOf('inline') === 0) wrap.style.display = 'inline-block';
    el.parentNode.insertBefore(wrap, el); wrap.appendChild(el);
    const mkA = (c, ic, label) => { const a = document.createElement('button'); a.type = 'button'; a.className = 'hs-arrow '+c; a.tabIndex = -1; a.setAttribute('aria-label', label); a.innerHTML = ic; wrap.appendChild(a); return a; };
    const L = mkA('l', IC.left, 'Scroll left'), R = mkA('r', IC.right, 'Scroll right');
    const upd = () => {
      const max = el.scrollWidth - el.clientWidth, x = el.scrollLeft;
      el.style.setProperty('--fl', x > 4 ? 1 : 0); el.style.setProperty('--fr', x < max - 4 ? 1 : 0);
      L.classList.toggle('show', x > 4); R.classList.toggle('show', x < max - 4); el.classList.toggle('can', max > 4);
    };
    el.addEventListener('scroll', upd, { passive:true }); new ResizeObserver(upd).observe(el); upd();
    const by = d => el.scrollBy({ left:d * el.clientWidth * .7, behavior:REDUCED ? 'auto' : 'smooth' });
    L.onclick = () => by(-1); R.onclick = () => by(1);
    el.addEventListener('wheel', e => {
      if(Math.abs(e.deltaY) <= Math.abs(e.deltaX) || e.ctrlKey) return;
      const max = el.scrollWidth - el.clientWidth; if(max <= 4) return;
      const dir = Math.sign(e.deltaY); if((dir < 0 && el.scrollLeft <= 0) || (dir > 0 && el.scrollLeft >= max - 1)) return;
      e.preventDefault(); el.scrollLeft += e.deltaY;
    }, { passive:false });
    let sx = 0, sl = 0, down = false, moved = false;
    el.addEventListener('pointerdown', e => { if(e.pointerType !== 'mouse' || e.button !== 0 || el.scrollWidth - el.clientWidth <= 4) return; down = true; moved = false; sx = e.clientX; sl = el.scrollLeft; });
    window.addEventListener('pointermove', e => { if(!down) return; const dx = e.clientX - sx; if(!moved && Math.abs(dx) > 5){ moved = true; el.classList.add('drag'); } if(moved) el.scrollLeft = sl - dx; });
    window.addEventListener('pointerup', () => { if(!down) return; down = false; if(moved){ el.classList.remove('drag'); el._noClick = Date.now(); } });
    el.addEventListener('click', e => { if(el._noClick && Date.now() - el._noClick < 120){ e.preventDefault(); e.stopPropagation(); } }, true);
    const on = el.querySelector('.on,.active,[aria-selected=true]'); if(on) requestAnimationFrame(() => { const r = on.getBoundingClientRect(), c = el.getBoundingClientRect(); if(r.right > c.right || r.left < c.left) el.scrollLeft += r.left - c.left - 20; });
  }
  function scanScrollers(root){
    $$('.w-seg,.xtools,[data-hscroll]', root).forEach(enhanceScroller);
    $$('.view *, .modal *', root === document ? document : root).forEach(el => {
      if(el._hs || el.scrollWidth <= el.clientWidth + 2 || el.clientWidth < 80) return;
      const o = getComputedStyle(el).overflowX; if(o === 'auto' || o === 'scroll') enhanceScroller(el);
    });
  }

  /* ============================================================
     CONFIRM
     ============================================================ */
  function confirmUI(o){
    o = o || {};
    return new Promise(res => {
      const m = document.createElement('div'); m.className = 'nx-modal'; m.style.placeItems = 'center';
      m.innerHTML = '<div class="nxc'+(o.danger ? ' danger' : '')+'" role="alertdialog" aria-modal="true" aria-labelledby="nxcT" aria-describedby="nxcP"><div class="nxc-i">'+(o.danger ? IC.warn : IC.ask)+'</div><h3 id="nxcT">'+esc(o.title || 'Are you sure?')+'</h3><p id="nxcP">'+esc(o.text || '')+'</p><div class="nxc-a"><button type="button" class="btn ghost" data-r="0">'+esc(o.cancel || 'Cancel')+'</button><button type="button" class="btn pri" data-r="1">'+esc(o.ok || 'Confirm')+'</button></div></div>';
      document.body.appendChild(m);
      const prev = document.activeElement;
      const done = v => { document.removeEventListener('keydown', key, true); m.classList.add('out'); setTimeout(() => { m.remove(); prev && prev.focus && prev.focus(); }, 150); res(v); };
      const key = e => { if(e.key === 'Escape'){ e.preventDefault(); e.stopPropagation(); done(false); } else if(e.key === 'Tab'){ const bs = $$('button', m); const i = bs.indexOf(document.activeElement); e.preventDefault(); bs[(i + (e.shiftKey ? -1 : 1) + bs.length) % bs.length].focus(); } };
      document.addEventListener('keydown', key, true);
      m.addEventListener('pointerdown', e => { if(e.target === m) done(false); });
      m.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if(b) done(b.dataset.r === '1'); });
      $('[data-r="' + (o.danger ? 0 : 1) + '"]', m).focus();
    });
  }

  /* ============================================================
     COMMAND PALETTE
     ============================================================ */
  function palette(){
    if($('.nx-modal.pal-w') || !$('#nav')) return;
    if(!document.body.classList.contains('done') && document.body.classList.contains('lock') && $('#intro') && getComputedStyle($('#intro')).display !== 'none') return;
    const g = n => { try{ return (0, eval)(n); }catch(e){ return undefined; } };      /* app globals are top-level const/let, not on window */
    const items = [];
    const add = o => items.push(o);

    /* ---- pages ---- */
    const PAGE_DESC = { dash:'Your score, streak and next step', practice:'Drill by section, domain and difficulty', bank:'Browse and filter every question', plan:'Your week-by-week study plan', test:'Full digital SAT, timed and adaptive', lessons:'Short written lessons with examples', watch:'Video lessons that remember your spot', progress:'Scores, accuracy and trends', review:'Redo the questions you missed', rewards:'XP, streaks, challenges and badges' };
    $$('#nav button[data-v]').forEach(b => { const ic = b.querySelector('i'); add({ g:'Pages', t:b.textContent.trim(), d:PAGE_DESC[b.dataset.v] || '', ic:ic ? ic.className : 'ph ph-arrow-right', fn:() => b.click(), k:b.dataset.v }); });
    add({ g:'Pages', t:'Scholar profile', d:'Name, coach and goals', ic:'ph ph-user-circle', fn:() => window.openProfile ? openProfile() : (window.go && go('profile')), k:'profile scholar avatar mascot coach name goal test date xp level' });
    add({ g:'Pages', t:'Settings', d:'Preferences, backup, version', ic:'ph ph-gear-six', fn:() => window.openSettings ? openSettings() : (window.go && go('settings')), k:'settings preferences export backup version about timer' });

    /* ---- topics (start a practice set) ---- */
    const TP = g('typeof TOPICS === "undefined" ? null : TOPICS'), ST = g('typeof state === "undefined" ? null : state');
    if(TP) Object.keys(TP).forEach(k => {
      const t = TP[k], d = ST && ST.byTopic && ST.byTopic[k], acc = d && d.attempts ? Math.round(d.correct / d.attempts * 100) + '% accuracy · ' + d.attempts + ' answered' : t.desc;
      add({ g:'Practice a topic', t:t.short, d:acc, ic:'ph ' + t.icon, tag:t.sec === 'm' ? 'Math' : 'Reading & Writing', fn:() => { if(window.go) go('practice'); setTimeout(() => { try{ startPractice(k); }catch(e){} }, 60); }, k:t.label + ' ' + t.desc + ' drill practice start' });
    });
    if(TP) add({ g:'Practice a topic', t:'Mixed set', d:'Ten adaptive questions from every topic', ic:'ph ph-shuffle', tag:'Quick', fn:() => { try{ startPractice('mixed'); }catch(e){} }, k:'mixed random quick adaptive all' });

    /* ---- lessons ---- */
    const LS = g('typeof LESSONS === "undefined" ? null : LESSONS');
    if(LS) LS.forEach(l => add({ g:'Lessons', t:l.t, d:l.s, ic:'ph ' + (l.ic || 'ph-book-open').replace(/^ph /, ''), tag:ST && ST.lessonDone && ST.lessonDone[l.id] ? 'Done' : '', fn:() => { if(window.go) go('lessons'); setTimeout(() => { try{ openLesson(l.id); }catch(e){} }, 80); }, k:l.s + ' lesson learn ' + (l.topic || '') }));

    /* ---- badges ---- */
    const BD = g('typeof BADGES === "undefined" ? null : BADGES'), EX = g('typeof E === "function" ? E() : null');
    if(BD) BD.forEach(b => { const on = !!(EX && EX.badges && EX.badges[b[0]]); add({ g:'Badges', t:b[1], d:b[2], ic:'ph-fill ' + (on ? b[3] : 'ph-lock-simple'), tag:on ? 'Unlocked' : 'Locked', on, fn:() => { if(window.go) go('rewards'); }, k:'badge medal reward achievement ' + b[2] }); });

    /* ---- actions ---- */

    const m = document.createElement('div'); m.className = 'nx-modal pal-w';
    m.innerHTML = '<div class="pal" role="dialog" aria-modal="true" aria-label="Search">'
      + '<div class="pal-in">' + IC.search + '<input type="text" placeholder="Search pages, topics, lessons, badges…" aria-label="Search" autocomplete="off" autocapitalize="off" spellcheck="false" role="combobox" aria-expanded="true" aria-controls="palList" aria-autocomplete="list">'
      + '<button type="button" class="pal-x" aria-label="Clear search" hidden>' + IC.x + '</button><kbd class="pal-esc">esc</kbd></div>'
      + '<div class="pal-l" id="palList" role="listbox"></div>'
      + '<div class="pal-f"><span><kbd>↑</kbd><kbd>↓</kbd>navigate</span><span><kbd>↵</kbd>open</span><span class="pal-ct"></span></div></div>';
    document.body.appendChild(m);
    const inp = $('input', m), list = $('.pal-l', m), xb = $('.pal-x', m), ct = $('.pal-ct', m); let act = 0, shown = [];

    /* ---- matching: every typed word must hit; title starts rank highest ---- */
    const norm = x => String(x || '').toLowerCase();
    function score(it, words){
      const t = norm(it.t), hay = norm(it.t + ' ' + (it.d || '') + ' ' + (it.k || '') + ' ' + (it.tag || '')); let s = 0;
      for(const w of words){
        if(!hay.includes(w)) return -1;
        if(t === w) s += 100; else if(t.startsWith(w)) s += 60; else if(t.split(/[\s·&/-]+/).some(x => x.startsWith(w))) s += 40; else if(t.includes(w)) s += 25; else s += 6;
      }
      return s;
    }
    function mark(text, words){
      text = String(text == null ? '' : text); if(!words.length) return esc(text);
      const lo = text.toLowerCase(), on = new Array(text.length).fill(false);
      words.forEach(w => { let i = lo.indexOf(w); while(i > -1){ for(let j = i; j < i + w.length; j++) on[j] = true; i = lo.indexOf(w, i + w.length); } });
      let out = '', open = false;
      for(let i = 0; i < text.length; i++){ if(on[i] && !open){ out += '<mark>'; open = true; } else if(!on[i] && open){ out += '</mark>'; open = false; } out += esc(text[i]); }
      return out + (open ? '</mark>' : '');
    }
    const ORDER = ['Pages','Practice a topic','Lessons','Badges','Actions'];
    const render = () => {
      const q = inp.value.trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean);
      xb.hidden = !q;
      if(!words.length){
        const cap = { 'Pages':99, 'Practice a topic':99, 'Lessons':0, 'Badges':0, 'Actions':99 };
        shown = ORDER.flatMap(gname => items.filter(i => i.g === gname).slice(0, cap[gname]));
      } else {
        shown = items.map(i => ({ i, s:score(i, words) })).filter(x => x.s >= 0).sort((a, b) => b.s - a.s || ORDER.indexOf(a.i.g) - ORDER.indexOf(b.i.g)).slice(0, 40).map(x => x.i);
        /* keep groups together, strongest group first */
        const first = {}; shown.forEach((i, n) => { if(first[i.g] == null) first[i.g] = n; });
        shown = shown.slice().sort((a, b) => first[a.g] - first[b.g]);
      }
      act = Math.min(act, Math.max(0, shown.length - 1));
      let gname = '', html = '';
      shown.forEach((i, n) => {
        if(i.g !== gname){ gname = i.g; html += '<div class="nx-grp">' + esc(gname) + '</div>'; }
        html += '<div class="pal-i' + (n === act ? ' act' : '') + (i.on === false ? ' off' : '') + '" role="option" id="pal' + n + '" aria-selected="' + (n === act) + '" data-n="' + n + '"><i class="' + esc(i.ic) + '"></i>'
          + '<span class="pal-tx"><b>' + mark(i.t, words) + '</b>' + (i.d ? '<small>' + mark(i.d, words) + '</small>' : '') + '</span>'
          + (i.tag ? '<em class="' + (i.tag === 'Unlocked' || i.tag === 'Done' ? 'ok' : '') + '">' + esc(i.tag) + '</em>' : '') + IC.ret + '</div>';
      });
      list.innerHTML = html || '<div class="pal-none"><div class="pal-none-i">' + IC.search + '</div><b>No results for “' + esc(inp.value.trim()) + '”</b><span>Try “algebra”, “streak”, “test” or “badge”.</span></div>';
      ct.textContent = shown.length ? shown.length + (words.length ? (shown.length === 1 ? ' result' : ' results') : ' shortcuts') : '';
      inp.setAttribute('aria-activedescendant', shown.length ? 'pal' + act : '');
    };
    const setAct = (n, scroll) => { if(!shown.length) return; act = (n + shown.length) % shown.length; $$('.pal-i', list).forEach((e, i) => { e.classList.toggle('act', i === act); e.setAttribute('aria-selected', i === act); }); inp.setAttribute('aria-activedescendant', 'pal' + act); if(scroll !== false){ const a = $('.pal-i.act', list); a && a.scrollIntoView({ block:'nearest' }); } };
    const close = () => { document.removeEventListener('keydown', key, true); m.classList.add('out'); setTimeout(() => m.remove(), 150); };
    const run = n => { const i = shown[n]; if(!i) return; close(); setTimeout(i.fn, 30); };
    const key = e => {
      if(e.key === 'Escape'){ e.preventDefault(); e.stopPropagation(); if(inp.value){ inp.value = ''; act = 0; render(); } else close(); }
      else if(e.key === 'ArrowDown'){ e.preventDefault(); setAct(act + 1); } else if(e.key === 'ArrowUp'){ e.preventDefault(); setAct(act - 1); }
      else if(e.key === 'Home' && e.target !== inp){ e.preventDefault(); setAct(0); } else if(e.key === 'End' && e.target !== inp){ e.preventDefault(); setAct(shown.length - 1); }
      else if(e.key === 'Enter'){ e.preventDefault(); run(act); }
      else if(e.key === 'Tab'){ e.preventDefault(); inp.focus(); }
    };
    document.addEventListener('keydown', key, true);
    inp.addEventListener('input', () => { act = 0; render(); list.scrollTop = 0; });
    xb.addEventListener('click', () => { inp.value = ''; act = 0; render(); inp.focus(); });
    list.addEventListener('click', e => { const i = e.target.closest('.pal-i'); if(i) run(+i.dataset.n); });
    list.addEventListener('pointermove', e => { const i = e.target.closest('.pal-i'); if(i && +i.dataset.n !== act) setAct(+i.dataset.n, false); });
    m.addEventListener('pointerdown', e => { if(e.target === m) close(); });
    render(); inp.focus();
  }
  document.addEventListener('keydown', e => {
    if((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k'){ e.preventDefault(); palette(); }
  });
  function addPaletteHint(){
    const nav = $('#nav'); if(!nav || $('.nx-sk')) return;
    const mac = /Mac|iPhone|iPad/.test(navigator.platform);
    const b = document.createElement('button'); b.type = 'button'; b.className = 'nx-sk';
    b.innerHTML = IC.search+'<span>Jump to…</span><kbd>'+(mac ? '⌘' : 'Ctrl')+'</kbd><kbd>K</kbd>';
    b.onclick = palette; nav.parentNode.insertBefore(b, nav);
  }

  /* ============================================================
     SCROLL PROGRESS
     ============================================================ */
  const bar = document.createElement('div'); bar.id = 'nxProg'; bar.setAttribute('aria-hidden','true'); document.body.appendChild(bar);
  let pT = 0;
  addEventListener('scroll', () => {
    if(pT) return; pT = requestAnimationFrame(() => { pT = 0; const h = document.documentElement.scrollHeight - innerHeight; const f = h > 40 ? clamp(scrollY / h, 0, 1) : 0; bar.style.setProperty('--sp', f); bar.classList.toggle('on', scrollY > 30 && h > 40); });
  }, { passive:true });

  /* ============================================================
     SWEEP + OBSERVE
     ============================================================ */
  function sweep(root){
    root = root || document;
    $$('select', root).forEach(enhanceSelect);
    $$('input[type=number]', root).forEach(enhanceNumber);
    $$('input[type=date]', root).forEach(enhanceDate);
    $$('input[type=range]', root).forEach(enhanceRange);
  }
  let sweepT = 0, scanT = 0;
  new MutationObserver(muts => {
    let added = false;
    for(const m of muts) if(m.addedNodes.length) { for(const n of m.addedNodes) if(n.nodeType === 1 && !n.classList.contains('nx-tip') && !n.classList.contains('nx-pop')){ added = true; break; } if(added) break; }
    if(!added) return;
    clearTimeout(sweepT); sweepT = setTimeout(() => sweep(), 16);
    if(!scanT) scanT = setTimeout(() => { scanT = 0; scanScrollers(document); }, 900);
  }).observe(document.documentElement, { childList:true, subtree:true });

  function init(){ sweep(); scanScrollers(document); addPaletteHint(); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  addEventListener('load', () => { sweep(); scanScrollers(document); addPaletteHint(); });

  window.UI = { confirm:confirmUI, closePop, palette, enhance:sweep, scroller:enhanceScroller };
})();
