/* ============================================================
   TAILORED PRACTICE: the test-taker. Same Bluebook-style shell (#exam, .xhead/.xbody/.xfoot) as the
   original exam; questions, scoring and routing come from the engine, telemetry from TestSession
   (/engine/recorder.mjs, the engine's own recorder: batching, crash buffer, idempotent flush).
   Answers are never in the browser: the engine scores on submit.
   ============================================================ */
(function(){
  'use strict';
  const A = window.SATAPI, SAT = window.SAT; if(!A || !SAT) return;
  let SX = null, RecMod = null;

  async function recorderClass(){
    if(RecMod) return RecMod;
    RecMod = (await import(A.url('assets/engine/src/session/recorder.mjs'))).TestSession;
    return RecMod;
  }
  const KIND = { 'mini-mock': 'Mini-mock', 'native-mock': 'Full mock', 'skill-drill': 'Skill drill', 'spaced-retest': 'Retest' };
  const secName = s => s === 'math' ? 'Math' : 'Reading and Writing';
  const fmtT = s => { s = Math.max(0, Math.round(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
  const cur = () => SX && SX.mod.questions[SX.qi];
  const isSpr = q => q && q.format === 'spr';

  /* ---------- entry points ---------- */
  async function begin(created){
    const TS = await recorderClass();
    SX = newState(created.session_id, created.kind, created.total_modules, created.adaptive, TS);
    open();
    setModule(created.module, { fresh: true });
    SX.phase = 'intro'; paint();
  }
  async function resume(sid){
    const TS = await recorderClass();
    let st;
    try{ st = await A.get('/api/sessions/' + sid); }catch(e){ if(e.status === 404 || e.status === 403) A.setActive(null); throw e; }
    if(st.status === 'finished'){ A.setActive(null); SAT.open('audit', sid); return; }
    SX = newState(sid, st.kind, st.modules_total, st.kind === 'native-mock', TS);
    SX.modNo = st.modules_submitted + 1;
    if(!st.module){
      /* every built module is submitted but the session was not finished */
      open(); SX.phase = 'finishing'; paint(); return finish();
    }
    open();
    setModule(st.module, { fresh: false, server: st });
    SX.phase = 'q'; startTimers(); paint();
  }
  function newState(sid, kind, total, adaptive, TS){
    return { sid, kind, total, adaptive, modNo: 1, phase: 'intro', qi: 0, elimOn: false, elim: {}, hl: {}, mapOpen: false, hideTimer: false, calcOpen: false, timer: null, busy: false, fiveWarned: false,
      rec: new TS({ sessionId: sid, storage: window.localStorage, sink: ev => A.post('/api/sessions/' + sid + '/events', { events: ev }) }), mod: null, routing: null, result: null };
  }

  /* ---------- module lifecycle ---------- */
  function setModule(mod, o){
    SX.mod = mod; SX.qi = 0; SX.elim = {}; SX.hl = {}; SX.fiveWarned = false; SX.sprVal = {};
    if(!SX.mod.limitMs) SX.mod.limitMs = (mod.time_limit_sec || 1800) * 1000;
    SX.pendingStart = { fresh: o.fresh, server: o.server || null };
    if(!o.fresh) startModuleRecorder();
  }
  function startModuleRecorder(){
    const rec = SX.rec, mod = SX.mod, ids = mod.questions.map(q => q.id), p = SX.pendingStart || {}, srv = p.server;
    const restored = rec.restore();
    if(restored && rec.module && rec.module.id === mod.module_id && !rec.module.submitted){
      SX.qi = Math.max(0, ids.indexOf(rec.current));
      rec.lastInputAt = rec.now();   // time while the tab was closed is not "idle thinking"
    } else {
      const last = srv ? srv.last_seq : 0;
      rec.seq = Math.max(rec.seq, last); rec.sentSeq = Math.max(rec.sentSeq, last); rec.buffer = [];
      rec.startModule({ moduleId: mod.module_id, questionIds: ids, limitMs: mod.limitMs });
      if(srv){
        rec.answers = Object.assign({}, srv.answers || {});
        if(srv.elapsed_ms != null) rec.module.startedAt = rec.now() - srv.elapsed_ms;
      }
    }
    SX.pendingStart = null;
  }
  function startTimers(){
    clearInterval(SX.timer);
    SX.timer = setInterval(tick, 1000);
    document.addEventListener('keydown', onKey);
    document.addEventListener('visibilitychange', onVis);
    document.addEventListener('pointerup', onHlPointer);
    window.addEventListener('beforeunload', onUnload);
  }
  function stopTimers(){
    if(!SX) return;
    clearInterval(SX.timer); clearInterval(SX.brkT);
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('visibilitychange', onVis);
    document.removeEventListener('pointerup', onHlPointer);
    window.removeEventListener('beforeunload', onUnload);
  }
  const onUnload = () => { if(SX && SX.rec) SX.rec._save(); };
  const onVis = () => { if(!SX || !SX.rec.module) return; if(document.hidden) SX.rec.blur(); else SX.rec.focus(); };

  function tick(){
    if(!SX || SX.phase !== 'q' && SX.phase !== 'check') return;
    SX.rec.tick();
    const rem = SX.rec.timeRemainingMs();
    if(rem != null && rem <= 300000 && !SX.fiveWarned){ SX.fiveWarned = true; SX.hideTimer = false; toast('5 minutes left in this module', 'ph-clock'); }
    paintTimer();
    if(rem != null && rem <= 0 && !SX.busy){ toast('Time is up for this module', 'ph-clock'); submit(true); }
  }

  /* ---------- shell ---------- */
  function open(){
    document.body.classList.add('lock');
    const ex = $('#exam'); ex.classList.remove('hidden'); ex.dataset.sat = '1';
    ex.innerHTML = '<div class="xhead"><div class="xtitle"><b id="sxTitle"></b></div><div class="xtimer"><div class="tm mono" id="sxTm">00:00</div><button id="sxTmBtn" type="button"><i class="ph ph-eye-slash"></i><span>Hide</span></button></div><div class="xtools" id="sxTools"></div></div>' +
      '<div class="xbody" id="sxBody"></div><div class="xfoot" id="sxFoot"><div class="xname" id="sxName"></div><button class="qpill" id="sxPill" type="button"></button><div class="xnav" id="sxNav"></div></div>';
    $('#sxTmBtn').onclick = () => { SX.hideTimer = !SX.hideTimer; paintTimer(); };
    $('#sxPill').onclick = () => { SX.mapOpen = !SX.mapOpen; paintMap(); };
  }
  function close(){
    if(!SX) return;
    stopTimers(); hidePop();
    const w = $('#dwin'); if(w) w.classList.add('hidden');
    const ex = $('#exam'); ex.classList.add('hidden'); ex.innerHTML = ''; delete ex.dataset.sat;
    document.body.classList.remove('lock');
    SX = null;
  }
  function title(){
    const m = SX.mod; if(!m) return '';
    return SX.kind === 'skill-drill' || SX.kind === 'spaced-retest' ? KIND[SX.kind] : KIND[SX.kind] + ' · ' + secName(m.section) + ' · Module ' + m.module_index;
  }
  function paint(){
    if(!SX) return;
    hidePop(); SX.mapOpen = false; paintMap();
    $('#sxTitle').textContent = title();
    $('#sxFoot').style.display = SX.phase === 'q' ? '' : 'none';
    $('#sxBody').className = 'xbody';
    const f = { intro: paintIntro, q: paintQuestion, check: paintCheck, brk: paintBreak, finishing: paintFinishing, done: paintDone }[SX.phase];
    f(); paintTimer();
  }
  function paintTimer(){
    const t = $('#sxTm'), b = $('#sxTmBtn'); if(!t || !SX) return;
    const live = SX.phase === 'q' || SX.phase === 'check', rem = live ? SX.rec.timeRemainingMs() : null;
    t.classList.toggle('low', rem != null && rem <= 60000);
    if(!live) t.textContent = '--:--';
    else if(SX.hideTimer) t.innerHTML = '<i class="ph ph-clock" style="font-size:20px;color:var(--mut)"></i>';
    else t.textContent = fmtT(rem / 1000);
    b.innerHTML = SX.hideTimer ? '<i class="ph ph-eye"></i><span>Show</span>' : '<i class="ph ph-eye-slash"></i><span>Hide</span>';
    b.style.visibility = live ? 'visible' : 'hidden';
  }
  function tools(q){
    const t = $('#sxTools'), math = q ? q.section === 'math' : SX.mod.section === 'math';
    let h = '';
    if(math) h += '<button class="tool' + (SX.calcOpen ? ' on' : '') + '" id="sxCalc" type="button"><i class="ph ph-calculator"></i><span>Calculator</span></button><button class="tool" id="sxRef" type="button"><i class="ph ph-ruler"></i><span>Reference</span></button>';
    else h += '<button class="tool" id="sxHl" type="button"><i class="ph ph-highlighter-circle"></i><span>Highlights</span></button>';
    h += '<button class="tool" id="sxExit" type="button"><i class="ph ph-sign-out"></i><span>Exit</span></button>';
    t.innerHTML = h;
    if(math){
      $('#sxCalc').onclick = () => { SX.calcOpen = !SX.calcOpen; if(typeof toggleCalc === 'function') toggleCalc(SX.calcOpen); SX.rec.calculator(SX.calcOpen); $('#sxCalc').classList.toggle('on', SX.calcOpen); };
      $('#sxRef').onclick = () => { if(typeof openReference === 'function') openReference(); };
    } else {
      $('#sxHl').onclick = () => toast('Select text in the passage to highlight it', 'ph-highlighter-circle');
      if(SX.calcOpen){ SX.calcOpen = false; const w = $('#dwin'); if(w) w.classList.add('hidden'); }
    }
    $('#sxExit').onclick = exit;
  }
  async function exit(){
    const ok = await SAT.confirm('Leave this test?', 'Your answers are saved. You can pick up where you stopped from the Practice page (the timer keeps running while you are away).', 'Leave', false);
    if(!ok || !SX) return;
    try{ await SX.rec.flush(); }catch(e){}
    close(); go('sat'); SAT.render();
  }

  /* ---------- screens ---------- */
  function paintIntro(){
    const m = SX.mod, n = m.questions.length, mins = Math.round(m.limitMs / 60000);
    $('#sxTools').innerHTML = '<button class="tool" id="sxExit" type="button"><i class="ph ph-sign-out"></i><span>Exit</span></button>'; $('#sxExit').onclick = exit;
    const second = SX.modNo > 1;
    $('#sxBody').innerHTML = '<div class="interstitial"><div class="box"><img class="mas" data-mood="listen" src="' + IMG.m_listen + '" alt=""><span class="tag">' + esc(KIND[SX.kind]) + ' · module ' + SX.modNo + ' of ' + SX.total + '</span><h2>' + esc(title()) + '</h2>' +
      '<p>' + n + ' questions, ' + mins + ' minutes. ' + (SX.adaptive && second ? 'This module was picked from how you did in the last one. ' : '') + 'You can move back and forth inside a module and mark questions to come back to. The timer starts when you press the button.</p>' +
      (m.section === 'math' ? '<p class="muted">Math: the Desmos calculator and the reference sheet are in the top bar. Some questions ask you to type your own answer.</p>' : '') +
      '<button class="btn acc lg" id="sxGo" type="button">Start module<i class="ph ph-arrow-right"></i></button></div></div>';
    $('#sxGo').onclick = () => { if(SX.pendingStart) startModuleRecorder(); SX.phase = 'q'; SX.qi = 0; startTimers(); paint(); };
  }
  function paintBreak(){
    $('#sxTools').innerHTML = '';
    $('#sxBody').innerHTML = '<div class="interstitial"><div class="box"><img class="mas" data-mood="wink" src="' + IMG.m_wink + '" alt=""><h2>Take a break</h2><div class="brk" id="sxBrk" role="timer">10:00</div><p>Reading and Writing is done. Stretch, drink water, rest your eyes. Math is next. You can skip the break whenever you are ready.</p><button class="btn acc lg" id="sxBrkGo" type="button">Continue to Math<i class="ph ph-arrow-right"></i></button></div></div>';
    let left = 600; clearInterval(SX.brkT);
    SX.brkT = setInterval(() => { const el = $('#sxBrk'); if(!el){ clearInterval(SX.brkT); return; } left--; el.textContent = fmtT(left); if(left <= 0) $('#sxBrkGo').click(); }, 1000);
    $('#sxBrkGo').onclick = () => { clearInterval(SX.brkT); SX.phase = 'intro'; paint(); };
  }
  function paintFinishing(){
    $('#sxTools').innerHTML = '';
    $('#sxBody').innerHTML = '<div class="interstitial"><div class="box"><i class="ph ph-circle-notch spin" style="font-size:40px;color:var(--acc)"></i><h2>Building your audit</h2><p>Scoring your answers and working out where the points went. This takes a few seconds.</p></div></div>';
  }

  function paintQuestion(){
    const m = SX.mod, q = cur(), i = SX.qi, rec = SX.rec, math = q.section === 'math';
    tools(q);
    const split = !!q.passage || math || !!q.visual;
    const body = $('#sxBody'); body.className = 'xbody' + (split ? ' split' : ''); body.classList.remove('elimon');
    const flagged = !!rec.flags[q.id];
    const qbar = '<div class="qbar"><span class="qnumbox">' + (i + 1) + '</span><button class="flagbtn' + (flagged ? ' on' : '') + '" id="sxFlag" type="button"></button>' + (isSpr(q) ? '' : '<button class="elimtoggle" id="sxElim" type="button" title="Cross out answer choices"><s>ABC</s></button>') + '</div>';
    let opts;
    if(isSpr(q)){
      opts = '<div class="spr"><input id="sxSpr" inputmode="decimal" autocomplete="off" maxlength="10" placeholder="Your answer" aria-label="Your answer"><div class="prev" id="sxPrev"></div><div class="hint">Type a number, a decimal or a fraction like 3/4. Use - for negatives.</div></div>';
    } else {
      opts = '<div class="xopts" id="sxOpts" role="radiogroup" aria-label="Answer choices">' + q.choices.map((c, k) => '<div class="xopt" data-k="' + c.key + '"><button class="o" type="button" role="radio"><span class="k">' + c.key + '</span><span class="t">' + SAT.fmt(c.text) + '</span></button><button class="x" type="button" aria-label="Cross out choice ' + c.key + '"></button></div>').join('') + '</div>';
    }
    const stem = '<div class="stem' + (!math ? ' serif' : '') + '">' + SAT.fmt(q.stem) + '</div>';
    const vis = q.visual ? SAT.visual(q.visual) : '';
    if(q.passage){
      body.innerHTML = '<div class="pane left"><div class="passage" id="sxPassage">' + SAT.passage(q.passage) + '</div>' + vis + '</div><div class="pane"><div class="wrap">' + qbar + stem + opts + '</div></div>';
      if(SX.hl[q.id]) $('#sxPassage').innerHTML = SX.hl[q.id];
    } else if(math || q.visual){
      body.innerHTML = '<div class="pane left">' + stem + vis + '</div><div class="pane"><div class="wrap">' + qbar + opts + '</div></div>';
    } else {
      body.innerHTML = '<div class="pane"><div class="wrap" style="max-width:780px;margin:0 auto">' + qbar + stem + opts + '</div></div>';
    }
    $('#sxFlag').onclick = () => { rec.toggleFlag(); paintFlag(); paintMap(); };
    if($('#sxElim')) $('#sxElim').onclick = () => { SX.elimOn = !SX.elimOn; paintOptions(); };
    if(isSpr(q)){
      const inp = $('#sxSpr'); if(rec.answers[q.id] !== undefined) inp.value = rec.answers[q.id];
      let t = null;
      inp.oninput = () => { inp.value = inp.value.replace(/[^0-9./-]/g, ''); $('#sxPrev').textContent = inp.value ? 'Answer preview: ' + inp.value : ''; clearTimeout(t); t = setTimeout(sprCommit, 700); };
      inp.onblur = sprCommit;
      inp.onkeydown = e => { if(e.key === 'Enter'){ sprCommit(); next(); } };
      $('#sxPrev').textContent = inp.value ? 'Answer preview: ' + inp.value : '';
      setTimeout(() => inp.focus({ preventScroll: true }), 50);
    } else {
      $$('#sxOpts .xopt').forEach(row => { const k = row.dataset.k; row.querySelector('.o').onclick = () => pick(k); row.querySelector('.x').onclick = () => strike(k); });
    }
    paintFlag(); paintOptions(); paintFoot(); paintMap();
    $$('#sxBody .pane').forEach(p => p.scrollTop = 0);
  }
  function sprCommit(){
    const q = cur(), inp = $('#sxSpr'); if(!q || !inp || !isSpr(q) || SX.phase !== 'q') return;
    const v = inp.value.trim(), have = SX.rec.answers[q.id];
    if(v && v !== have) SX.rec.select(v); else if(!v && have !== undefined) SX.rec.clear();
    paintFoot(); paintMap();
  }
  function paintFlag(){
    const q = cur(), f = !!SX.rec.flags[q.id], b = $('#sxFlag'); if(!b) return;
    b.classList.toggle('on', f);
    b.innerHTML = '<i class="ph' + (f ? '-fill' : '') + ' ph-flag"></i><span>' + (f ? 'Marked for review' : 'Mark for review') + '</span>';
  }
  function paintOptions(){
    const q = cur(); if(isSpr(q)) return;
    $('#sxBody').classList.toggle('elimon', SX.elimOn);
    const el = $('#sxElim'); if(el) el.classList.toggle('on', SX.elimOn);
    const str = SX.elim[q.id] || [], ans = SX.rec.answers[q.id];
    $$('#sxOpts .xopt').forEach(row => {
      const k = row.dataset.k, o = row.querySelector('.o'), x = row.querySelector('.x'), struck = str.indexOf(k) > -1;
      o.classList.toggle('sel', ans === k); o.classList.toggle('elim', struck); o.setAttribute('aria-checked', ans === k ? 'true' : 'false');
      x.innerHTML = struck ? '<i class="ph ph-arrow-counter-clockwise"></i>' : '<i class="ph ph-x"></i>';
    });
  }
  function pick(k){
    const q = cur(); if(SX.busy) return;
    if((SX.elim[q.id] || []).indexOf(k) > -1) return;
    if(SX.rec.answers[q.id] === k) SX.rec.clear(); else SX.rec.select(k);
    paintOptions(); paintFoot(); paintMap();
  }
  function strike(k){
    const q = cur(), s = SX.elim[q.id] = SX.elim[q.id] || [], at = s.indexOf(k);
    if(at > -1) s.splice(at, 1); else { s.push(k); SX.rec.eliminate(k); if(SX.rec.answers[q.id] === k) SX.rec.clear(); }
    paintOptions(); paintFoot(); paintMap();
  }
  function paintFoot(){
    if(SX.phase !== 'q') return;
    const n = SX.mod.questions.length, i = SX.qi;
    $('#sxName').textContent = ((A.session() && A.session().profile && A.session().profile.display_name) || '').toUpperCase();
    $('#sxPill').innerHTML = 'Question ' + (i + 1) + ' of ' + n + '<i class="ph ph-caret-up"></i>';
    const nav = $('#sxNav'); nav.innerHTML = '';
    const back = document.createElement('button'); back.className = 'btn'; back.type = 'button'; back.innerHTML = '<i class="ph ph-arrow-left"></i>Back'; back.disabled = i === 0; back.onclick = () => goQ(i - 1); nav.appendChild(back);
    const nx = document.createElement('button'); nx.className = 'btn acc'; nx.type = 'button'; nx.innerHTML = (i === n - 1 ? 'Review' : 'Next') + '<i class="ph ph-arrow-right"></i>'; nx.onclick = next; nav.appendChild(nx);
  }
  function next(){ sprCommit(); const n = SX.mod.questions.length; if(SX.qi === n - 1){ SX.phase = 'check'; paint(); } else goQ(SX.qi + 1); }
  function goQ(i){
    if(i < 0 || i >= SX.mod.questions.length) return;
    sprCommit(); SX.qi = i; SX.phase = 'q'; SX.rec.goTo(SX.mod.questions[i].id); paint();
  }

  /* ---------- question map + check screen ---------- */
  function mapHtml(filter){
    const rec = SX.rec; let h = '<div class="qgrid">';
    SX.mod.questions.forEach((q, i) => {
      const ans = rec.answers[q.id] !== undefined, flg = !!rec.flags[q.id];
      if(filter === 'un' && ans) return; if(filter === 'fl' && !flg) return;
      const c = []; if(i === SX.qi && SX.phase === 'q') c.push('cur'); if(ans) c.push('ans');
      h += '<button type="button" class="' + c.join(' ') + '" data-q="' + i + '" aria-label="Question ' + (i + 1) + (ans ? ', answered' : ', not answered') + (flg ? ', marked' : '') + '">' + (i + 1) + (flg ? '<i class="ph-fill ph-flag fl"></i>' : '') + '</button>';
    });
    return h + '</div>';
  }
  function paintMap(){
    let el = $('#sxMap'); if(el) el.remove();
    const pill = $('#sxPill'); if(pill) pill.classList.toggle('open', !!(SX && SX.mapOpen));
    if(!SX || !SX.mapOpen || SX.phase !== 'q') return;
    const f = SX.mapFilter || 'all';
    el = document.createElement('div'); el.className = 'qmap'; el.id = 'sxMap';
    el.innerHTML = '<div class="row" style="justify-content:space-between;margin-bottom:10px"><h4>' + esc(title()) + '</h4><div class="pr-pills"><button type="button" class="pr-pill' + (f === 'all' ? ' on' : '') + '" data-mf="all">All</button><button type="button" class="pr-pill' + (f === 'un' ? ' on' : '') + '" data-mf="un">Unanswered</button><button type="button" class="pr-pill' + (f === 'fl' ? ' on' : '') + '" data-mf="fl">Marked</button></div></div>' + mapHtml(f) + '<div class="row" style="justify-content:center;margin-top:16px"><button class="btn sm" id="sxToReview" type="button">Go to review page</button></div>';
    $('#exam').appendChild(el);
    el.querySelectorAll('[data-mf]').forEach(b => b.onclick = () => { SX.mapFilter = b.dataset.mf; paintMap(); });
    el.querySelectorAll('[data-q]').forEach(b => b.onclick = () => { SX.mapOpen = false; goQ(+b.dataset.q); });
    $('#sxToReview').onclick = () => { sprCommit(); SX.phase = 'check'; paint(); };
  }
  function paintCheck(){
    const rec = SX.rec, qs = SX.mod.questions, n = qs.length;
    $('#sxTools').innerHTML = '<button class="tool" id="sxExit" type="button"><i class="ph ph-sign-out"></i><span>Exit</span></button>'; $('#sxExit').onclick = exit;
    const un = qs.filter(q => rec.answers[q.id] === undefined).length, fl = Object.keys(rec.flags).filter(k => rec.flags[k]).length;
    const last = SX.modNo >= SX.total;
    $('#sxBody').innerHTML = '<div class="pane"><div class="checkscreen"><h2>Check your work</h2><p>' + (un ? 'You have ' + un + ' unanswered question' + (un > 1 ? 's' : '') + '. ' : 'You answered every question. ') + (fl ? fl + ' marked for review. ' : '') + 'Tap a number to go back to it. Once you submit, you cannot return to this module.</p>' + mapHtml() +
      '<div class="row" style="justify-content:center;gap:12px"><button class="btn lg" id="sxBackQ" type="button"><i class="ph ph-arrow-left"></i>Back to questions</button><button class="btn acc lg" id="sxSubmit" type="button">' + (last ? 'Submit and see results' : 'Submit module') + '<i class="ph ph-arrow-right"></i></button></div></div></div>';
    $$('#sxBody [data-q]').forEach(b => b.onclick = () => goQ(+b.dataset.q));
    $('#sxBackQ').onclick = () => goQ(n - 1);
    $('#sxSubmit').onclick = () => submit(false);
  }

  /* ---------- submit, routing, finish ---------- */
  async function submit(expired){
    if(!SX || SX.busy) return; SX.busy = true; sprCommit();
    const btn = $('#sxSubmit'); if(btn) SAT.busy(btn, true, 'Submitting');
    const rec = SX.rec, mod = SX.mod, sid = SX.sid;
    let answers = {};
    try{ ({ answers } = await rec.submitModule()); }
    catch(e){ try{ await rec.flush(); }catch(e2){} answers = Object.assign({}, rec.answers); }
    const body = { answers: {}, expired: !!(expired || rec.module.expired) };
    mod.questions.forEach(q => { body.answers[q.id] = answers[q.id] === undefined ? '' : String(answers[q.id]); });
    try{
      const r = await A.post('/api/sessions/' + sid + '/modules/' + encodeURIComponent(mod.module_id) + '/submit', body);
      SX.busy = false; SX.routing = r.routing;
      SX.calcOpen = false; { const w = $('#dwin'); if(w) w.classList.add('hidden'); }
      if(r.next_module){
        SX.modNo++; setModule(r.next_module, { fresh: true });
        SX.phase = SX.kind === 'native-mock' && mod.section === 'rw' && r.next_module.section === 'math' ? 'brk' : 'intro'; paint();
      } else { SX.phase = 'finishing'; paint(); await finish(); }
    }catch(e){
      SX.busy = false; if(btn) SAT.busy(btn, false);
      if(SX.phase === 'q' || SX.phase === 'check'){ SX.phase = 'check'; paint(); }
      toast(e.code === 'network' || e.code === 'timeout' ? 'No connection. Your answers are safe on this device. Press Submit again when you are back online.' : SAT.errText(e), 'ph-warning-circle');
    }
  }
  async function finish(){
    const sid = SX.sid;
    try{
      const r = await A.post('/api/sessions/' + sid + '/finish', {});
      SX.result = r; SX.rec.clearCrashBuffer(); A.setActive(null);
      SX.phase = 'done'; stopTimers(); paint();
    }catch(e){
      toast(SAT.errText(e), 'ph-warning-circle');
      $('#sxBody').innerHTML = '<div class="interstitial"><div class="box"><i class="ph ph-warning-circle" style="font-size:40px;color:var(--bad)"></i><h2>Could not finish yet</h2><p>' + esc(SAT.errText(e)) + ' Your answers are saved.</p><div class="row" style="justify-content:center"><button class="btn acc" id="sxRetry" type="button">Try again</button><button class="btn ghost" id="sxLeave" type="button">Leave</button></div></div></div>';
      $('#sxRetry').onclick = () => { SX.phase = 'finishing'; paint(); finish(); };
      $('#sxLeave').onclick = () => { close(); go('sat'); };
    }
  }
  function paintDone(){
    const r = SX.result, sc = r.scores || {}, sid = SX.sid, kind = SX.kind;
    const c = (sc.rw ? sc.rw.correct : 0) + (sc.math ? sc.math.correct : 0), t = (sc.rw ? sc.rw.total : 0) + (sc.math ? sc.math.total : 0), pct = t ? Math.round(c / t * 100) : 0;
    const part = (nm, s) => s ? '<div><span>' + nm + '</span><b>' + s.correct + '/' + s.total + '</b></div>' : '';
    const isMock = /mock/.test(kind);
    const btns = [];
    if(isMock) btns.push(['See my audit<i class="ph ph-arrow-right"></i>', 'acc', () => { close(); SAT.open('audit', sid); }]);
    if(r.review_available) btns.push([isMock ? 'Review mistakes' : 'Review mistakes<i class="ph ph-arrow-right"></i>', isMock ? 'line' : 'acc', () => { close(); SAT.open('review', sid); }]);
    btns.push(['Back to practice', 'ghost', () => { close(); SAT.open('start'); }]);
    const mood = moodForScore(pct);
    $('#sxTools').innerHTML = ''; $('#sxFoot').style.display = 'none';
    const b = $('#sxBody'); b.className = 'xbody'; b.style.background = 'var(--side)';
    b.innerHTML = '<div class="xdone"><div class="donebox"><div><img class="lm" src="' + IMG.logo + '" alt="Jamal\'s International Academy"><h1>' + (isMock ? 'Test complete' : 'Set complete') + '</h1><p>' + esc(c + ' of ' + t + ' correct. ' + (r.n_wrong ? 'Next: tell us why you missed the ' + r.n_wrong + ' you got wrong. It takes about 10 seconds each.' : 'No mistakes to review.')) + '</p>' +
      '<div class="dring" id="sxRing"><div><b id="sxRingN">0%</b><span>Correct</span></div></div><div class="dstats">' + part('Reading and Writing', sc.rw) + part('Math', sc.math) + '<div><span>Questions</span><b>' + t + '</b></div></div>' +
      '<p class="sat-done-note">Raw counts on practice questions. This is not a predicted SAT score.</p><div class="donebtns" id="sxBtns"></div></div><div class="art"><div class="script">' + mood.script + '</div><img data-mood="' + moodOf(mood.art) + '" src="' + IMG[mood.art] + '" alt=""></div></div></div>';
    const t0 = performance.now();
    (function tk(now){ const p = REDUCED ? 1 : Math.min((now - t0) / 1500, 1), e = 1 - Math.pow(1 - p, 3), v = Math.round(e * pct), rg = $('#sxRing'); if(!rg) return; rg.style.setProperty('--v', v); $('#sxRingN').textContent = v + '%'; if(p < 1) requestAnimationFrame(tk); })(t0);
    const box = $('#sxBtns');
    btns.forEach(([label, cls, fn]) => { const x = document.createElement('button'); x.type = 'button'; x.className = 'btn lg ' + cls; x.innerHTML = label; x.onclick = fn; box.appendChild(x); });
    const bar = $('.xhead'); if(bar) bar.style.display = 'none';
  }

  /* ---------- keyboard + highlights ---------- */
  function onKey(e){
    if(!SX || SX.phase !== 'q') return;
    if(e.key === 'Escape'){ SX.mapOpen = false; paintMap(); hidePop(); return; }
    const tag = (e.target.tagName || '').toLowerCase(); if(tag === 'input' || tag === 'textarea') return;
    if(e.metaKey || e.ctrlKey || e.altKey) return;
    if(e.key === 'ArrowRight') next(); else if(e.key === 'ArrowLeft') goQ(SX.qi - 1);
    else { const q = cur(), k = 'abcd'.indexOf(e.key.toLowerCase()), k2 = '1234'.indexOf(e.key), kk = k > -1 ? k : k2; if(kk > -1 && !isSpr(q) && q.choices[kk]) pick(q.choices[kk].key); }
  }
  function hidePop(){ const p = $('#hlpop'); if(p) p.remove(); }
  function onHlPointer(e){
    if(!SX || SX.phase !== 'q') return;
    if(e.target.closest && e.target.closest('#hlpop')) return;
    const p = $('#sxPassage'); if(!p){ hidePop(); return; }
    setTimeout(() => {
      const sel = getSelection();
      if(!sel || sel.isCollapsed || !p.contains(sel.anchorNode) || !p.contains(sel.focusNode)){ hidePop(); return; }
      const r = sel.getRangeAt(0), rect = r.getBoundingClientRect(); hidePop();
      const pop = document.createElement('div'); pop.id = 'hlpop';
      pop.innerHTML = '<button data-c="y" title="Yellow"><span class="dotc" style="background:#f0c04a"></span></button><button data-c="b" title="Blue"><span class="dotc" style="background:#35c7e6"></span></button><button data-c="p" title="Green"><span class="dotc" style="background:#86efac"></span></button><button data-c="x" title="Remove highlight"><i class="ph ph-eraser"></i></button>';
      document.body.appendChild(pop);
      pop.style.left = Math.max(8, Math.min(innerWidth - pop.offsetWidth - 8, rect.left + rect.width / 2 - pop.offsetWidth / 2)) + 'px';
      pop.style.top = Math.max(8, rect.top - pop.offsetHeight - 10) + 'px';
      pop.onpointerdown = ev => ev.preventDefault();
      pop.querySelectorAll('button').forEach(b => b.onclick = () => applyHl(b.dataset.c, r));
    }, 0);
  }
  function applyHl(c, range){
    const p = $('#sxPassage'), q = cur();
    if(c === 'x') p.querySelectorAll('mark').forEach(mk => { if(range.intersectsNode(mk)){ while(mk.firstChild) mk.parentNode.insertBefore(mk.firstChild, mk); mk.remove(); } });
    else { const mk = document.createElement('mark'); mk.className = c; try{ mk.appendChild(range.extractContents()); range.insertNode(mk); }catch(err){ return; } SX.rec.highlight(); }
    p.normalize(); SX.hl[q.id] = p.innerHTML; getSelection().removeAllRanges(); hidePop();
  }

  /* ---------- public ---------- */
  SAT.exam = {
    begin, resume, close,
    active: () => !!SX,
    /* after a reload: if a session is still open on the server, say so (the Practice page also shows a resume card) */
    offerResume(){
      const a = A.active(); if(!a || SX) return;
      if(Date.now() - a.at > 1000 * 60 * 60 * 24 * 3){ A.setActive(null); return; }
      toast('You have an unfinished test. Open Tailored practice to resume it.', 'ph-clock');
    }
  };
})();
