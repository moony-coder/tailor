// Audit narrative orchestration: cache -> model chain (rate-limited, 429 backoff + jitter) -> one repair retry -> template.
import { buildMessages, parseNarrative } from './prompts.mjs';
import { templateNarrative } from './template.mjs';
import { cacheKey, AiCache } from './cache.mjs';
import { LlmError } from './provider.mjs';
import { makeId, estimateTokens } from '../util/misc.mjs';

/**
 * deps = { db, provider|null, limiter, routing (config/model-routing.json), now, sleep, rand }
 * returns { narrative, source: 'cache'|'llm'|'template', model, reason?, attempts:[{model,status}] }
 */
export async function generateNarrative(digest, deps, { force = false } = {}) {
  const { db, provider, limiter, routing } = deps, now = deps.now ?? (() => Date.now()), sleep = deps.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms))), rand = deps.rand ?? Math.random;
  const task = routing.tasks.audit_narrative, version = routing.prompt_versions.audit_narrative, retry = routing.retry;
  const cache = new AiCache(db, now), log = [];
  const fallback = (reason) => ({ narrative: templateNarrative(digest), source: 'template', model: null, reason, attempts: log });
  if (!provider) return fallback('llm_disabled');

  const messages = buildMessages(digest);
  const promptTokens = estimateTokens(messages[0].content) + estimateTokens(messages[1].content);

  for (const model of task.models) {
    const key = cacheKey('audit_narrative', version, model, digest);
    if (!force) {
      const hit = await cache.get(key);
      if (hit) { const p = parseNarrative(hit.text, digest); if (p.ok) return { narrative: { ...p.value, source: 'llm' }, source: 'cache', model, attempts: log }; }
    }
  }
  for (const model of task.models) {
    const key = cacheKey('audit_narrative', version, model, digest);
    const need = promptTokens + task.max_completion_tokens;
    if (limiter.dailyExhausted(model, need)) { log.push({ model, status: 'daily_cap' }); continue; }
    let repairNote = null;
    for (let attempt = 1; attempt <= retry.max_tries; attempt++) {
      await limiter.acquire(model, need);
      const t0 = now();
      let res;
      try {
        res = await provider.chat({ model, messages: repairNote ? [...messages, { role: 'user', content: repairNote }] : messages, response_format: { type: 'json_object' }, max_completion_tokens: task.max_completion_tokens, temperature: task.temperature, reasoning_effort: task.reasoning_effort });
      } catch (e) {
        const status = e instanceof LlmError ? e.status : 0;
        await cache.logUsage({ id: makeId('u_', now()), kind: 'audit_narrative', model, latency_ms: now() - t0, status: status === 429 ? 'rate_limited' : `error_${status || 'net'}` });
        log.push({ model, status: status === 429 ? '429' : `error_${status || 'net'}`, try: attempt });
        if (e instanceof LlmError && (e.status === 401 || e.status === 403 || e.status === 400 || e.status === 404)) break;      // not retryable: next model
        if (attempt >= retry.max_tries) break;
        const backoff = Math.min(retry.max_delay_ms, retry.base_delay_ms * 2 ** (attempt - 1));
        const wait = e.retryAfterMs != null ? Math.min(e.retryAfterMs, retry.max_delay_ms * 3) : Math.round(backoff * (0.5 + rand() * 0.5));
        if (status === 429) limiter.block(model, wait); else await sleep(wait);
        continue;
      }
      limiter.usedActual(model, (res.tokens_in ?? 0) + (res.tokens_out ?? 0));
      const parsed = parseNarrative(res.text, digest);
      await cache.logUsage({ id: makeId('u_', now()), kind: 'audit_narrative', model, tokens_in: res.tokens_in, tokens_out: res.tokens_out, latency_ms: now() - t0, status: parsed.ok ? 'ok' : 'invalid_output' });
      if (parsed.ok) {
        await cache.put({ key, kind: 'audit_narrative', model, prompt_version: version, digest, text: JSON.stringify(parsed.value), tokens_in: res.tokens_in, tokens_out: res.tokens_out });
        log.push({ model, status: 'ok', try: attempt });
        return { narrative: { ...parsed.value, source: 'llm' }, source: 'llm', model, attempts: log };
      }
      log.push({ model, status: 'invalid_output', try: attempt, errors: parsed.errors.slice(0, 3) });
      if (repairNote) break;                                  // one repair retry only, then next model
      repairNote = `Your reply was rejected: ${parsed.errors.slice(0, 3).join('; ')}. Reply again with ONE valid JSON object in the exact schema, using only numbers from the data.`;
      attempt--; // the repair does not consume a network-retry slot
    }
  }
  return fallback('all_models_failed');
}
