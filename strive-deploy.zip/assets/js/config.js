/* Site settings. Edit this file, nothing else needs to change. */
window.STRIVE_CONFIG = {
  /* Leave checkoutUrl empty and EVERYTHING is free (no paywall shown).
     Set it to a real payment link (Stripe Payment Link etc.) to switch the Plus paywall on.
     Note: unlocking Plus after payment must be verified on a server. See README. */
  checkoutUrl: '',
  currency: '$', priceMonth: 12, priceYear: 79, freeBankPerDay: 20,
  /* Tailored practice (SAT audit). false hides every entry point; the dashboard works exactly as before. */
  SAT_AUDIT_ENABLED: true,
  /* Groq API key. It words the AI part of the audit; if it is empty or wrong, the audit still works with built-in wording.
     Replace it any time: edit the line below and redeploy. Note: anything in this file is visible to anyone who opens the site,
     so use a key you can rotate and set a spend/usage limit on it in the Groq console. */
  groqApiKey: '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'
};
