/* Runs before the app paints: students who have not finished /onboarding are sent there. */
document.documentElement.classList.add('js');
try{ sessionStorage.removeItem('strive_stay_home'); }catch(e){}   /* opening the app ends a 'stay on landing' visit */
/* DEMO: anyone without a finished profile gets the demo student (22-demo.js fills in the results). */
(function(){
  try{
    var raw = localStorage.getItem('strive_sat_v3'), s = null;
    try{ s = JSON.parse(raw || 'null'); }catch(e){}
    if(!s || !s.profile || !s.profile.onboarded){
      localStorage.setItem('strive_sat_v3', JSON.stringify({ v:3, createdAt:Date.now(), profile:{ name:'Aisha', onboarded:true, demo:true } }));
    }
  }catch(e){}
})();
(function(){
  try{
    var s = JSON.parse(localStorage.getItem('strive_sat_v3') || 'null');
    if(!s || !s.profile || !s.profile.onboarded) location.replace('onboarding.html');
  }catch(e){ location.replace('onboarding.html'); }
})();
