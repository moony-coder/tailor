// In-memory Db adapter: tests, the simulator, and (optionally persisted) the browser.
import { PRIMARY_KEYS, UNIQUE_KEYS, pkOf, matches, sortRows } from './interface.mjs';
import { deepClone } from '../util/misc.mjs';

export class MemoryDb {
  constructor(opts = {}) {
    this.tables = new Map(); this.persist = opts.persist ?? null;
    if (opts.snapshot) for (const [t, rows] of Object.entries(opts.snapshot)) this.tables.set(t, new Map(rows.map((r) => [this._key(t, r), deepClone(r)])));
  }
  _key(table, row) { return JSON.stringify(PRIMARY_KEYS[table].map((k) => row[k] ?? (k === 'micro_skill_id' ? '' : null))); }
  _t(table) { if (!PRIMARY_KEYS[table]) throw new Error(`unknown table ${table}`); if (!this.tables.has(table)) this.tables.set(table, new Map()); return this.tables.get(table); }
  _changed() { if (this.persist) this.persist(this.snapshot()); }
  _checkUnique(table, row, ownKey) {
    for (const cols of UNIQUE_KEYS[table] ?? []) for (const [k, r] of this._t(table)) if (k !== ownKey && cols.every((c) => r[c] === row[c])) throw new Error(`duplicate unique key in ${table}: ${cols.join(',')}`);
  }
  snapshot() { return Object.fromEntries([...this.tables].map(([t, m]) => [t, [...m.values()].map(deepClone)])); }
  async insert(table, row) {
    const t = this._t(table), k = this._key(table, row);
    if (t.has(k)) throw new Error(`duplicate primary key in ${table}: ${k}`);
    this._checkUnique(table, row, null); t.set(k, deepClone(row)); this._changed(); return deepClone(row);
  }
  async upsert(table, row) { const k = this._key(table, row); this._checkUnique(table, row, k); this._t(table).set(k, deepClone(row)); this._changed(); return deepClone(row); }
  async get(table, id) { const w = pkOf(table, id); return deepClone(this._t(table).get(JSON.stringify(PRIMARY_KEYS[table].map((k) => w[k] ?? null)))) ?? null; }
  async select(table, where = {}, opts = {}) {
    let rows = sortRows([...this._t(table).values()].filter((r) => matches(r, where)), opts.orderBy, opts.desc);
    if (opts.limit) rows = rows.slice(0, opts.limit);
    return rows.map(deepClone);
  }
  async count(table, where = {}) { return [...this._t(table).values()].filter((r) => matches(r, where)).length; }
  async update(table, where, patch) {
    let n = 0; const t = this._t(table);
    for (const [k, r] of [...t]) if (matches(r, where)) { const next = { ...r, ...deepClone(patch) }; t.delete(k); t.set(this._key(table, next), next); n++; }
    if (n) this._changed(); return n;
  }
  async delete(table, where) { let n = 0; const t = this._t(table); for (const [k, r] of [...t]) if (matches(r, where)) { t.delete(k); n++; } if (n) this._changed(); return n; }
  async transaction(fn) {
    const before = this.snapshot();
    try { return await fn(this); }
    catch (e) { this.tables = new Map(Object.entries(before).map(([t, rows]) => [t, new Map(rows.map((r) => [this._key(t, r), r]))])); throw e; }
  }
}
