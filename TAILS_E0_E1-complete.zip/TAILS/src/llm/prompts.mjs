// Prompt + output schema for the audit narrative. The model sees ONLY the digest (counts, shares, codes). Never student free text.
import { digestNumbers } from '../engine/digest.mjs';

export const SYSTEM_AUDIT = `You write a short SAT-prep audit for a student who is a non-native English speaker.
Rules: second person ("you"). Plain English, short sentences. Use ONLY numbers that appear in the JSON the user sends; never invent or round differently.
No promises of score gains. No claims about College Board. No medical or psychological claims. Do not mention that you are an AI.
If data_quality shows few attempts or low confidence, say the picture is not certain.
Finish plan_note with the single most important next action.
Reply with ONE JSON object only, exactly: {"headline":string,"snapshot":string,"levers":[{"skill":string,"why":string,"fix":string}],"behaviors":[string],"plan_note":string,"caution":string}
"skill" must be a skill id copied from top_levers. At most 3 levers and 2 behaviors.`;

export function buildMessages(digest) {
  const clean = { ...digest }; delete clean._tokens;
  return [{ role: 'system', content: SYSTEM_AUDIT }, { role: 'user', content: JSON.stringify(clean) }];
}

const isStr = (x, max = 400) => typeof x === 'string' && x.length > 0 && x.length <= max;
/** Strict parse + schema + "no invented numbers" + skill ids must exist in the digest. Returns {ok, value, errors}. */
export function parseNarrative(text, digest) {
  const errors = [];
  let v;
  try { v = JSON.parse(String(text).trim().replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch { return { ok: false, errors: ['not valid JSON'] }; }
  if (!v || typeof v !== 'object' || Array.isArray(v)) return { ok: false, errors: ['not an object'] };
  const allowedKeys = ['headline', 'snapshot', 'levers', 'behaviors', 'plan_note', 'caution'];
  for (const k of Object.keys(v)) if (!allowedKeys.includes(k)) errors.push(`unexpected key ${k}`);
  for (const k of ['headline', 'snapshot', 'plan_note', 'caution']) if (!isStr(v[k], 500)) errors.push(`${k} must be a non-empty string`);
  if (!Array.isArray(v.levers) || v.levers.length > 3) errors.push('levers must be an array of at most 3');
  else v.levers.forEach((l, i) => {
    if (!isStr(l?.skill, 40) || !isStr(l?.why) || !isStr(l?.fix)) errors.push(`levers[${i}] needs skill, why, fix`);
    else if (!digest.top_levers?.some((t) => t.skill === l.skill)) errors.push(`levers[${i}].skill ${l.skill} is not in the digest`);
  });
  if (!Array.isArray(v.behaviors) || v.behaviors.length > 2 || v.behaviors.some((b) => !isStr(b))) errors.push('behaviors must be at most 2 strings');
  if (errors.length) return { ok: false, errors };
  const allowed = digestNumbers(digest);
  const alltext = [v.headline, v.snapshot, v.plan_note, v.caution, ...v.levers.flatMap((l) => [l.why, l.fix]), ...v.behaviors].join(' ');
  const plain = alltext.replace(/[A-Z]{1,3}\.[A-Z0-9.#-]+/g, ' ');                // skill ids like M.ALG.SYS contain no claims
  for (const m of plain.match(/\d+(?:\.\d+)?/g) ?? []) {
    const num = m.replace(/^0+(?=\d)/, '');
    if (!allowed.has(m) && !allowed.has(num) && !['1', '2', '3', '7', '30', '10'].includes(m)) errors.push(`number ${m} is not in the digest`);    // 1/2/3 = "top 3", 7 = "7-day", 10/30 = habits
  }
  const banned = /\b(guarantee|will (?:raise|increase|improve) your score|College Board (?:says|recommends|confirms)|depress|anxiety disorder|ADHD)\b/i;
  if (banned.test(alltext)) errors.push('contains a banned claim');
  return errors.length ? { ok: false, errors } : { ok: true, value: v, errors: [] };
}
