/* ============================================================
   DESMOS (floating, draggable, resizable window; real Desmos API)
   ============================================================ */
const DESMOS_SRC = 'https://www.desmos.com/api/v1.11/calculator.js?apiKey=dcb31709b452b1cf9dc26972add0fda6';
let calc=null, calcSci=null, desmosLoading=false;
function buildDwin(){
  const w=document.createElement('div'); w.id='dwin'; w.className='hidden';
  w.innerHTML='<div class="dh" id="dwDrag"><i class="ph ph-dots-six-vertical grip"></i><b>Calculator</b><span class="dsw hidden" id="dwSw"><button class="on" data-m="g">Graphing</button><button data-m="s">Scientific</button></span><span class="spacer"></span><button id="dwClose" aria-label="Close calculator"><i class="ph ph-x"></i></button></div><div id="dcalc" class="loading">Loading Desmos...</div><div id="dcalcS" class="hidden" style="flex:1;min-height:0;background:#fff"></div>';
  document.body.appendChild(w);
  $('#dwClose').onclick=()=>toggleCalc(false);
  const h=$('#dwDrag'); let sx,sy,ox,oy,drag=false;
  h.addEventListener('pointerdown',e=>{ if(e.target.closest('button')) return; drag=true; h.setPointerCapture(e.pointerId); const r=w.getBoundingClientRect(); sx=e.clientX; sy=e.clientY; ox=r.left; oy=r.top; });
  h.addEventListener('pointermove',e=>{ if(!drag) return; const nx=Math.max(-w.offsetWidth+120,Math.min(innerWidth-120,ox+e.clientX-sx)), ny=Math.max(0,Math.min(innerHeight-44,oy+e.clientY-sy)); w.style.left=nx+'px'; w.style.top=ny+'px'; });
  h.addEventListener('pointerup',()=>{ drag=false; });
  $$('#dwSw button').forEach(b=>b.onclick=()=>{ const s=b.dataset.m==='s'; $$('#dwSw button').forEach(x=>x.classList.toggle('on',x===b)); $('#dcalc').classList.toggle('hidden',s); $('#dcalcS').classList.toggle('hidden',!s); if(s && !calcSci && window.Desmos){ calcSci=Desmos.ScientificCalculator($('#dcalcS')); } (s?calcSci:calc) && (s?calcSci:calc).resize(); });
  new ResizeObserver(()=>{ if(calc) calc.resize(); if(calcSci) calcSci.resize(); }).observe(w);
  return w;
}
function toggleCalc(force){
  let w=$('#dwin')||buildDwin();
  const show = force===undefined ? w.classList.contains('hidden') : force;
  w.classList.toggle('hidden',!show);
  const b=$('#tCalc'); if(b) b.classList.toggle('on',show);
  if(show) ensureDesmos();
}
function ensureDesmos(){
  if(calc){ calc.resize(); return; }
  if(window.Desmos){ initDesmos(); return; }
  if(desmosLoading) return; desmosLoading=true;
  const s=document.createElement('script'); s.src=DESMOS_SRC; s.async=true;
  s.onload=()=>initDesmos();
  s.onerror=()=>{ desmosLoading=false; const d=$('#dcalc'); d.innerHTML='<div style="text-align:center;padding:20px;line-height:1.6">Could not reach Desmos. Check your connection, or<br><a href="https://www.desmos.com/calculator" target="_blank" rel="noopener" style="color:#5b3ff0;font-weight:600">open Desmos in a new tab</a>.</div>'; };
  document.head.appendChild(s);
}
function initDesmos(){
  const d=$('#dcalc'); d.classList.remove('loading'); d.textContent='';
  calc = Desmos.GraphingCalculator(d, { keypad:true, expressions:true, settingsMenu:true, zoomButtons:true, expressionsTopbar:true, pointsOfInterest:true, trace:true, border:false, images:false, folders:false, notes:false, links:false, autosize:true });
  try{ if(Desmos.enabledFeatures && Desmos.enabledFeatures.ScientificCalculator) $('#dwSw').classList.remove('hidden'); }catch(e){}
  calc.resize();
}
function openReference(){
  const cards=[
    ['Circle','A = πr²','C = 2πr'],['Rectangle','A = ℓw'],['Triangle','A = ½bh'],['Pythagorean theorem','a² + b² = c²'],
    ['Special right triangles','30-60-90: x, x√3, 2x','45-45-90: x, x, x√2'],['Rectangular prism','V = ℓwh'],['Cylinder','V = πr²h'],
    ['Sphere','V = (4/3)πr³'],['Cone','V = (1/3)πr²h'],['Pyramid','V = (1/3)ℓwh'],['Angle facts','360° in a circle','2π radians in a circle','180° in a triangle']
  ];
  const m=openModal('<h2>Reference sheet</h2><p>The formulas the SAT provides for Math. Many questions need a formula that is not listed here, so know the common ones.</p><div class="refgrid">'+cards.map(c=>'<div class="refc"><b>'+c[0]+'</b>'+c.slice(1).map(l=>'<span>'+esc(l)+'</span>').join('')+'</div>').join('')+'</div><div class="acts"><button class="btn pri" id="refX">Close</button></div>');
  m.querySelector('.modal').classList.add('wide'); m.style.zIndex=320;
  m.querySelector('#refX').onclick=()=>m.remove();
}

/* ---------- coach (mascot companion in practice) ---------- */
let coachT=null;
function coachSay(face, text){
  const ex=$('#exam'); if(!ex || !X) return;
  let c=$('#coach');
  if(!c){ c=document.createElement('div'); c.id='coach'; c.innerHTML='<div class="coachsay script off"></div><img alt="">'; ex.appendChild(c); }
  { const im=c.querySelector('img'); im.src=IMG[face]; im.dataset.mood=moodOf(face); } const s=c.querySelector('.coachsay'); s.textContent=text; s.classList.remove('off');
  clearTimeout(coachT); coachT=setTimeout(()=>s.classList.add('off'),3200);
}
