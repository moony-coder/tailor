// Mistake interview, second chances, question reports.
import { makeId, iso, DAY_MS } from '../util/misc.mjs';
import { computeMastery } from '../engine/mastery.mjs';
import { selectInterview, chipsFor, validateReview, nextDueDays } from '../review/interview.mjs';
import { pickSecondChance } from '../questions/assembler.mjs';
import { reviewView, publicView, isCorrect, correctKey } from '../questions/score.mjs';
import { recomputeRootCauses, recomputeMastery } from './analysis.mjs';
import { refreshPlan } from './plan.mjs';
import { ApiError, invalid, notFound, conflict, forbidden, getSession, assertOwner } from './shared.mjs';

/** GET /api/sessions/:id/review-queue */
export async function getReviewQueue(ctx, sessionId, actor) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  const s = await getSession(db, sessionId); assertOwner(s, actor);
  const all = await db.select('attempts', { profile_id: s.profile_id });
  const attempts = all.filter((a) => a.session_id === sessionId);
  if (s.source === 'bluebook') return { session_id: sessionId, queue: [], auto: attempts.filter((a) => !a.is_correct).map((a) => a.id), cap: cfg.interview.cap, note: 'Bluebook imports hold labels only, so there is nothing to re-open. Use the official Bluebook review for the questions themselves.' };
  const mastery = computeMastery(all, cfg, ctx.now());
  const sel = selectInterview(attempts, mastery, tax, cfg);
  const byId = new Map(attempts.map((a) => [a.id, a]));
  const reviews = new Map((await db.select('mistake_reviews', { session_id: sessionId })).map((r) => [r.attempt_id, r]));
  const queue = sel.queue.map((c) => {
    const a = byId.get(c.attempt_id), q = ctx.qById.get(a.question_id), rv = reviews.get(a.id);
    return { attempt_id: a.id, why: c.why, priority: c.priority, is_correct: !!a.is_correct, position: a.position, skill: { id: a.skill_id, name: tax.skillName(a.skill_id) },
      question: reviewView(q, a.chosen), chips: chipsFor(tax, a.section), done: !!rv, review: rv ? { self_reason: rv.self_reason, understood_after_solution: rv.understood_after_solution, takeaway_text: rv.takeaway_text } : null };
  });
  return { session_id: sessionId, queue, auto: sel.auto, cap: sel.cap, total_candidates: sel.total_candidates, remaining: queue.filter((x) => !x.done).length };
}

/** POST /api/reviews/:attemptId */
export async function submitReview(ctx, attemptId, body, actor) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  const a = await db.get('attempts', attemptId); if (!a) throw notFound('attempt'); assertOwner(a, actor);
  if (!a.question_id) throw invalid('imported (Bluebook) attempts cannot be reviewed here');
  const v = validateReview(body ?? {}, tax, a.section);
  if (!v.ok) throw invalid('review rejected', v.errors);
  const nowIso = iso(ctx.now()), id = `rv_${attemptId}`;
  const existed = await db.get('mistake_reviews', id);
  await db.upsert('mistake_reviews', { id, attempt_id: attemptId, session_id: a.session_id, profile_id: a.profile_id, self_reason: body.self_reason ?? null, understood_after_solution: body.understood_after_solution ?? null,
    takeaway_text: body.takeaway_text ?? null, second_chance_due_at: existed?.second_chance_due_at ?? null, second_chance_result: existed?.second_chance_result ?? null,
    system_root_cause: existed?.system_root_cause ?? null, system_confidence: existed?.system_confidence ?? null, independent_root_cause: null, self_root_cause: v.rootCause, agreement: null, created_at: existed?.created_at ?? nowIso });
  let report = null, second = null;
  if (body.self_reason === 'DISAGREE') {       // "I think the key is wrong": goes to the teacher, no second chance, excluded from nothing yet
    const open = (await db.select('question_reports', { question_id: a.question_id, profile_id: a.profile_id, attempt_id: attemptId }))[0];
    if (!open) { report = { id: makeId('qr_', ctx.now()), question_id: a.question_id, profile_id: a.profile_id, attempt_id: attemptId, reason: 'student disagrees with the key (from review)', status: 'open', created_at: nowIso, resolved_at: null }; await db.insert('question_reports', report); }
  } else if (!a.is_correct) {
    const pending = (await db.select('second_chances', { attempt_id: attemptId })).find((c) => c.status === 'pending');
    if (!pending) {
      const orig = ctx.qById.get(a.question_id);
      const seen = new Set((await db.select('attempts', { profile_id: a.profile_id })).map((x) => x.question_id).filter(Boolean));
      const pick = pickSecondChance(ctx, orig, seen), due = iso(ctx.now() + nextDueDays(0, cfg) * DAY_MS);
      second = { id: makeId('sc_', ctx.now()), attempt_id: attemptId, profile_id: a.profile_id, original_question_id: orig.id, serve_question_id: pick.question.id, serve_kind: pick.kind, stage: 0, due_at: due, status: 'pending', answered_at: null, chosen: null, result: null };
      await db.insert('second_chances', second);
      await db.update('mistake_reviews', { id }, { second_chance_due_at: due });
    } else second = pending;
  }
  await recomputeRootCauses(ctx, a.profile_id);
  await recomputeMastery(ctx, a.profile_id);
  await refreshPlan(ctx, a.profile_id);
  const rv = await db.get('mistake_reviews', id);
  return { saved: true, attempt_id: attemptId, self_root_cause: rv.self_root_cause, inferred_root_cause: rv.independent_root_cause, agreement: rv.agreement == null ? null : !!rv.agreement, reported: !!report, second_chance: second && { id: second.id, due_at: second.due_at, serve_kind: second.serve_kind } };
}

/** GET /api/second-chance?profile_id= (extra route the UI needs) : pending ones, due first. */
export async function listSecondChances(ctx, profileId, actor) {
  if (actor && actor !== profileId) throw forbidden();
  const rows = (await ctx.db.select('second_chances', { profile_id: profileId, status: 'pending' }, { orderBy: 'due_at' }));
  const now = ctx.now();
  return { items: rows.map((r) => { const q = ctx.qById.get(r.serve_question_id); return { id: r.id, attempt_id: r.attempt_id, stage: r.stage, due_at: r.due_at, due: Date.parse(r.due_at) <= now, serve_kind: r.serve_kind, skill: ctx.tax.skillName(q.skill_id), question: publicView(q, 1) }; }),
    note: 'In the testing phase every second chance can be answered immediately; "due" only shows whether the spacing has passed.' };
}

/** POST /api/second-chance/:id/answer  body {chosen} */
export async function answerSecondChance(ctx, id, body, actor) {
  const { db } = ctx, cfg = ctx.config.thresholds;
  const sc = await db.get('second_chances', id); if (!sc) throw notFound('second chance'); assertOwner(sc, actor);
  if (sc.status !== 'pending') throw conflict('this second chance was already answered', { status: sc.status, result: sc.result });
  const q = ctx.qById.get(sc.serve_question_id);
  const chosen = body?.chosen == null || body.chosen === '' ? null : String(body.chosen);
  if (chosen == null) throw invalid('chosen is required');
  if (q.format !== 'spr' && !q.choices.some((c) => c.key === chosen)) throw invalid('chosen must be one of the answer keys');
  const ok = isCorrect(q, chosen), nowIso = iso(ctx.now());
  await db.update('second_chances', { id }, { status: ok ? 'passed' : 'failed', answered_at: nowIso, chosen, result: ok ? 'pass' : 'fail' });
  await db.update('mistake_reviews', { attempt_id: sc.attempt_id }, { second_chance_result: ok ? 'pass' : 'fail' });
  let next = null;
  if (!ok) {      // not fixed yet: ask again later, further out each time
    const stage = sc.stage + 1, due = iso(ctx.now() + nextDueDays(stage, cfg) * DAY_MS);
    next = { id: makeId('sc_', ctx.now()), attempt_id: sc.attempt_id, profile_id: sc.profile_id, original_question_id: sc.original_question_id, serve_question_id: sc.serve_question_id, serve_kind: sc.serve_kind, stage, due_at: due, status: 'pending', answered_at: null, chosen: null, result: null };
    await db.insert('second_chances', next);
  }
  await recomputeRootCauses(ctx, sc.profile_id);
  await recomputeMastery(ctx, sc.profile_id);
  await refreshPlan(ctx, sc.profile_id);
  const a = await db.get('attempts', sc.attempt_id);
  return { correct: ok, correct_key: correctKey(q), explanation: reviewView(q, chosen), updated_root_cause: a?.root_cause ?? null, meaning: ok ? 'You solved a similar question correctly now, so the first miss was most likely an execution slip rather than a knowledge gap.' : 'Still not solved, so this looks like a knowledge or strategy gap. It is now in your plan.', next_due_at: next?.due_at ?? null };
}

/** POST /api/questions/:id/report */
export async function reportQuestion(ctx, questionId, body, actor) {
  const { db } = ctx;
  if (!ctx.qById.has(questionId)) throw notFound('question');
  const profile_id = body?.profile_id ?? actor; if (!profile_id) throw invalid('profile_id is required');
  if (actor && profile_id !== actor) throw forbidden();
  const reason = typeof body?.reason === 'string' ? body.reason.trim().slice(0, 280) : '';
  if (!reason) throw invalid('reason is required (max 280 characters)');
  const r = { id: makeId('qr_', ctx.now()), question_id: questionId, profile_id, attempt_id: body.attempt_id ?? null, reason, status: 'open', created_at: iso(ctx.now()), resolved_at: null };
  await db.insert('question_reports', r);
  const open = await db.count('question_reports', { question_id: questionId, status: 'open' });
  return { id: r.id, status: 'open', open_reports_for_question: open };
}
