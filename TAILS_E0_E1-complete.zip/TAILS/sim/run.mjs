#!/usr/bin/env node
// TAILS simulation + backtest harness.
//   node sim/run.mjs                              all personas, 3 seeds, today's exposure behaviour
//   node sim/run.mjs --persona B_1200_1500 --seeds 8 --exposure unlimited
//   node sim/run.mjs --exposure all               never | recycle | unlimited side by side
//   node sim/run.mjs --compare sim/engines/naive.mjs      new engine vs the current one
//   node sim/run.mjs --report                     write sim/out/report.md and summary.json
//   node sim/run.mjs --gate                       CI: hard invariants + no regression vs sim/baseline.json (exit 1 on failure)
//   node sim/run.mjs --update-baseline            accept the current numbers as the new baseline (do this only after an intended improvement)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { loadAll } from '../src/loaders/node.mjs';
import { runStudent } from './driver.mjs';
import { PERSONAS, DEFAULT_SEED } from './personas.mjs';
import { summarize, aggregate, METRICS, HARD } from './metrics.mjs';
import current from './engines/current.mjs';
import naive from './engines/naive.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2), has = (f) => argv.includes(`--${f}`), opt = (f, d) => { const i = argv.indexOf(`--${f}`); return i >= 0 ? argv[i + 1] : d; };

export async function runMatrix({ data, engine, personas = Object.keys(PERSONAS), seeds = 3, exposure = 'never', seedOffset = 0 }) {
  const rows = [], traces = [];
  for (const name of personas) for (let k = seedOffset; k < seedOffset + seeds; k++) {
    const persona = PERSONAS[name], T = runStudent({ persona, data, engine, seed: DEFAULT_SEED + k * 101, exposure });
    rows.push({ key: name, exposure, ...summarize(T, persona, data) }); traces.push(T);
  }
  const by = {}; for (const r of rows) (by[r.key] ??= []).push(r);
  return { rows, traces, agg: Object.fromEntries(Object.entries(by).map(([k, v]) => [k, { ...aggregate(v), key: k, exposure }])) };
}

const fmt = (v, w = 7) => String(v ?? '-').padStart(w);
function printTable(title, agg, cols) {
  console.log(`\n${title}`); console.log('persona'.padEnd(14) + cols.map((c) => c.padStart(c.length > 8 ? c.length + 1 : 9)).join(''));
  for (const [k, a] of Object.entries(agg)) console.log(k.padEnd(14) + cols.map((c) => fmt(a[c], c.length > 8 ? c.length + 1 : 9)).join(''));
}
const COLS = ['start_true', 'end_true', 'target', 'gain', 'gap_closed', 'nowcast_early', 'nowcast_mature', 'forecast_mae_mid', 'short_share', 'diag_repeat', 'run_dry_skills', 'mastery_rho'];

async function loadEngine(p) { return p ? (await import(pathToFileURL(path.resolve(p)).href)).default : current; }

async function main() {
  const data = await loadAll(), seeds = Number(opt('seeds', 3)), only = opt('persona', null), personas = only ? only.split(',') : Object.keys(PERSONAS);
  const engine = await loadEngine(opt('engine', null));
  const t0 = Date.now();

  if (has('gate') || has('update-baseline')) {
    const tolFile = path.join(HERE, 'tolerances.json'), TOL = fs.existsSync(tolFile) ? JSON.parse(fs.readFileSync(tolFile, 'utf8')) : null;
    const gateSeeds = Number(opt('seeds', TOL?.seeds ?? 4)), out = {}, failures = [], notes = [];
    for (const exposure of ['never', 'unlimited']) {
      const m = await runMatrix({ data, engine, personas, seeds: gateSeeds, exposure });
      out[exposure] = m.agg;
      for (const r of m.rows) for (const h of HARD) { if (h.max != null && r[h.key] > h.max) failures.push(`HARD ${exposure}/${r.key}/seed${r.seed}: ${h.key}=${r[h.key]} > ${h.max}`); if (h.min != null && r[h.key] < h.min) failures.push(`HARD ${exposure}/${r.key}/seed${r.seed}: ${h.key}=${r[h.key]} < ${h.min}`); }
    }
    // determinism: the same run twice is byte-identical
    const P = PERSONAS.B_1200_1500, a = JSON.stringify(summarize(runStudent({ persona: P, data, engine, seed: DEFAULT_SEED, exposure: 'never' }), P, data)), b = JSON.stringify(summarize(runStudent({ persona: P, data, engine, seed: DEFAULT_SEED, exposure: 'never' }), P, data));
    if (a !== b) failures.push('HARD determinism: two identical runs differ');
    // harness validity: in the oracle world (engine curve exact, no mock noise) the score model must be close once it has evidence
    const o = out.unlimited?.oracle; if (o && o.nowcast_mature > 90) failures.push(`HARD harness-validity: oracle nowcast_mature ${o.nowcast_mature} > 90 (world and engine disagree even when they should not)`);
    const bpath = path.join(HERE, 'baseline.json');
    if (has('update-baseline')) {
      const body = JSON.stringify({ engine: engine.version, seeds: gateSeeds, metrics: out }, null, 1);
      fs.writeFileSync(bpath, body); fs.mkdirSync(path.join(HERE, 'baselines'), { recursive: true }); fs.writeFileSync(path.join(HERE, 'baselines', `${engine.version}.json`), body);
      console.log(`baseline written: ${bpath} (engine ${engine.version}, ${gateSeeds} seeds)`);
    } else {
      const baseFile = fs.existsSync(bpath) ? JSON.parse(fs.readFileSync(bpath, 'utf8')) : null;
      if (!baseFile) failures.push('no sim/baseline.json (run with --update-baseline once)');
      else {
        const base = baseFile.metrics; if (baseFile.seeds !== gateSeeds) failures.push(`baseline was made with ${baseFile.seeds} seeds, gate runs ${gateSeeds}: compare like with like`);
        const tol = (m, kind) => TOL?.tolerances?.[m.key]?.[kind] ?? (kind === 'cell' ? m.tol : m.tol / 2);
        for (const ex of Object.keys(out)) {
          for (const m of METRICS) {
            // (1) pooled: the average over personas is far less noisy, so this catches small across-the-board regressions
            const pv = (src) => { const v = Object.values(src[ex] ?? {}).map((x) => x[m.key]).filter((x) => x != null); return v.length ? v.reduce((s, x) => s + x, 0) / v.length : null; };
            const bp = pv(base), np = pv(out); if (bp != null && np != null) { const worse = m.dir === 'lower' ? np - bp : bp - np; if (worse > tol(m, 'pooled')) failures.push(`REGRESSION ${ex}/ALL-PERSONAS: ${m.label} ${+bp.toFixed(3)} -> ${+np.toFixed(3)} (pooled tolerance ${tol(m, 'pooled')})`); else if (-worse > tol(m, 'pooled')) notes.push(`improved ${ex}/ALL: ${m.label} ${+bp.toFixed(3)} -> ${+np.toFixed(3)}`); }
            // (2) per persona: only large moves, so one broken persona cannot hide inside a good average
            for (const [k, a2] of Object.entries(out[ex])) { const bv = base[ex]?.[k]?.[m.key], nv = a2[m.key]; if (bv == null || nv == null) continue; const worse = m.dir === 'lower' ? nv - bv : bv - nv; if (worse > tol(m, 'cell')) failures.push(`REGRESSION ${ex}/${k}: ${m.label} ${bv} -> ${nv} (cell tolerance ${tol(m, 'cell')})`); }
          }
        }
      }
    }
    console.log(failures.length ? `SIM GATE FAILED (${failures.length})\n  ` + failures.slice(0, 40).join('\n  ') : `SIM GATE OK (${personas.length} personas x ${gateSeeds} seeds x 2 worlds, ${((Date.now() - t0) / 1000).toFixed(1)}s)` + (notes.length ? '\n  ' + notes.slice(0, 12).join('\n  ') : ''));
    process.exit(failures.length ? 1 : 0);
  }

  const modes = opt('exposure', 'never') === 'all' ? ['never', 'recycle', 'unlimited'] : [opt('exposure', 'never')];
  const results = {};
  for (const ex of modes) { const m = await runMatrix({ data, engine, personas, seeds, exposure: ex }); results[ex] = m; printTable(`engine=${engine.id}  exposure=${ex}  seeds=${seeds}`, m.agg, COLS); }

  if (opt('compare', null)) {
    const other = await loadEngine(opt('compare')), ex = modes[0], m2 = await runMatrix({ data, engine: other, personas, seeds, exposure: ex });
    console.log(`\nCOMPARE  ${engine.id} (A) vs ${other.id} (B)   exposure=${ex}   (positive = B better)`);
    console.log('persona'.padEnd(14) + ['gain A', 'gain B', 'd gain', 'd nowcast', 'd short'].map((c) => c.padStart(10)).join(''));
    for (const k of Object.keys(results[ex].agg)) { const a = results[ex].agg[k], b = m2.agg[k]; console.log(k.padEnd(14) + [a.gain, b.gain, +(b.gain - a.gain).toFixed(1), +(a.nowcast_mae - b.nowcast_mae).toFixed(1), +(a.short_share - b.short_share).toFixed(2)].map((x) => String(x).padStart(10)).join('')); }
  }
  if (has('report')) { const { writeReport } = await import('./report.mjs'); const file = await writeReport({ data, engine, results, seeds, personas, runMatrix, naive }); console.log('\nreport:', file); }
  if (has('json')) fs.writeFileSync(path.join(HERE, 'out', 'summary.json'), JSON.stringify(Object.fromEntries(Object.entries(results).map(([k, v]) => [k, v.agg])), null, 1));
  console.log(`\n(${((Date.now() - t0) / 1000).toFixed(1)}s)`);
}
if (import.meta.url === pathToFileURL(process.argv[1]).href) main();
