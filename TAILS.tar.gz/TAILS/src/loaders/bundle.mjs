// Bundle -> { taxonomy, questions, lessons, config }. Pure (no fs), so Node and the browser share it.
import { createTaxonomy } from '../taxonomy/index.mjs';
export function fromBundle(b) {
  return {
    taxonomy: createTaxonomy({ skills: b.skills, microskills: b.microskills, traps: b.traps, reasons: b.reasons }),
    questions: b.questions,
    lessons: b.lessons.lessons,
    config: { thresholds: b.thresholds, blueprints: b.blueprints, routing: b.routing },
    graph: b.graph ?? null,
  };
}
