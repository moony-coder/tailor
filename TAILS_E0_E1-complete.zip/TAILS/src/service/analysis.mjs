// Re-derives everything that depends on the attempt log: root causes, mastery, levers, behaviours, digest. Idempotent.
import { groupBy, iso, makeId } from '../util/misc.mjs';
import { inferRootCause } from '../engine/rootcause.mjs';
import { computeMastery, masteryRows, skillP, skillN } from '../engine/mastery.mjs';
import { topLevers } from '../engine/levers.mjs';
import { topBehaviors } from '../engine/behaviors.mjs';
import { buildDigest } from '../engine/digest.mjs';

/** Latest answered second chance per attempt. */
function latestChances(chances) {
  const m = new Map();
  for (const c of chances.filter((c) => c.answered_at)) { const cur = m.get(c.attempt_id); if (!cur || c.answered_at > cur.answered_at) m.set(c.attempt_id, c); }
  return m;
}

/** Re-infer root causes for every wrong attempt of the profile and persist changes. Mastery used for "careless candidate" excludes the attempt's own session. */
export async function recomputeRootCauses(ctx, profileId) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  const attempts = await db.select('attempts', { profile_id: profileId }, { orderBy: ['created_at', 'position'] });
  const reviews = new Map((await db.select('mistake_reviews', { profile_id: profileId })).map((r) => [r.attempt_id, r]));
  const chances = latestChances(await db.select('second_chances', { profile_id: profileId }));
  const sessionStart = new Map();
  for (const a of attempts) { const c = sessionStart.get(a.session_id); if (!c || a.created_at < c) sessionStart.set(a.session_id, a.created_at); }
  const priorCache = new Map();
  const priorMastery = (sid) => {
    if (!priorCache.has(sid)) priorCache.set(sid, computeMastery(attempts.filter((x) => x.session_id !== sid && x.created_at < sessionStart.get(sid)), cfg, ctx.now()));
    return priorCache.get(sid);
  };
  let changed = 0;
  await db.transaction(async (tx) => {
    for (const a of attempts) {
      if (a.is_correct) { if (a.root_cause != null) { await tx.update('attempts', { id: a.id }, { root_cause: null, root_cause_conf: null }); changed++; } continue; }
      const rv = reviews.get(a.id), sc = chances.get(a.id);
      const reason = rv?.self_reason ? tax.reasonByCode.get(rv.self_reason) : null;
      const pm = a.skill_id && !a.domain_estimated ? priorMastery(a.session_id) : null;
      const ev = {
        trapHint: a.trap_code ? tax.trapByCode.get(a.trap_code)?.root_cause_hint ?? null : null,
        skillP: pm ? skillP(pm, a.skill_id) : null, skillN: pm ? skillN(pm, a.skill_id) : 0,
        self: rv ? { root_cause: reason?.root_cause ?? null, code: rv.self_reason, understood: rv.understood_after_solution } : null,
        secondChance: sc ? { result: sc.status === 'passed' ? 'passed' : 'failed', same_question: sc.serve_kind === 'same' } : null,
      };
      const r = inferRootCause(a, ev, cfg);
      if (a.root_cause !== r.root_cause || a.root_cause_conf !== r.confidence) { await tx.update('attempts', { id: a.id }, { root_cause: r.root_cause, root_cause_conf: r.confidence }); changed++; }
      if (rv) await tx.update('mistake_reviews', { id: rv.id }, { system_root_cause: r.root_cause, system_confidence: r.confidence, independent_root_cause: r.independent.root_cause, self_root_cause: r.self_root_cause, agreement: r.agreement });
    }
  });
  return { n_attempts: attempts.length, changed };
}

export async function recomputeMastery(ctx, profileId, { sessionId = null } = {}) {
  const { db } = ctx, cfg = ctx.config.thresholds, nowMs = ctx.now();
  const attempts = await db.select('attempts', { profile_id: profileId });
  const mastery = computeMastery(attempts, cfg, nowMs);
  const rows = masteryRows(profileId, mastery, iso(nowMs));
  await db.transaction(async (tx) => {
    await tx.delete('skill_mastery', { profile_id: profileId });
    for (const r of rows) await tx.insert('skill_mastery', r);
    if (sessionId) for (const r of rows) await tx.insert('skill_mastery_history', { id: makeId('h_', nowMs), profile_id: profileId, skill_id: r.skill_id, micro_skill_id: r.micro_skill_id, session_id: sessionId, p_mastery: r.p_mastery, n_attempts: r.n_attempts, created_at: iso(nowMs) });
  });
  return mastery;
}

export async function moduleSummaries(ctx, sessionId) {
  const rows = await ctx.db.select('session_modules', { session_id: sessionId });
  return rows.filter((r) => r.score_json).map((r) => r.score_json);
}

/** Everything the audit needs, computed from the DB right now. */
export async function buildAuditInputs(ctx, profileId, sessionId) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  const all = await db.select('attempts', { profile_id: profileId }, { orderBy: ['created_at', 'position'] });
  const session = all.filter((a) => a.session_id === sessionId);
  const mastery = computeMastery(all, cfg, ctx.now());
  const levers = topLevers(all, mastery, tax, cfg);
  const mods = await moduleSummaries(ctx, sessionId);
  const behaviorsTop = topBehaviors(session, mods, cfg);
  const snaps = (await db.select('error_profile_snapshots', { profile_id: profileId }, { orderBy: 'created_at' })).filter((s) => s.session_id !== sessionId);
  const previous = snaps.length ? snaps[snaps.length - 1].json : null;
  const digest = buildDigest({ attempts: session, levers, mastery, previous, modules: mods, tax, cfg, behaviorsTop });
  return { all, session, mastery, levers, mods, behaviorsTop, digest, previous };
}
