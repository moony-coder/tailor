/* ================= v4 polish: countdown, readiness status, review empty state, roadmap ================= */
(function(){
  const pad = (n,l=2) => String(n).padStart(l,'0');

  /* ---- live countdown to test day (08:00 local on the chosen date) ---- */
  let cdTimer = null; const cdLast = {};
  const cdTarget = () => new Date(state.profile.testDate+'T08:00:00').getTime();
  function cdSet(id, v){
    const el = $('#'+id); if(!el || cdLast[id]===v) return;
    const first = cdLast[id]===undefined; el.textContent = v; cdLast[id] = v;
    if(!first && !REDUCED){ el.classList.remove('tick'); void el.offsetWidth; el.classList.add('tick'); }
  }
  function cdTick(){
    if(!$('#cdD')) return;
    const t = Math.max(0, cdTarget() - Date.now()), s = Math.floor(t/1000);
    cdSet('cdD', String(Math.floor(s/86400)));
    cdSet('cdH', pad(Math.floor(s%86400/3600)));
    cdSet('cdM', pad(Math.floor(s%3600/60)));
    cdSet('cdS', pad(s%60));
    const rl = $('#cdRail');
    if(rl){
      const sec = s%60;
      if(sec===0 || rl.dataset.s===undefined){ rl.classList.add('snap'); rl.style.setProperty('--p', rl.dataset.s===undefined ? sec/60 : 0); void rl.offsetWidth; rl.classList.remove('snap'); }
      rl.dataset.s = sec; rl.style.setProperty('--p', (sec+1)/60);
    }
  }
  const _ad4 = animateDash;
  animateDash = function(){
    _ad4();
    const d = new Date(state.profile.testDate+'T08:00:00');
    $('#sDate').textContent = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    $('#sDays').textContent = 'Counting down to 8:00 AM';
    Object.keys(cdLast).forEach(k => delete cdLast[k]);
    cdTick(); clearInterval(cdTimer);
    cdTimer = setInterval(() => { if(!document.hidden && currentView==='dash') cdTick(); }, 1000);
  };

  /* ---- analytics: readiness status + a concrete next step ---- */
  const _rp4 = renderProgress;
  renderProgress = function(){
    _rp4();
    const acc = accuracy(), v = state.answered ? Math.min(100, Math.round(acc*.9+10)) : 0, tag = $('#readyTag'), p = $('#readyP');
    if(tag) tag.textContent = v>=85 ? 'Test ready' : v>=70 ? 'Getting close' : v>=50 ? 'Building momentum' : 'Early days';
    if(p) p.textContent = acc>=85 ? 'You are above the 85% accuracy target. Keep your streak going.' : (85-acc)+' more percentage points of accuracy to reach your 85% target.';
  };

  /* ---- review: composed empty state ---- */
  const _rv4 = renderReview;
  renderReview = function(){
    _rv4();
    if(state.missed.length) return;
    $('#reviewList').innerHTML =
      '<div class="card rvempty"><div class="rve-main"><img data-mood="trophy" src="'+IMG.m_trophy+'" alt="">'+
      '<div><h3>Nothing to review</h3><p>Every question you miss lands here with its full explanation.</p>'+
      '<button class="btn acc lg" onclick="go(\'practice\')">Start practice<i class="ph ph-arrow-right"></i></button></div></div>'+
      '<ol class="rve-steps">'+
      '<li><i class="ph ph-x-circle"></i><b>Miss a question</b><span>It is saved here automatically.</span></li>'+
      '<li><i class="ph ph-book-open-text"></i><b>Read the explanation</b><span>See exactly why the right answer works.</span></li>'+
      '<li><i class="ph ph-check-circle"></i><b>Get it right later</b><span>Once you do, it leaves the list.</span></li>'+
      '</ol></div>';
  };

  /* ---- study plan: phase bar + week rail + one detailed week ---- */
  let planSel = 1;
  const DAYFULL = {Mon:'Monday',Tue:'Tuesday',Wed:'Wednesday',Thu:'Thursday',Fri:'Friday',Sat:'Saturday'};
  const dayIcon = t => /^Drill/.test(t) ? 'ph-target' : /^Lesson/.test(t) ? 'ph-book-open-text' : /^Timed/.test(t) ? 'ph-timer' : /^Retry/.test(t) ? 'ph-arrows-clockwise' : /^Mixed/.test(t) ? 'ph-shuffle' : /^Full practice/.test(t) ? 'ph-exam' : 'ph-notebook';
  function roadHTML(){
    const W = planWeeks(); planSel = Math.max(1, Math.min(planSel, W.length));
    const w = W[planSel-1], todayI = todayIdx();
    const groups = []; W.forEach(x => { const g = groups[groups.length-1]; if(g && g.ph===x.ph){ g.to = x.w; } else groups.push({ph:x.ph, from:x.w, to:x.w}); });
    const op = {Foundations:.35, 'Drill and pace':.65, 'Test simulation':1, Sprint:1};
    const chip = x => '<button class="wkb'+(x.w===planSel?' on':'')+(x.last?' tst':'')+'" data-wk="'+x.w+'" aria-pressed="'+(x.w===planSel)+'" aria-label="Week '+x.w+(x.last?', practice test week':'')+'">'+x.w+'<small>'+(x.last?'test':'')+'</small></button>';
    const phases = '<div class="phases">'+groups.map(g => {
      const n = g.to-g.from+1, items = W.filter(x => x.w>=g.from && x.w<=g.to);
      return '<div class="ph-seg" style="--n:'+n+';--o:'+(op[g.ph]||.5)+'"><b>'+esc(g.ph)+'</b><small>'+(n===1?'Week '+g.from:'Weeks '+g.from+'-'+g.to)+'</small><div class="wkrail" role="group" aria-label="'+esc(g.ph)+' weeks">'+items.map(chip).join('')+'</div></div>';
    }).join('')+'</div>';
    const days = w.days.map((d,k) => {
      const now = planSel===1 && k===todayI;
      return '<div class="dayt'+(now?' today':'')+(/^Full practice/.test(d[1])?' big':'')+'" style="--k:'+k+'"><span class="dic"><i class="ph '+dayIcon(d[1])+'"></i></span><b>'+DAYFULL[d[0]]+(now?', today':'')+'</b><span>'+esc(d[1])+'</span></div>';
    }).join('');
    const detail = '<div class="card wkd"><div class="wkd-top"><div><h3>Week '+w.w+'</h3><div class="wkd-tags"><span class="tag acc">'+esc(w.ph)+'</span>'+(planSel===1?'<span class="tag good">This week</span>':'')+(w.last?'<span class="tag warn">Practice test week</span>':'')+'</div></div>'+
      '<div class="wkd-nav"><button class="iconbtn" data-wkstep="-1" aria-label="Previous week"'+(planSel<=1?' disabled':'')+'><i class="ph ph-caret-left"></i></button><button class="iconbtn" data-wkstep="1" aria-label="Next week"'+(planSel>=W.length?' disabled':'')+'><i class="ph ph-caret-right"></i></button>'+
      (planSel===1?'<button class="btn acc" style="margin-left:6px" onclick="startPractice(\''+w.a+'\')">Start today\'s drill<i class="ph ph-arrow-right"></i></button>':'')+'</div></div>'+
      '<p class="wkd-sub">Focus on <b>'+esc(TOPICS[w.a].short)+'</b> and <b>'+esc(TOPICS[w.b].short)+'</b>. Plan for about '+w.min+' minutes a day.</p>'+
      '<div class="days6 wkd-anim">'+days+'</div><div class="wkd-foot">Sunday is your rest day.</div></div>';
    return '<div class="road" id="road">'+phases+detail+'</div>';
  }
  const _pl4 = renderPlan;
  renderPlan = function(){
    _pl4();
    const body = $('#planBody'); if(!body) return;
    body.querySelectorAll('.wkgrid,.tiles').forEach(n => n.remove());
    body.insertAdjacentHTML('beforeend', roadHTML());
  };
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-wk],[data-wkstep]'); if(!b) return;
    planSel = b.dataset.wk ? +b.dataset.wk : planSel + (+b.dataset.wkstep);
    const old = $('#road'); if(old){ const t = document.createElement('div'); t.innerHTML = roadHTML(); old.replaceWith(t.firstChild); }
  });
})();

hydrate();


/* ===== v5: change test date ===== */
function openDatePicker(){
 let sel=state.profile.testDate;const now=Date.now(),today=ymd(now);
 const row=d=>{const days=Math.max(0,Math.ceil((satAt(d.d)-now)/DAY));
  let sub='Anticipated date, deadlines not published yet';
  if(!d.est){sub=today<=d.r?'Register by '+satShort(d.r):today<=d.l?'Late registration until '+satShort(d.l):'Registration closed';}
  return '<button type="button" class="dprow'+(d.d===sel?' on':'')+'" data-d="'+d.d+'" role="radio" aria-checked="'+(d.d===sel)+'"><span><b>'+satLong(d.d)+'</b><small>'+sub+'</small></span><span class="dpn">'+days+' day'+(days===1?'':'s')+'</span><i class="ph ph-check-circle"></i></button>';};
 const up=satUpcoming(),off=up.filter(d=>!d.est),est=up.filter(d=>d.est);
 const m=openModal('<h2>Change test date</h2><p>Official College Board SAT dates. Every SAT is on a Saturday.</p><div class="dplist" role="radiogroup" aria-label="SAT test dates">'+(off.length?'<div class="dpgroup">2026 to 2027 school year</div>'+off.map(row).join(''):'')+(est.length?'<div class="dpgroup">Anticipated 2027 to 2028</div>'+est.map(row).join(''):'')+'</div><div class="dpnote">Dates from College Board. Always confirm on satsuite.collegeboard.org before you register.</div><div class="acts"><button class="btn ghost" id="dpCancel">Cancel</button><button class="btn pri" id="dpSave">Save date</button></div>');
 m.querySelector('#dpCancel').onclick=()=>m.remove();
 m.querySelectorAll('.dprow').forEach(b=>b.onclick=()=>{sel=b.dataset.d;m.querySelectorAll('.dprow').forEach(x=>{const on=x===b;x.classList.toggle('on',on);x.setAttribute('aria-checked',on);});});
 m.querySelector('#dpSave').onclick=()=>{state.profile.testDate=sel;saveState();m.remove();animateDash();toast('Test date updated','ph-calendar-check');};
 const cur=m.querySelector('.dprow.on');if(cur)setTimeout(()=>cur.scrollIntoView({block:'center'}),30);
}
document.addEventListener('click',e=>{if(e.target.closest('#cdChange'))openDatePicker();});


/* ===== math typesetting: stacked fractions, radicals, exponents, serif italic variables, display equations ===== */
(function(){
 const SUPM={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','ⁿ':'n','ᵗ':'t','ˣ':'x','⁻':'−','⁺':'+','ʸ':'y','ᵃ':'a','ᵇ':'b','ᵏ':'k','ⁱ':'i','ᵐ':'m','ᵖ':'p','ʳ':'r','ˢ':'s'};
 const SUPRE=/[⁰¹²³⁴⁵⁶⁷⁸⁹ⁿᵗˣ⁻⁺ʸᵃᵇᵏⁱᵐᵖʳˢ]+/g;
 const WL=new Set(['ax','bx','cx','kx','mx','px','qx','xy','ab']);
 const VO='\u0004',VC='\u0005',SO='\u0001',SC='\u0002',CG='\u0003';
 function mark(s){
  const p=s.split(/([A-Za-z]+)/);
  for(let i=1;i<p.length;i+=2){
   const w=p[i];let v=false;
   if(w.length===1){
    v=true;const after=p[i+1]||'',nx=p[i+2]||'';
    if(w==='I')v=false;
    else if((w==='a'||w==='A')&&after===' '&&nx.length>=3&&/^[a-z]/.test(nx)&&!/^(and|or|are|is|where|for)$/.test(nx))v=false;
    else if((w==='a'||w==='A')&&/^ [\d$]/.test(after)&&/^[a-z]{3,}/.test(nx))v=false;   /* "after a 20% discount": article, not a variable */
    if(after==='.'&&/^[a-z]$/.test(nx))v=false;
   }else if(w.length===2&&WL.has(w))v=true;
   if(v)p[i]=VO+w+VC;
  }
  return p.join('');
 }
 function grp(s,i){let d=0;for(let j=i;j<s.length;j++){const c=s[j];if(c==='(')d++;else if(c===')'){d--;if(!d)return j;}}return -1;}
 const WRE=/^[A-Za-z0-9\u0004\u0005]+(?:[.,][0-9]+)*/;
 function toks(s){
  const o=[];let i=0;
  while(i<s.length){
   const c=s[i];
   if(c==='('){const j=grp(s,i);if(j>0){o.push({t:'g',v:s.slice(i+1,j)});i=j+1;continue;}}
   if(c===SO){const j=s.indexOf(SC,i);if(j>0){o.push({t:'s',v:s.slice(i+1,j)});i=j+1;continue;}}
   if(c===CG&&s[i+1]==='('){const j=grp(s,i+1);if(j>0){o.push({t:'s',v:s.slice(i+2,j)});i=j+1;continue;}}
   if(c==='√'){
    if(s[i+1]==='('){const j=grp(s,i+1);if(j>0){o.push({t:'r',v:s.slice(i+2,j)});i=j+1;continue;}}
    const m=WRE.exec(s.slice(i+1));
    if(m){o.push({t:'r',v:m[0]});i+=1+m[0].length;continue;}
   }
   if(c==='/'){o.push({t:'/'});i++;continue;}
   const m=WRE.exec(s.slice(i));
   if(m){o.push({t:'w',v:m[0]});i+=m[0].length;continue;}
   const l=o[o.length-1];
   if(l&&l.t==='x')l.v+=c;else o.push({t:'x',v:c});
   i++;
  }
  return o;
 }
 const leaf=t=>esc(t).split(VO).join('<i class="v">').split(VC).join('</i>');
 const isC=t=>t&&(t.t==='w'||t.t==='g'||t.t==='s'||t.t==='r');
 function one(t){
  if(t.t==='w'||t.t==='x')return leaf(t.v);
  if(t.t==='g')return '<span class="pa">(</span>'+ts(t.v)+'<span class="pa">)</span>';
  if(t.t==='s')return '<sup class="ex">'+ts(t.v)+'</sup>';
  if(t.t==='r')return '<span class="rad"><span class="rs">√</span><span class="rb">'+ts(t.v)+'</span></span>';
  return '<span class="sl">/</span>';
 }
 function mathy(c){
  if(c.length===1&&c[0].t==='w'){
   const w=c[0].v.replace(/[\u0004\u0005]/g,'');
   if(/^[A-Za-z]{2,}$/.test(w)&&!WL.has(w))return false;
   if(/[A-Za-z]{3,}/.test(w))return false;
  }
  return true;
 }
 function side(c){return c.length===1&&c[0].t==='g'?ts(c[0].v):c.map(one).join('');}
 function ts(s){
  const tk=toks(s),o=[];let i=0;
  while(i<tk.length){
   if(isC(tk[i])){
    let j=i;while(j<tk.length&&isC(tk[j]))j++;
    const n=tk.slice(i,j);
    if(tk[j]&&tk[j].t==='/'&&isC(tk[j+1])){
     let k=j+1;while(k<tk.length&&isC(tk[k]))k++;
     const d=tk.slice(j+1,k);
     if(mathy(n)&&mathy(d)){o.push('<span class="fr"><span class="n">'+side(n)+'</span><span class="d">'+side(d)+'</span></span>');i=k;continue;}
    }
    o.push(n.map(one).join(''));i=j;continue;
   }
   o.push(one(tk[i]));i++;
  }
  return o.join('');
 }
 function mx(src){
  let s=String(src).replace(SUPRE,m=>SO+[...m].map(c=>SUPM[c]).join('')+SC);
  s=s.replace(/\^\(/g,CG+'(').replace(/\^([A-Za-z0-9−+-]+)/g,(m,a)=>SO+a+SC);
  s=s.replace(/ ([=≠≤≥<>]) /g,'\u00A0$1\u00A0');
  return ts(mark(s)).replace(/(<\/span>|<\/sup>)([?.,;:!])/g,'$1\u2060$2');
 }
 const isEq=l=>{const t=l.trim();return t.length>2&&t.length<=70&&/[=≠<>≤≥]/.test(t)&&!/[A-Za-z]{4,}/.test(t)&&!/[?:.]$/.test(t);};
 function mxq(src){
  const parts=[];let cur=null;
  for(const l of String(src).split('\n')){
   if(isEq(l)){if(!cur||!cur.eq){cur={eq:true,l:[]};parts.push(cur);}cur.l.push(l.trim());continue;}
   if(!l.trim()&&cur&&cur.eq){cur=null;continue;}
   if(!cur||cur.eq){cur={eq:false,l:[]};parts.push(cur);}
   cur.l.push(l);
  }
  return parts.map(p=>p.eq?'<span class="eqn">'+p.l.map(x=>'<span>'+mx(x)+'</span>').join('')+'</span>':mx(p.l.join('\n').replace(/^\n+|\n+$/g,''))).join('');
 }
 window.mx=mx;window.mxq=mxq;
})();

/* ===== v5: question bank workspace ===== */
BK.view = 'list';

