const TAGS=[['careless','Careless slip','ph-warning'],['concept','Concept gap','ph-brain'],['time','Ran out of time','ph-timer'],['misread','Misread it','ph-eye'],['guess','Bad guess','ph-dice-five']];
const DOMS={math_algebra:'Algebra',math_adv:'Advanced Math',rw_craft:'Craft and Structure',rw_info:'Information and Ideas',rw_conv:'Standard English Conventions'};
const keyOf=q=>q.id||q.q;
const E=()=>{const e=state.ext=state.ext||{};e.log=e.log||[];e.tags=e.tags||{};e.tagTs=e.tagTs||{};e.seen=e.seen||{};e.bmk=e.bmk||{};e.goal=e.goal||10;if(e.freeze==null)e.freeze=1;e.xp=e.xp||0;e.badges=e.badges||{};e.tl=e.tl||'auto';return e;};
const weekTs=()=>new Date(monday()+'T00:00:00').getTime();
const todayN=()=>E().log.filter(l=>ymd(l.ts)===ymd(Date.now())).length;

/* Map QB questions into accurate BANK domain buckets */
(function(){
  QB.forEach(o=>{
    let t = 'rw_info';
    const d = (o.dom || '').toLowerCase();
    if(o.sec==='m'){
      t = (d.includes('algebra') || d.includes('problem')) ? 'math_algebra' : 'math_adv';
    } else {
      t = d.includes('craft') || d.includes('expression') ? 'rw_craft' : d.includes('standard') || d.includes('convention') ? 'rw_conv' : 'rw_info';
    }
    const q={id:o.id,skill:o.skill,dom:o.dom,diff:o.diff};
    q.q=o.q;q.passage=o.passage||undefined;q.why=o.why;if(o.fig)q.fig=true;
    if(o.spr){q.spr=true;q.ans=o.ans;}else{q.opts=o.opts;q.a=o.a;}
    BANK[t].push(q);
  });
})();

function allQ(){
  const out=[];
  for(const t in BANK){
    BANK[t].forEach(q=>out.push({
      q:Object.assign({_topic:t},q),
      t,
      sec:TOPICS[t].sec==='m'?'m':'rw',
      dom:q.dom||DOMS[t],
      skill:q.skill||'General '+DOMS[t].toLowerCase(),
      diff:q.diff
    }));
  }
  return out;
}

function startList(items,o={}){
  if(!items.length){toast('No questions match','ph-funnel');return;}
  const k=items.every(i=>i.sec==='m')?'m':items.every(i=>i.sec==='rw')?'rw':'mixed';
  const mins=o.timed?Math.ceil(items.reduce((s,i)=>s+(i.sec==='m'?95:71),0)/60):null;
  if(o.timed)E().timed=(E().timed||0)+1;
  launch({mode:'practice',topic:'bank',title:(o.timed?'Timed drill':'Practice')+': Question bank',mods:[newMod(o.timed?'Timed drill':'Practice',k,items.map(i=>i.q),mins,o.timed?'Timed drill':'Practice')]});
}

/* ---- exam hooks: images, timing, error-log chips ---- */
let qT0=Date.now();
function figHTML(t){const out=[];let tb=[];const fl=()=>{if(tb.length){out.push('<table class="dtab"><thead><tr>'+tb[0].map(c=>'<th>'+esc(c)+'</th>').join('')+'</tr></thead><tbody>'+tb.slice(1).map(r=>'<tr>'+r.map(c=>'<td>'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table>');tb=[];}};
 t.split('\n').forEach(l=>{if(l.indexOf(' | ')>-1)tb.push(l.split(' | ').map(x=>x.trim()));else{fl();out.push(esc(l));}});fl();
 return out.join('\n').replace(/\n+(<table)/g,'\n$1').replace(/(<\/table>)\n+/g,'$1\n');}
const _rq=renderQuestion;renderQuestion=function(){_rq();qT0=Date.now();const q=cur().qs[X.qi];if(q.fig&&q.passage&&!cur().hl[X.qi]){const p=$('#xPassage');if(p)p.innerHTML=figHTML(q.passage);}if(q.img){const el=$('#xbody .pane.left .stem')||$('#xbody .stem');if(el){el.classList.remove('serif');el.innerHTML='<img class="qimg" src="'+q.img+'" alt="Official question">';}$('#xbody').classList.add('imgq');}};
const _ra=recordAttempt;recordAttempt=function(tp,ok,q,ch){_ra(tp,ok,q,ch);if(!q)return;const e=E();e.log.push({k:keyOf(q),tp,sk:q.skill||'',d:q.diff,ok:ok?1:0,t:Math.min(300,Math.round((Date.now()-qT0)/1000)),ts:Date.now()});if(e.log.length>800)e.log.shift();e.seen[keyOf(q)]=ok?'ok':'miss';e.xp+=ok?10:3;checkBadges();};
function tagChips(q,cb){const t=E().tags[keyOf(q)];return '<div class="why-tags"><span>Why did you miss it?</span>'+TAGS.map(g=>'<button class="tagchip'+(t===g[0]?' on':'')+'" data-t="'+g[0]+'" data-cb="'+cb+'"><i class="ph '+g[2]+'"></i>'+g[1]+'</button>').join('')+'</div>';}
const _pe=paintExplain;paintExplain=function(){_pe();if(!X||X.phase!=='q')return;const m=cur(),q=m.qs[X.qi],i=X.qi,ex=$('#xExp .explain');if(!ex||!(X.mode==='practice'&&m.checked[i]))return;
 if(q.whyImg)ex.insertAdjacentHTML('beforeend',q.whyImg.map(s=>'<img class="qimg why" src="'+s+'" alt="Rationale">').join(''));
 if(!isCorrect(q,m.ans[i]))ex.insertAdjacentHTML('beforeend',tagChips(q,'x'));};
document.addEventListener('click',e=>{const b=e.target.closest('.tagchip');if(!b)return;const em=E(),t=b.dataset.t;let q;
 if(b.dataset.cb==='x'){q=cur().qs[X.qi];}else{q=state.missed[+b.dataset.i].q;}
 em.tags[keyOf(q)]=t;em.tagTs[keyOf(q)]=Date.now();checkBadges();
 if(b.dataset.cb==='x'){b.parentNode.querySelectorAll('.tagchip').forEach(c=>c.classList.toggle('on',c===b));const msg={careless:'Slow down on the last read. You knew this one.',concept:'Noted. I will queue this skill in your plan.',time:'Try a timed drill. Pacing is a skill too.',misread:'Underline the question word next time.',guess:'Eliminate two choices before you guess.'}[t];coachSay(t==='concept'||t==='time'?'m_headache':'m_think',msg);}
 else renderReview();});
const _rr=renderReview;renderReview=function(){_rr();const list=$('#reviewList');if(!state.missed.length)return;const e=E(),cnt={};
 state.missed.forEach(m=>{const t=e.tags[keyOf(m.q)]||'';if(t)cnt[t]=(cnt[t]||0)+1;});const tot=Object.values(cnt).reduce((a,b)=>a+b,0),top=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0];
 const tip={careless:'Most of your misses are slips, not gaps. Re-read the question before you lock in.',concept:'Most misses are concept gaps. Open the lesson for that skill, then re-try.',time:'Time is costing you. Use a timed drill from the Question bank.',misread:'You are misreading prompts. Underline what is being asked.',guess:'Guessing is costing points. Cross out two choices first.'};
 let h='<div class="card errlog"><div class="row" style="justify-content:space-between"><b>Error log</b><span class="tag acc">'+tot+' of '+state.missed.length+' tagged</span></div>'+TAGS.map(g=>{const n=cnt[g[0]]||0;return '<div class="erow"><span><i class="ph '+g[2]+'"></i> '+g[1]+'</span><div class="ebar"><b style="width:'+(tot?n/tot*100:0)+'%"></b></div><span>'+n+'</span></div>';}).join('')+'<div class="einsight">'+(top?tip[top[0]]:'Tag each miss below with a reason. After a few, I will tell you what is really costing you points.')+'</div></div>';
 list.insertAdjacentHTML('afterbegin',h);
 list.querySelectorAll('.reviewitem').forEach((d,i)=>{const m=state.missed[i];if(!m)return;const q=m.q,t=e.tags[keyOf(q)];
  if(q.img){const s=d.querySelector('.stem');if(s)s.innerHTML='<img class="qimg" src="'+q.img+'" alt="">';}
  const b=d.querySelector('.rv-body');if(b)b.insertAdjacentHTML('beforeend','<div class="rvtags">'+TAGS.map(g=>'<button class="tagchip'+(t===g[0]?' on':'')+'" data-t="'+g[0]+'" data-cb="r" data-i="'+i+'"><i class="ph '+g[2]+'"></i>'+g[1]+'</button>').join('')+'</div>');});};

/* ---- QUESTION BANK: persistent shell, in-place updates (qb-*) ----
   The toolbar and the two panes are built ONCE. Filters, selection and answers then change
   classes / text in place, so toggles glide and nothing flashes. Only a real content change
   (new filter result, new question) cross-fades, via Motion.swap / Motion.rise. */
const BK = { s: 'm', d: new Set(), dom: '', skill: '', type: '', st: '', q: '', sel: 0, picked: null, checked: false };
let BKI = [];
let bkBuilt = false;
const bkMotion = fn => window.Motion ? fn(window.Motion) : null;

function bkStats(){
  const all = typeof allQ === 'function' ? allQ() : [];
  const e = typeof E === 'function' ? E() : { seen: {}, bmk: {} };
  let ok = 0, miss = 0, saved = 0;
  all.forEach(i => { const k = keyOf(i.q), s = e.seen && e.seen[k]; if (s === 'ok') ok++; else if (s === 'miss') miss++; if (e.bmk && e.bmk[k]) saved++; });
  return { all, ok, miss, saved, m: all.filter(i => i.sec === 'm').length, rw: all.filter(i => i.sec === 'rw').length };
}

function bkBuild(){
  const host = $('#bkF'); if (!host) return;
  host.innerHTML = `
    <header class="qb-head">
      <div class="qb-title"><h1>Question bank</h1><p>Search, filter and solve any question right here, then read the full rationale.</p></div>
      <dl class="qb-stats">
        <div><dt>Solved</dt><dd id="qbSolved">0</dd></div>
        <div><dt>Missed</dt><dd id="qbMissed">0</dd></div>
        <div><dt>Saved</dt><dd id="qbSaved">0</dd></div>
      </dl>
    </header>
    <div class="qb-toolbar">
      <div class="qb-row">
        <div class="qb-seg lg" data-seg="solid" role="group" aria-label="Section">
          <button type="button" data-bks="m"><i class="ph-bold ph-function"></i>Math<small id="qbCm"></small></button>
          <button type="button" data-bks="rw"><i class="ph-bold ph-book-open-text"></i>Reading &amp; Writing<small id="qbCrw"></small></button>
        </div>
        <label class="qb-search">
          <i class="ph ph-magnifying-glass"></i>
          <input type="search" id="bkSearchInp" placeholder="Search a skill, keyword or question ID" autocomplete="off" spellcheck="false">
          <button type="button" id="bkSearchClear" class="qb-clear" aria-label="Clear search" hidden><i class="ph-fill ph-x-circle"></i></button>
        </label>
      </div>
      <div class="qb-row qb-filters">
        <div class="qb-f"><span>Domain</span><select id="bkDomSel" aria-label="Domain"></select></div>
        <div class="qb-f"><span>Difficulty</span>
          <div class="qb-chips" role="group" aria-label="Difficulty">
            <button type="button" class="qb-chip" data-bk-diff="all">All</button>
            ${['Easy', 'Medium', 'Hard'].map(d => `<button type="button" class="qb-chip" data-bk-diff="${d}">${d}</button>`).join('')}
          </div>
        </div>
        <div class="qb-f"><span>Status</span>
          <div class="qb-seg" data-seg role="group" aria-label="Status">
            <button type="button" data-bk-st="">All</button>
            <button type="button" data-bk-st="new">Unseen</button>
            <button type="button" data-bk-st="miss">Missed</button>
            <button type="button" data-bk-st="ok">Solved</button>
            <button type="button" data-bk-st="bmk">Saved</button>
          </div>
        </div>
        <div class="qb-end"><b id="bkCount"></b><button type="button" class="btn sm ghost" id="bkResetFilters" hidden><i class="ph ph-arrow-counter-clockwise"></i>Reset</button></div>
      </div>
    </div>`;
  const ws = $('#bkWorkspace');
  if (ws && !$('#qbIns')) $('#bkSide').innerHTML = '<div class="qb-ins" id="qbIns"></div>';

  /* one delegated listener per host (never re-bound) */
  host.addEventListener('click', e => {
    const sec = e.target.closest('[data-bks]');
    if (sec) { if (sec.dataset.bks !== BK.s) { BK.s = sec.dataset.bks; BK.dom = ''; BK.skill = ''; BK.type = ''; bkReset(); bkSync(); bkFilter(true); } return; }
    const df = e.target.closest('[data-bk-diff]');
    if (df) { const d = df.dataset.bkDiff; if (d === 'all') BK.d.clear(); else BK.d.has(d) ? BK.d.delete(d) : BK.d.add(d); bkReset(); bkSync(); bkFilter(true); return; }
    const st = e.target.closest('[data-bk-st]');
    if (st) { BK.st = st.dataset.bkSt; bkReset(); bkSync(); bkFilter(true); return; }
    if (e.target.closest('#bkSearchClear')) { BK.q = ''; $('#bkSearchInp').value = ''; bkReset(); bkSync(); bkFilter(true); $('#bkSearchInp').focus(); return; }
    if (e.target.closest('#bkResetFilters')) { BK.q = ''; BK.dom = ''; BK.d.clear(); BK.st = ''; $('#bkSearchInp').value = ''; bkReset(); bkSync(); bkFilter(true); }
  });
  let t = 0;
  $('#bkSearchInp').addEventListener('input', e => {
    BK.q = e.target.value; bkReset(); bkSync();
    clearTimeout(t); t = setTimeout(() => bkFilter(false), 140);
  });
  $('#bkDomSel').addEventListener('change', e => { BK.dom = e.target.value; bkReset(); bkSync(); bkFilter(true); });

  $('#bkList').addEventListener('click', e => { const row = e.target.closest('.qb-item'); if (row) bkSelect(+row.dataset.n); });
  bkBuilt = true;
}
function bkReset(){ BK.sel = 0; BK.picked = null; BK.checked = false; }

/* controls, counts and button states follow BK (no re-render) */
function bkSync(){
  const s = bkStats(), host = $('#bkF'); if (!host) return;
  const secItems = s.all.filter(i => i.sec === BK.s);
  const doms = [...new Set(secItems.map(i => i.dom).filter(Boolean))].sort();
  const set = (id, v) => { const el = $(id); if (el && el.textContent !== String(v)) { el.textContent = v; bkMotion(M => M.tick(el.closest('div') || el)); } };
  set('#qbSolved', s.ok); set('#qbMissed', s.miss); set('#qbSaved', s.saved);
  $('#qbCm').textContent = s.m; $('#qbCrw').textContent = s.rw;
  host.querySelectorAll('[data-bks]').forEach(b => b.classList.toggle('on', b.dataset.bks === BK.s));
  host.querySelectorAll('[data-bk-diff]').forEach(b => { const d = b.dataset.bkDiff; b.classList.toggle('on', d === 'all' ? BK.d.size === 0 : BK.d.has(d)); });
  host.querySelectorAll('[data-bk-st]').forEach(b => b.classList.toggle('on', b.dataset.bkSt === BK.st));
  const sel = $('#bkDomSel');
  if (sel && sel.dataset.sec !== BK.s) {
    sel.dataset.sec = BK.s;
    sel.innerHTML = `<option value="">All domains (${doms.length})</option>` + doms.map(d => `<option value="${esc(d)}">${esc(d)}</option>`).join('');
  }
  if (sel) sel.value = BK.dom;
  const hasQ = !!BK.q;
  $('#bkSearchClear').hidden = !hasQ;
  $('#bkResetFilters').hidden = !(BK.q || BK.dom || BK.d.size || BK.st);
}

/* recompute the matching list, repaint rows, then the inspector */
function bkFilter(animate){
  const all = typeof allQ === 'function' ? allQ() : [];
  const e = typeof E === 'function' ? E() : { seen: {}, bmk: {} };
  const qStr = (BK.q || '').trim().toLowerCase();
  BKI = all.filter(i => {
    if (i.sec !== BK.s) return false;
    if (BK.d.size && !BK.d.has(i.diff)) return false;
    if (BK.dom && i.dom !== BK.dom) return false;
    if (BK.skill && i.skill !== BK.skill) return false;
    if (BK.st) {
      const k = keyOf(i.q), st = e.seen && e.seen[k];
      if (BK.st === 'new' && st) return false;
      if (BK.st === 'miss' && st !== 'miss') return false;
      if (BK.st === 'ok' && st !== 'ok') return false;
      if (BK.st === 'bmk' && !(e.bmk && e.bmk[k])) return false;
    }
    if (qStr) {
      const hay = ((i.q.id || '') + ' ' + (i.skill || '') + ' ' + (i.dom || '') + ' ' + (i.q.q || '') + ' ' + (i.q.passage || '')).toLowerCase();
      if (!hay.includes(qStr)) return false;
    }
    return true;
  });
  BKI.sort((a, b) => (a.q.id ? 0 : 1) - (b.q.id ? 0 : 1));
  if (BK.sel >= BKI.length) BK.sel = Math.max(0, BKI.length - 1);

  const cnt = $('#bkCount'), txt = BKI.length + ' question' + (BKI.length === 1 ? '' : 's');
  if (cnt && cnt.textContent !== txt) { cnt.textContent = txt; if (animate) bkMotion(M => M.tick(cnt)); }

  const paint = () => { bkPaintList(); const l = $('#bkList'); if (l) l.scrollTop = 0; };
  if (animate) { bkMotion(M => M.swap($('#bkList'), paint)) || paint(); } else paint();
  bkPaintSide(animate);
}

function bkRow(it, n, e){
  const q = it.q, k = keyOf(q), s = e.seen && e.seen[k], bm = e.bmk && e.bmk[k];
  const snippet = (q.q || '').replace(/<[^>]*>/g, '').trim();
  return `
    <button type="button" class="qb-item${n === BK.sel ? ' on' : ''}" data-n="${n}" aria-current="${n === BK.sel}">
      <span class="qb-n">${n + 1}</span>
      <span class="qb-mid">
        <span class="qb-skill">${esc(it.skill)}</span>
        <span class="qb-sub">${esc(it.dom)}${snippet ? '<span class="qb-snip">' + esc(snippet.slice(0, 70)) + (snippet.length > 70 ? '…' : '') + '</span>' : ''}</span>
      </span>
      <span class="qb-meta">
        <span class="diff d${diffRank(it.diff)}"><i></i><i></i><i></i></span>
        <span class="qb-st ${s === 'ok' ? 'ok' : s === 'miss' ? 'miss' : 'none'}">${bm ? '<i class="ph-fill ph-bookmark-simple"></i>' : ''}${s === 'ok' ? 'Solved' : s === 'miss' ? 'Missed' : 'Unseen'}</span>
      </span>
    </button>`;
}
function bkPaintList(){
  const e = typeof E === 'function' ? E() : { seen: {}, bmk: {} };
  const el = $('#bkList'); if (!el) return;
  el.innerHTML = BKI.length ? BKI.map((it, n) => bkRow(it, n, e)).join('') : `
    <div class="qb-empty">
      <i class="ph ph-magnifying-glass"></i>
      <h3>No questions match</h3>
      <p>Try a shorter search, or clear a filter.</p>
      <button type="button" class="btn sm acc" id="bkEmptyReset">Reset filters</button>
    </div>`;
  const rb = $('#bkEmptyReset'); if (rb) rb.onclick = () => $('#bkResetFilters').click();
}
/* one row's status changed (answer / bookmark): patch it, do not repaint the list */
function bkPatchRow(n){
  const it = BKI[n], row = $('#bkList .qb-item[data-n="' + n + '"]'); if (!it || !row) return;
  const e = typeof E === 'function' ? E() : { seen: {}, bmk: {} };
  const tmp = document.createElement('div'); tmp.innerHTML = bkRow(it, n, e);
  const next = tmp.firstElementChild.querySelector('.qb-st'), cur = row.querySelector('.qb-st');
  if (cur && next) { cur.className = next.className; cur.innerHTML = next.innerHTML; bkMotion(M => M.tick(cur)); }
}

function bkSelect(n){
  if (n === BK.sel && BKI[n]) return;
  BK.sel = n; BK.picked = null; BK.checked = false;
  document.querySelectorAll('#bkList .qb-item').forEach(r => { const on = +r.dataset.n === n; r.classList.toggle('on', on); r.setAttribute('aria-current', on); });
  const row = $('#bkList .qb-item[data-n="' + n + '"]'); if (row) row.scrollIntoView({ block: 'nearest', behavior: window.Motion && !Motion.reduced ? 'smooth' : 'auto' });
  bkPaintSide(true);
  if (innerWidth < 980) $('#bkSide').scrollIntoView({ block: 'start', behavior: 'smooth' });
}

/* ---------------- inspector ---------------- */
function bkExpHTML(it){
  const q = it.q, ok = isCorrect(q, BK.picked);
  const why = it.sec === 'm' && typeof mx === 'function' ? mx(q.why || '') : esc(q.why || '');
  return `<div class="qb-exp-in"><div class="qb-exp-h"><i class="ph-fill ${ok ? 'ph-check-circle' : 'ph-info'}" style="color:${ok ? 'var(--good)' : 'var(--warn)'}"></i><b>${ok ? 'Correct' : 'Solution and rationale'}${q.spr ? ' (answer: ' + esc(q.ans[0]) + ')' : ''}</b></div><div class="qb-exp-b">${why}</div></div>`;
}
function bkInsHTML(it){
  const q = it.q, e = typeof E === 'function' ? E() : { seen: {}, bmk: {} };
  const k = keyOf(q), bm = !!(e.bmk && e.bmk[k]);
  const passage = q.passage ? `<div class="qb-passage">${q.fig ? (typeof figHTML === 'function' ? figHTML(q.passage) : esc(q.passage)) : esc(q.passage)}</div>` : '';
  const stem = it.sec === 'm' && typeof mx === 'function' ? mx(q.q) : esc(q.q);
  let inter = '';
  if (q.spr) {
    inter = `<div class="qb-spr"><label for="bkSprInp">Student-produced response</label><div><input type="text" id="bkSprInp" class="mono" placeholder="Type your answer, e.g. 7/4 or 1.75" autocomplete="off"><button type="button" class="btn sm acc" id="bkCheckBtn"><i class="ph ph-check"></i>Check</button></div></div>`;
  } else if (Array.isArray(q.opts)) {
    const L = ['A', 'B', 'C', 'D'];
    inter = '<div class="qb-opts">' + q.opts.map((o, idx) => `<button type="button" class="qb-opt" data-bk-opt="${idx}"><span class="k">${L[idx]}</span><span class="t">${it.sec === 'm' && typeof mx === 'function' ? mx(o) : esc(o)}</span></button>`).join('') + '</div>';
  }
  return `
    <div class="qb-ins-top">
      <div>
        <div class="qb-tags"><span class="tag acc">${esc(it.dom)}</span><span class="diff d${diffRank(it.diff)}"><i></i><i></i><i></i>&nbsp;${esc(it.diff)}</span>${q.id ? `<span class="tag mono">#${esc(q.id)}</span>` : ''}</div>
        <h3>${esc(it.skill)}</h3>
      </div>
      <button type="button" class="qb-bmk${bm ? ' on' : ''}" id="bkBmkBtn" aria-pressed="${bm}" title="${bm ? 'Remove from saved' : 'Save question'}"><i class="ph${bm ? '-fill' : ''} ph-bookmark-simple"></i></button>
    </div>
    <div class="qb-stem">
      ${passage}
      ${q.img ? `<img src="${q.img}" alt="Question diagram" class="qb-img">` : ''}
      <div class="qb-q">${stem}</div>
    </div>
    ${inter}
    <div class="qb-exp" id="qbExp" data-open="0"><div></div></div>
    <div class="qb-foot">
      <div class="qb-nav"><button type="button" class="btn sm ghost" id="bkPrevBtn" aria-label="Previous question"><i class="ph ph-arrow-left"></i>Prev</button><button type="button" class="btn sm ghost" id="bkNextBtn" aria-label="Next question">Next<i class="ph ph-arrow-right"></i></button></div>
      <div class="qb-act"><button type="button" class="btn sm ghost" id="bkRevealBtn"><i class="ph ph-eye"></i><span>Rationale</span></button><button type="button" class="btn sm acc" id="bkOpenBluebook"><i class="ph ph-play"></i>Bluebook drill</button></div>
    </div>`;
}

function bkPaintSide(animate){
  const ins = $('#qbIns'); if (!ins) return;
  const it = BKI[BK.sel];
  const paint = () => {
    if (!it) { ins.innerHTML = `<div class="qb-ins-empty"><i class="ph ph-notebook"></i><p>Pick a question from the list to solve it here and read the full explanation.</p></div>`; return; }
    ins.innerHTML = bkInsHTML(it);
    bkWireIns(it);
    bkUpdateIns(it);
  };
  if (animate) { bkMotion(M => M.swap(ins, paint)) || paint(); } else paint();
}

/* reflect picked / checked in the already-rendered inspector, with CSS transitions only */
function bkUpdateIns(it){
  const q = it.q, ins = $('#qbIns'); if (!ins) return;
  ins.querySelectorAll('[data-bk-opt]').forEach(b => {
    const idx = +b.dataset.bkOpt;
    b.classList.toggle('correct', BK.checked && idx === q.a);
    b.classList.toggle('wrong', BK.checked && BK.picked === idx && idx !== q.a);
    b.classList.toggle('on', !BK.checked && BK.picked === idx);
    b.disabled = !!BK.checked;
  });
  const inp = $('#bkSprInp', ins); if (inp) { if (BK.picked != null && inp.value !== BK.picked) inp.value = BK.picked; inp.disabled = !!BK.checked; }
  const chk = $('#bkCheckBtn', ins); if (chk) chk.disabled = !!BK.checked;
  const exp = $('#qbExp', ins);
  if (exp) { if (BK.checked) exp.firstElementChild.innerHTML = bkExpHTML(it); exp.dataset.open = BK.checked ? '1' : '0'; }
  const rv = $('#bkRevealBtn', ins); if (rv) { rv.querySelector('i').className = 'ph ph-' + (BK.checked ? 'eye-slash' : 'eye'); rv.querySelector('span').textContent = BK.checked ? 'Hide' : 'Rationale'; }
  const pv = $('#bkPrevBtn', ins), nx = $('#bkNextBtn', ins);
  if (pv) pv.disabled = BK.sel <= 0; if (nx) nx.disabled = BK.sel >= BKI.length - 1;
}
function bkAnswer(it, picked){
  const q = it.q;
  BK.picked = picked; BK.checked = true;
  if (typeof recordAttempt === 'function') recordAttempt(it.t, q.spr ? isCorrect(q, picked) : picked === q.a, q, picked);
  bkUpdateIns(it); bkPatchRow(BK.sel); bkSync();
}
function bkWireIns(it){
  const ins = $('#qbIns'), q = it.q, e = typeof E === 'function' ? E() : { seen: {}, bmk: {} }, k = keyOf(q);
  ins.querySelectorAll('[data-bk-opt]').forEach(b => b.onclick = () => { if (!BK.checked) bkAnswer(it, +b.dataset.bkOpt); });
  const chk = $('#bkCheckBtn', ins), inp = $('#bkSprInp', ins);
  if (chk) { const go = () => { if (!BK.checked && inp) bkAnswer(it, inp.value.trim()); }; chk.onclick = go; inp.onkeydown = ev => { if (ev.key === 'Enter') go(); }; }
  $('#bkRevealBtn', ins).onclick = () => { BK.checked = !BK.checked; if (!BK.checked) BK.picked = null; bkUpdateIns(it); };
  $('#bkBmkBtn', ins).onclick = ev => {
    e.bmk = e.bmk || {}; if (e.bmk[k]) delete e.bmk[k]; else e.bmk[k] = 1;
    if (typeof saveState === 'function') saveState();
    const b = ev.currentTarget, on = !!e.bmk[k];
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.querySelector('i').className = 'ph' + (on ? '-fill' : '') + ' ph-bookmark-simple';
    bkPatchRow(BK.sel); bkSync();
    if (BK.st === 'bmk' && !on) bkFilter(true);
  };
  $('#bkOpenBluebook', ins).onclick = () => { if (typeof startList === 'function') startList([it]); };
  $('#bkPrevBtn', ins).onclick = () => { if (BK.sel > 0) bkSelect(BK.sel - 1); };
  $('#bkNextBtn', ins).onclick = () => { if (BK.sel < BKI.length - 1) bkSelect(BK.sel + 1); };
}

function renderBank(){
  if (!$('#bkF')) return;
  if (!bkBuilt) bkBuild();
  bkSync();
  bkFilter(false);
}

/* ---- diagnostic + plan ---- */
function startDiagnostic(){const qs=[];Object.keys(TOPICS).forEach(k=>qs.push(...shuffle(tagTopics([k])).slice(0,4)));launch({mode:'practice',topic:'diag',title:'Diagnostic',diag:true,mods:[newMod('Diagnostic','mixed',shuffle(qs),null,'Diagnostic')]});}
const _fp=finishPractice;finishPractice=function(){if(X&&X.diag){const m=X.mods[0],by={};let c=0;m.qs.forEach((q,i)=>{const ok=isCorrect(q,m.ans[i]),b=by[q._topic]=by[q._topic]||{n:0,c:0};b.n++;if(ok){b.c++;c++;}});E().diag={ts:Date.now(),by,pct:Math.round(c/m.qs.length*100)};toast('Diagnostic saved. Your study plan is ready.','ph-map-trifold');}
 if(X&&X.mods[0].qs.length>=8&&X.mods[0].qs.every((q,i)=>isCorrect(q,X.mods[0].ans[i])))E().perfect=1;_fp();checkBadges();};
function ranked(){const e=E();return Object.keys(TOPICS).map(k=>{const d=(e.diag&&e.diag.by[k])||null,s=state.byTopic[k]||{attempts:0,correct:0},n=d?d.n:s.attempts,c=d?d.c:s.correct,acc=n?c/n:.5,per=TOPICS[k].sec==='m'?2:3;return{k,acc,n,pts:Math.max(0,Math.round((.85-acc)*600/per/10)*10)};}).sort((a,b)=>b.pts-a.pts);}
const TL=[['auto','Until test day'],['6m','6 months'],['3m','3 months'],['1m','1 month'],['1w','1 week']];
function planWeeks(){const t=E().tl,n=t==='auto'?Math.max(1,Math.min(26,Math.ceil(daysLeft()/7))):{'6m':26,'3m':13,'1m':4,'1w':1}[t],r=ranked(),out=[];
 for(let w=0;w<n;w++){const p=n<=1?.5:w/n,ph=n<=1?'Sprint':p<.4?'Foundations':p<.8?'Drill and pace':'Test simulation',a=r[w%r.length].k,b=r[(w+1)%r.length].k,last=(w+1)%4===0||w===n-1;
  out.push({w:w+1,ph,a,b,last,min:t==='1w'?90:45,days:[['Mon','Drill '+TOPICS[a].short+', 10 questions'],['Tue',ph==='Foundations'?'Lesson, then 8 questions on '+TOPICS[b].short:'Timed drill, 10 questions on '+TOPICS[b].short],['Wed','Retry your missed questions'],['Thu','Mixed set, 10 questions'],['Fri',last?'Full practice test':'Drill '+TOPICS[a].short+' again, then tag errors'],['Sat','Review the error log, 15 min']]});}
 return out;}
function renderPlan(){const e=E(),r=ranked(),W=planWeeks(),dg=e.diag;
 $('#planBody').innerHTML='<div class="grid g2"><div class="cta-card"><span class="tag '+(dg?'good':'warn')+'">'+(dg?'Diagnostic done':'Start here')+'</span><h3>'+(dg?'Last diagnostic: '+dg.pct+'% correct':'Find your weak spots first')+'</h3><p>20 mixed questions across every skill. I rank what is costing you points, then build the weekly plan around it.</p><div class="row"><button class="btn acc" onclick="startDiagnostic()"><i class="ph ph-stethoscope"></i>'+(dg?'Retake':'Take')+' diagnostic</button></div></div>'
 +'<div class="card"><div class="muted" style="font-size:13px">What costs you the most points</div>'+r.slice(0,4).map(x=>'<div class="costrow"><span>'+esc(TOPICS[x.k].label)+'</span><em>+'+x.pts+' pts available</em><div class="ebar"><b style="width:'+Math.round(x.acc*100)+'%"></b></div></div>').join('')+'</div></div>'
 +'<div class="card tlbar" style="margin-top:18px"><div><b>Your timeline</b><div class="muted" style="font-size:13px;margin-top:4px">'+W.length+' week'+(W.length>1?'s':'')+' · about '+W[0].min+' min a day · test '+fmtDate(state.profile.testDate)+'</div></div><div class="chips">'+TL.map(t=>'<button class="chip'+(e.tl===t[0]?' on':'')+'" data-tl="'+t[0]+'">'+t[1]+'</button>').join('')+'</div></div>'
 +'<div class="wkgrid">'+W.slice(0,4).map(w=>'<div class="card wk"><h4>Week '+w.w+'<span class="ph-tag">'+w.ph+'</span></h4><div class="muted" style="font-size:12.5px">Focus: '+esc(TOPICS[w.a].short)+' and '+esc(TOPICS[w.b].short)+'</div><ul>'+w.days.map(d=>'<li><b>'+d[0]+'</b><span>'+esc(d[1])+'</span></li>').join('')+'</ul>'+(w.w===1?'<button class="btn sm acc" style="margin-top:14px" onclick="startPractice(\''+w.a+'\')">Start today\'s drill<i class="ph ph-arrow-right"></i></button>':'')+'</div>').join('')+'</div>'
 +(W.length>4?'<div class="tiles">'+W.slice(4).map(w=>'<div class="tile"><b>Week '+w.w+'</b>'+w.ph+(w.last?' · test':'')+'</div>').join('')+'</div>':'');}
document.addEventListener('click',e=>{const c=e.target.closest('[data-tl]');if(c){E().tl=c.dataset.tl;saveState();renderPlan();}});

/* ---- analytics: heatmap + costliest ---- */
const _rp=renderProgress;renderProgress=function(){_rp();const old=$('#v3ins');if(old)old.remove();const e=E(),L=e.log;
 const rows=Object.keys(TOPICS).map(k=>({l:TOPICS[k].label,f:x=>x.tp===k,seed:state.byTopic[k]})).concat([...new Set(allQ().filter(i=>i.q.skill).map(i=>i.skill))].map(s=>({l:s,f:x=>x.sk===s})));
 const cell=(n,c)=>n?'<div class="c" style="background:hsl('+Math.round(c/n*125)+',62%,58%)" title="'+c+' of '+n+'">'+Math.round(c/n*100)+'%</div>':'<div class="c no">·</div>';
 let h='<div class="card" id="v3ins" style="margin-top:18px"><div class="row" style="justify-content:space-between"><div class="muted" style="font-size:13px">Skill heatmap · accuracy by difficulty</div><span class="tag acc">Live from your attempts</span></div><div class="hm" style="margin-top:16px"><span></span><span class="h">All</span><span class="h">Easy</span><span class="h">Medium</span><span class="h">Hard</span>';
 rows.forEach(r=>{const a=L.filter(r.f),all=a.length?cell(a.length,a.filter(x=>x.ok).length):(r.seed&&r.seed.attempts?cell(r.seed.attempts,r.seed.correct):cell(0,0));h+='<span class="rl" title="'+esc(r.l)+'">'+esc(r.l)+'</span>'+all+['Easy','Medium','Hard'].map(d=>{const b=a.filter(x=>x.d===d);return cell(b.length,b.filter(x=>x.ok).length);}).join('');});
 h+='</div></div>';$('#v-progress').insertAdjacentHTML('beforeend',h);};

/* ---- rewards ---- */
const wkStart=()=>E().log.filter(l=>l.ts>=weekTs());
const CHAL=[['Answer 40 questions','ph-pencil-line',40,l=>l.length,150],['Solve 6 hard questions','ph-mountains',6,l=>l.filter(x=>x.d==='Hard'&&x.ok).length,200],['Tag 5 missed questions','ph-notebook',5,()=>Object.values(E().tagTs).filter(t=>t>=weekTs()).length,120]];
const BADGES=[['first','First step','Answer a question','ph-footprints','#cd7f32',()=>state.answered>=1],['c100','Centurion','Answer 100 questions','ph-target','#c0c8d0',()=>state.answered>=100],['sharp','Sharpshooter','80% overall accuracy','ph-crosshair','#f5c451',()=>accuracy()>=80],
 ['w7','On fire','7-day streak','ph-fire','#ff9a4d',()=>state.streak>=7],['w14','Unstoppable','14-day streak','ph-flame','#f5c451',()=>state.streak>=14],['off10','Official 10','Solve 10 official questions','ph-seal-check','#4ade80',()=>Object.entries(E().seen).filter(([k,v])=>v==='ok'&&k.length===8).length>=10],
 ['hard5','Summit','5 hard questions right','ph-mountains','#7cc0ff',()=>E().log.filter(x=>x.d==='Hard'&&x.ok).length>=5],['diag','Diagnosed','Finish the diagnostic','ph-stethoscope','#4ade80',()=>!!E().diag],['log5','Error hunter','Tag 5 misses','ph-notebook','#cd7f32',()=>Object.keys(E().tags).length>=5],
 ['timed','Against the clock','Finish a timed drill','ph-timer','#c0c8d0',()=>(E().timed||0)>=1],['test','Test taker','Complete a full test','ph-exam','#f5c451',()=>state.testsDone>=1],['perfect','Flawless','Perfect set of 8+','ph-crown','#f5c451',()=>!!E().perfect],['xp','Voltage','Earn 1,000 XP','ph-lightning','#ff9a4d',()=>E().xp>=1000],['goal3','Habit','Hit your daily goal 3 times','ph-check-circle','#4ade80',()=>(E().goalDays||0)>=3]];
function burst(){if(REDUCED)return;const b=document.createElement('div');b.className='burst';const cs=['#4ade80','#f5c451','#7cc0ff','#ff9a4d','#fafcfb'];for(let i=0;i<46;i++){const a=Math.random()*Math.PI-Math.PI,d=160+Math.random()*340;b.insertAdjacentHTML('beforeend','<i style="--c:'+cs[i%5]+';--dx:'+Math.cos(a)*d+'px;--dy:'+(Math.sin(a)*d+160)+'px;--r:'+Math.random()*720+'deg;animation-delay:'+Math.random()*.15+'s"></i>');}document.body.appendChild(b);setTimeout(()=>b.remove(),1900);}
let quiet=true;
function checkBadges(){const e=E();if(todayN()>=e.goal&&e.goalDay!==ymd(Date.now())){e.goalDay=ymd(Date.now());e.goalDays=(e.goalDays||0)+1;if(!quiet){toast('Daily goal reached. +50 XP','ph-target');e.xp+=50;burst();}}
 BADGES.forEach(b=>{if(!e.badges[b[0]]&&b[5]()){e.badges[b[0]]=Date.now();if(!quiet){toast('Badge unlocked: '+b[1],'ph-medal');burst();if(X)coachSay('m_cheer','Badge unlocked: '+b[1]+'!');}}});}
function renderRewards(){const e=E(),n=todayN(),pct=Math.min(100,Math.round(n/e.goal*100)),lv=Math.floor(e.xp/300)+1,wl=wkStart(),mine=wl.reduce((s,l)=>s+(l.ok?10:3),0);
  $('#rwBody').innerHTML='<div class="rwtop"><div class="card bigrow"><div class="gring" style="--v:'+pct+'"><b>'+n+'<small>of '+e.goal+'</small></b></div><div><b style="font-size:17px">Daily goal</b><div class="muted" style="font-size:13px;margin:4px 0 12px">Questions answered today</div><div class="chips">'+[5,10,20,30].map(g=>'<button class="chip'+(e.goal===g?' on':'')+'" data-goal="'+g+'">'+g+'</button>').join('')+'</div></div></div>'
 +'<div class="card"><div class="row" style="justify-content:space-between"><b style="font-size:17px"><i class="ph-fill ph-fire" style="color:#ff9a4d"></i> '+state.streak+'-day streak</b><span class="tag acc">Level '+lv+'</span></div><div class="muted" style="font-size:13px;margin-top:6px">Streak freezes protect one missed day. Earn one every 7 days.</div><div class="frz">'+[0,1].map(i=>'<i class="'+(i<e.freeze?'on':'')+'"><i class="ph-fill ph-snowflake" style="background:none;width:auto;height:auto"></i></i>').join('')+'</div><div class="bar" style="margin-top:14px"><i style="width:'+((e.xp%300)/3)+'%"></i></div><div class="muted" style="font-size:12px;margin-top:6px">'+e.xp+' XP · '+(300-e.xp%300)+' to level '+(lv+1)+'</div></div></div>'
 +'<h2 class="sectiontitle">Weekly challenges</h2><div class="grid g3">'+CHAL.map(c=>{const v=Math.min(c[2],c[3](wl,e));return '<div class="card chal"><div class="row"><span class="ic"><i class="ph '+c[1]+'"></i></span><span class="tag '+(v>=c[2]?'good':'warn')+'">+'+c[4]+' XP</span></div><h3 style="font-size:16px;margin-top:12px">'+c[0]+'</h3><div class="muted" style="font-size:13px">'+v+' of '+c[2]+'</div><div class="bar"><i style="width:'+v/c[2]*100+'%"></i></div></div>';}).join('')+'</div>'
 +'<h2 class="sectiontitle">Badges <span class="muted" style="font-size:14px;font-weight:500">'+Object.keys(e.badges).length+' of '+BADGES.length+'</span></h2><div class="badges">'+BADGES.map(b=>{const on=!!e.badges[b[0]];return '<div class="card bd'+(on?'':' lock')+'"><div class="medal" style="--c:'+b[4]+'"><i class="ph-fill '+(on?b[3]:'ph-lock-simple')+'"></i></div><b style="font-size:14px">'+b[1]+'</b><small>'+b[2]+'</small></div>';}).join('')+'</div>'
 ;}
document.addEventListener('click',e=>{const g=e.target.closest('[data-goal]');if(g){E().goal=+g.dataset.goal;saveState();renderRewards();}});
checkBadges();quiet=false;
