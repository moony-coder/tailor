// TestSession: framework-agnostic recorder the UI calls. Works in the browser (pass localStorage as `storage`) and in Node tests.
// Guarantees: batching (timer + module end), crash-safe buffer, monotonic seq across modules, serialised flush (never loses/duplicates a batch),
// idle detection that is "lazy" (back-filled with the real timestamp when the next input arrives, so it works even if timers were throttled).
export class TestSession {
  /**
   * @param {{sessionId:string, sink:(events:object[])=>Promise<any>, storage?:{getItem,setItem,removeItem}, now?:()=>number,
   *          idleMs?:number, flushEvery?:number, flushMs?:number}} o
   */
  constructor(o) {
    this.sessionId = o.sessionId; this.sink = o.sink; this.storage = o.storage ?? null; this.now = o.now ?? (() => Date.now());
    this.idleMs = o.idleMs ?? 20000; this.flushEvery = o.flushEvery ?? 25; this.flushMs = o.flushMs ?? 5000;
    this.seq = 0; this.sentSeq = 0; this.buffer = []; this.flushing = null; this.lastFlushAt = this.now();
    this.module = null;           // { id, questionIds, limitMs, startedAt, submitted }
    this.current = null;          // question id on screen
    this.answers = {}; this.flags = {}; this.lastInputAt = null; this.idle = false; this.blurred = false; this.timer = null;
  }
  get key() { return `sat-session:${this.sessionId}`; }

  // ---- lifecycle ----
  startModule({ moduleId, questionIds, limitMs }) {
    const t = this.now();
    this.module = { id: moduleId, questionIds: questionIds.slice(), limitMs, startedAt: t, submitted: false, expired: false };
    this.answers = {}; this.flags = {}; this.current = null; this.lastInputAt = t; this.idle = false; this.blurred = false;
    this._emit('module_started', null, { limit_ms: limitMs }, t);
    this.show(questionIds[0]);
  }
  /** Rebuild from the crash buffer. Returns true if a session was restored. */
  restore() {
    if (!this.storage) return false;
    const raw = this.storage.getItem(this.key); if (!raw) return false;
    let s; try { s = JSON.parse(raw); } catch { return false; }
    Object.assign(this, { seq: s.seq, sentSeq: s.sentSeq, buffer: s.buffer, module: s.module, current: s.current, answers: s.answers, flags: s.flags, lastInputAt: s.lastInputAt, idle: s.idle, blurred: s.blurred });
    return true;
  }
  timeRemainingMs() { return this.module ? Math.max(0, this.module.limitMs - (this.now() - this.module.startedAt)) : null; }
  getState() { return { current: this.current, answers: { ...this.answers }, flags: { ...this.flags }, remaining_ms: this.timeRemainingMs(), module: this.module && { ...this.module }, pending_events: this.buffer.length }; }

  // ---- user actions ----
  show(qid) {
    this._input();
    const from = this.current; this.current = qid;
    if (from && from !== qid) this._emit('navigate', qid, { from, to: qid });
    this._emit('question_shown', qid);
  }
  goTo(qid) { this.show(qid); }
  select(choice) {
    this._input(); const q = this.current; if (!q || this._closed()) return;
    const prev = this.answers[q]; const rem = this.timeRemainingMs();
    if (prev === choice) return;
    this.answers[q] = choice;   // state first: _emit persists the crash buffer
    if (prev !== undefined) this._emit('answer_changed', q, { from: prev, to: choice, rem }); else this._emit('answer_selected', q, { choice, rem });
  }
  clear() { this._input(); const q = this.current; if (!q || this._closed() || this.answers[q] === undefined) return; delete this.answers[q]; this._emit('answer_cleared', q); }
  eliminate(choice) { this._input(); if (this.current && !this._closed()) this._emit('option_eliminated', this.current, { choice }); }
  toggleFlag() { this._input(); const q = this.current; if (!q || this._closed()) return; if (this.flags[q]) { delete this.flags[q]; this._emit('flag_cleared', q); } else { this.flags[q] = true; this._emit('flag_set', q); } }
  calculator(open) { this._input(); if (this.current) this._emit(open ? 'calculator_opened' : 'calculator_closed', this.current); }
  highlight() { this._input(); if (this.current) this._emit('highlight_added', this.current); }
  notes() { this._input(); if (this.current) this._emit('notes_opened', this.current); }
  blur() { this._idleCheck(); if (this.blurred) return; this.blurred = true; this._emit('tab_blurred', this.current); }
  focus() { if (!this.blurred) return; this.blurred = false; this._emit('tab_focused', this.current); this.lastInputAt = this.now(); }

  /** Call from a setInterval (optional). Handles time expiry and flush timer. */
  tick() {
    if (!this.module || this.module.submitted) return;
    this._idleCheck();
    if (!this.module.expired && this.timeRemainingMs() <= 0) this._expire();
    if (this.buffer.length && this.now() - this.lastFlushAt >= this.flushMs) this.flush().catch(() => {});
  }
  async submitModule() {
    if (!this.module || this.module.submitted) return { answers: { ...this.answers }, expired: !!this.module?.expired };
    this._idleCheck(); this._input();
    if (!this.module.expired && this.timeRemainingMs() <= 0) this._expire();
    this.module.submitted = true;
    this._emit('module_submitted', this.current, { rem: this.timeRemainingMs() });
    await this.flush();
    return { answers: { ...this.answers }, expired: this.module.expired };
  }

  // ---- internals ----
  _closed() { return !this.module || this.module.submitted || this.module.expired; }
  _expire() {
    const t = this.module.startedAt + this.module.limitMs;
    this.module.expired = true; this._emit('time_expired', this.current, {}, Math.max(t, this.lastInputAt ?? t));
  }
  _input() { this._idleCheck(); const t = this.now(); if (this.idle) { this.idle = false; this._emit('idle_ended', this.current, {}, t); } this.lastInputAt = t; }
  _idleCheck() {
    if (!this.module || this.idle || this.blurred || this.lastInputAt == null) return;
    if (this.now() - this.lastInputAt >= this.idleMs) { this.idle = true; this._emit('idle_started', this.current, {}, this.lastInputAt + this.idleMs); }
  }
  _emit(type, qid = null, payload = {}, t = this.now()) {
    const ev = { seq: ++this.seq, type, t_ms: t, module_id: this.module?.id ?? null, question_id: qid ?? null, payload };
    this.buffer.push(ev); this._save();
    if (this.buffer.length >= this.flushEvery) this.flush().catch(() => {});
  }
  _save() {
    if (!this.storage) return;
    try { this.storage.setItem(this.key, JSON.stringify({ seq: this.seq, sentSeq: this.sentSeq, buffer: this.buffer, module: this.module, current: this.current, answers: this.answers, flags: this.flags, lastInputAt: this.lastInputAt, idle: this.idle, blurred: this.blurred })); } catch { /* quota: keep going */ }
  }
  /** Serialised: a second flush waits for the first, then sends only what is still unsent. Failures keep the events buffered. */
  async flush() {
    while (this.flushing) { try { await this.flushing; } catch { /* retry below */ } }
    this.lastFlushAt = this.now();
    if (!this.buffer.length || !this.sink) { this._save(); return 0; }
    const batch = this.buffer.slice();
    const p = Promise.resolve().then(() => this.sink(batch));
    this.flushing = p;
    try { await p; this.buffer = this.buffer.slice(batch.length); this.sentSeq = batch[batch.length - 1].seq; this._save(); return batch.length; }
    finally { if (this.flushing === p) this.flushing = null; }
  }
  clearCrashBuffer() { this.storage?.removeItem(this.key); }
}
