// Pure: events -> per-attempt metrics. Never reads the DB. `correctFn(qid, choice)` supplies correctness (so changed_right_to_wrong can be computed).
const clipOverlap = (a0, a1, b0, b1) => Math.max(0, Math.min(a1, b1) - Math.max(a0, b0));

/**
 * @param {object[]} events  all events of ONE module, any order (sorted by seq here); duplicates by seq are ignored
 * @param {{id:string}[]} questions module questions in position order
 * @param {(qid:string, choice:any)=>boolean} correctFn
 * @returns {{perQuestion: Map<string,object>, module:{started_at, ended_at, submitted, expired, limit_ms, used_ms}}}
 */
export function deriveModule(events, questions, correctFn) {
  const seen = new Set(); const evs = [];
  for (const e of events.slice().sort((a, b) => a.seq - b.seq)) { if (seen.has(e.seq)) continue; seen.add(e.seq); evs.push(e); }
  const started = evs.find((e) => e.type === 'module_started');
  const endEv = evs.find((e) => e.type === 'module_submitted' || e.type === 'time_expired');
  const lastT = evs.length ? evs[evs.length - 1].t_ms : 0;
  const endT = endEv ? endEv.t_ms : lastT;
  const limit = started?.payload?.limit_ms ?? null;
  const expired = evs.some((e) => e.type === 'time_expired');
  const submitted = evs.some((e) => e.type === 'module_submitted');

  // inactive intervals (idle + blur); an unclosed one runs to the module end
  const inactive = [];
  let idleFrom = null, blurFrom = null;
  for (const e of evs) {
    if (e.type === 'idle_started') idleFrom = e.t_ms;
    else if (e.type === 'idle_ended' && idleFrom != null) { inactive.push([idleFrom, e.t_ms]); idleFrom = null; }
    else if (e.type === 'tab_blurred') blurFrom = blurFrom ?? e.t_ms;
    else if (e.type === 'tab_focused' && blurFrom != null) { inactive.push([blurFrom, e.t_ms]); blurFrom = null; }
  }
  if (idleFrom != null) inactive.push([idleFrom, endT]);
  if (blurFrom != null) inactive.push([blurFrom, endT]);

  const per = new Map(questions.map((q) => [q.id, { question_id: q.id, visits: 0, total_ms: 0, active_ms: 0, first_response_ms: null, answer_changes: 0, changed_right_to_wrong: 0,
    final_choice: null, flagged: 0, eliminated: [], calc_opened: 0, highlights_used: 0, time_remaining_ms: null, shown_at: null, _intervals: [], _first_answer_t: null, _first_shown: null }]));

  let cur = null, curFrom = null;
  const close = (t) => { if (cur && curFrom != null) per.get(cur)?._intervals.push([curFrom, Math.max(curFrom, t)]); cur = null; curFrom = null; };
  for (const e of evs) {
    const m = e.question_id ? per.get(e.question_id) : null;
    if (e.type === 'question_shown' && m) { close(e.t_ms); cur = e.question_id; curFrom = e.t_ms; m.visits++; if (m._first_shown == null) m._first_shown = e.t_ms; }
    else if (e.type === 'module_submitted' || e.type === 'time_expired') close(e.t_ms);
    if (!m) continue;
    switch (e.type) {
      case 'answer_selected': m.final_choice = e.payload.choice; m.time_remaining_ms = e.payload.rem ?? m.time_remaining_ms; if (m._first_answer_t == null) m._first_answer_t = e.t_ms; break;
      case 'answer_changed': {
        m.answer_changes++; m.final_choice = e.payload.to; m.time_remaining_ms = e.payload.rem ?? m.time_remaining_ms;
        if (correctFn(m.question_id, e.payload.from) && !correctFn(m.question_id, e.payload.to)) m.changed_right_to_wrong = 1;
        break;
      }
      case 'answer_cleared': m.final_choice = null; break;
      case 'flag_set': m.flagged = 1; break;
      case 'flag_cleared': m.flagged = 0; break;
      case 'option_eliminated': if (!m.eliminated.includes(e.payload.choice)) m.eliminated.push(e.payload.choice); break;
      case 'calculator_opened': m.calc_opened = 1; break;
      case 'highlight_added': m.highlights_used++; break;
      default:
    }
  }
  close(endT);
  for (const m of per.values()) {
    let total = 0, active = 0, cum = 0; m.first_response_ms = null;
    for (const [a, b] of m._intervals) {
      const len = b - a; let dead = 0;
      for (const [i0, i1] of inactive) dead += clipOverlap(a, b, i0, i1);
      if (m._first_answer_t != null && m.first_response_ms == null && m._first_answer_t >= a && m._first_answer_t <= b) m.first_response_ms = cum + (m._first_answer_t - a);
      cum += len; total += len; active += Math.max(0, len - dead);
    }
    m.total_ms = total; m.active_ms = active;
    delete m._intervals; delete m._first_answer_t; delete m._first_shown; delete m.shown_at;
  }
  return { perQuestion: per, module: { started_at: started?.t_ms ?? null, ended_at: endEv?.t_ms ?? null, submitted, expired, limit_ms: limit, used_ms: started && endEv ? endEv.t_ms - started.t_ms : null } };
}
