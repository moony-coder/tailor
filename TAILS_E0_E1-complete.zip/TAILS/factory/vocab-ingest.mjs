// node factory/vocab-ingest.mjs <deepseek-reply.txt> [--into path/to/vocab.json]
// Pulls the JSON array out of a pasted chat reply, validates each entry, de-duplicates by word and merges into vocab.json.
import fs from 'node:fs';
import { extractJson } from './lib/common.mjs';
const [file, ...rest] = process.argv.slice(2), into = rest.includes('--into') ? rest[rest.indexOf('--into') + 1] : 'assets/data/vocab.json';
if (!file) { console.error('usage: node factory/vocab-ingest.mjs reply.txt [--into vocab.json]'); process.exit(1); }
const raw = extractJson(fs.readFileSync(file, 'utf8')), arr = Array.isArray(raw) ? raw : raw?.words ?? [];
const cur = fs.existsSync(into) ? JSON.parse(fs.readFileSync(into, 'utf8')) : { words: [] }, have = new Set(cur.words.map((w) => w.word.toLowerCase()));
const POS = ['adj', 'verb', 'noun', 'adv'], bad = []; let ok = 0;
for (const w of arr) {
  const e = [];
  if (!w.word || /\s{2,}/.test(w.word)) e.push('word missing');
  if (!POS.includes(w.pos)) e.push('pos must be adj|verb|noun|adv');
  if (!w.meaning || w.meaning.split(' ').length > 14) e.push('meaning missing or too long');
  if (!w.example || !new RegExp(String(w.word).slice(0, Math.max(4, String(w.word).length - 3)), 'i').test(w.example)) e.push('example must use the word');
  if (have.has(String(w.word).toLowerCase())) e.push('duplicate');
  if (e.length) { bad.push(`${w.word}: ${e.join('; ')}`); continue; }
  cur.words.push({ word: w.word.toLowerCase(), pos: w.pos, meaning: w.meaning, example: w.example, synonyms: w.synonyms ?? [], confusable: w.confusable ?? null, tier: w.tier ?? 2, topic: w.topic ?? 'general' }); have.add(w.word.toLowerCase()); ok++;
}
fs.mkdirSync(new URL('.', 'file://' + (into.startsWith('/') ? into : process.cwd() + '/' + into)).pathname, { recursive: true });
fs.writeFileSync(into, JSON.stringify(cur, null, 1));
console.log(`${ok} words added (total ${cur.words.length}); ${bad.length} rejected`); bad.forEach((b) => console.log('  x ' + b));
