/* ============================================================
   TAILORED PRACTICE pages: Practice (start), Audit, 7-day plan, Skill map.
   Review / Import live in 34-35. Every page: (body, route, alive) => Promise.
   `alive()` is false once the student navigated away, so late responses never paint over a newer page.
   ============================================================ */
(function(){
  'use strict';
  const A = window.SATAPI, SAT = window.SAT; if(!A || !SAT) return;
  const P = SAT.pages;
  const when = iso => { try{ return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ', ' + new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }); }catch(e){ return ''; } };
  const KIND = { 'mini-mock': 'Mini-mock', 'native-mock': 'Full mock', 'skill-drill': 'Skill drill', 'spaced-retest': 'Retest', 'bluebook-import': 'Bluebook import' };
  const CAUSE_ICON = { CARELESS: 'ph-eye', CONTENT_GAP: 'ph-book-open-text', VOCAB: 'ph-text-aa', COMPREHENSION: 'ph-article', STRATEGY: 'ph-chess-knight', TIMING: 'ph-timer', OVERTHINK: 'ph-brain', GUESS: 'ph-dice-five', TOOL: 'ph-calculator', UNKNOWN: 'ph-question' };
  SAT.KIND = KIND; SAT.when = when;

  /* the signed-in student's sessions (needs a profile; shows a friendly gate otherwise) */
  async function mySessions(){ if(!A.session()) return null; try{ return (await A.get('/api/sessions')).sessions; }catch(e){ if(e.status === 401) return null; throw e; } }
  function gate(body, what){
    body.innerHTML = '<div class="card sat-gate"><i class="ph ph-user-circle"></i><div><h3>Start your first test</h3><p class="muted">' + esc(what) + '</p><button class="btn acc" id="satGateGo">Take a mini-mock<i class="ph ph-arrow-right"></i></button></div></div>';
    $('#satGateGo').onclick = () => SAT.open('start');
  }
  const latestFinished = (ss, re) => (ss || []).find(s => s.status === 'finished' && re.test(s.kind));

  /* ============================================================ PRACTICE */
  P.start = async function(body, r, alive){
    const [tax, ss] = await Promise.all([A.get('/api/taxonomy', { public: true }), mySessions()]);
    if(!alive()) return;
    const tests = (A.health && A.health.tests) || {};
    const open = (ss || []).filter(s => s.status === 'active');
    let sc = { items: [] };
    if(A.session()){ try{ sc = await A.get('/api/second-chance'); }catch(e){} }
    const due = (sc.items || []).filter(x => x.due).length;
    let html = '';
    if(open.length){
      const s = open[0];
      html += '<div class="card sat-resume"><i class="ph ph-clock-countdown"></i><div class="grow"><b>You have an unfinished ' + esc(KIND[s.kind] || 'test') + '</b><div class="muted fs-13">Started ' + esc(when(s.started_at)) + '. Your answers are saved. The module timer kept running while you were away.</div></div><button class="btn acc" id="satResume">Resume<i class="ph ph-arrow-right"></i></button></div>';
    }
    if(sc.items && sc.items.length){
      html += '<div class="card sat-resume"><i class="ph ph-arrows-clockwise"></i><div class="grow"><b>' + sc.items.length + ' second chance' + (sc.items.length > 1 ? 's' : '') + ' waiting' + (due ? ' (' + due + ' due)' : '') + '</b><div class="muted fs-13">A fresh try at questions you missed, without the solution. It shows whether the miss was a slip or a real gap.</div></div><button class="btn line" id="satSC">Try them<i class="ph ph-arrow-right"></i></button></div>';
    }
    html += '<div class="grid g3 sat-start">' +
      '<div class="card lift"><span class="tag acc"><i class="ph ph-compass"></i>Best first step</span><h3 class="card-h">Mini-mock</h3><p class="muted card-p">12 Reading and Writing + 10 Math questions, timed. About 30 minutes. Gives you a full audit and a 7-day plan.</p><button class="btn acc mt-16" id="satMini"' + (tests['mini-mock'] === false ? ' disabled' : '') + '>Start mini-mock<i class="ph ph-arrow-right"></i></button></div>' +
      '<div class="card lift"><span class="tag"><i class="ph ph-exam"></i>' + (tests['native-mock'] === false ? 'Needs a bigger question bank' : 'About 2 h 14 min') + '</span><h3 class="card-h">Full mock</h3><p class="muted card-p">Four modules, like the real digital SAT. The second module in each section adapts to how you did in the first.</p><button class="btn mt-16" id="satFull"' + (tests['native-mock'] === false ? ' disabled' : '') + '>' + (tests['native-mock'] === false ? 'Not available yet' : 'Start full mock') + '</button></div>' +
      '<div class="card lift"><span class="tag"><i class="ph ph-target"></i>Targeted</span><h3 class="card-h">Skill drill</h3><p class="muted card-p">10 questions on one skill, matched to your level. Use it on a lever from your audit.</p>' +
      '<div class="field mt-16"><label for="satDom">Skill</label><select class="inp" id="satSkill"><option value="">Pick a skill</option>' + tax.domains.map(d => '<optgroup label="' + esc(d.name) + '"><option value="d:' + esc(d.id) + '">All of ' + esc(d.name) + '</option>' + d.skills.map(s => '<option value="s:' + esc(s.id) + '">' + esc(s.name) + '</option>').join('') + '</optgroup>').join('') + '</select></div>' +
      '<button class="btn line mt-12" id="satDrill" disabled>Start drill<i class="ph ph-arrow-right"></i></button></div></div>';
    html += '<h2 class="sectiontitle">Your tests</h2><div id="satHist">' + histHtml(ss) + '</div>' +
      '<div class="card sat-note"><i class="ph ph-shield-check"></i><div><b>How this works</b><p class="muted">Questions are written for this platform and checked by code and a second solver. Your answers and timing stay in this browser; only a short summary (never your free-text notes) is sent to the AI that words the audit. This is not a predicted SAT score.</p></div></div>';
    body.innerHTML = html;
    const go1 = (b, body1) => { if(b) b.onclick = () => SAT.startSession(body1, b); };
    go1($('#satMini'), { kind: 'mini-mock' }); go1($('#satFull'), { kind: 'native-mock' });
    if($('#satResume')) $('#satResume').onclick = async () => { SAT.busy($('#satResume'), true, 'Opening'); try{ await SAT.exam.resume(open[0].id); }catch(e){ toast(SAT.errText(e), 'ph-warning-circle'); SAT.busy($('#satResume'), false); } };
    if($('#satSC')) $('#satSC').onclick = () => SAT.open('review', 'second-chance');
    const sel = $('#satSkill'), dr = $('#satDrill');
    sel.onchange = () => { dr.disabled = !sel.value; };
    dr.onclick = () => { const v = sel.value; if(!v) return; SAT.startSession(v[0] === 'd' ? { kind: 'skill-drill', domain: v.slice(2) } : { kind: 'skill-drill', skill_id: v.slice(2) }, dr); };
    body.querySelectorAll('[data-open]').forEach(b => b.onclick = () => SAT.open(b.dataset.open, b.dataset.id));
  };
  function histHtml(ss){
    if(!ss || !ss.length) return '<div class="card muted">No tests yet. Your first mini-mock takes about half an hour.</div>';
    return '<div class="sat-list">' + ss.slice(0, 12).map(s => '<div class="card sat-row"><div class="grow"><b>' + esc(KIND[s.kind] || s.kind) + '</b><div class="muted fs-13">' + esc(when(s.started_at)) + (s.source === 'bluebook' ? ' · from Bluebook labels' : '') + '</div></div>' +
      (s.status === 'finished' ? '<span class="tag good">Finished</span><button class="btn sm line" data-open="audit" data-id="' + esc(s.id) + '">Audit</button><button class="btn sm ghost" data-open="review" data-id="' + esc(s.id) + '">Review</button>' : '<span class="tag warn">In progress</span>') + '</div>').join('') + '</div>';
  }

  /* ============================================================ AUDIT */
  P.audit = async function(body, r, alive){
    const ss = await mySessions();
    if(!alive()) return;
    if(!ss) return gate(body, 'Your audit appears here after your first test.');
    let sid = r.id; const choices = ss.filter(s => s.status === 'finished' && /mock|bluebook/.test(s.kind));
    if(!sid) sid = choices.length ? choices[0].id : null;
    if(!sid) return gate(body, 'You need one finished mock (or a Bluebook import) first. The audit explains your mistakes across it.');
    const au = await A.get('/api/audit/' + encodeURIComponent(sid));
    if(!alive()) return;
    if(!au.ready){ body.innerHTML = '<div class="card">' + esc(au.message || 'No answers recorded for this session yet.') + '</div>'; return; }
    const R = au.report, N = au.narrative || {}, conf = au.confidence || {};
    const src = au.narrative_source === 'llm' || au.narrative_source === 'cache' ? 'Wording by AI from a short summary of your results' : 'Standard wording (AI is off or unavailable)';
    let h = '';
    if(choices.length > 1) h += '<div class="row sat-pick"><label class="muted fs-13" for="satAuPick">Audit for</label><select class="inp" id="satAuPick">' + choices.map(s => '<option value="' + esc(s.id) + '"' + (s.id === sid ? ' selected' : '') + '>' + esc((KIND[s.kind] || s.kind) + ' · ' + when(s.started_at)) + '</option>').join('') + '</select></div>';
    h += '<div class="card sat-hero"><div class="row jc-between"><span class="tag acc"><i class="ph ph-compass"></i>' + esc(KIND[au.kind] || 'Audit') + ' · ' + esc(when(au.started_at)) + '</span><span class="tag ' + (conf.label === 'standard' ? 'good' : 'warn') + '" title="' + esc(conf.why || '') + '"><i class="ph ph-gauge"></i>Confidence: ' + esc(conf.label || 'reduced') + '</span></div>' +
      '<h2 class="sat-h">' + esc(N.headline || 'Your audit') + '</h2><p class="sat-snap">' + esc(N.snapshot || '') + '</p>' +
      '<div class="sat-scores">' + ['rw', 'math'].filter(k => R.scores[k]).map(k => { const s = R.scores[k]; return '<div><span>' + (k === 'rw' ? 'Reading and Writing' : 'Math') + '</span><b>' + s.correct + '<small>/' + s.total + '</small></b><div class="bar thin"><i style="width:' + Math.round(s.accuracy * 100) + '%"></i></div></div>'; }).join('') + '</div>' +
      (conf.why ? '<p class="muted fs-13"><i class="ph ph-info"></i> ' + esc(conf.why) + '</p>' : '') + '</div>';

    /* levers */
    h += '<h2 class="sectiontitle">Your biggest levers</h2>';
    if(!R.levers.length) h += '<div class="card muted">Not enough mistakes spread across one area to name a lever yet. That is good news. Another mock will sharpen this.</div>';
    else h += '<div class="sat-levers">' + R.levers.map((l, i) => {
      const nl = (N.levers || []).find(x => x.skill === l.skill_id) || {};
      return '<div class="card sat-lever"><div class="row jc-between"><span class="sat-rank">' + (i + 1) + '</span><span class="tag"><i class="ph ' + (CAUSE_ICON[l.main_cause] || 'ph-question') + '"></i>' + esc(l.cause_label || l.main_cause) + '</span></div>' +
        '<h3>' + esc(l.name) + '</h3><p class="muted">' + esc(nl.why || '') + '</p>' + (nl.fix ? '<p class="sat-fix"><i class="ph ph-lightbulb"></i><span>' + esc(nl.fix) + '</span></p>' : '') +
        '<div class="sat-meta"><span title="Rough estimate of questions you could win back on a full test if this is fixed">≈ +' + (Math.round(l.gain * 10) / 10) + ' questions</span><span>~' + l.cost_minutes + ' min of work</span><span>mastery ' + Math.round(l.p * 100) + '%</span></div>' +
        (l.provisional || l.low_data ? '<div class="tag warn mt-8"><i class="ph ph-warning-circle"></i>First guess, few answers so far</div>' : '') +
        (l.traps && l.traps.length ? '<div class="sat-traps mt-8">' + l.traps.map(t => '<span class="chip" title="' + esc(t.code) + '">' + esc(t.code.replace(/-/g, ' ').toLowerCase()) + ' × ' + t.count + '</span>').join('') + '</div>' : '') +
        (l.lessons && l.lessons.length ? '<div class="sat-lessons mt-8">' + l.lessons.map(x => '<div><i class="ph ph-book-open-text"></i>' + esc(x.title) + ' <span class="muted">' + x.minutes + ' min' + (x.recorded ? '' : ', outline') + '</span></div>').join('') + '</div>' : '') +
        '<div class="row mt-16"><button class="btn acc sm" data-drill="' + esc(l.skill_id) + '" data-level="' + esc(l.level) + '">Drill this<i class="ph ph-arrow-right"></i></button></div></div>';
    }).join('') + '</div>';

    /* domains + error mix */
    h += '<div class="grid g2 mt-22"><div class="card"><h3 class="card-h">By domain</h3><div class="sat-doms mt-12">' + R.domains.map(d => '<div class="sat-dom"><div class="row jc-between"><span>' + esc(d.name) + '</span><span class="muted fs-13">' + d.correct + '/' + d.total + (d.estimated_total ? ' (est.)' : '') + (d.band ? ' · band ' + d.band : '') + '</span></div><div class="bar thin ' + (d.correct / d.total < 0.5 ? 'bad' : 'good') + '"><i style="width:' + Math.round(d.correct / d.total * 100) + '%"></i></div></div>').join('') + '</div></div>' +
      '<div class="card"><h3 class="card-h">Why points were lost</h3>' + (R.error_mix.length ? '<div class="sat-doms mt-12">' + R.error_mix.map(m => '<div class="sat-dom"><div class="row jc-between"><span><i class="ph ' + (CAUSE_ICON[m.cause] || 'ph-question') + '"></i> ' + esc(m.label) + '</span><span class="muted fs-13">' + m.n + ' · ' + Math.round(m.share * 100) + '%</span></div><div class="bar thin"><i style="width:' + Math.round(m.share * 100) + '%"></i></div></div>').join('') + '</div><p class="muted fs-13 mt-12">Tell us why you missed each question in <a href="#sat/review/' + esc(sid) + '" data-open="review" data-id="' + esc(sid) + '">Mistake review</a> to make this sharper.</p>' : '<p class="muted">No mistakes in this session.</p>') + '</div></div>';

    /* pacing + behaviors */
    const pc = R.pacing || {}, pl = [];
    if(pc.avg_time_vs_target != null) pl.push('You used about ' + Math.round(pc.avg_time_vs_target * 100) + '% of the target time per question.');
    if(pc.late_decay) pl.push('Accuracy dropped late in a module.');
    if(pc.rushes_late) pl.push('You sped up and rushed near the end of a module.');
    if(pc.unanswered) pl.push(pc.unanswered + ' question' + (pc.unanswered > 1 ? 's were' : ' was') + ' left blank.');
    (pc.modules || []).forEach(m => { if(m.used_fraction != null) pl.push((m.section === 'math' ? 'Math' : 'Reading and Writing') + ' module ' + m.module_index + ': used ' + Math.round(m.used_fraction * 100) + '% of the time' + (m.expired ? ' (time ran out)' : '') + '.'); });
    if(!pl.length) pl.push('No timing data was recorded for this session, so pacing is not judged.');
    h += '<div class="grid g2 mt-22"><div class="card"><h3 class="card-h"><i class="ph ph-timer"></i> Pacing</h3><ul class="sat-ul mt-12">' + pl.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' +
      '<div class="card"><h3 class="card-h"><i class="ph ph-brain"></i> Habits</h3>' + ((N.behaviors || []).length ? '<ul class="sat-ul mt-12">' + N.behaviors.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '<p class="muted mt-12">No clear habit stands out yet.</p>') + '</div></div>';

    /* traps + vocab */
    if((R.traps || []).length || (R.vocab_gaps || []).length){
      h += '<div class="grid g2 mt-22">';
      h += '<div class="card"><h3 class="card-h"><i class="ph ph-warning-diamond"></i> Trap profile</h3>' + ((R.traps || []).length ? '<div class="sat-doms mt-12">' + R.traps.map(t => '<div class="sat-trap"><b>' + esc(t.name) + '</b> <span class="muted fs-13">' + Math.round(t.share * 100) + '% of misses</span><div class="muted fs-13">' + esc(t.meaning || '') + '</div></div>').join('') + '</div>' : '<p class="muted mt-12">No repeated trap yet.</p>') + '</div>';
      h += '<div class="card"><h3 class="card-h"><i class="ph ph-text-aa"></i> Words to learn</h3>' + ((R.vocab_gaps || []).length ? '<div class="sat-vocab mt-12">' + R.vocab_gaps.map(v => '<div><b>' + esc(v.term) + '</b><span class="muted"> · ' + esc(v.meaning) + '</span></div>').join('') + '</div>' : '<p class="muted mt-12">No vocabulary gaps found.</p>') + '</div></div>';
    }

    /* trend / deep audit */
    const dp = R.deep || {};
    if(dp.series && dp.series.length){
      h += '<div class="card mt-22"><div class="row jc-between"><h3 class="card-h"><i class="ph ph-chart-line-up"></i> Trend across your mocks</h3><span class="tag">' + (dp.due ? 'Deep audit due now' : 'Next deep audit in ' + dp.next_deep_in + ' mock' + (dp.next_deep_in === 1 ? '' : 's')) + '</span></div>' + spark(dp.series.map(s => s.acc)) +
        '<p class="muted mt-8">' + esc(dp.advice || (dp.series.length < 2 ? 'Your first mock sets the baseline. A trend appears after your second.' : 'Accuracy by mock, oldest to newest.')) + '</p>' + (dp.plateau ? '<div class="tag warn mt-8"><i class="ph ph-warning-circle"></i>Plateau: the last three mocks are within a few points of each other</div>' : '') + '</div>';
    } else if(R.trend && R.trend.vs_previous){ h += '<div class="card mt-22 muted"><i class="ph ph-chart-line-up"></i> ' + esc(R.trend.vs_previous) + '</div>'; }

    /* plan note + unsure + honesty */
    h += '<div class="card mt-22 sat-plan-note"><i class="ph ph-calendar-check"></i><div class="grow"><b>' + esc(N.plan_note || 'Your 7-day plan is ready.') + '</b></div><button class="btn acc" data-open="plan">Open my plan<i class="ph ph-arrow-right"></i></button></div>';
    const U = R.unsure || {};
    h += '<div class="card mt-22"><h3 class="card-h"><i class="ph ph-question"></i> What we are unsure about</h3><ul class="sat-ul mt-12">' + (N.caution ? '<li>' + esc(N.caution) + '</li>' : '') + (U.notes || []).map(x => '<li>' + esc(x) + '</li>').join('') +
      ((U.low_data_skills || []).length ? '<li>Too few answers to judge: ' + U.low_data_skills.map(s => esc(s.name)).join(', ') + '.</li>' : '') + (U.low_confidence_share > 0.3 ? '<li>' + Math.round(U.low_confidence_share * 100) + '% of the "why" labels are guesses. Answer the Mistake review to fix that.</li>' : '') + '</ul></div>';
    const H = au.honesty || {};
    h += '<p class="sat-disc muted"><i class="ph ph-shield-check"></i> ' + esc(src) + '. ' + esc(H.verification || '') + ' ' + esc(H.scores || '') + ' ' + esc(H.disclaimer || '') + '</p>';
    body.innerHTML = h;
    const pick = $('#satAuPick'); if(pick) pick.onchange = () => SAT.open('audit', pick.value);
    body.querySelectorAll('[data-open]').forEach(b => b.onclick = e => { e.preventDefault(); SAT.open(b.dataset.open, b.dataset.id); });
    body.querySelectorAll('[data-drill]').forEach(b => b.onclick = () => { const id = b.dataset.drill, dom = b.dataset.level === 'domain'; SAT.startSession(dom ? { kind: 'skill-drill', domain: id } : { kind: 'skill-drill', skill_id: id }, b); });
  };
  function spark(vals){
    const W = 320, H = 70, lo = Math.min(...vals, .2) - .05, hi = Math.max(...vals, .6) + .05;
    const X = i => vals.length > 1 ? 10 + i / (vals.length - 1) * (W - 20) : W / 2, Y = v => 8 + (1 - (v - lo) / (hi - lo)) * (H - 16);
    const d = vals.map((v, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1)).join(' ');
    return '<svg class="sat-spark" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Accuracy by mock: ' + vals.map(v => Math.round(v * 100) + '%').join(', ') + '"><path d="' + d + '" fill="none" stroke="var(--acc)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>' + vals.map((v, i) => '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(v).toFixed(1) + '" r="4" fill="var(--acc)"/><text x="' + X(i).toFixed(1) + '" y="' + (Y(v) - 9).toFixed(1) + '" text-anchor="middle">' + Math.round(v * 100) + '%</text>').join('') + '</svg>';
  }

  /* ============================================================ PLAN */
  const KIND_ICON = { lesson: 'ph-book-open-text', drill: 'ph-target', retest: 'ph-arrows-clockwise', mock: 'ph-exam', pacing: 'ph-timer', review: 'ph-text-aa' };
  P.plan = async function(body, r, alive){
    if(!A.session()) return gate(body, 'Your 7-day plan is built from your first audit.');
    const res = await A.get('/api/plan');
    if(!alive()) return;
    const pl = res.plan;
    if(!pl){ body.innerHTML = '<div class="card sat-gate"><i class="ph ph-calendar-check"></i><div><h3>No plan yet</h3><p class="muted">' + esc(res.message || 'Finish a mock to get one.') + '</p><button class="btn acc" id="satPlanGo">Take a mini-mock<i class="ph ph-arrow-right"></i></button></div></div>'; $('#satPlanGo').onclick = () => SAT.open('start'); return; }
    const created = Date.parse(pl.created_at), today = Math.min(pl.horizon_days, Math.max(1, Math.floor((Date.now() - created) / 86400000) + 1));
    const pct = pl.progress.total ? Math.round(pl.progress.done / pl.progress.total * 100) : 0;
    let h = '<div class="card sat-hero"><div class="row jc-between"><div><h2 class="sat-h">' + pl.progress.done + ' of ' + pl.progress.total + ' done</h2><p class="muted">About ' + pl.minutes_per_day + ' minutes a day. Built from your audit of ' + esc(when(pl.created_at)) + '.</p></div><button class="btn line sm" data-open="audit" data-id="' + esc(pl.session_id) + '">See the audit</button></div><div class="bar mt-12"><i style="width:' + pct + '%"></i></div></div>';
    if((pl.notes || []).length) h += '<div class="card sat-note mt-16"><i class="ph ph-info"></i><div>' + pl.notes.map(n => '<p class="muted">' + esc(n) + '</p>').join('') + '</div></div>';
    h += '<div class="sat-days mt-16">' + pl.days.map(d => {
      const isToday = d.day_index === today;
      return '<div class="card sat-day' + (isToday ? ' today' : '') + '"><div class="row jc-between"><b>Day ' + d.day_index + (isToday ? ' · today' : '') + '</b><span class="muted fs-13">' + d.minutes + ' min</span></div>' +
        (d.items.length ? d.items.map(it => itemHtml(it)).join('') : '<p class="muted fs-13 mt-8">Rest day.</p>') + '</div>';
    }).join('') + '</div>' +
    '<p class="sat-disc muted">Cadence that works: one mock a week plus 20 to 40 minutes of targeted work a day. Lessons marked "outline" are written but not yet recorded as video.</p>';
    body.innerHTML = h;
    body.querySelectorAll('[data-open]').forEach(b => b.onclick = () => SAT.open(b.dataset.open, b.dataset.id));
    const items = new Map(pl.days.flatMap(d => d.items).map(i => [i.id, i]));
    body.querySelectorAll('[data-st]').forEach(b => b.onclick = async () => {
      const row = b.closest('.sat-item'), cur = row.dataset.s, nx = b.dataset.st === 'done' ? (cur === 'done' ? 'todo' : 'done') : (cur === 'skipped' ? 'todo' : 'skipped');
      b.disabled = true;
      try{ await A.patch('/api/plan-items/' + encodeURIComponent(row.dataset.id), { status: nx }); items.get(row.dataset.id).status = nx; row.dataset.s = nx; row.className = 'sat-item ' + nx; row.querySelector('[data-st="done"]').innerHTML = '<i class="ph' + (nx === 'done' ? '-fill' : '') + ' ph-check-circle"></i>'; row.querySelector('[data-st="skipped"]').classList.toggle('on', nx === 'skipped'); }
      catch(e){ toast(SAT.errText(e), 'ph-warning-circle'); }
      b.disabled = false;
    });
    body.querySelectorAll('[data-go]').forEach(b => b.onclick = () => SAT.startFromPlanItem(items.get(b.dataset.go), b));
    body.querySelectorAll('[data-words]').forEach(b => b.onclick = () => { const it = items.get(b.dataset.words); openModal('<h2>Your word list</h2><p>From the vocabulary questions you missed.</p><div class="sat-vocab">' + ((it.meta_json && it.meta_json.words) || []).map(w => '<div><b>' + esc(w.term || w) + '</b>' + (w.meaning ? '<span class="muted"> · ' + esc(w.meaning) + '</span>' : '') + '</div>').join('') + '</div><div class="acts"><button class="btn acc" onclick="this.closest(\'.modal-bg\').remove()">Done</button></div>'); });
  };
  function itemHtml(it){
    const runnable = it.kind === 'drill' || it.kind === 'retest' || it.kind === 'mock';
    return '<div class="sat-item ' + it.status + '" data-id="' + esc(it.id) + '" data-s="' + it.status + '"><button class="sat-chk" data-st="done" type="button" aria-label="Mark done"><i class="ph' + (it.status === 'done' ? '-fill' : '') + ' ph-check-circle"></i></button><div class="grow"><div class="sat-il"><i class="ph ' + (KIND_ICON[it.kind] || 'ph-circle') + '"></i>' + esc(it.label) + '</div><div class="muted fs-13">' + esc(it.kind) + ' · ' + it.minutes + ' min' + (it.kind === 'lesson' && !(it.meta_json && it.meta_json.recorded) ? ' · outline' : '') + '</div></div>' +
      (runnable && it.status === 'todo' ? '<button class="btn sm acc" data-go="' + esc(it.id) + '" type="button">Start</button>' : '') + (it.kind === 'review' ? '<button class="btn sm line" data-words="' + esc(it.id) + '" type="button">Words</button>' : '') +
      '<button class="btn sm ghost sat-skip' + (it.status === 'skipped' ? ' on' : '') + '" data-st="skipped" type="button" title="Skip this item">Skip</button></div>';
  }

  /* ============================================================ SKILLS */
  P.skills = async function(body, r, alive){
    if(!A.session()) return gate(body, 'Your skill map fills in as you answer questions.');
    const m = await A.get('/api/skills/mastery');
    if(!alive()) return;
    const any = m.domains.some(d => d.n_attempts > 0);
    const seg = band => '<span class="sat-band" role="img" aria-label="' + (band ? 'Band ' + band + ' of 7' : 'No data') + '">' + [1, 2, 3, 4, 5, 6, 7].map(i => '<i class="' + (band && i <= band ? 'on b' + band : '') + '"></i>').join('') + '</span>';
    let h = '<div class="card sat-note"><i class="ph ph-info"></i><div><p class="muted">' + esc(m.note) + (any ? '' : ' Take a mini-mock to start filling this in.') + '</p></div></div><div class="grid g2 mt-16">' +
      m.domains.map(d => '<div class="card"><div class="row jc-between"><h3 class="card-h">' + esc(d.name) + '</h3>' + seg(d.enough_data ? d.band : null) + '</div><div class="muted fs-13 mb-8">' + (d.n_attempts ? d.n_attempts + ' answers' + (d.enough_data ? '' : ', too few to trust') : 'No answers yet') + '</div><div class="sat-skills">' +
        d.skills.map(s => '<div class="sat-skill' + (s.enough_data ? '' : ' faint') + '"><span class="grow">' + esc(s.name) + '</span><span class="muted fs-13">' + (s.n_attempts ? Math.round(s.p_mastery * 100) + '% · ' + s.n_attempts : '·') + '</span>' + seg(s.enough_data ? s.band : null) + '<button class="btn sm ghost" data-skill="' + esc(s.id) + '" type="button" title="Drill this skill">Drill</button></div>').join('') + '</div></div>').join('') + '</div>';
    body.innerHTML = h;
    body.querySelectorAll('[data-skill]').forEach(b => b.onclick = () => SAT.startSession({ kind: 'skill-drill', skill_id: b.dataset.skill }, b));
  };
})();
