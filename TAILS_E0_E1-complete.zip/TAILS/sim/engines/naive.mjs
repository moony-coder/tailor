// Control group: a planner with NO intelligence. It rotates through skills (weighted by test weight), ignores mastery,
// never reviews, never reacts to checkpoints. If the real engine cannot beat this on true score gain, it adds no value.
import cur from './current.mjs';

function naiveDay(inp) {
  const { tax, lessons, bank, settings, progress = {}, mastery } = inp, seen = progress.seen ?? new Set(), done = progress.lessonDone ?? new Set();
  const evidence = [...mastery.values()].filter((m) => m.level === 'skill' && !m.insufficient).length;
  if (evidence < 4 && !progress.diagnosticDone) return cur.buildDay(inp);      // same diagnostic day as the real engine
  const day = progress.day ?? 1, budget = Math.max(settings.minutes_per_day ?? 120, 120), steps = [];
  const taken = new Set(), used = () => steps.reduce((s, x) => s + x.minutes, 0), skills = tax.skills.slice().sort((a, b) => b.weight_on_test - a.weight_on_test || a.id.localeCompare(b.id));
  steps.push({ kind: 'vocab', ref_id: 'vocab', label: 'Vocabulary', minutes: 15 }, { kind: 'mistakes', ref_id: 'mistakes', label: 'Mistakes', minutes: 10 });
  for (let i = 0; used() + 16 < budget && i < skills.length * 2; i++) {
    const s = skills[(day * 3 + i) % skills.length], pool = bank.filter((q) => q.skill_id === s.id && !seen.has(q.id) && !taken.has(q.id)).sort((a, b) => Math.abs(a.difficulty - 3) - Math.abs(b.difficulty - 3) || a.id.localeCompare(b.id)).slice(0, 20);
    if (pool.length < 6) continue;
    const l = lessons.find((x) => x.skill_id === s.id && x.kind === 'concept' && !done.has(x.id));
    if (l) steps.push({ kind: 'lesson', ref_id: l.id, label: l.title, minutes: l.target_minutes ?? 10 });
    pool.forEach((q) => taken.add(q.id));
    steps.push({ kind: 'practice', ref_id: s.id, label: s.name, minutes: Math.ceil(pool.reduce((a, q) => a + (q.est_time_sec ?? 75), 0) / 60 * 1.15), question_ids: pool.map((q) => q.id) });
  }
  steps.push({ kind: 'timed', ref_id: 'timed-set', label: 'Timed set', minutes: 16 });
  return { mode: 'normal', minutes_total: used(), minimum_met: used() >= 120, steps, why: [], pool_alerts: [], focus: [] };
}
export default { ...cur, id: 'naive-rotation', version: 'naive-1', buildDay: naiveDay };
