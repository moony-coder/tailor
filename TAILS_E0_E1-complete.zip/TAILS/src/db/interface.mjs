// Db interface (repository contract). Engine/API code talks ONLY to this; adapters implement it.
//   await db.insert(table, row)               -> row   (throws on duplicate primary/unique key)
//   await db.upsert(table, row)               -> row
//   await db.get(table, id | {pk parts})      -> row | null
//   await db.select(table, where?, opts?)     -> row[]   opts: {orderBy:'col'|['col'], desc, limit}
//   await db.count(table, where?)             -> number
//   await db.update(table, where, patch)      -> rows changed
//   await db.delete(table, where)             -> rows deleted
//   await db.transaction(async (tx) => {...}) -> result
// where = { col: value } or { col: {op:'<'|'<='|'>'|'>='|'!='|'in', value} }.
// Columns named `json` or ending `_json` hold JS objects in code (adapters serialise). Booleans are 0/1.
// Everything is async so a Postgres/Supabase adapter can drop in later without touching engine code.

export const PRIMARY_KEYS = {
  profiles: ['id'], skills: ['id'], micro_skills: ['id'], trap_codes: ['code'], reasons: ['code'],
  questions: ['id'], question_micro_skills: ['question_id', 'micro_skill_id'],
  tests: ['id'], test_modules: ['id'], module_questions: ['module_id', 'position'],
  sessions: ['id'], session_modules: ['session_id', 'module_id'], attempts: ['id'], events: ['id'],
  mistake_reviews: ['id'], second_chances: ['id'], question_reports: ['id'],
  skill_mastery: ['profile_id', 'skill_id', 'micro_skill_id'], skill_mastery_history: ['id'],
  error_profile_snapshots: ['id'], study_plans: ['id'], plan_items: ['id'],
  lessons: ['id'], lesson_progress: ['profile_id', 'lesson_id'], bluebook_imports: ['id'],
  ai_cache: ['key_hash'], ai_usage_log: ['id'],
};
/** UNIQUE constraints mirrored from the SQL schema so MemoryDb behaves like SQL. */
export const UNIQUE_KEYS = { events: [['session_id', 'seq']], mistake_reviews: [['attempt_id']] };
export const isJsonColumn = (c) => c === 'json' || c.endsWith('_json');

export function pkOf(table, rowOrId) {
  const keys = PRIMARY_KEYS[table];
  if (!keys) throw new Error(`unknown table ${table}`);
  if (rowOrId !== null && typeof rowOrId === 'object') return Object.fromEntries(keys.map((k) => [k, rowOrId[k] ?? (k === 'micro_skill_id' ? '' : undefined)]));
  if (keys.length !== 1) throw new Error(`${table} has a composite key; pass an object`);
  return { [keys[0]]: rowOrId };
}
export function cond(v) { return v !== null && typeof v === 'object' && !Array.isArray(v) && 'op' in v ? v : { op: '=', value: v }; }
export function matches(row, where = {}) {
  for (const [col, raw] of Object.entries(where)) {
    const { op, value } = cond(raw);
    const x = row[col] === undefined ? null : row[col];
    if (op === '=') { if (value === null ? x !== null : x !== value) return false; }
    else if (op === '!=') { if (value === null ? x === null : x === value) return false; }
    else if (op === 'in') { if (!value.includes(x)) return false; }
    else if (x === null) return false;
    else if (op === '<') { if (!(x < value)) return false; }
    else if (op === '<=') { if (!(x <= value)) return false; }
    else if (op === '>') { if (!(x > value)) return false; }
    else if (op === '>=') { if (!(x >= value)) return false; }
    else throw new Error(`bad op ${op}`);
  }
  return true;
}
export function sortRows(rows, orderBy, desc = false) {
  if (!orderBy) return rows;
  const cols = Array.isArray(orderBy) ? orderBy : [orderBy], dir = desc ? -1 : 1;
  return rows.slice().sort((a, b) => {
    for (const c of cols) {
      const x = a[c] ?? null, y = b[c] ?? null;
      if (x === y) continue;
      if (x === null) return -dir; if (y === null) return dir;
      return (x < y ? -1 : 1) * dir;
    }
    return 0;
  });
}
