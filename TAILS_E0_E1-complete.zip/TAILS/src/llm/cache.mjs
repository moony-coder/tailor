// Cache first. key = sha256(kind | prompt_version | model | canonical_json(digest)); stored in ai_cache. Bump prompt_version to invalidate.
import { sha256, canonicalJson } from '../util/hash.mjs';
import { iso } from '../util/misc.mjs';

export const cacheKey = (kind, promptVersion, model, digest) => sha256([kind, promptVersion, model, canonicalJson(digest)].join('|'));

export class AiCache {
  constructor(db, now = () => Date.now()) { this.db = db; this.now = now; }
  async get(key) { const r = await this.db.get('ai_cache', key); return r ? { text: r.output_text, model: r.model, created_at: r.created_at } : null; }
  async put({ key, kind, model, prompt_version, digest, text, tokens_in, tokens_out }) {
    await this.db.upsert('ai_cache', { key_hash: key, kind, model, prompt_version, input_digest_json: digest, output_text: text, tokens_in: tokens_in ?? null, tokens_out: tokens_out ?? null, created_at: iso(this.now()) });
  }
  async logUsage({ id, kind, model, tokens_in, tokens_out, latency_ms, status }) {
    await this.db.insert('ai_usage_log', { id, kind, model: model ?? null, tokens_in: tokens_in ?? null, tokens_out: tokens_out ?? null, latency_ms: latency_ms ?? null, status, created_at: iso(this.now()) });
  }
  /** Daily usage for the admin view. */
  async usageToday() {
    const day = iso(this.now()).slice(0, 10), rows = (await this.db.select('ai_usage_log', {})).filter((r) => r.created_at.startsWith(day));
    const by = {};
    for (const r of rows) { const b = (by[r.model ?? 'none'] ??= { calls: 0, ok: 0, tokens_in: 0, tokens_out: 0 }); b.calls++; if (r.status === 'ok') b.ok++; b.tokens_in += r.tokens_in ?? 0; b.tokens_out += r.tokens_out ?? 0; }
    return { day, by_model: by };
  }
}
