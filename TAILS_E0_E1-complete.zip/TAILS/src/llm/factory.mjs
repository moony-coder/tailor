// Builds the runtime LLM bundle from the server environment. The key is read ONLY from env (GROQ_API_KEY by default), never from files in the repo.
// Returns null when no key is configured: every caller already treats "no LLM" as "use the template narrative".
import { OpenAICompatibleProvider } from './provider.mjs';
import { RateLimiter } from './limiter.mjs';

export function createLlm(routing, env = process.env, opts = {}) {
  const p = routing.provider ?? {};
  const keyName = p.api_key_env ?? 'GROQ_API_KEY';
  const apiKey = (env[keyName] ?? '').trim();
  if (!apiKey || env.LLM_DISABLED === '1') return null;
  const provider = opts.provider ?? new OpenAICompatibleProvider({ baseUrl: env.LLM_BASE_URL || p.base_url, apiKey, fetchImpl: opts.fetchImpl, timeoutMs: Number(env.LLM_TIMEOUT_MS) || 30000 });
  const limiter = new RateLimiter(routing.models, { now: opts.now, sleep: opts.sleep });
  return { provider, limiter, sleep: opts.sleep, rand: opts.rand };
}
