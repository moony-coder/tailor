// Vocabulary trainer engine. PURE. Spaced repetition per word (stages in days), daily queue = due first, then new words.
export const VOCAB_CFG = { stages: [0, 1, 3, 7, 14, 30], new_per_day: 10, due_cap: 25 };
export const dayNum = (ms = Date.now()) => Math.floor(ms / 86400000);
/** state: { [word]: { stage, due, lapses, seen } }. Right answer -> next stage; wrong -> back to stage 0 (due again today's session end / tomorrow). */
export function review(state, word, correct, day, cfg = VOCAB_CFG) {
  const cur = state[word] ?? { stage: -1, lapses: 0, seen: 0 }, stage = correct ? Math.min(cur.stage + 1, cfg.stages.length - 1) : 0;
  return { ...state, [word]: { stage, due: day + (correct ? cfg.stages[stage] : 1), lapses: cur.lapses + (correct ? 0 : 1), seen: cur.seen + 1 } };
}
export function buildQueue(words, state, day, cfg = VOCAB_CFG, newCount = cfg.new_per_day) {
  const due = words.filter((w) => state[w.word] && state[w.word].due <= day).sort((a, b) => state[a.word].due - state[b.word].due || a.word.localeCompare(b.word)).slice(0, cfg.due_cap);
  const fresh = words.filter((w) => !state[w.word]).sort((a, b) => a.tier - b.tier || a.word.localeCompare(b.word)).slice(0, newCount);
  return { due, fresh, queue: [...due, ...fresh] };
}
const h = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; };
/** Multiple-choice "what does it mean" with distractors from other words (same part of speech first). Deterministic per word+day. */
export function makeQuestion(word, words, day) {
  const pool = words.filter((w) => w.word !== word.word).sort((a, b) => (b.pos === word.pos) - (a.pos === word.pos) || h(a.word + day) - h(b.word + day));
  const wrong = []; for (const w of pool) { if (wrong.length === 3) break; if (w.meaning !== word.meaning) wrong.push(w.meaning); }
  const choices = [word.meaning, ...wrong].sort((a, b) => h(a + word.word + day) - h(b + word.word + day));
  return { word: word.word, pos: word.pos, choices, answer: choices.indexOf(word.meaning), example: word.example, meaning: word.meaning };
}
export const dueCount = (state, day) => Object.values(state).filter((s) => s.due <= day).length;
