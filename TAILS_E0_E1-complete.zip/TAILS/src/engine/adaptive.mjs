// TAILS adaptive testing (item-level). PURE. 3PL-lite IRT: P = c + (1-c)*sigmoid(theta - b), guessing floor c = 0.25 (4 choices).
// Picks the next question with the most information at the student's current ability, balances skill coverage,
// stops when the estimate is precise enough. Ability maps back to a section score through the bank's own difficulty mix.
import { sectionScore } from './score.mjs';
import { bFromDifficulty } from './itemcal.mjs';
const C = 0.25, SIG0 = 1.5, sig = (x) => 1 / (1 + Math.exp(-x));
export const ADAPT_TEST_CFG = { min_items: 10, max_items: 20, se_stop: 0.55, skill_penalty: 0.12 };
export const prob = (th, b) => C + (1 - C) * sig(th - b);
const info = (th, b) => { const s = sig(th - b), d = (1 - C) * s * (1 - s), p = C + (1 - C) * s; return d * d / (p * (1 - p)); };
export const startState = (section) => ({ section, theta: 0, se: SIG0, asked: [], skillCount: {} });
/** MAP estimate of ability with a weak N(0, 1.5^2) prior so an all-correct or all-wrong run stays finite. */
export function estimate(asked) {
  let th = 0;
  for (let i = 0; i < 25; i++) {
    let g = -th / (SIG0 * SIG0), h = -1 / (SIG0 * SIG0);
    for (const a of asked) { const s = sig(th - a.b), p = C + (1 - C) * s, d = (1 - C) * s * (1 - s); g += (a.correct - p) / (p * (1 - p)) * d; h -= d * d / (p * (1 - p)); }
    const step = g / h; th = Math.max(-4, Math.min(4, th - step)); if (Math.abs(step) < 1e-4) break;
  }
  const I = asked.reduce((s, a) => s + info(th, a.b), 0) + 1 / (SIG0 * SIG0);
  return { theta: th, se: 1 / Math.sqrt(I) };
}
export function nextItem(state, bank, seen = new Set(), bOf = (q) => bFromDifficulty(q.difficulty), cfg = ADAPT_TEST_CFG) {
  const used = new Set(state.asked.map((a) => a.id));
  let best = null, bs = -1;
  for (const q of bank) {
    if (q.section !== state.section || q.format !== 'mcq4' || used.has(q.id) || seen.has(q.id)) continue;
    const sc = info(state.theta, bOf(q)) - cfg.skill_penalty * (state.skillCount[q.skill_id] ?? 0);
    if (sc > bs + 1e-12 || (Math.abs(sc - bs) <= 1e-12 && best && q.id < best.id)) { bs = sc; best = q; }
  }
  return best;
}
export function record(state, q, correct, bOf = (x) => bFromDifficulty(x.difficulty)) {
  const asked = [...state.asked, { id: q.id, skill: q.skill_id, b: bOf(q), correct: correct ? 1 : 0 }], e = estimate(asked);
  return { ...state, asked, theta: e.theta, se: e.se, skillCount: { ...state.skillCount, [q.skill_id]: (state.skillCount[q.skill_id] ?? 0) + 1 } };
}
export const isDone = (state, cfg = ADAPT_TEST_CFG) => state.asked.length >= cfg.max_items || (state.asked.length >= cfg.min_items && state.se <= cfg.se_stop);
/** Ability -> expected accuracy over the section's blueprint (skill weights x the bank's own difficulty mix) -> section score + range. */
export function summarize(state, bank, tax, bOf = (q) => bFromDifficulty(q.difficulty)) {
  const per = new Map(); for (const q of bank) if (q.section === state.section && q.format === 'mcq4') { (per.get(q.skill_id) ?? per.set(q.skill_id, []).get(q.skill_id)).push(bOf(q)); }
  const acc = (th) => { let w = 0, s = 0; for (const sk of tax.skills) { const bs = per.get(sk.id); if (!bs || tax.sectionOf(sk.id) !== state.section) continue; w += sk.weight_on_test; s += sk.weight_on_test * bs.reduce((x, b) => x + prob(th, b), 0) / bs.length; } return w ? s / w : 0.5; };
  const skill = {}; for (const a of state.asked) { const e = skill[a.skill] ?? (skill[a.skill] = { c: 0, n: 0 }); e.n++; e.c += a.correct; }
  return { section: state.section, theta: +state.theta.toFixed(2), se: +state.se.toFixed(2), n: state.asked.length, accuracy: +acc(state.theta).toFixed(3), score: Math.round(sectionScore(acc(state.theta))), low: Math.round(sectionScore(acc(state.theta - 1.28 * state.se))), high: Math.round(sectionScore(acc(state.theta + 1.28 * state.se))), skill };
}
