// Fake students. Each persona = who they are (start/target/time) + how they behave (world parameters).
// start_score is the TRUE score at day 0. `known_score` is what the student tells the engine (null = no test yet).
export const PERSONAS = {
  A_novice:   { label: 'Student A: no test, wants 1400',            start_score: 1050, known_score: null, target: 1400, days: 75, minutes: 120, attend: 0.95, learn: 1.0, speed: 1.0, careless: 0.03 },
  B_1200_1500:{ label: 'Student B: 1200 -> 1500',                    start_score: 1200, known_score: 1200, target: 1500, days: 60, minutes: 130, attend: 0.95, learn: 1.0, speed: 1.0, careless: 0.03,
                skill_profile: { 'M.ALG.SYS': -0.5, 'M.ADV.NLEQ': -0.4, 'M.GT.TRIG': -0.6, 'RW.CS.WIC': -0.4, 'RW.SEC.BND': -0.3 } },
  plateau:    { label: 'Plateau: learning stalls after day 25',      start_score: 1150, known_score: 1150, target: 1450, days: 75, minutes: 120, attend: 0.95, learn: 1.0, plateau_after: 25, plateau_decay: 6, speed: 1.0, careless: 0.03 },
  skipper:    { label: 'Skips days (attends ~55%, in streaks)',       start_score: 1200, known_score: 1200, target: 1450, days: 75, minutes: 120, attend: 0.55, absence_run: 3, learn: 1.0, speed: 1.0, careless: 0.03 },
  careless:   { label: 'Careless: 15% slips, knows the content',      start_score: 1250, known_score: 1250, target: 1500, days: 60, minutes: 120, attend: 0.95, learn: 1.0, speed: 0.9, careless: 0.15 },
  slow:       { label: 'Slow worker: 1.4x time, learns slower',       start_score: 1100, known_score: 1100, target: 1400, days: 90, minutes: 120, attend: 0.9, learn: 0.65, speed: 1.4, careless: 0.04, stamina_drop: 0.45 },
  busy:       { label: 'Busy: 75 min a day',                          start_score: 1200, known_score: 1200, target: 1400, days: 60, minutes: 75, attend: 0.9, learn: 1.0, speed: 1.0, careless: 0.03 },
  // 60 min < the 70-minute diagnostic: tests whether a student with little time can ever get started (E3 finding)
  busy60:     { label: 'Busy60: 60 min a day, no test yet',           start_score: 1100, known_score: null, target: 1350, days: 60, minutes: 60, attend: 0.9, learn: 1.0, speed: 1.0, careless: 0.03 },
  fast:       { label: 'Fast learner (learns 1.8x)',                  start_score: 1250, known_score: 1250, target: 1500, days: 60, minutes: 120, attend: 0.95, learn: 1.8, speed: 0.95, careless: 0.02 },
  // sanity world: the engine's score curve is exactly right and mocks have no noise -> forecast error must be small, or the harness itself is wrong
  oracle:     { label: 'Oracle world (engine curve exact)',           start_score: 1200, known_score: 1200, target: 1450, days: 60, minutes: 120, attend: 1.0, learn: 1.0, speed: 1.0, careless: 0.0, stamina_drop: 0, mock_noise: false, curve: { slope: 1, shift: 0 } },
};
export const DEFAULT_SEED = 20261022;
