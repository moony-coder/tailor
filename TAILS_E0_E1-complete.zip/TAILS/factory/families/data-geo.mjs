// Problem Solving & Data Analysis (M.PSDA.*) and Geometry & Trig (M.GT.*) families.
import { q, Q, nz, byBand, reject, CONTEXT_NAMES, money } from './_kit.mjs';

export default [
  {
    id: 'pct-successive', skill: 'M.PSDA.PCT', levels: [2, 3, 4, 5],
    gen(r, d) {
      const P0 = r.int(4, 40) * 10;
      const up = r.pick([10, 20, 25, 30, 40, 50]), down = r.pick([10, 20, 25, 30, 40, 50]);
      const fin = q(P0).mul(q(100 + up, 100)).mul(q(100 - down, 100));
      if (!fin.isInt) reject('nonint');
      const item = r.pick(['jacket', 'bicycle', 'headphones', 'backpack', 'lamp']);
      const naive = q(P0).mul(q(100 + up - down, 100));
      if (naive.eq(fin)) reject('same');
      const askPct = d >= 5;
      const pctNet = fin.sub(P0).div(P0).mul(100);
      if (askPct && !pctNet.isInt) reject('pct');
      return {
        skill: this.skill, micro: ['M.PSDA.PCT#SUCCESSIVE-CHANGE'], difficulty: d, context: 'finance', drivers: ['MULTI-STEP', ...(askPct ? ['ASK-DIFFERENT-THING'] : [])],
        sig: `${P0},${up},${down},${askPct}`,
        stem: askPct
          ? `A store raised the price of a ${item} by ${up}%. Later, it lowered the new price by ${down}%. The final price is what percent ${pctNet.dec() >= 0 ? 'greater' : 'less'} than the original price?`
          : `A store raised the price of a ${item}, originally ${money(P0)}, by ${up}%. Later, it lowered the new price by ${down}%. What is the final price, in dollars?`,
        answer: askPct ? { value: Math.abs(pctNet.dec()), tex: `$${Math.abs(pctNet.dec())}\\%$` } : { value: fin, tex: `$${fin.tex()}$` },
        wrong: askPct
          ? [{ value: Math.abs(up - down) === Math.abs(pctNet.dec()) ? Math.abs(up - down) + 1 : Math.abs(up - down), tex: `$${Math.abs(up - down) === Math.abs(pctNet.dec()) ? Math.abs(up - down) + 1 : Math.abs(up - down)}\\%$`, trap: 'PERCENT-OF-VS-CHANGE', why: 'Percents of different bases cannot be added or subtracted directly.', think: `+${up}% then -${down}% is ${up - down}%.`, trapPy: `${Math.abs(up - down) === Math.abs(pctNet.dec()) ? Math.abs(up - down) + 1 : Math.abs(up - down)}` },
            { value: 100 - Math.abs(pctNet.dec()), tex: `$${100 - Math.abs(pctNet.dec())}\\%$`, trap: 'ASKED-DIFFERENT', why: 'That is the final price as a percent of the original, not the change.', think: 'Final over original.', trapPy: `100 - ${Math.abs(pctNet.dec())}` },
            { value: up + down, tex: `$${up + down}\\%$`, trap: 'WRONG-FORMULA', why: 'The two changes go in opposite directions.', think: 'Add both percents.', trapPy: `${up + down}` }]
          : [{ value: naive, tex: `$${naive.tex()}$`, trap: 'PERCENT-OF-VS-CHANGE', why: `The ${down}% is taken from the NEW price, so the changes do not simply cancel to ${up - down}%.`, think: `Net change is ${up - down}%.`, trapPy: `${P0}*sp.Rational(${100 + up - down}, 100)` },
            { value: q(P0).mul(q(100 + up, 100)), tex: `$${q(P0).mul(q(100 + up, 100)).tex()}$`, trap: 'STOPPED-EARLY', why: 'This is the price after only the increase.', think: 'Apply the increase.', trapPy: `${P0}*sp.Rational(${100 + up}, 100)` },
            { value: q(P0).mul(q(100 - down, 100)), tex: `$${q(P0).mul(q(100 - down, 100)).tex()}$`, trap: 'IGNORED-CONSTRAINT', why: 'The increase was skipped.', think: 'Final price is the discounted original.', trapPy: `${P0}*sp.Rational(${100 - down}, 100)` }],
        solvePy: `fin = ${P0}*sp.Rational(${100 + up}, 100)*sp.Rational(${100 - down}, 100)\ncomputed = ${askPct ? `abs((fin - ${P0})/${P0}*100)` : 'fin'}`,
        steps: [`After +${up}%: ${P0} × ${(1 + up / 100).toFixed(2)} = ${q(P0).mul(q(100 + up, 100)).tex()}.`, `After -${down}%: × ${(1 - down / 100).toFixed(2)} = ${fin.tex()}.`, ...(askPct ? [`Change: ${pctNet.tex()}% of the original.`] : [])],
        insight: 'Successive percent changes multiply: × (1 + a) × (1 - b).',
      };
    },
  },
  {
    id: 'pct-reverse', skill: 'M.PSDA.PCT', levels: [3, 4, 5],
    gen(r, d) {
      const orig = r.int(8, 60) * 5, off = r.pick([10, 15, 20, 25, 30, 35, 40]);
      const sale = q(orig).mul(q(100 - off, 100)); if (!sale.isInt && !q(sale.n * 100, sale.d).isInt) reject('cents');
      const wrongUp = sale.mul(q(100 + off, 100));
      return {
        skill: this.skill, micro: ['M.PSDA.PCT#REVERSE-PERCENT'], difficulty: d, context: 'finance', drivers: ['HIDDEN-CONSTRAINT'], hypothesis: ['H.PERCENT-BASE'],
        sig: `${orig},${off}`,
        stem: `After a ${off}% discount, the sale price of a pair of shoes is ${money(sale.dec())}. What was the original price, in dollars?`,
        answer: { value: q(orig), tex: `$${orig}$` },
        wrong: [
          { value: wrongUp, tex: `$${wrongUp.dec().toFixed(2)}$`, trap: 'PERCENT-OF-VS-CHANGE', why: `The ${off}% was of the ORIGINAL price, so adding ${off}% of the sale price undershoots.`, think: `Undo the discount by adding ${off}%.`, trapPy: `sp.Rational(${sale.n}, ${sale.d})*sp.Rational(${100 + off}, 100)`, py: `sp.Rational(${sale.n}, ${sale.d})*sp.Rational(${100 + off}, 100)` },
          { value: sale.mul(q(off, 100)), tex: `$${sale.mul(q(off, 100)).dec().toFixed(2)}$`, trap: 'ASKED-DIFFERENT', why: 'That is a percent of the sale price, not the original price.', think: `Find ${off}% of the price.`, trapPy: `sp.Rational(${sale.n}, ${sale.d})*sp.Rational(${off}, 100)`, py: `sp.Rational(${sale.n}, ${sale.d})*sp.Rational(${off}, 100)` },
          { value: sale.add(off), tex: `$${sale.add(off).dec().toFixed(2)}$`, trap: 'UNIT-ERROR', why: `${off}% is not ${off} dollars.`, think: `Add back the ${off} off.`, trapPy: `sp.Rational(${sale.n}, ${sale.d}) + ${off}`, py: `sp.Rational(${sale.n}, ${sale.d}) + ${off}` },
        ],
        solvePy: `p = sp.Symbol('p')\ncomputed = sp.solve(sp.Eq(p*sp.Rational(${100 - off}, 100), sp.Rational(${sale.n}, ${sale.d})), p)[0]`,
        steps: [`Sale = original × ${(1 - off / 100).toFixed(2)}.`, `Original = ${sale.dec()} ÷ ${(1 - off / 100).toFixed(2)} = ${orig}.`],
        insight: 'To undo a percent change, divide by the multiplier, do not reverse the percent.',
      };
    },
  },
  {
    id: 'ratio-units', skill: 'M.PSDA.RATIO', levels: [1, 2, 3, 4, 5],
    gen(r, d) {
      const name = r.pick(CONTEXT_NAMES);
      const rate = r.pick([3, 4, 5, 6, 8, 12, 15]), per = r.pick([2, 4, 5, 10]); // rate units per `per` minutes
      const hrs = byBand(d, [1, r.pick([1, 2, 3]), r.pick([q(3, 2), q(5, 2), q(5, 4)])]);
      const minutes = Q.of(hrs).mul(60);
      const ans = minutes.div(per).mul(rate);
      if (!ans.isInt) reject('nonint');
      const thing = r.pick([['pages', 'prints'], ['liters', 'pumps'], ['bottles', 'fills'], ['boxes', 'packs']]);
      return {
        skill: this.skill, micro: ['M.PSDA.RATIO#UNIT-CONVERSION', 'M.PSDA.RATIO#RATE-TIME'], difficulty: d, context: 'everyday', drivers: d >= 4 ? ['MULTI-STEP'] : [],
        sig: `${rate},${per},${hrs}`,
        stem: `A machine ${thing[1]} ${rate} ${thing[0]} every ${per} minutes. At this rate, how many ${thing[0]} does it ${thing[1].replace(/s$/, '')} in ${Q.of(hrs).isInt ? hrs : Q.of(hrs).dec()} hour${Q.of(hrs).eq(1) ? '' : 's'}?`,
        answer: { value: ans, tex: `$${ans.tex()}$` },
        wrong: [
          { value: Q.of(hrs).div(per).mul(rate), tex: `$${+Q.of(hrs).div(per).mul(rate).dec().toFixed(2)}$`, trap: 'UNIT-ERROR', why: 'Hours were not converted to minutes.', think: 'Use the hours directly.', trapPy: `${Q.of(hrs).py()}/${per}*${rate}`, py: `${Q.of(hrs).py()}/${per}*${rate}` },
          { value: minutes.mul(rate), tex: `$${minutes.mul(rate).tex()}$`, trap: 'IGNORED-CONSTRAINT', why: `The rate is per ${per} minutes, not per minute.`, think: `${rate} per minute.`, trapPy: `${minutes.py()}*${rate}` },
          { value: minutes.div(rate).mul(per), tex: `$${+minutes.div(rate).mul(per).dec().toFixed(2)}$`, trap: 'WRONG-FORMULA', why: 'The ratio was flipped.', think: 'Minutes per item times time.', trapPy: `${minutes.py()}/${rate}*${per}`, py: `${minutes.py()}/${rate}*${per}` },
        ],
        solvePy: `computed = ${Q.of(hrs).py()}*60/${per}*${rate}`,
        steps: [`${Q.of(hrs).dec()} h = ${minutes.dec()} minutes.`, `${minutes.dec()} ÷ ${per} = ${minutes.div(per).tex()} groups of ${per} minutes.`, `× ${rate} = ${ans.tex()}.`],
        insight: 'Convert units first; write the rate as a fraction and let the units cancel.',
      };
    },
  },
  {
    id: 'onevar-mean', skill: 'M.PSDA.ONEVAR', levels: [2, 3, 4, 5],
    gen(r, d) {
      const n = r.int(4, 9), mean = r.int(60, 92);
      const newScore = r.int(40, 100), newN = n + 1;
      const total = n * mean + newScore;
      const nm = q(total, newN);
      if (!nm.isInt && d <= 3) reject('nonint');
      const ask = d >= 5 ? 'needed' : 'new';
      const target = mean + r.int(1, 4);
      const need = target * newN - n * mean;
      if (ask === 'needed' && (need > 100 || need < 0)) reject('impossible');
      return {
        skill: this.skill, micro: ['M.PSDA.ONEVAR#MEAN-MEDIAN-MODE'], difficulty: d, context: 'statistics', drivers: ['MULTI-STEP'],
        sig: `${n},${mean},${ask === 'new' ? newScore : target}`,
        stem: ask === 'new'
          ? `The mean score of ${n} quizzes is ${mean}. After one more quiz with a score of ${newScore}, what is the mean score of all ${newN} quizzes?`
          : `The mean score of ${n} quizzes is ${mean}. What score on the next quiz would make the mean of all ${newN} quizzes exactly ${target}?`,
        spr: true,
        answer: { value: ask === 'new' ? nm : q(need) },
        wrong: [{ trap: 'WRONG-FORMULA', tex: `${(mean + (ask === 'new' ? newScore : target)) / 2}`, think: 'Average the two numbers.', why: 'The old mean represents many quizzes.' }],
        solvePy: ask === 'new' ? `computed = sp.Rational(${n}*${mean} + ${newScore}, ${newN})` : `s = sp.Symbol('s')\ncomputed = sp.solve(sp.Eq((${n}*${mean} + s)/${newN}, ${target}), s)[0]`,
        steps: [`Old total = ${n} × ${mean} = ${n * mean}.`, ask === 'new' ? `New total = ${total}; mean = ${total}/${newN} = ${nm.tex()}.` : `Needed total = ${newN} × ${target} = ${target * newN}; score = ${target * newN} - ${n * mean} = ${need}.`],
        insight: 'Work with totals: total = mean × count.',
      };
    },
  },
  {
    id: 'prob-table', skill: 'M.PSDA.PROB', levels: [2, 3, 4, 5],
    gen(r, d) {
      const A = r.int(12, 60), B = r.int(12, 60), C = r.int(12, 60), D = r.int(12, 60);
      const rows = ['Juniors', 'Seniors'], cols = ['Prefer online', 'Prefer in person'];
      const tot = A + B + C + D;
      const cond = d >= 3;
      const ans = cond ? q(C, C + D) : q(A, tot);
      const w = cond
        ? [{ value: q(C, tot), tex: `$${q(C, tot).tex()}$`, trap: 'IGNORED-CONSTRAINT', why: 'This divides by everyone, but the question is limited to seniors.', think: 'Seniors who prefer online over all students.', trapPy: `sp.Rational(${C}, ${tot})` },
          { value: q(C, A + C), tex: `$${q(C, A + C).tex()}$`, trap: 'WRONG-VARIABLE', why: 'This conditions on "prefer online" instead of on "senior".', think: 'Out of the online group.', trapPy: `sp.Rational(${C}, ${A + C})` },
          { value: q(D, C + D), tex: `$${q(D, C + D).tex()}$`, trap: 'MISREAD-GRAPH', why: 'That is the seniors who prefer in person.', think: 'Wrong cell in the right row.', trapPy: `sp.Rational(${D}, ${C + D})` }]
        : [{ value: q(A, A + B), tex: `$${q(A, A + B).tex()}$`, trap: 'IGNORED-CONSTRAINT', why: 'The question asks out of all students, not only juniors.', think: 'Out of juniors.', trapPy: `sp.Rational(${A}, ${A + B})` },
          { value: q(A, A + C), tex: `$${q(A, A + C).tex()}$`, trap: 'WRONG-VARIABLE', why: 'This divides by only the online group.', think: 'Out of the online group.', trapPy: `sp.Rational(${A}, ${A + C})` },
          { value: q(A + B, tot), tex: `$${q(A + B, tot).tex()}$`, trap: 'MISREAD-GRAPH', why: 'That counts all juniors, not juniors who prefer online.', think: 'Juniors over total.', trapPy: `sp.Rational(${A + B}, ${tot})` }];
      if (new Set([ans, ...w.map((x) => x.value)].map((x) => x.tex())).size < 4) reject('coll');
      return {
        skill: this.skill, micro: [cond ? 'M.PSDA.PROB#TABLE-CONDITIONAL' : 'M.PSDA.PROB#SIMPLE-PROB'], difficulty: d, context: 'statistics', drivers: ['DATA-COMPLEXITY'],
        sig: `${A},${B},${C},${D},${cond}`,
        visual: { kind: 'table', data: { columns: ['', ...cols, 'Total'], rows: [[rows[0], A, B, A + B], [rows[1], C, D, C + D], ['Total', A + C, B + D, tot]] }, alt_text: `Table: Juniors ${A} online, ${B} in person; Seniors ${C} online, ${D} in person; total ${tot}.` },
        stem: cond
          ? 'The table shows how a group of students prefers to attend a review course. If a senior from the group is selected at random, what is the probability that the student prefers online?'
          : 'The table shows how a group of students prefers to attend a review course. If one student is selected at random from the whole group, what is the probability that the student is a junior who prefers online?',
        answer: { value: ans, tex: `$${ans.tex()}$` }, wrong: w,
        solvePy: `computed = sp.Rational(${cond ? C : A}, ${cond ? C + D : tot})`,
        steps: [cond ? `Given "senior": restrict to the seniors row, total ${C + D}.` : `Whole group: total ${tot}.`, `Favorable: ${cond ? C : A}.`, `Probability: ${ans.tex()}.`],
        insight: '"Given X" or "if an X is selected" means the denominator is the X total only.',
      };
    },
  },
  {
    id: 'gt-pythag', skill: 'M.GT.TRIG', levels: [1, 2, 3, 4],
    gen(r, d) {
      const T = r.pick([[3, 4, 5], [5, 12, 13], [8, 15, 17], [7, 24, 25], [20, 21, 29], [9, 40, 41]]);
      const k = r.int(1, byBand(d, [3, 4, 6]));
      const [a, b, c] = T.map((v) => v * k);
      const askLeg = d >= 3;
      const ans = askLeg ? b : c;
      const w = askLeg
        ? [{ value: Math.round(Math.sqrt(a * a + c * c) * 100) / 100, tex: `$\\sqrt{${a * a + c * c}}$`, trap: 'WRONG-FORMULA', why: 'The hypotenuse was treated as a leg; subtract squares to find a leg.', think: 'Always add the squares.', py: `sp.sqrt(${a * a + c * c})`, trapPy: `sp.sqrt(${a}**2 + ${c}**2)` },
          { value: c - a, tex: `$${c - a}$`, trap: 'WRONG-FORMULA', why: 'Side lengths do not subtract directly; their squares do.', think: 'Hypotenuse minus the leg.', trapPy: `${c} - ${a}` },
          { value: c * c - a * a, tex: `$${c * c - a * a}$`, trap: 'STOPPED-EARLY', why: 'This is b², the square root was not taken.', think: 'c² - a² is the answer.', trapPy: `${c}**2 - ${a}**2` }]
        : [{ value: a + b, tex: `$${a + b}$`, trap: 'WRONG-FORMULA', why: 'The legs do not add to the hypotenuse.', think: 'Hypotenuse = leg + leg.', trapPy: `${a} + ${b}` },
          { value: a * a + b * b, tex: `$${a * a + b * b}$`, trap: 'STOPPED-EARLY', why: 'This is c²; take the square root.', think: 'a² + b² is c.', trapPy: `${a}**2 + ${b}**2` },
          { value: Math.round(Math.sqrt(b * b - a * a) * 1000) / 1000, tex: `$\\sqrt{${b * b - a * a}}$`, trap: 'WRONG-FORMULA', why: 'Subtracting squares finds a leg, not the hypotenuse.', think: 'Subtract the squares.', py: `sp.sqrt(${b * b - a * a})`, trapPy: `sp.sqrt(${b}**2 - ${a}**2)` }];
      return {
        skill: this.skill, micro: ['M.GT.TRIG#PYTHAGOREAN'], difficulty: d, context: 'geometry', drivers: [],
        sig: `${a},${b},${c},${askLeg}`,
        stem: askLeg ? `In right triangle $ABC$, angle $C$ is a right angle. If $AB = ${c}$ and $BC = ${a}$, what is the length of $AC$?` : `In right triangle $ABC$, angle $C$ is a right angle. If $AC = ${b}$ and $BC = ${a}$, what is the length of $AB$?`,
        answer: { value: ans, tex: `$${ans}$` }, wrong: w,
        solvePy: `s = sp.Symbol('s', positive=True)\ncomputed = ${askLeg ? `sp.solve(sp.Eq(${a}**2 + s**2, ${c}**2), s)[0]` : `sp.solve(sp.Eq(${a}**2 + ${b}**2, s**2), s)[0]`}`,
        steps: askLeg ? [`AB is the hypotenuse (opposite the right angle).`, `AC² = ${c}² - ${a}² = ${c * c - a * a}.`, `AC = ${b}.`] : [`AB² = ${a}² + ${b}² = ${c * c}.`, `AB = ${c}.`],
        insight: 'Hypotenuse is opposite the right angle; c² = a² + b². Spot triples like 3-4-5 and 5-12-13 to skip the math.',
      };
    },
  },
  {
    id: 'gt-circle-sector', skill: 'M.GT.CIRCLE', levels: [2, 3, 4, 5],
    gen(r, d) {
      const R = r.int(2, 12), ang = r.pick([30, 40, 45, 60, 72, 90, 120, 135, 150, 180, 240, 270]);
      const ask = byBand(d, ['arc', 'area', r.pick(['area', 'arc'])]);
      const frac = q(ang, 360);
      const val = ask === 'arc' ? frac.mul(2 * R) : frac.mul(R * R); // times pi
      const piTex = (v) => (v.eq(1) ? '\\pi' : v.isInt ? `${v.n}\\pi` : `\\frac{${v.n}\\pi}{${v.d}}`);
      const piPy = (v) => `${v.py()}*sp.pi`;
      const other = ask === 'arc' ? frac.mul(R * R) : frac.mul(2 * R);
      const full = ask === 'arc' ? q(2 * R) : q(R * R);
      const rad = d >= 5;
      const angTex = rad ? `\\frac{${frac.mul(2).n === 1 ? '' : frac.mul(2).n}\\pi}{${frac.mul(2).d}}` : `${ang}^\\circ`;
      const W = [[other, 'WRONG-FORMULA', ask === 'arc' ? 'This is the sector area, not the arc length.' : 'This is the arc length, not the sector area.', 'Arc and sector use the same formula.'],
        [full, 'STOPPED-EARLY', 'This is for the whole circle; take the fraction for the central angle.', 'Use the full-circle formula.'],
        [frac.mul(ask === 'arc' ? R : 2 * R * R), 'DOUBLE-HALF', 'A factor of 2 was misplaced.', ask === 'arc' ? 'Arc = angle fraction × πr.' : 'Area = angle fraction × 2πr².']];
      const all = [val, ...W.map((w) => w[0])].map((v) => `${v.n}/${v.d}`);
      if (new Set(all).size < 4) reject('coll');
      return {
        skill: this.skill, micro: ['M.GT.CIRCLE#ARC-SECTOR', ...(rad ? [] : [])], difficulty: d, context: 'geometry', drivers: rad ? ['REPRESENTATION-SWITCH'] : [],
        sig: `${R},${ang},${ask},${rad}`,
        stem: `A circle has a radius of ${R}. A central angle measuring $${angTex}$${rad ? ' radians' : ''} intercepts an arc of the circle. What is the ${ask === 'arc' ? 'length of the arc' : 'area of the sector formed by the central angle'}?`,
        answer: { value: val, key_value: `${val.n}/${val.d}`, tex: `$${piTex(val)}$`, py: piPy(val) },
        wrong: W.map(([v, trap, why, think]) => ({ value: v, key_value: `${v.n}/${v.d}`, tex: `$${piTex(v)}$`, trap, why, think, py: piPy(v), trapPy: piPy(v) })),
        solvePy: `r = ${R}\ntheta = sp.Rational(${ang}, 180)*sp.pi\ncomputed = ${ask === 'arc' ? 'r*theta' : 'sp.Rational(1, 2)*r**2*theta'}`,
        steps: [`The angle is ${frac.tex()} of a full turn.`, `${ask === 'arc' ? `Circumference = ${2 * R}π` : `Area = ${R * R}π`}; × ${frac.tex()} = ${piTex(val)}.`],
        insight: 'Part of a circle = (angle / 360°) × whole. Arc uses 2πr, sector uses πr².',
      };
    },
  },
  {
    id: 'gt-volume-scale', skill: 'M.GT.AREAVOL', levels: [2, 3, 4, 5],
    gen(r, d) {
      const k = byBand(d, [2, r.pick([2, 3]), r.pick([3, 4, q(3, 2), q(5, 2)])]);
      const V = r.int(2, 30) * 4;
      const K = Q.of(k);
      const ans = q(V).mul(K).mul(K).mul(K);
      const shape = r.pick(['cube', 'rectangular prism', 'cylinder', 'cone']);
      return {
        skill: this.skill, micro: ['M.GT.AREAVOL#SCALE-FACTOR', 'M.GT.AREAVOL#VOLUME-FORMULAS'], difficulty: d, context: 'geometry', drivers: ['HIDDEN-CONSTRAINT'],
        sig: `${V},${K.n}/${K.d},${shape}`,
        stem: `A ${shape} has a volume of ${V} cubic centimeters. Each linear dimension of the ${shape} is multiplied by ${K.isInt ? K.n : K.dec()} to make a larger, similar ${shape}. What is the volume, in cubic centimeters, of the larger ${shape}?`,
        answer: { value: ans, tex: `$${+ans.dec().toFixed(3)}$` },
        wrong: [
          { value: q(V).mul(K), tex: `$${+q(V).mul(K).dec().toFixed(3)}$`, trap: 'WRONG-FORMULA', why: 'Volume scales by the CUBE of the length factor.', think: 'Scale the volume by the same factor.', trapPy: `${V}*${K.py()}`, py: `${V}*${K.py()}` },
          { value: q(V).mul(K).mul(K), tex: `$${+q(V).mul(K).mul(K).dec().toFixed(3)}$`, trap: 'WRONG-FORMULA', why: 'Squaring the factor works for area, not volume.', think: 'Square the factor.', trapPy: `${V}*${K.py()}**2`, py: `${V}*${K.py()}**2` },
          { value: q(V).mul(K).mul(3), tex: `$${+q(V).mul(K).mul(3).dec().toFixed(3)}$`, trap: 'ARITH-SLIP', why: 'Multiplying by 3 is not cubing.', think: 'Three dimensions, so times 3k.', trapPy: `${V}*${K.py()}*3`, py: `${V}*${K.py()}*3` },
        ],
        solvePy: `k = ${K.py()}\ncomputed = ${V}*k**3`,
        steps: [`Lengths × ${K.dec()} ⇒ volume × ${K.dec()}³ = ${K.mul(K).mul(K).dec()}.`, `${V} × ${K.mul(K).mul(K).dec()} = ${ans.dec()}.`],
        insight: 'Scale factor k: lengths × k, areas × k², volumes × k³.',
      };
    },
  },
];
