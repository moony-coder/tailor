// Provider interface: chat({model, messages, response_format?, max_completion_tokens, temperature, reasoning_effort?}) -> {text, tokens_in, tokens_out}
// Errors carry .status and .retryAfterMs so the caller can back off. API key comes ONLY from the server environment; it is never logged.
export class LlmError extends Error {
  constructor(message, { status = 0, retryAfterMs = null, retryable = false } = {}) { super(message); this.name = 'LlmError'; this.status = status; this.retryAfterMs = retryAfterMs; this.retryable = retryable; }
}

export class OpenAICompatibleProvider {
  constructor({ baseUrl, apiKey, fetchImpl = globalThis.fetch, timeoutMs = 30000 }) {
    if (!apiKey) throw new LlmError('no API key configured', { status: 401 });
    this.baseUrl = baseUrl.replace(/\/$/, ''); this.fetch = fetchImpl; this.timeoutMs = timeoutMs; this._key = apiKey; this.name = 'openai-compatible';
  }
  toJSON() { return { name: this.name, baseUrl: this.baseUrl }; }       // never serialise the key
  async chat({ model, messages, response_format, max_completion_tokens, temperature, reasoning_effort }) {
    const body = { model, messages, max_completion_tokens, temperature };
    if (response_format) body.response_format = response_format;
    if (reasoning_effort) body.reasoning_effort = reasoning_effort;
    const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), this.timeoutMs);
    let res;
    try {
      res = await this.fetch(`${this.baseUrl}/chat/completions`, { method: 'POST', signal: ctl.signal, headers: { 'content-type': 'application/json', authorization: `Bearer ${this._key}` }, body: JSON.stringify(body) });
    } catch (e) { throw new LlmError(`network error: ${e.name === 'AbortError' ? 'timeout' : e.message}`, { retryable: true }); }
    finally { clearTimeout(timer); }
    if (!res.ok) {
      const ra = res.headers?.get?.('retry-after'); let retryAfterMs = null;
      if (ra != null && ra !== '') { const s = Number(ra); retryAfterMs = Number.isFinite(s) ? Math.round(s * 1000) : Math.max(0, Date.parse(ra) - Date.now()) || null; }
      throw new LlmError(`HTTP ${res.status}`, { status: res.status, retryAfterMs, retryable: res.status === 429 || res.status >= 500 });
    }
    const j = await res.json();
    const text = j.choices?.[0]?.message?.content ?? '';
    return { text, tokens_in: j.usage?.prompt_tokens ?? null, tokens_out: j.usage?.completion_tokens ?? null, model: j.model ?? model };
  }

  /** Speech-to-text (OpenAI-compatible /audio/transcriptions). `file` = { bytes: Uint8Array|Buffer, name, type } */
  async transcribe({ model, file, language = 'en', response_format = 'verbose_json' }) {
    const form = new FormData();
    form.append('model', model); form.append('language', language); form.append('response_format', response_format); form.append('temperature', '0');
    form.append('file', new Blob([file.bytes], { type: file.type ?? 'audio/mpeg' }), file.name ?? 'audio.mp3');
    const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), 120000);
    let res;
    try { res = await this.fetch(`${this.baseUrl}/audio/transcriptions`, { method: 'POST', signal: ctl.signal, headers: { authorization: `Bearer ${this._key}` }, body: form }); }
    catch (e) { throw new LlmError(`network error: ${e.name === 'AbortError' ? 'timeout' : e.message}`, { retryable: true }); }
    finally { clearTimeout(timer); }
    if (!res.ok) { const ra = Number(res.headers?.get?.('retry-after')); throw new LlmError(`HTTP ${res.status}`, { status: res.status, retryAfterMs: Number.isFinite(ra) ? ra * 1000 : null, retryable: res.status === 429 || res.status >= 500 }); }
    const j = await res.json();
    return { text: j.text ?? '', segments: (j.segments ?? []).map((s) => ({ start: s.start, end: s.end, text: s.text })), duration: j.duration ?? null, model };
  }
}

/** Deterministic provider for tests. script = array of responses/errors consumed in order, or a function(req, n). */
export class MockProvider {
  constructor(script = null) { this.script = script; this.calls = []; this.name = 'mock'; }
  async chat(req) {
    this.calls.push(req); const n = this.calls.length;
    let step = typeof this.script === 'function' ? this.script(req, n) : this.script?.[n - 1];
    if (step === undefined) step = { text: defaultMockJson(req) };
    if (step instanceof Error) throw step;
    if (typeof step === 'string') step = { text: step };
    return { tokens_in: 400, tokens_out: 200, model: req.model, ...step };
  }
}
function defaultMockJson(req) {
  // echo something valid for the narrative schema using only numbers found in the user message
  let d = {}; try { d = JSON.parse(req.messages.at(-1).content.replace(/^[^{]*/, '')); } catch { /* ignore */ }
  const l = d.top_levers?.[0];
  return JSON.stringify({ headline: 'Mock audit: your next step is clear.', snapshot: 'This is a deterministic mock narrative.', levers: l ? [{ skill: l.skill, why: `Mastery is ${l.p}.`, fix: 'Do the drill.' }] : [], behaviors: [], plan_note: 'Follow the plan.', caution: 'Mock output.' });
}
