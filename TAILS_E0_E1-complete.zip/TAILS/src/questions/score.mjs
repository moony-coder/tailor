// Scoring + safe views of questions. Pure functions.
import { checkSpr } from '../util/misc.mjs';

export function isCorrect(q, chosen) {
  if (chosen === null || chosen === undefined || chosen === '') return false;
  if (q.format === 'spr') return checkSpr(chosen, q.spr.accepted);
  return q.choices.some((c) => c.key === chosen && c.is_correct);
}
export const correctKey = (q) => (q.format === 'spr' ? q.spr.accepted[0] : q.choices.find((c) => c.is_correct).key);
export function trapOf(q, chosen) {
  if (q.format === 'spr' || !chosen) return null;
  return q.choices.find((c) => c.key === chosen)?.trap_code ?? null;
}

/** What the test-taker may see: no keys, no trap codes, no explanations. */
export function publicView(q, position) {
  return {
    id: q.id, position, section: q.section, format: q.format, stem: q.stem, passage: q.passage ? { text: q.passage.text, type: q.passage.type } : null,
    visual: q.visual, choices: q.format === 'spr' ? null : q.choices.map((c) => ({ key: c.key, text: c.text })),
  };
}
/** What the student sees in review (after the attempt). */
export function reviewView(q, chosen) {
  return {
    ...publicView(q), correct: correctKey(q), chosen: chosen ?? null, chosen_why_wrong: q.format === 'spr' ? null : (q.choices.find((c) => c.key === chosen)?.why_wrong ?? null),
    solution: q.solution, choices_explained: q.format === 'spr' ? null : q.choices.map((c) => ({ key: c.key, text: c.text, is_correct: c.is_correct, note: c.is_correct ? c.why_right : c.why_wrong })),
  };
}

/** Weighted routing score: easy 1, medium 1.5, hard 2 points. Returns fraction of possible weighted points. */
export function weightedScore(items, weights) {
  let got = 0, max = 0;
  for (const { band, correct } of items) { const w = weights[band] ?? 1; max += w; if (correct) got += w; }
  return max ? got / max : 0;
}
