// Bluebook import: LABELS ONLY (test number, section, module, which question numbers were wrong, domain as shown). Never question text.
// Writes the same `attempts` rows as native tests (source='bluebook'); no telemetry => lower confidence.
import { makeId, iso } from '../util/misc.mjs';

export const BLUEBOOK_TESTS = ['4', '5', '6', '7', '8', '9', '10', '11', 'other'];
const MODULE_SIZE = { rw: 27, math: 22 };
const LEVEL_RE = /^[1-7]$/;
const NO_TEXT = /[\r\n]|.{41,}/;      // short labels only: anything long or multi-line is refused as "looks like pasted question text"

/**
 * input = { profile_id, test_number, section:'rw'|'math', module:1|2, wrong:[{n, domain, skill_id?, chosen?, ran_out_of_time?}],
 *           unsure_right?:[n], domain_levels?:{ 'RW.CS':1-7, ... }, notes? }
 */
export function validateBluebookInput(input, tax) {
  const errors = [], warnings = [];
  const i = input ?? {};
  if (!i.profile_id) errors.push('profile_id is required');
  if (!BLUEBOOK_TESTS.includes(String(i.test_number))) errors.push(`test_number must be one of ${BLUEBOOK_TESTS.join(', ')}`);
  if (!['rw', 'math'].includes(i.section)) errors.push("section must be 'rw' or 'math'");
  if (![1, 2].includes(i.module)) errors.push('module must be 1 or 2');
  const size = MODULE_SIZE[i.section];
  if (i.notes != null && (typeof i.notes !== 'string' || NO_TEXT.test(i.notes))) errors.push('notes must be a single short line (do not paste question text)');
  if (!Array.isArray(i.wrong)) errors.push('wrong must be an array');
  else {
    const seen = new Set();
    i.wrong.forEach((w, k) => {
      const at = `wrong[${k}]`;
      if (!Number.isInteger(w?.n) || w.n < 1 || (size && w.n > size)) errors.push(`${at}.n must be an integer 1..${size ?? '?'}`);
      else if (seen.has(w.n)) errors.push(`${at}.n ${w.n} is listed twice`); else seen.add(w.n);
      const d = w?.domain && tax.domainById.get(w.domain);
      if (!d) errors.push(`${at}.domain is required and must be a known domain id`);
      else if (i.section && d.section !== i.section) errors.push(`${at}.domain ${w.domain} is not a ${i.section} domain`);
      if (w?.skill_id) { const s = tax.skillById.get(w.skill_id); if (!s) errors.push(`${at}.skill_id unknown`); else if (w.domain && s.domain !== w.domain) errors.push(`${at}.skill_id ${w.skill_id} is not in ${w.domain}`); }
      if (w?.chosen != null && !/^[A-D]$/.test(String(w.chosen))) errors.push(`${at}.chosen must be A-D`);
      for (const key of Object.keys(w ?? {})) if (!['n', 'domain', 'skill_id', 'chosen', 'ran_out_of_time'].includes(key)) errors.push(`${at}.${key} is not allowed (labels only)`);
    });
    if (i.wrong.length > (size ?? 27)) errors.push('more wrong answers than questions in the module');
  }
  if (i.unsure_right != null) {
    if (!Array.isArray(i.unsure_right) || i.unsure_right.some((n) => !Number.isInteger(n) || n < 1 || n > (size ?? 27))) errors.push('unsure_right must be question numbers');
    else if (i.wrong?.some?.((w) => i.unsure_right.includes(w.n))) errors.push('a question cannot be both wrong and unsure-right');
  }
  if (i.domain_levels != null) {
    for (const [d, lv] of Object.entries(i.domain_levels)) {
      if (!tax.domainById.has(d)) errors.push(`domain_levels: unknown domain ${d}`); else if (!LEVEL_RE.test(String(lv))) errors.push(`domain_levels.${d} must be 1..7`);
    }
  }
  if (!errors.length && i.wrong.length === size) warnings.push('every question is marked wrong: please double-check');
  return { ok: !errors.length, errors, warnings };
}

/**
 * Builds attempt rows (not yet persisted). Right answers are anonymous in Bluebook score details, so they are created with an ESTIMATED domain:
 *   the module has size questions; (size - wrong) are right; we spread them across domains by official domain share minus the wrong ones already named.
 */
export function buildBluebookAttempts(input, ctx, { sessionId, now = ctx.now() }) {
  const tax = ctx.tax, size = MODULE_SIZE[input.section];
  const moduleId = `bb-${input.test_number}-${input.section}-m${input.module}`;
  const mk = (n, p) => ({
    id: makeId('a_', now), session_id: sessionId, profile_id: input.profile_id, question_id: null,
    question_ref: `BB-T${input.test_number}-${input.section === 'rw' ? 'RW' : 'M'}-M${input.module}-Q${n}`,
    position: n, module_id: moduleId, module_index: input.module, module_size: size, section: input.section,
    est_time_sec: input.section === 'rw' ? 60 : 85, telemetry: 0, source: 'bluebook', created_at: iso(now), unanswered: 0, answer_changes: 0, changed_right_to_wrong: 0,
    first_response_ms: null, total_ms: null, active_ms: null, visits: null, trap_code: null, domain_estimated: 0, ran_out_of_time: 0, flagged: 0, micro_skill_ids_json: [], ...p,
  });
  const rows = [];
  const wrongN = new Set(input.wrong.map((w) => w.n));
  for (const w of input.wrong) {
    rows.push(mk(w.n, { domain: w.domain, skill_id: w.skill_id ?? null, difficulty: 3, chosen: w.chosen ?? null, is_correct: 0, ran_out_of_time: w.ran_out_of_time ? 1 : 0, unanswered: w.ran_out_of_time && !w.chosen ? 1 : 0 }));
  }
  // estimate domains of the right answers
  const domains = tax.domains.filter((d) => d.section === input.section);
  const nRight = size - input.wrong.length;
  const named = Object.fromEntries(domains.map((d) => [d.id, input.wrong.filter((w) => w.domain === d.id).length]));
  const exp = Object.fromEntries(domains.map((d) => [d.id, Math.max(0, Math.round(d.share * size) - named[d.id])]));
  const slots = [];
  const order = domains.map((d) => d.id);
  let guard = 0;
  while (slots.length < nRight && guard++ < 1000) {
    let progressed = false;
    for (const d of order) if (slots.length < nRight && exp[d] > 0) { slots.push(d); exp[d]--; progressed = true; }
    if (!progressed) { for (const d of order) if (slots.length < nRight) slots.push(d); }
  }
  const rightNumbers = Array.from({ length: size }, (_, k) => k + 1).filter((n) => !wrongN.has(n));
  rightNumbers.forEach((n, k) => rows.push(mk(n, { domain: slots[k] ?? order[0], skill_id: null, difficulty: 3, is_correct: 1, domain_estimated: 1, flagged: input.unsure_right?.includes(n) ? 1 : 0 })));
  rows.sort((a, b) => a.position - b.position);
  return { rows, moduleId };
}

/** External practice links (links only). */
export function studyLinks(weakDomains, tax) {
  return {
    note: 'Links only. Use College Board and Khan Academy for official explanations; do not paste question text into this app.',
    college_board_question_bank: 'https://satsuite.collegeboard.org/practice/practice-questions',
    khan_academy_sat: 'https://www.khanacademy.org/test-prep/v2-sat',
    domains: weakDomains.map((d) => ({ domain: d, name: tax.skillName(d) })),
  };
}
