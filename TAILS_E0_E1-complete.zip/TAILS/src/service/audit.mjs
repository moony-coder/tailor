// GET /api/audit/:sessionId : digest + report (+ narrative). Report numbers come from code; the narrative is optional wording on top.
import { round } from '../util/misc.mjs';
import { generateNarrative } from '../llm/narrative.mjs';
import { readinessBand } from '../engine/mastery.mjs';
import { buildAuditInputs } from './analysis.mjs';
import { deepAudit } from '../engine/deep.mjs';
import { lessonsFor } from '../engine/plan.mjs';
import { vocabularyGaps } from './vocab.mjs';
import { scoreBySection } from './sessions.mjs';
import { getSession, assertOwner } from './shared.mjs';

const CAUSE_LABEL = { CARELESS: 'Careless execution', CONTENT_GAP: 'Content gap', VOCAB: 'Vocabulary', COMPREHENSION: 'Comprehension', STRATEGY: 'Strategy / traps', TIMING: 'Timing', OVERTHINK: 'Overthinking', GUESS: 'Guessing', TOOL: 'Tool use (calculator)', UNKNOWN: 'Unclear', REPORT: 'Question reported' };

export async function getAudit(ctx, sessionId, actor, { force = false } = {}) {
  const { db, tax } = ctx, cfg = ctx.config.thresholds;
  const s = await getSession(db, sessionId); assertOwner(s, actor);
  const inp = await buildAuditInputs(ctx, s.profile_id, sessionId);
  const { session, digest, levers, mastery, mods, all } = inp;
  if (!session.length) return { session_id: sessionId, status: s.status, ready: false, message: 'No answers recorded for this session yet.' };
  const llm = ctx.llm ?? {};
  const out = await generateNarrative(digest, { db, provider: llm.provider ?? null, limiter: llm.limiter, routing: ctx.config.routing, now: ctx.now, sleep: llm.sleep, rand: llm.rand }, { force });
  const wrong = session.filter((a) => !a.is_correct);
  const mix = {}; for (const a of wrong) mix[a.root_cause ?? 'UNKNOWN'] = (mix[a.root_cause ?? 'UNKNOWN'] ?? 0) + 1;
  const domains = [];
  for (const sec of ['rw', 'math']) for (const d of tax.domains.filter((x) => x.section === sec)) {
    const rows = session.filter((a) => a.domain === d.id); if (!rows.length) continue;
    const m = mastery.get(`${d.id}|`);
    domains.push({ domain: d.id, name: d.name, section: sec, correct: rows.filter((a) => a.is_correct).length, total: rows.length, estimated_total: rows.some((a) => a.domain_estimated), band: m ? readinessBand(m.p, cfg.mastery.readiness_band_cutpoints) : null });
  }
  const bb = s.source === 'bluebook', hasTel = session.some((a) => a.telemetry);
  const vocab = vocabularyGaps(ctx, all, { sessionId });
  const deep = deepAudit(await db.select('sessions', { profile_id: s.profile_id }), all, cfg);
  const bank = ctx.bank.reduce((c, q) => (c[q.status] = (c[q.status] ?? 0) + 1, c), {});
  const trackedQs = new Set(session.map((a) => a.question_id).filter(Boolean));
  const unapproved = [...trackedQs].filter((id) => ctx.qById.get(id)?.status !== 'approved').length;
  return {
    session_id: sessionId, profile_id: s.profile_id, ready: true, kind: s.kind, source: s.source, status: s.status, started_at: s.started_at,
    digest, narrative: out.narrative, narrative_source: out.source, narrative_model: out.model ?? null, narrative_note: out.reason ?? null,
    report: {
      scores: scoreBySection(session), domains, modules: mods,
      levers: levers.map((l) => ({ skill_id: l.skill_id, level: l.level, name: l.name, p: l.p, n: l.n, main_cause: l.main_cause, cause_label: CAUSE_LABEL[l.main_cause], gain: l.gain, cost_minutes: l.cost_minutes, low_data: !!l.insufficient, provisional: !!l.provisional, traps: l.traps, lessons: lessonsFor(ctx.lessons, { skill_id: l.level === 'domain' ? null : l.skill_id, cause: l.main_cause, trapCodes: (l.traps ?? []).map((t) => t.code) }).slice(0, 3).map((x) => ({ id: x.id, title: x.title, recorded: !!x.video_ref, minutes: x.target_minutes ?? null })) })),
      error_mix: Object.entries(mix).sort((a, b) => b[1] - a[1]).map(([cause, n]) => ({ cause, label: CAUSE_LABEL[cause] ?? cause, n, share: round(n / Math.max(1, wrong.length)) })),
      behaviors: inp.behaviorsTop, trend: digest.trend,
      pacing: { avg_time_vs_target: digest.pacing.avg_time_vs_target, late_decay: digest.pacing.late_decay, rushes_late: digest.pacing.rushes_late, unanswered: digest.pacing.unanswered, modules: mods.map((m) => ({ section: m.section, module_index: m.module_index, size: m.size, correct: m.correct, unanswered: m.unanswered, used_fraction: m.used_fraction, expired: m.expired })) },
      traps: (digest.top_traps ?? []).map((t) => ({ code: t.code, share: t.share, name: tax.trapByCode.get(t.code)?.name ?? t.code, meaning: tax.trapByCode.get(t.code)?.description ?? null, fix_lesson: ctx.lessons.find((x) => x.trap_code === t.code && x.kind === 'fixit')?.id ?? null })),
      vocab_gaps: vocab,
      unsure: { low_data_skills: (digest.data_quality.low_data_skills ?? []).map((id) => ({ skill_id: id, name: tax.skillName(id) })), low_confidence_share: digest.data_quality.low_confidence_share, n_attempts: digest.data_quality.n_attempts, notes: [...(bb ? ['Bluebook labels have no timing or answer-change data.'] : []), ...(!hasTel && !bb ? ['No timing data was recorded.'] : []), ...(session.length < 20 ? ['Fewer than 20 questions in this session: treat the ranking as a first guess.'] : [])] },
      deep,
      mistakes: wrong.slice(0, 40).map((a) => ({ attempt_id: a.id, position: a.position, skill_id: a.skill_id, domain: a.domain, root_cause: a.root_cause, confidence: a.root_cause_conf, trap_code: a.trap_code })),
    },
    confidence: {
      label: bb ? 'lower' : hasTel ? 'standard' : 'reduced',
      why: bb ? 'Imported from Bluebook labels: no timing or answer-change data, right answers have estimated domains only.' : hasTel ? 'Built from your answers plus timing and answer-change data.' : 'No timing data was recorded for this session.',
    },
    honesty: {
      verification: `${unapproved} of ${trackedQs.size} questions in this session are machine-verified but not yet teacher-approved.`,
      bank_status_counts: bank, scores: 'Raw counts only. This is not a predicted SAT score.',
      disclaimer: 'SAT prep tool. Not affiliated with College Board. SAT is a registered trademark of College Board.',
    },
  };
}
