// npm test -> engine release gate + bank integrity + simulation gate (hard invariants + no regression vs sim/baseline.json).
import { spawnSync } from 'node:child_process';
const steps = [['engine tests', ['test/engine.test.mjs']], ['bank integrity', ['tools/bank-check.mjs']], ['simulation gate', ['sim/run.mjs', '--gate']]];
let bad = 0;
for (const [name, args] of steps) {
  const r = spawnSync('node', args, { encoding: 'utf8', cwd: new URL('..', import.meta.url).pathname });
  const ok = r.status === 0; if (!ok) bad++;
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}`);
  if (!ok) console.log(r.stdout.split('\n').slice(0, 30).join('\n') + r.stderr);
}
process.exit(bad ? 1 : 0);
