// Browser loader: ONE file, the same data.json bundle the Node loader reads. `url` is where the static host serves it.
import { fromBundle } from './bundle.mjs';
export async function loadAllBrowser(url = './data.json') {
  const r = await fetch(url); if (!r.ok) throw new Error(`${url}: ${r.status}`);
  return fromBundle(await r.json());
}
