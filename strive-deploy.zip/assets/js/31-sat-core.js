/* ============================================================
   TAILORED PRACTICE: shared helpers, the hub view (#v-sat), hash routing, nav entry, dashboard card.
   Pages live in 33-sat-pages.js, the test-taker in 32-sat-exam.js.
   ============================================================ */
(function(){
  'use strict';
  const A = window.SATAPI; if(!A) return;
  const SAT = window.SAT = { pages: {}, api: A };

  /* ---------- text + math (KaTeX is vendored, assets/vendor/katex) ---------- */
  /* "$5 and $6" is money, not math: a real math span never starts or ends with a space */
  const isMath = tex => !!tex && !/^\s|\s$/.test(tex);
  function tex2html(tex){
    if(window.katex){ try{ return window.katex.renderToString(tex, { throwOnError: false, output: 'htmlAndMathml' }); }catch(e){} }
    return '<span class="mathfb">' + esc(tex) + '</span>';
  }
  /** Escapes HTML and renders $...$ as math. A "$" that is a price stays a price. */
  SAT.fmt = function(src){
    const s = String(src == null ? '' : src); let out = '', i = 0;
    while(i < s.length){
      const c = s[i];
      if(c === '\\' && s[i + 1] === '$'){ out += '$'; i += 2; continue; }
      if(c === '$'){
        let j = i + 1; while(j < s.length && !(s[j] === '$' && s[j - 1] !== '\\')) j++;
        if(j < s.length){ const tex = s.slice(i + 1, j); if(isMath(tex)){ out += tex2html(tex); i = j + 1; continue; } }
        out += '$'; i++; continue;
      }
      let k = i; while(k < s.length && s[k] !== '$' && !(s[k] === '\\' && s[k + 1] === '$')) k++;
      out += esc(s.slice(i, k)); i = k;
    }
    return out;
  };

  /* ---------- visuals (tables, one geometry figure) ---------- */
  function geoSvg(d, alt){
    if(d && d.shape === 'right-triangle-with-altitude' && d.AB > 0 && d.BC > 0){
      const s = 150 / Math.max(d.AB, d.BC), B = [40, 190], Aa = [40, 190 - d.AB * s], C = [40 + d.BC * s, 190];
      const dx = C[0] - Aa[0], dy = C[1] - Aa[1], t = ((B[0] - Aa[0]) * dx + (B[1] - Aa[1]) * dy) / (dx * dx + dy * dy), D = [Aa[0] + t * dx, Aa[1] + t * dy];
      const L = (p, x, y, txt) => '<text x="' + (p[0] + x) + '" y="' + (p[1] + y) + '">' + txt + '</text>';
      return '<svg class="sat-geo" viewBox="0 0 ' + (C[0] + 40) + ' 230" role="img" aria-label="' + esc(alt || 'Right triangle') + '">' +
        '<polygon points="' + [Aa, B, C].map(p => p.join(',')).join(' ') + '" fill="none" stroke="currentColor" stroke-width="2"/>' +
        '<line x1="' + B[0] + '" y1="' + B[1] + '" x2="' + D[0].toFixed(1) + '" y2="' + D[1].toFixed(1) + '" stroke="currentColor" stroke-width="2" stroke-dasharray="5 4"/>' +
        '<path d="M' + (B[0] + 12) + ' ' + B[1] + ' v-12 h-12" fill="none" stroke="currentColor" stroke-width="1.6"/>' +
        L(Aa, -22, 4, 'A') + L(B, -22, 16, 'B') + L(C, 6, 16, 'C') + L(D, 8, -4, 'D') +
        L([B[0], (Aa[1] + B[1]) / 2], -26, 4, d.AB) + L([(B[0] + C[0]) / 2, B[1]], -4, 20, d.BC) + '</svg>';
    }
    return null;
  }
  SAT.visual = function(v){
    if(!v) return '';
    if(v.kind === 'table' && v.data && Array.isArray(v.data.columns)){
      return '<figure class="sat-fig"><table class="sat-tbl" aria-label="' + esc(v.alt_text || 'Table') + '"><thead><tr>' + v.data.columns.map(c => '<th>' + SAT.fmt(c) + '</th>').join('') + '</tr></thead><tbody>' +
        (v.data.rows || []).map(r => '<tr>' + r.map(c => '<td>' + SAT.fmt(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></figure>';
    }
    if(v.kind === 'geometry'){ const g = geoSvg(v.data, v.alt_text); if(g) return '<figure class="sat-fig">' + g + '<figcaption class="sr">' + esc(v.alt_text || '') + '</figcaption></figure>'; }
    return '<figure class="sat-fig"><div class="sat-alt"><i class="ph ph-image"></i>' + esc(v.alt_text || 'Figure') + '</div></figure>';
  };
  /** A reading passage: "Text 1 / Text 2" headers bold, notes keep their bullet lines. */
  SAT.passage = function(p){
    if(!p || !p.text) return '';
    return String(p.text).split('\n').map(l => /^Text \d$/.test(l.trim()) ? '<b class="ptag">' + esc(l.trim()) + '</b>' : SAT.fmt(l)).join('\n');
  };

  /* ---------- small UI helpers ---------- */
  SAT.pct = x => x == null ? '—' : Math.round(x * 100) + '%';
  SAT.errText = e => e && e.code === 'network' ? 'Something went wrong starting this. Reload the page and try again.' : e && e.code === 'timeout' ? 'That took too long. Try again in a moment.' : (e && e.message) || 'Something went wrong.';
  SAT.busy = (btn, on, label) => { if(!btn) return; if(on){ btn.dataset.l = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<i class="ph ph-circle-notch spin"></i>' + (label || 'Working'); } else { btn.disabled = false; if(btn.dataset.l) btn.innerHTML = btn.dataset.l; } };
  SAT.loading = (msg) => '<div class="card sat-load" role="status"><i class="ph ph-circle-notch spin"></i><span>' + esc(msg || 'Loading') + '</span></div>';
  SAT.errorCard = (e, retryId) => '<div class="card sat-err" role="alert"><i class="ph ph-warning-circle"></i><div><b>' + esc(SAT.errText(e)) + '</b>' + (retryId ? '<div class="mt-8"><button class="btn sm" id="' + retryId + '"><i class="ph ph-arrow-clockwise"></i>Try again</button></div>' : '') + '</div></div>';
  SAT.confirm = function(title, text, okLabel, danger){
    return new Promise(res => {
      const m = openModal('<h2>' + esc(title) + '</h2><p>' + esc(text) + '</p><div class="acts"><button class="btn ghost" data-x="0">Cancel</button><button class="btn ' + (danger ? 'bad' : 'acc') + '" data-x="1">' + esc(okLabel || 'OK') + '</button></div>');
      m.querySelectorAll('[data-x]').forEach(b => b.onclick = () => { m.remove(); res(b.dataset.x === '1'); });
    });
  };
  /* ---------- starting sessions (shared by Start, Plan, Audit, Skills pages) ---------- */
  SAT.startSession = async function(body, btn){
    SAT.busy(btn, true, 'Building');
    try{
      const r = await A.post('/api/sessions', body);
      A.setActive({ sid: r.session_id, kind: r.kind, at: Date.now() });
      await SAT.exam.begin(r);
      return r;
    }catch(e){
      if(e.code === 'bank_too_small') toast('The question bank cannot fill that test yet. Try a mini-mock or a skill drill.', 'ph-warning-circle');
      else if(e.code !== 'no_profile') toast(SAT.errText(e), 'ph-warning-circle');
      return null;
    }finally{ SAT.busy(btn, false); }
  };
  /** Plan item -> session request. */
  SAT.startFromPlanItem = function(it, btn){
    const m = it.meta_json || {};
    if(it.kind === 'mock') return SAT.startSession({ kind: 'mini-mock', plan_item_id: it.id }, btn);
    if(it.kind === 'drill' || it.kind === 'retest'){
      const body = { kind: it.kind === 'retest' ? 'spaced-retest' : 'skill-drill', size: m.size || undefined, plan_item_id: it.id };
      if(m.scope === 'domain' || !m.skill_id) body.domain = m.domain || m.skill_id; else body.skill_id = m.skill_id;
      return SAT.startSession(body, btn);
    }
    return null;
  };

  /* ---------- hub view + routing ---------- */
  const TABS = [
    ['start', 'ph-target', 'Practice'], ['audit', 'ph-compass', 'Audit'], ['review', 'ph-chat-circle-text', 'Review'],
    ['plan', 'ph-calendar-check', '7-day plan'], ['skills', 'ph-chart-bar', 'Skills'], ['import', 'ph-upload-simple', 'Bluebook import']
  ];
  const TITLES = {
    start: ['Tailored practice', 'Short tests built around your weak spots. After each one you get a plain-language audit of why you lose points and what to do about it.'],
    audit: ['Your audit', 'Why the points were lost, which fixes pay off most, and what we are not sure about yet.'],
    review: ['Mistake review', 'One tap per question: why did you miss it? That is the data timing alone cannot give us.'],
    plan: ['7-day plan', 'Built from your last audit. 20 to 40 minutes a day, then a retest to see if the fix held.'],
    skills: ['Skill map', 'Readiness by skill, from 1 to 7. Grey means we have too few answers to trust the number.'],
    import: ['Bluebook import', 'Took an official Bluebook practice test? Enter which question numbers you missed and get the same audit.']
  };
  let renderToken = 0;
  const route = () => { const m = /^#sat(?:\/([a-z]+))?(?:\/([\w.-]+))?/.exec(location.hash); return m ? { page: TABS.some(t => t[0] === m[1]) ? m[1] : 'start', id: m[2] || null } : { page: 'start', id: null }; };
  SAT.route = route;
  SAT.open = function(page, id){
    const h = '#sat/' + page + (id ? '/' + id : '');
    if(location.hash !== h) history.pushState(null, '', h);
    if(typeof currentView !== 'undefined' && currentView === 'sat') SAT.render(); else go('sat');
  };
  SAT.render = async function(){
    const body = $('#satBody'); if(!body) return;
    const r = route(), my = ++renderToken, tabs = $('#satTabs'), t = TITLES[r.page];
    $('#satH1').textContent = t[0]; $('#satSub').textContent = t[1];
    tabs.innerHTML = TABS.map(x => '<button type="button" data-p="' + x[0] + '" class="' + (x[0] === r.page ? 'on' : '') + '"><i class="ph ' + x[1] + '"></i><span>' + x[2] + '</span></button>').join('');
    tabs.querySelectorAll('button').forEach(b => b.onclick = () => SAT.open(b.dataset.p));
    body.innerHTML = SAT.loading();
    const page = SAT.pages[r.page];
    try{ await page(body, r, () => my === renderToken); }
    catch(e){ if(my !== renderToken) return; body.innerHTML = SAT.errorCard(e, 'satRetry'); const b = $('#satRetry'); if(b) b.onclick = () => SAT.render(); }
    if(my === renderToken && typeof observeReveals === 'function') observeReveals();
  };

  /* ---------- wiring into the existing shell (nothing is replaced, only added) ---------- */
  if(typeof VIEWS !== 'undefined' && VIEWS.indexOf('sat') < 0) VIEWS.push('sat');
  if(typeof MORE_VIEWS !== 'undefined' && MORE_VIEWS.indexOf('sat') < 0) MORE_VIEWS.push('sat');
  const _go = go;
  go = function(name){
    if(name !== 'sat' && /^#sat/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search);
    else if(name === 'sat' && !/^#sat/.test(location.hash)) history.replaceState(null, '', '#sat/start');
    const r = _go(name);
    if(name === 'sat') SAT.render();
    return r;
  };
  addEventListener('hashchange', () => { if(/^#sat/.test(location.hash)){ if(typeof currentView !== 'undefined' && currentView === 'sat') SAT.render(); else go('sat'); } });

  function mountDom(){
    if($('#v-sat')) return;
    const main = $('#main'); if(!main) return;
    const sec = document.createElement('section');
    sec.className = 'view hidden'; sec.id = 'v-sat';
    sec.innerHTML = '<div class="pagehead"><div><h1 id="satH1">Tailored practice</h1><p id="satSub"></p></div><img class="pm" data-img="m_think" src="assets/img/mark.png" data-mood="think" alt=""></div>' +
      '<div class="segs sat-tabs" id="satTabs" role="tablist" aria-label="Tailored practice sections"></div><div id="satBody" aria-live="polite"></div>' +
      '<p class="sat-disc muted">SAT prep tool. Not affiliated with College Board. SAT is a registered trademark of College Board. Scores here are raw counts on practice questions, not a predicted SAT score.</p>';
    main.appendChild(sec);
    if(typeof hydrate === 'function') hydrate(sec);
    const nav = $('#nav');
    if(nav && !nav.querySelector('[data-v="sat"]')){
      const b = document.createElement('button'); b.dataset.v = 'sat'; b.className = 'sat-nav hidden'; b.innerHTML = '<i class="ph ph-compass"></i>Tailored';
      b.addEventListener('click', () => go('sat'));
      const after = nav.querySelector('[data-v="practice"]'); after ? after.after(b) : nav.prepend(b);
    }
    const ms = document.querySelector('#moreSheet .ms-card');
    if(ms && !ms.querySelector('[data-v="sat"]')){
      const b = document.createElement('button'); b.dataset.v = 'sat'; b.className = 'sat-nav hidden'; b.innerHTML = '<i class="ph ph-compass"></i>Tailored practice';
      b.addEventListener('click', () => go('sat')); ms.prepend(b);
    }
  }

  /* ---------- dashboard card ---------- */
  async function dashCard(){
    const host = $('#satDashCard'); if(!host) return;
    host.classList.toggle('hidden', !A.online); if(!A.online) return;
    const cta = '<div class="sdc-main"><span class="tag acc"><i class="ph ph-compass"></i>Tailored audit</span><h3>Find out why you lose points</h3><p class="muted">Take a 22-question mini-mock. You get a personal audit, a 7-day plan, and drills built from your own mistakes.</p></div><div class="sdc-act"><button class="btn acc" id="sdcGo">Start mini-mock<i class="ph ph-arrow-right"></i></button></div>';
    const draw = html => { host.innerHTML = html; const g = $('#sdcGo'); if(g) g.onclick = () => SAT.open('start'); host.querySelectorAll('[data-open]').forEach(b => b.onclick = () => SAT.open(b.dataset.open, b.dataset.id || null)); };
    if(!A.session()){ draw(cta); return; }
    try{
      const [ss, pl] = await Promise.all([A.get('/api/sessions', { noReauth: true }), A.get('/api/plan', { noReauth: true })]);
      const done = (ss.sessions || []).filter(s => s.status === 'finished' && /mock|bluebook/.test(s.kind));
      if(!done.length){ draw(cta); return; }
      const last = done[0], au = await A.get('/api/audit/' + last.id, { noReauth: true });
      const lv = au.report && au.report.levers && au.report.levers[0];
      const plan = pl.plan, today = plan ? Math.min(plan.horizon_days, Math.max(1, Math.floor((Date.now() - Date.parse(plan.created_at)) / 86400000) + 1)) : 0;
      const items = plan ? (plan.days[today - 1] || { items: [] }).items.filter(i => i.status === 'todo').slice(0, 3) : [];
      draw('<div class="sdc-main"><span class="tag acc"><i class="ph ph-compass"></i>Your latest audit</span><h3>' + esc((au.narrative && au.narrative.headline) || 'Your audit is ready') + '</h3>' +
        (lv ? '<p class="muted">Biggest lever: <b>' + esc(lv.name) + '</b> (' + esc(lv.cause_label || '') + ')' + (lv.provisional ? ', first guess' : '') + '.</p>' : '') +
        '<div class="row mt-8"><button class="btn acc sm" data-open="audit" data-id="' + esc(last.id) + '">Open audit<i class="ph ph-arrow-right"></i></button><button class="btn line sm" data-open="review" data-id="' + esc(last.id) + '">Review mistakes</button></div></div>' +
        '<div class="sdc-today"><b>Today in your plan' + (plan ? ' (day ' + today + ')' : '') + '</b>' + (items.length ? '<ul>' + items.map(i => '<li><i class="ph ph-' + (i.kind === 'lesson' ? 'book-open-text' : 'target') + '"></i>' + esc(i.label) + ' <span class="muted">' + i.minutes + ' min</span></li>').join('') + '</ul>' : '<p class="muted">Nothing left for today.</p>') + '<button class="btn ghost sm" data-open="plan">Open plan</button></div>');
    }catch(e){ draw(cta); }
  }
  function mountCard(){
    if($('#satDashCard')) return;
    const dash = $('#v-dash'), hero = dash && dash.querySelector('.herocard'); if(!hero) return;
    const c = document.createElement('div'); c.className = 'card sat-dash hidden'; c.id = 'satDashCard';
    hero.after(c);
  }
  const _ad = animateDash;
  animateDash = function(){ _ad(); dashCard(); };

  function boot(){
    mountDom(); mountCard();
    document.addEventListener('sat:ready', () => {
      dashCard();
      if(A.online && /^#sat/.test(location.hash) && typeof currentView !== 'undefined' && currentView !== 'sat') go('sat');
      else if(A.online && typeof currentView !== 'undefined' && currentView === 'sat') SAT.render();
      else if(!A.online && typeof currentView !== 'undefined' && currentView === 'sat') go('dash');
      if(A.online && SAT.exam && SAT.exam.offerResume) SAT.exam.offerResume();
    });
    if(A.health !== null || A.online) document.dispatchEvent(new CustomEvent('sat:ready', { detail: { online: A.online } }));
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
