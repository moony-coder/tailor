// sim/report.mjs : turns a simulation run into a readable report (sim/out/report.md + sim/out/summary.json).
//   node sim/run.mjs --report [--seeds 4] [--exposure all]
// Sections: scoreboard (metric vs the target each later phase must reach), per-world persona tables,
// control comparison (does the engine beat "rotate through skills and never think"?), and a sample day-by-day trace.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { METRICS } from './metrics.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const WORLDS = { never: 'Bank as it is today (an item is gone after one use)', recycle: 'Blueprint recycle rule (wrong answers return after 14 days, right ones after 45)', unlimited: 'Unlimited fresh items (isolates planner and score model from content volume)' };
const mean = (a) => { const v = a.filter((x) => x != null); return v.length ? v.reduce((s, x) => s + x, 0) / v.length : null; };
const f = (v, d = 1) => (v == null ? '-' : typeof v === 'number' ? String(+v.toFixed(d)) : String(v));
const table = (head, rows) => `| ${head.join(' | ')} |\n|${head.map((_, i) => (i ? '---:' : '---')).join('|')}|\n${rows.map((r) => `| ${r.join(' | ')} |`).join('\n')}\n`;
const meets = (m, v) => (m.target == null || v == null ? null : m.dir === 'lower' ? v <= m.target : v >= m.target);

export async function writeReport({ data, engine, results, seeds, personas, runMatrix, naive }) {
  const modes = ['never', 'recycle', 'unlimited'], res = { ...results };
  for (const m of modes) if (!res[m]) res[m] = await runMatrix({ data, engine, personas, seeds, exposure: m });
  const out = [];
  out.push(`# TAILS simulation report`, '', `Engine: **${engine.version}** (${engine.id}) | personas: ${personas.length} | seeds per persona: ${seeds} | days per run: 60 to 90`, '',
    '> The simulated student (learning speed, forgetting, scoring curve) is an **assumption**, not data. The report measures the engine against a fixed, explicit world so changes can be compared. See `docs/SIMULATION.md`.', '');

  // ---- scoreboard ----
  out.push('## 1. Scoreboard: where the engine stands against the targets', '', 'Average over all personas (including `busy60`, which stalls on the diagnostic and so inflates "diagnostic repeated"). "Target" is what the later phases (E3 to E7) must reach; blank = no target yet.', '');
  const rows = [];
  for (const m of METRICS) {
    const cell = (ex) => { const v = mean(Object.values(res[ex].agg).map((a) => a[m.key])); return v == null ? '-' : `${f(v, Math.abs(v) < 1 ? 2 : 1)}${meets(m, v) === true ? ' ✓' : meets(m, v) === false ? ' ✗' : ''}`; };
    rows.push([m.label, m.dir === 'lower' ? 'lower' : 'higher', m.target ?? '', cell('never'), cell('recycle'), cell('unlimited')]);
  }
  out.push(table(['Metric', 'Better', 'Target', 'Today\'s bank', 'Recycle rule', 'Unlimited items'], rows));

  // ---- per world ----
  out.push('## 2. Per persona', '');
  const COLS = [['start_true', 'Start'], ['end_true', 'End'], ['target', 'Target'], ['gain', 'Gain'], ['gap_closed', 'Gap closed'], ['nowcast_early', 'Err early'], ['nowcast_mature', 'Err mature'], ['forecast_mae_mid', 'Fcst err 15-35d'], ['short_share', 'Short days'], ['diag_repeat', 'Extra diag days'], ['mastery_rho', 'Skill rank rho']];
  for (const ex of modes) {
    out.push(`### ${WORLDS[ex]}`, '', table(['Persona', ...COLS.map((c) => c[1])], Object.entries(res[ex].agg).map(([k, a]) => [k, ...COLS.map(([key]) => f(a[key], key === 'gap_closed' || key === 'short_share' || key === 'mastery_rho' ? 2 : 0))])));
  }

  // ---- control ----
  out.push('## 3. Does the engine beat a planner with no intelligence?', '', 'Control = rotate through skills by test weight, ignore mastery, no spaced review, no checkpoint reaction. Same lessons, same bank, same students. Positive = the real engine gains more.', '');
  const ctrlRows = [];
  for (const ex of modes) {
    const c = await runMatrix({ data, engine: naive, personas, seeds, exposure: ex });
    for (const k of Object.keys(res[ex].agg)) { const a = res[ex].agg[k], b = c.agg[k]; ctrlRows.push([ex, k, f(a.gain, 0), f(b.gain, 0), f(a.gain - b.gain, 0)]); }
  }
  out.push(table(['World', 'Persona', 'Engine gain', 'Control gain', 'Engine minus control'], ctrlRows));
  for (const ex of modes) { const d = ctrlRows.filter((r) => r[0] === ex && Number(r[3]) > 0).map((r) => Number(r[4])); out.push(`- **${ex}**: engine ahead in ${d.filter((x) => x > 0).length} of ${d.length} personas, average difference ${f(mean(d), 0)} points.`); }
  out.push('');

  // ---- findings ----
  out.push('## 4. Findings (computed from this run)', '');
  const A = res.never.agg, U = res.unlimited.agg, F = [];
  const avg = (agg, k) => mean(Object.values(agg).map((a) => a[k]));
  if (avg(A, 'short_share') > 0.2) F.push(`The bank runs out: ${f(avg(A, 'short_share') * 100, 0)}% of normal days are shorter than the 2-hour promise with today's bank (${f(avg(U, 'short_share') * 100, 0)}% with unlimited items).`);
  const diagAvg = mean(Object.entries(A).filter(([k]) => k !== 'busy60').map(([, a]) => a.diag_repeat));
  if (diagAvg > 0.5) F.push(`The diagnostic comes back ${f(diagAvg, 1)} extra time(s) on average (busy60 excluded, it is reported separately).`);
  if (A.busy60 && A.busy60.diag_repeat > 5) F.push(`A student with 60 minutes a day never finishes the 70-minute diagnostic (${f(A.busy60.diag_repeat, 0)} diagnostic days, gain ${f(A.busy60.gain, 0)}).`);
  if (avg(U, 'nowcast_early') > 100) F.push(`Early score predictions are far off (mean error ${f(avg(U, 'nowcast_early'), 0)} points before day 14) because the model ignores the score the student already knows; after day 14 the error is ${f(avg(U, 'nowcast_mature'), 0)}.`);
  if (U.oracle) F.push(`Oracle world (engine curve exactly right, no mock noise): mature error ${f(U.oracle.nowcast_mature, 0)} points. In this world the engine's own curve is exact, so what remains is score-model error (mastery estimate and item-difficulty effects), not world mismatch.`);
  if (avg(A, 'over_avail_share') > 0.1) F.push(`${f(avg(A, 'over_avail_share') * 100, 0)}% of planned days are longer than the time the student actually has (stated minutes are floored at 120).`);
  const behind = Object.keys(A).filter((k) => ctrlRows.find((r) => r[0] === 'never' && r[1] === k && Number(r[4]) < -3));
  if (behind.length) F.push(`With today's bank the control planner out-gains the real engine for: ${behind.join(', ')}.`);
  out.push(...(F.length ? F.map((x) => `- ${x}`) : ['- none above the report thresholds']), '');

  // ---- trace ----
  const tr = res.never.traces.find((t) => /Student B/.test(t.persona)) ?? res.never.traces[0];
  out.push(`## 5. Sample trace: ${tr.persona} (seed ${tr.seed}, today's bank)`, '', table(['Day', 'Mode', 'Planned min', 'Available', 'Questions', 'Focus (top skills)', 'True score'],
    tr.days.filter((d) => d.attended && !d.mock && d.mode).slice(0, 14).map((d) => [d.day, d.mode, d.planned_min, d.avail_min, d.q, (d.focus ?? []).slice(0, 3).join(', '), d.truth])));
  out.push(`Mocks: ${tr.mocks.map((m) => `day ${m.day}: predicted ${m.predicted}, actual ${m.actual}, true ${m.true_now}`).join(' | ')}`, '');

  fs.mkdirSync(path.join(HERE, 'out'), { recursive: true });
  const file = path.join(HERE, 'out', 'report.md');
  fs.writeFileSync(file, out.join('\n'));
  fs.writeFileSync(path.join(HERE, 'out', 'summary.json'), JSON.stringify({ engine: engine.version, seeds, worlds: Object.fromEntries(modes.map((m) => [m, res[m].agg])) }, null, 1));
  return file;
}
