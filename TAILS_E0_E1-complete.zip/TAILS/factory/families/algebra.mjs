// Algebra families (M.ALG.*). Each gen(r, d) returns a spec for build(); throw Reject to resample.
import { q, Q, lin, nz, byBand, reject, CONTEXT_NAMES, money } from './_kit.mjs';

const X = "x = sp.Symbol('x')";

export default [
  // ------------------------------------------------------------------ LIN1
  {
    id: 'lin1-solve', skill: 'M.ALG.LIN1', levels: [1, 2, 3, 4],
    gen(r, d) {
      // a(x + b) + c = e x + f   -> x
      const a = byBand(d, [r.int(2, 5), r.int(2, 9), r.int(3, 12)]) * (d >= 4 ? r.sign() : 1);
      const b = nz(r, -9, 9), c = nz(r, -15, 15);
      let e = d <= 1 ? 0 : nz(r, -6, 8); if (e === a) e = a + 1;
      const xs = d <= 3 ? q(nz(r, -12, 12)) : q(nz(r, -20, 20), r.pick([2, 3, 4, 5]));
      const f = q(a).mul(xs.add(b)).add(c).sub(q(e).mul(xs));
      if (!f.isInt) reject('f not integer');
      const L = d <= 1 ? `${a}(x ${b < 0 ? '-' : '+'} ${Math.abs(b)}) ${c < 0 ? '-' : '+'} ${Math.abs(c)}` : `${a}(x ${b < 0 ? '-' : '+'} ${Math.abs(b)}) ${c < 0 ? '-' : '+'} ${Math.abs(c)}`;
      const R = lin([[e, 'x'], [f, '']]);
      // mistakes
      const noDist = q(f.n).sub(a * 1 * 0).sub(b + c).div(a - e);           // a x + b + c = e x + f  (forgot to distribute)
      const signSlip = f.sub(a * b).add(c).div(a - e);                      // moved c with wrong sign
      const addE = f.sub(a * b).sub(c).div(a + e);                          // added e x instead of subtracting
      return {
        skill: this.skill, micro: ['M.ALG.LIN1#SOLVE-BASIC', ...(d >= 4 ? ['M.ALG.LIN1#FRACTIONS-DISTRIBUTE'] : [])], difficulty: d,
        drivers: d >= 4 ? ['MULTI-STEP'] : [], sig: `${a},${b},${c},${e},${f.n}`,
        stem: `$${L} = ${R}$\n\nWhat value of $x$ is the solution to the given equation?`,
        answer: { value: xs, tex: `$${xs.tex()}$`, why: `Distribute, collect the x-terms on one side and constants on the other: x = ${xs.spr()}.` },
        wrong: [
          { value: noDist, tex: `$${noDist.tex()}$`, trap: 'ORDER-OF-OPS', why: `This comes from multiplying only x by ${a} and not ${b}.`, think: `${a}(x + ${b}) is ${a}x + ${b}.`, trapPy: `sp.solve(sp.Eq(${a}*x + (${b}) + (${c}), ${e}*x + ${f.n}), x)[0]` },
          { value: signSlip, tex: `$${signSlip.tex()}$`, trap: 'SIGN-ERROR', why: `The constant ${c} was moved across the equals sign without changing its sign.`, think: 'Move the number over as it is.', trapPy: `sp.Rational(${f.n} - ${a * b} + (${c}), ${a - e})` },
          { value: addE, tex: `$${addE.tex()}$`, trap: 'SIGN-ERROR', why: `${e}x was added to the left side instead of subtracted.`, think: 'Bring the x-term over and add it.', trapPy: `sp.Rational(${f.n} - ${a * b} - (${c}), ${a + e})` },
        ],
        solvePy: `${X}\ncomputed = sp.solve(sp.Eq(${a}*(x + (${b})) + (${c}), ${e}*x + ${f.n}), x)[0]`,
        steps: [`Distribute: ${lin([[a, 'x'], [a * b + c, '']])} = ${R}.`, `Collect x-terms: ${lin([[a - e, 'x']])} = ${f.sub(a * b + c).tex()}.`, `Divide: x = ${xs.spr()}.`],
        insight: 'Distribute first, then undo addition before multiplication.', fast: 'Type both sides into Desmos as y = left and y = right; the x-coordinate of the intersection is the answer.',
        desmos: `Graph y = ${L} and y = ${R}; read the x-value where they meet.`,
      };
    },
  },
  {
    id: 'lin1-ask-different', skill: 'M.ALG.LIN1', levels: [2, 3, 4, 5],
    gen(r, d) {
      // a x + b = c  ->  value of m x + n  (smart route: multiply whole equation)
      const k = byBand(d, [r.int(2, 3), r.int(2, 5), r.pick([q(1, 2), q(3, 2), q(2, 3), q(5, 2), q(4, 3)])]);
      const m = r.int(1, 6), n = nz(r, -9, 9);
      const a = Q.of(m).mul(Q.of(k)), b = Q.of(n).mul(Q.of(k));
      if (!a.isInt || !b.isInt) reject('non-int');
      const xv = q(nz(r, -9, 12), d >= 5 ? r.pick([1, 3, 7]) : 1);
      const c = a.mul(xv).add(b);
      if (!c.isInt) reject('c');
      const target = xv.mul(m).add(n);
      const ctx = d >= 5 && r.int(0, 1);
      return {
        skill: this.skill, micro: ['M.ALG.LIN1#SOLVE-BASIC'], difficulty: d, drivers: ['ASK-DIFFERENT-THING', ...(d >= 4 ? ['MULTI-STEP'] : [])], hypothesis: ['H.ASK-DIFFERENT'],
        sig: `${a.n},${b.n},${c.n},${m},${n}`,
        stem: ctx ? `If $${lin([[a, 'x'], [b, '']])} = ${c.tex()}$, what is the value of $${lin([[m, 'x'], [n, '']])}$?` : `If $${lin([[a, 'x'], [b, '']])} = ${c.tex()}$, what is the value of $${lin([[m, 'x'], [n, '']])}$?`,
        answer: { value: target, tex: `$${target.tex()}$`, why: `Notice ${lin([[a, 'x'], [b, '']])} is ${Q.of(k).tex()} times (${lin([[m, 'x'], [n, '']])}), so divide ${c.tex()} by ${Q.of(k).tex()}.` },
        wrong: [
          { value: xv, tex: `$${xv.tex()}$`, trap: 'ASKED-DIFFERENT', why: 'This is the value of x, but the question asks for a different expression.', think: 'Solve for x, done.', trapPy: `sp.solve(sp.Eq(${a.n}*x + ${b.n}, ${c.n}), x)[0]` },
          { value: c, tex: `$${c.tex()}$`, trap: 'STOPPED-EARLY', why: 'This is the right side of the given equation, not the requested expression.', think: 'The expressions look similar, so the value is the same.', trapPy: `${c.n}` },
          { value: xv.mul(m).sub(n), tex: `$${xv.mul(m).sub(n).tex()}$`, trap: 'SIGN-ERROR', why: `The constant ${n} entered with the wrong sign.`, think: 'Multiply x and subtract the constant.', trapPy: `sp.solve(sp.Eq(${a.n}*x + ${b.n}, ${c.n}), x)[0]*${m} - (${n})` },
        ],
        solvePy: `${X}\nxv = sp.solve(sp.Eq(${a.n}*x + ${b.n}, ${c.n}), x)[0]\ncomputed = ${m}*xv + (${n})`,
        steps: [`See that ${lin([[a, 'x'], [b, '']])} = ${Q.of(k).tex()}(${lin([[m, 'x'], [n, '']])}).`, `So ${lin([[m, 'x'], [n, '']])} = ${c.tex()} ÷ ${Q.of(k).tex()} = ${target.tex()}.`],
        insight: 'Before solving for x, check whether the asked expression is a multiple of the given one.',
      };
    },
  },
  {
    id: 'lin1-no-solution', skill: 'M.ALG.LIN1', levels: [3, 4, 5],
    gen(r, d) {
      // p(kx - s) = t x + u has no solution -> p*k = t and -p s != u
      const p = r.int(2, 6), k = nz(r, -7, 9), t = p * k, s = nz(r, -8, 8);
      let u = nz(r, -20, 20); if (u === -p * s) u += 1;
      const mode = d >= 5 ? 'infinite' : 'none';
      let uu = u; if (mode === 'infinite') uu = -p * s;
      return {
        skill: this.skill, micro: ['M.ALG.LIN1#NO-OR-INFINITE-SOLUTIONS', 'M.ALG.LIN1#PARAM-FOR-CONDITION'], difficulty: d, drivers: ['PARAMETRIC', 'HIDDEN-CONSTRAINT'],
        sig: `${p},${k},${s},${uu},${mode}`,
        stem: `$${p}(kx ${s < 0 ? '+' : '-'} ${Math.abs(s)}) = ${lin([[t, 'x'], [uu, '']])}$\n\nIn the given equation, $k$ is a constant. If the equation has ${mode === 'none' ? 'no solution' : 'infinitely many solutions'}, what is the value of $k$?`,
        answer: { value: q(k), tex: `$${k}$`, why: `${mode === 'none' ? 'No solution' : 'Infinitely many solutions'} needs equal x-coefficients: ${p}k = ${t}, so k = ${k}.` },
        wrong: [
          { value: q(t), tex: `$${t}$`, trap: 'WRONG-VARIABLE', why: `${t} is the coefficient ${p}k, not k itself.`, think: 'Set k equal to the other x-coefficient.', trapPy: `${t}` },
          { value: q(-k), tex: `$${-k}$`, trap: 'SIGN-ERROR', why: 'The coefficients must be equal, not opposites.', think: 'They must cancel, so make them opposite.', trapPy: `-sp.Rational(${t}, ${p})` },
          { value: q(t - p), tex: `$${t - p}$`, trap: 'ORDER-OF-OPS', why: `Distributing ${p} only partly gives the wrong coefficient.`, think: `${p}(kx) is ${p} + k.`, trapPy: `${t} - ${p}` },
        ],
        solvePy: `x, k = sp.symbols('x k')\nexpr = sp.expand(${p}*(k*x - (${s})) - (${t}*x + (${uu})))\nsols = [v for v in sp.solve(sp.Poly(expr, x).coeff_monomial(x), k)]\nassert len(sols) == 1\nkv = sols[0]\nconst = expr.subs(k, kv).subs(x, 0)\nassert (const != 0) == ${mode === 'none' ? 'True' : 'False'}\ncomputed = kv`,
        steps: [`Expand: ${p}kx ${-p * s < 0 ? '-' : '+'} ${Math.abs(p * s)} = ${lin([[t, 'x'], [uu, '']])}.`, `For ${mode === 'none' ? 'no solution, the x-terms must match while the constants differ' : 'infinitely many solutions, both sides must be identical'}: ${p}k = ${t}.`, `k = ${k}.`],
        insight: 'No solution = same slope, different intercept. Infinite = identical sides.',
      };
    },
  },
  // ------------------------------------------------------------------ LIN2
  {
    id: 'lin2-slope', skill: 'M.ALG.LIN2', levels: [1, 2, 3, 4, 5],
    gen(r, d) {
      const x1 = r.int(-6, 6), y1 = r.int(-9, 9);
      let dx = nz(r, -6, 6), dy = nz(r, -10, 10); if (Math.abs(dx) === Math.abs(dy)) dy += 1; if (dy === 0) dy = 3;
      const x2 = x1 + dx, y2 = y1 + dy;
      const m = q(dy, dx);
      const perp = d >= 4;
      const ans = perp ? q(-dx, dy) : m;
      const stem = perp
        ? `Line $\\ell$ passes through the points $(${x1}, ${y1})$ and $(${x2}, ${y2})$. Line $k$ is perpendicular to line $\\ell$. What is the slope of line $k$?`
        : `A line in the $xy$-plane passes through the points $(${x1}, ${y1})$ and $(${x2}, ${y2})$. What is the slope of the line?`;
      const w = perp
        ? [
          { value: m, tex: `$${m.tex()}$`, trap: 'STOPPED-EARLY', why: 'That is the slope of line ℓ; a perpendicular slope is its negative reciprocal.', think: 'Find the slope, done.', trapPy: `sp.Rational(${dy}, ${dx})` },
          { value: q(dx, dy), tex: `$${q(dx, dy).tex()}$`, trap: 'SIGN-ERROR', why: 'The reciprocal was taken but the sign was not flipped.', think: 'Perpendicular means flip the fraction.', trapPy: `sp.Rational(${dx}, ${dy})` },
          { value: m.neg(), tex: `$${m.neg().tex()}$`, trap: 'WRONG-FORMULA', why: 'Only the sign changed; perpendicular slopes are negative reciprocals.', think: 'Perpendicular means opposite sign.', trapPy: `-sp.Rational(${dy}, ${dx})` },
        ]
        : [
          { value: q(dx, dy), tex: `$${q(dx, dy).tex()}$`, trap: 'WRONG-FORMULA', why: 'This is run over rise; slope is rise over run.', think: 'Change in x over change in y.', trapPy: `sp.Rational(${dx}, ${dy})` },
          { value: m.neg(), tex: `$${m.neg().tex()}$`, trap: 'SIGN-ERROR', why: 'The subtraction order was mixed between numerator and denominator.', think: 'y2 - y1 over x1 - x2.', trapPy: `sp.Rational(${dy}, ${-dx})` },
          { value: q(y2 + y1, x2 + x1 === 0 ? 7 : x2 + x1), tex: `$${q(y2 + y1, x2 + x1 === 0 ? 7 : x2 + x1).tex()}$`, trap: 'WRONG-FORMULA', why: 'The coordinates were added instead of subtracted.', think: 'Total y over total x.', trapPy: `sp.Rational(${y2 + y1}, ${x2 + x1 === 0 ? 7 : x2 + x1})` },
        ];
      return {
        skill: this.skill, micro: [perp ? 'M.ALG.LIN2#PARALLEL-PERPENDICULAR' : 'M.ALG.LIN2#POINT-ON-LINE'], difficulty: d, drivers: perp ? ['MULTI-STEP'] : [],
        sig: `${x1},${y1},${x2},${y2},${perp}`, stem, answer: { value: ans, tex: `$${ans.tex()}$` }, wrong: w,
        solvePy: `m = sp.Rational(${y2} - (${y1}), ${x2} - (${x1}))\ncomputed = ${perp ? '-1/m' : 'm'}`,
        steps: [`Slope = (${y2} - ${y1 < 0 ? `(${y1})` : y1}) / (${x2} - ${x1 < 0 ? `(${x1})` : x1}) = ${m.tex()}.`, ...(perp ? [`Perpendicular slope = negative reciprocal = ${ans.tex()}.`] : [])],
        insight: perp ? 'Perpendicular slopes multiply to -1.' : 'Slope = change in y / change in x, same order top and bottom.',
      };
    },
  },
  {
    id: 'lin2-context', skill: 'M.ALG.LIN2', levels: [2, 3, 4],
    gen(r, d) {
      const name = r.pick(CONTEXT_NAMES);
      const fee = r.int(2, 9) * 5, rate = r.int(3, 18), hours = r.int(3, 12), total = fee + rate * hours;
      const ask = d >= 4 ? 'hours' : 'total';
      const stem = ask === 'total'
        ? `${name} rents a kayak. The total cost $y$, in dollars, for $x$ hours is given by $y = ${rate}x + ${fee}$. What is the total cost, in dollars, of renting the kayak for ${hours} hours?`
        : `${name} rents a kayak. The total cost $y$, in dollars, for $x$ hours is given by $y = ${rate}x + ${fee}$. If ${name} paid ${money(total)} in total, for how many hours was the kayak rented?`;
      const ans = ask === 'total' ? total : hours;
      const w = ask === 'total'
        ? [{ value: rate * hours, tex: `$${rate * hours}$`, trap: 'STOPPED-EARLY', why: `The fixed fee of ${fee} dollars was left out.`, think: 'Rate times hours.', trapPy: `${rate}*${hours}` },
          { value: (rate + fee) * hours, tex: `$${(rate + fee) * hours}$`, trap: 'WRONG-FORMULA', why: 'The fixed fee is charged once, not every hour.', think: 'Both numbers are per hour.', trapPy: `(${rate}+${fee})*${hours}` },
          { value: fee * hours + rate, tex: `$${fee * hours + rate}$`, trap: 'SLOPE-INTERCEPT-SWAP', why: 'The slope and the intercept were swapped.', think: `The bigger number is the hourly rate.`, trapPy: `${fee}*${hours}+${rate}` }]
        : [{ value: q(total, rate), tex: `$${q(total, rate).tex()}$`, trap: 'STOPPED-EARLY', why: 'The fixed fee must be subtracted before dividing.', think: 'Total divided by the rate.', trapPy: `sp.Rational(${total}, ${rate})` },
          { value: q(total + fee, rate), tex: `$${q(total + fee, rate).tex()}$`, trap: 'SIGN-ERROR', why: 'The fee was added instead of subtracted.', think: 'Move the fee over and add.', trapPy: `sp.Rational(${total}+${fee}, ${rate})` },
          { value: total - fee, tex: `$${total - fee}$`, trap: 'STOPPED-EARLY', why: 'That is the hourly charge in total; it still has to be divided by the rate.', think: 'Subtract the fee, done.', trapPy: `${total}-${fee}` }];
      return {
        skill: this.skill, micro: ['M.ALG.LIN2#CONTEXT-INTERPRET', 'M.ALG.LIN2#SLOPE-INTERCEPT-MEANING'], difficulty: d, context: 'everyday', drivers: ask === 'hours' ? ['LONG-SETUP-WORD-PROBLEM'] : [],
        sig: `${fee},${rate},${hours},${ask}`, stem, answer: { value: ans, tex: `$${ans}$` }, wrong: w,
        solvePy: `${X}\n${ask === 'total' ? `computed = ${rate}*${hours} + ${fee}` : `computed = sp.solve(sp.Eq(${rate}*x + ${fee}, ${total}), x)[0]`}`,
        steps: ask === 'total' ? [`Substitute x = ${hours}: y = ${rate}(${hours}) + ${fee}.`, `y = ${total}.`] : [`Set ${rate}x + ${fee} = ${total}.`, `${rate}x = ${total - fee}.`, `x = ${hours}.`],
        insight: 'In y = mx + b, b is the one-time amount and m is the amount per unit.',
      };
    },
  },
  // ------------------------------------------------------------------ LFUNC
  {
    id: 'lfunc-two-points', skill: 'M.ALG.LFUNC', levels: [2, 3, 4, 5],
    gen(r, d) {
      const m = byBand(d, [q(nz(r, -6, 6)), q(nz(r, -9, 9), r.pick([1, 2])), q(nz(r, -9, 9), r.pick([2, 3, 4]))]);
      const b = q(r.int(-15, 15));
      const a1 = r.int(-5, 3), a2 = a1 + r.int(2, 8) * Q.of(m).d, c = a2 + r.int(1, 6) * Q.of(m).d;
      const f = (x) => m.mul(x).add(b);
      if (!f(a1).isInt || !f(a2).isInt || !f(c).isInt) reject('nonint');
      const ans = f(c);
      const slopeWrong = q(f(a2).n - f(a1).n, 1).div(a2 - a1 === 0 ? 1 : 1); // forgetting to divide by run
      const wA = f(a2).add(f(a2).sub(f(a1)));
      return {
        skill: this.skill, micro: ['M.ALG.LFUNC#FUNCTION-NOTATION', 'M.ALG.LFUNC#RATE-OF-CHANGE'], difficulty: d, drivers: d >= 4 ? ['MULTI-STEP'] : [],
        sig: `${m.n}/${m.d},${b.n},${a1},${a2},${c}`,
        stem: `For the linear function $f$, $f(${a1}) = ${f(a1).tex()}$ and $f(${a2}) = ${f(a2).tex()}$. What is the value of $f(${c})$?`,
        answer: { value: ans, tex: `$${ans.tex()}$` },
        wrong: [
          { value: wA, tex: `$${wA.tex()}$`, trap: 'WRONG-FORMULA', why: 'This assumes f changes by the same amount per step regardless of how far apart the inputs are.', think: 'Just keep adding the same jump.', trapPy: `${f(a2).py()} + (${f(a2).py()} - (${f(a1).py()}))` },
          { value: slopeWrong.mul(c).add(b), tex: `$${slopeWrong.mul(c).add(b).tex()}$`, trap: 'STOPPED-EARLY', why: 'The change in f was not divided by the change in x to get the slope.', think: 'Slope is just the difference of the outputs.', trapPy: `(${f(a2).py()} - (${f(a1).py()}))*${c} + (${b.py()})` },
          { value: m.mul(c), tex: `$${m.mul(c).tex()}$`, trap: 'STOPPED-EARLY', why: 'The y-intercept was left out.', think: 'f(x) = slope times x.', trapPy: `${m.py()}*${c}` },
        ],
        solvePy: `${X}\nm, b = sp.symbols('m b')\ns = sp.solve([sp.Eq(m*${a1} + b, ${f(a1).py()}), sp.Eq(m*${a2} + b, ${f(a2).py()})], [m, b])\ncomputed = s[m]*${c} + s[b]`,
        steps: [`Slope = (${f(a2).tex()} - ${f(a1).tex()}) / (${a2} - ${a1}) = ${m.tex()}.`, `Intercept: b = ${b.tex()}, so f(x) = ${lin([[m, 'x'], [b, '']])}.`, `f(${c}) = ${ans.tex()}.`],
        insight: 'Two points fix a line: find the slope, then the intercept, then evaluate.',
      };
    },
  },
  // ------------------------------------------------------------------ SYS
  {
    id: 'sys-solve', skill: 'M.ALG.SYS', levels: [1, 2, 3, 4, 5],
    gen(r, d) {
      const xv = nz(r, -8, 9), yv = nz(r, -8, 9);
      const a = nz(r, -5, 6), b = nz(r, -5, 6), c = nz(r, -5, 6), e = nz(r, -5, 6);
      if (a * e - b * c === 0) reject('singular');
      const p = a * xv + b * yv, s = c * xv + e * yv;
      const ask = byBand(d, ['x', 'y', r.pick(['x+y', 'x-y', '2x+y'])]);
      const ev = { x: xv, y: yv, 'x+y': xv + yv, 'x-y': xv - yv, '2x+y': 2 * xv + yv }[ask];
      const others = [xv, yv, xv + yv, xv - yv, yv - xv, -xv, -yv, 2 * xv + yv].filter((v) => v !== ev);
      const uniq = [...new Set(others)];
      if (uniq.length < 3) reject('few');
      const lab = (v) => (v === xv ? ['ASKED-DIFFERENT', 'That is the value of x.', 'x is the answer.'] : v === yv ? ['ASKED-DIFFERENT', 'That is the value of y.', 'y is the answer.'] : v === -xv || v === -yv ? ['SIGN-ERROR', 'A sign was lost during elimination.', 'Subtracting the equations flips nothing.'] : ['ASKED-DIFFERENT', 'This combines x and y in a different way than asked.', 'Add up what I found.']);
      const pyOf = (v) => (v === xv ? 's[x]' : v === yv ? 's[y]' : v === xv + yv ? 's[x]+s[y]' : v === xv - yv ? 's[x]-s[y]' : v === yv - xv ? 's[y]-s[x]' : v === -xv ? '-s[x]' : v === -yv ? '-s[y]' : '2*s[x]+s[y]');
      const picks = r.shuffle(uniq).slice(0, 3);
      return {
        skill: this.skill, micro: ['M.ALG.SYS#SOLVE-SUB-ELIM', ...(ask.length > 1 ? ['M.ALG.SYS#SOLVE-FOR-EXPRESSION'] : [])], difficulty: d,
        drivers: ask.length > 1 ? ['ASK-DIFFERENT-THING'] : [], sig: `${a},${b},${p},${c},${e},${s},${ask}`,
        stem: `$${lin([[a, 'x'], [b, 'y']])} = ${p}$\n$${lin([[c, 'x'], [e, 'y']])} = ${s}$\n\nThe solution to the given system of equations is $(x, y)$. What is the value of $${ask}$?`,
        answer: { value: ev, tex: `$${ev}$` },
        wrong: picks.map((v) => { const [t, why, think] = lab(v); return { value: v, tex: `$${v}$`, trap: t, why, think, trapPy: pyOf(v) }; }),
        solvePy: `x, y = sp.symbols('x y')\ns = sp.solve([sp.Eq(${a}*x + ${b}*y, ${p}), sp.Eq(${c}*x + ${e}*y, ${s})], [x, y])\ncomputed = ${pyOf(ev)}`,
        steps: ['Scale one equation so a variable cancels, then add or subtract.', `Solve: x = ${xv}, y = ${yv}.`, `${ask} = ${ev}.`],
        insight: 'Eliminate the variable with the easiest coefficients; re-read what is asked before answering.',
        desmos: 'Graph both equations; the intersection point is (x, y).',
      };
    },
  },
  {
    id: 'sys-no-solution', skill: 'M.ALG.SYS', levels: [3, 4, 5],
    gen(r, d) {
      // a x + b y = c ; k x + e y = f  has no solution  -> k = a e / b
      const a = nz(r, -6, 8), b = nz(r, -5, 6), t = nz(r, -4, 4), e = b * t;
      const k = a * t;
      const c = r.int(-12, 12); let f = r.int(-20, 20); if (f === c * t) f += 1;
      const inf = d >= 5;
      const ff = inf ? c * t : f;
      return {
        skill: this.skill, micro: [inf ? 'M.ALG.SYS#INFINITE-SOLUTIONS' : 'M.ALG.SYS#NO-SOLUTION-CONDITION'], difficulty: d, drivers: ['PARAMETRIC'],
        sig: `${a},${b},${c},${e},${ff},${inf}`,
        stem: `$${lin([[a, 'x'], [b, 'y']])} = ${c}$\n$kx ${e < 0 ? '-' : '+'} ${Math.abs(e) === 1 ? '' : Math.abs(e)}y = ${ff}$\n\nIn the given system of equations, $k$ is a constant. If the system has ${inf ? 'infinitely many solutions' : 'no solution'}, what is the value of $k$?`,
        answer: { value: k, tex: `$${k}$` },
        wrong: [
          { value: -k, tex: `$${-k}$`, trap: 'SIGN-ERROR', why: 'The lines must be parallel (same ratio), not opposite.', think: 'Make the x-terms cancel.', trapPy: `${-k}` },
          { value: a, tex: `$${a}$`, trap: 'IGNORED-CONSTRAINT', why: `The second equation is the first scaled by ${t}; k must be scaled too.`, think: 'Same x-coefficient means parallel.', trapPy: `${a}` },
          ...(Q.of(e).div(a).eq(k) || e === k || e === a || e === -k ? [{ value: k + t, tex: `$${k + t}$`, trap: 'ARITH-SLIP', why: 'The scale factor was added instead of multiplied.', think: 'Shift by the factor.', trapPy: `${k + t}` }] : [{ value: e, tex: `$${e}$`, trap: 'WRONG-VARIABLE', why: 'That is the y-coefficient, not the x-coefficient.', think: 'Match the y-number.', trapPy: `${e}` }]),
        ],
        solvePy: `k = sp.Symbol('k')\nsols = sp.solve(sp.Eq(${a}*${e} - ${b}*k, 0), k)\nassert len(sols) == 1\nkv = sols[0]\nratio = sp.Rational(${e}, ${b})\nassert (sp.Rational(${ff}) == ratio*${c}) == ${inf ? 'True' : 'False'}\ncomputed = kv`,
        steps: [`${inf ? 'Infinitely many solutions' : 'No solution'} means the second equation's left side is a multiple of the first.`, `The y-coefficients give the factor ${e}/${b} = ${t}.`, `So k = ${a} × ${t} = ${k}.`],
        insight: 'Parallel lines: coefficient ratios a/k = b/e. No solution: constants break the ratio; infinite: constants keep it.',
      };
    },
  },
  // ------------------------------------------------------------------ INEQ
  {
    id: 'ineq-budget', skill: 'M.ALG.INEQ', levels: [2, 3, 4, 5],
    gen(r, d) {
      const name = r.pick(CONTEXT_NAMES);
      const fee = r.int(3, 30) * 5, price = r.pick([4, 6, 7, 8, 9, 12, 14, 15, 18]), budget = fee + price * r.int(6, 30) + r.int(1, price - 1);
      const maxN = Math.floor((budget - fee) / price);
      const items = r.pick([['T-shirts', 'printing setup fee'], ['tickets', 'booking fee'], ['plants', 'delivery fee'], ['books', 'shipping fee']]);
      const ignore = Math.floor(budget / price);
      const ceil = Math.ceil((budget - fee) / price);
      return {
        skill: this.skill, micro: ['M.ALG.INEQ#CONTEXT-CONSTRAINT', 'M.ALG.INEQ#INTEGER-MIN-MAX'], difficulty: d, context: 'everyday', drivers: ['HIDDEN-CONSTRAINT', ...(d >= 4 ? ['LONG-SETUP-WORD-PROBLEM'] : [])],
        sig: `${fee},${price},${budget}`,
        stem: `${name} has at most ${money(budget)} to spend on ${items[0]}. Each item costs ${money(price)}, and there is a one-time ${items[1]} of ${money(fee)}. What is the maximum number of ${items[0]} ${name} can buy?`,
        answer: { value: maxN, tex: `$${maxN}$` },
        wrong: [
          { value: ceil, tex: `$${ceil}$`, trap: 'ROUNDING', why: `Rounding up would go over the ${money(budget)} limit.`, think: `${((budget - fee) / price).toFixed(2)} rounds to ${ceil}.`, trapPy: `sp.ceiling(sp.Rational(${budget - fee}, ${price}))` },
          { value: ignore, tex: `$${ignore}$`, trap: 'IGNORED-CONSTRAINT', why: 'The one-time fee was left out.', think: 'Budget divided by price.', trapPy: `sp.floor(sp.Rational(${budget}, ${price}))` },
          { value: Math.floor((budget + fee) / price), tex: `$${Math.floor((budget + fee) / price)}$`, trap: 'SIGN-ERROR', why: 'The fee was added to the budget instead of subtracted.', think: 'Combine the two money amounts.', trapPy: `sp.floor(sp.Rational(${budget + fee}, ${price}))` },
        ],
        solvePy: `n = sp.Symbol('n', integer=True)\ncomputed = max(v for v in range(0, 1000) if ${fee} + ${price}*v <= ${budget})`,
        steps: [`Write ${fee} + ${price}n ≤ ${budget}.`, `${price}n ≤ ${budget - fee}, so n ≤ ${((budget - fee) / price).toFixed(2)}.`, `n must be a whole number: ${maxN}.`],
        insight: 'With "at most", round DOWN to the largest whole number that still fits.',
      };
    },
  },
  {
    id: 'ineq-solve', skill: 'M.ALG.INEQ', levels: [1, 2, 3, 4],
    gen(r, d) {
      // a - b x  <  c  ->  x > (a-c)/b  ; ask least integer
      const b = r.int(2, 9), a = r.int(-10, 30), c = r.int(-20, 20);
      const bound = q(a - c, b);
      if (bound.isInt && d <= 2) {/* ok */}
      const strict = r.int(0, 1) === 1;
      // -b x < c - a  -> x > (a-c)/b  (flip)
      const least = strict ? Math.floor(bound.dec()) + 1 : Math.ceil(bound.dec());
      const noflip = strict ? Math.ceil(bound.dec()) - 1 : Math.floor(bound.dec());
      const w3 = least + 1;
      if (new Set([least, noflip, w3, -least]).size < 4) reject('collide');
      return {
        skill: this.skill, micro: ['M.ALG.INEQ#SOLVE-INEQ', 'M.ALG.INEQ#FLIP-SIGN'], difficulty: d, drivers: d >= 3 ? ['HIDDEN-CONSTRAINT'] : [],
        sig: `${a},${b},${c},${strict}`,
        stem: `$${a} - ${b}x ${strict ? '<' : '\\le'} ${c}$\n\nWhat is the least integer value of $x$ that satisfies the given inequality?`,
        answer: { value: least, tex: `$${least}$` },
        wrong: [
          { value: noflip, tex: `$${noflip}$`, trap: 'SIGN-ERROR', why: 'Dividing by a negative number reverses the inequality; this answer kept the original direction.', think: 'Divide both sides, keep the sign.', trapPy: `${noflip}` },
          { value: w3, tex: `$${w3}$`, trap: 'ROUNDING', why: `${w3 - 1} already satisfies the inequality.`, think: 'Round up to be safe.', trapPy: `${w3}` },
          { value: -least, tex: `$${-least}$`, trap: 'SIGN-ERROR', why: 'The sign of the boundary was flipped.', think: 'Moving -bx over makes the answer negative.', trapPy: `${-least}` },
        ],
        solvePy: `${X}\ncomputed = min(v for v in range(-500, 500) if ${a} - ${b}*v ${strict ? '<' : '<='} ${c})`,
        steps: [`Subtract ${a}: -${b}x ${strict ? '<' : '≤'} ${c - a}.`, `Divide by -${b} and flip: x ${strict ? '>' : '≥'} ${bound.tex()}.`, `Least integer: ${least}.`],
        insight: 'Multiplying or dividing by a negative flips the inequality sign.',
      };
    },
  },
];
