// Append-only event log + replay + shadow comparison (blueprint principle 5: expect failures, contain them).
// State is NEVER the source of truth; the log is. After fixing an engine bug, replay the log to rebuild everything.
export const ENGINE_VERSION = 'tails-2.2.1';
export const newLog = () => ({ v: ENGINE_VERSION, events: [] });
export function append(log, type, data = {}, t = Date.now()) { log.events.push({ seq: log.events.length + 1, v: ENGINE_VERSION, t, type, ...data }); return log; }
/** Rebuild state by folding events through a reducer (e.g. the adapt() function). */
export function replay(log, reducer, init = {}) { let st = init; const notes = []; for (const e of log.events) { const r = reducer(st, e); st = r.state; notes.push(...r.notes.map((n) => ({ seq: e.seq, n }))); } return { state: st, notes }; }
/** Shadow mode: run the same inputs through two engine configs and report differences before switching versions. */
export function diffDays(a, b) {
  const sig = (d) => d.steps.map((s) => `${s.kind}:${s.ref_id}`);
  const A = new Set(sig(a)), B = new Set(sig(b));
  return { minutes: [a.minutes_total, b.minutes_total], only_a: [...A].filter((x) => !B.has(x)), only_b: [...B].filter((x) => !A.has(x)), same: [...A].filter((x) => B.has(x)).length };
}
