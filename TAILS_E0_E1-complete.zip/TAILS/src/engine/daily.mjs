// TAILS Daily Planner v2. PURE: same inputs -> same day. No LLM, no network, no randomness.
// Turns (target score, current evidence, test date, time budget) into TODAY's checklist (>= min_minutes),
// a feasibility verdict, spaced-review picks and the reaction to a failed checkpoint.
// Reuses the existing engine: mastery Map (mastery.mjs), taxonomy (weight_on_test), lessons registry (122 ids), question bank.
import { keyOf } from './mastery.mjs';
import { requiredMastery, hoursNeeded, SCORE_CFG } from './score.mjs';
import { ADAPT_CFG } from './adapt.mjs';

export const DAILY_CFG = {
  min_minutes: 120,                 // student promise: at least 2 h a day
  review_stages_days: [1, 3, 7, 14, 30],
  checkpoint_size: 8,               // pass mark lives in ADAPT_CFG.checkpoint_pass_ratio (one place)
  vocab_minutes: 15, mistake_minutes: 10, timed_minutes: 16, review_cap_minutes: 14,
  prior_p: 0.5,
};
// 1400 -> ~0.83 mastery target, 1200 -> ~0.64. Clamped.
// kept for callers that want one number: mean of the per-section required mastery
export const targetP = (score) => { const r = requiredMastery(score); return (r.rw + r.math) / 2; };

/** Honest feasibility on the saturating-hours model (hpp = student's calibrated hours per point). */
export function feasibility({ current, target, days_until_test, minutes_per_day, hpp }, cfg = DAILY_CFG) {
  if (current == null) return { status: 'unknown', note: 'No test yet. Take the diagnostic to get a real forecast.' };
  const need = hoursNeeded(current, target, hpp ?? SCORE_CFG.hours_per_point_prior), have = days_until_test * minutes_per_day / 60, ratio = need ? have / need : 99;
  const status = ratio >= 1.15 ? 'on_track' : ratio >= 0.8 ? 'tight' : 'at_risk';
  return { status, gap: Math.max(0, target - current), hours_needed: Math.round(need), hours_available: Math.round(have), ratio: +ratio.toFixed(2),
    note: status === 'on_track' ? 'Enough time at your daily pace.' : status === 'tight' ? 'Possible, but you cannot miss many days.' : 'The time does not cover the gap. Options: more hours a day, a later test date, or a lower target.' };
}

/** Spaced repetition (FSRS-lite). state {stage,due_at}. Right -> next interval, wrong -> back to stage 0 with a fixit lesson. */
export function scheduleReview(state, correct, nowMs, cfg = DAILY_CFG) {
  const st = cfg.review_stages_days, stage = correct ? Math.min((state?.stage ?? -1) + 1, st.length - 1) : 0;
  return { stage, due_at: nowMs + st[stage] * 86400000, attach_fixit: !correct };
}

const minutesFor = (qs) => Math.ceil(qs.reduce((s, q) => s + (q.est_time_sec ?? 75), 0) / 60 * 1.15);

/**
 * inp: { tax, cfg(thresholds), daily?, mastery:Map, lessons[], bank[], settings:{target_score,current_score,days_until_test,minutes_per_day},
 *        progress:{ lessonDone:Set, checkpointFailed:[{skill_id,trap_code}], seen:Set, due:[{skill_id,due_at}], vocabDue:number }, now }
 */
export function buildDay(inp) {
  const D = { ...DAILY_CFG, ...(inp.daily ?? {}) }, { tax, mastery, lessons, bank, settings, progress = {} } = inp;
  const now = inp.now ?? 0, seen = progress.seen ?? new Set(), done = progress.lessonDone ?? new Set();
  const budget = Math.max(settings.minutes_per_day ?? D.min_minutes, D.min_minutes);
  const req = requiredMastery(settings.target_score ?? 1400), tp = (req.rw + req.math) / 2, steps = [], why = [];
  const usable = bank.filter((q) => q.status === 'verified' || q.status === 'approved' || q.status == null);
  const used = () => steps.reduce((s, x) => s + x.minutes, 0);
  const taken = new Set();    // items already assigned to a step TODAY: one question never appears twice in a day
  const add = (s) => { steps.push(s); (s.question_ids ?? []).forEach((id) => taken.add(id)); return s; };
  const pick = (skill, n, want) => {
    const pool = usable.filter((q) => q.skill_id === skill && !seen.has(q.id) && !taken.has(q.id));
    const ord = pool.slice().sort((a, b) => Math.abs(a.difficulty - want) - Math.abs(b.difficulty - want) || a.id.localeCompare(b.id));
    return ord.slice(0, n);
  };
  const fl = progress.flags ?? {}, wantDiff = (p) => Math.min(5, (p < 0.45 ? 2 : p < 0.6 ? 3 : p < 0.75 ? 4 : 5) + (fl.ahead ? 1 : 0));
  const pool_alerts = [];

  // ---- 0. no evidence at all: the day is the diagnostic ----
  const evidence = [...mastery.values()].filter((m) => m.level === 'skill' && !m.insufficient).length;
  if (evidence < 4) {
    const orient = lessons.filter((l) => l.kind === 'orientation' && !done.has(l.id)).slice(0, 2);
    orient.forEach((l) => add({ kind: 'lesson', ref_id: l.id, label: l.title, minutes: l.target_minutes ?? 8, why: 'Learn how the test works before measuring yourself.' }));
    add({ kind: 'diagnostic', ref_id: 'diagnostic', label: 'Diagnostic: 1 Reading & Writing module + 1 Math module', minutes: 70, why: 'TAILS cannot build an honest plan from zero evidence. This one test sets your starting point.' });
    add({ kind: 'review', ref_id: 'diag-review', label: 'Review every miss from the diagnostic (what went wrong, not just the answer)', minutes: Math.max(10, budget - used()), why: 'The reason behind each mistake is what the plan is built from.' });
    return { mode: 'diagnostic', minutes_total: used(), minimum_met: used() >= D.min_minutes, steps, why: ['No evidence yet, so today is the diagnostic. A full plan to the target is generated tonight.'], pool_alerts };
  }

  // ---- 1. spaced review of what is about to fade ----
  const due = (progress.due ?? []).filter((d) => d.due_at <= now).sort((a, b) => a.due_at - b.due_at);
  if (due.length) {
    let qs = [];
    for (const d of due) qs.push(...pick(d.skill_id, 2, 3));
    qs = qs.slice(0, 8);
    if (qs.length) add({ kind: 'review', ref_id: 'spaced', label: `Spaced review: ${[...new Set(qs.map((q) => tax.skillName(q.skill_id)))].slice(0, 3).join(', ')}`, minutes: Math.min(D.review_cap_minutes, minutesFor(qs)), question_ids: qs.map((q) => q.id), why: `${due.length} skill(s) are at the point of being forgotten. A short retrieval now costs less than relearning later.` });
  }

  // ---- 2. rank skills: points on the test * gap to target * (1 / hours to fix) ----
  const ranked = [];
  for (const s of tax.skills ?? []) {
    const m = mastery.get(keyOf(s.id)), p = m && !m.insufficient ? m.p : D.prior_p;
    const exp = s.weight_on_test * ((tax.domainById.get(s.domain)?.section === 'rw') ? 54 : 44);
    const gain = exp * Math.max(0, req[tax.sectionOf(s.id)] - p), unc = m ? Math.sqrt(m.variance) : 0.3;
    const lessonsLeft = lessons.filter((l) => l.skill_id === s.id && ['concept', 'examples', 'traps'].includes(l.kind) && !done.has(l.id)).length;
    ranked.push({ id: s.id, name: tax.skillName(s.id), p, gain: gain * (1 + unc), lessonsLeft, section: tax.sectionOf(s.id), tp: req[tax.sectionOf(s.id)] });
  }
  ranked.sort((a, b) => b.gain - a.gain || a.id.localeCompare(b.id));
  const top = ranked.filter((r) => r.gain > 0.02);

  // ---- 3. a failed checkpoint beats everything: targeted REVIEW lesson + fresh items, never the same video again ----
  for (const f of (progress.checkpointFailed ?? []).slice(0, 1)) {
    const fix = lessons.find((l) => l.kind === 'fixit' && l.trap_code === f.trap_code), r = ranked.find((x) => x.id === f.skill_id);
    if (fix) add({ kind: 'lesson', ref_id: fix.id, label: `Review lesson: ${fix.title}`, minutes: fix.target_minutes ?? 6, tag: 'review', why: `You missed the checkpoint because of "${f.trap_code}". A short targeted fix replaces repeating the whole lesson.` });
    const qs = pick(f.skill_id, 10, wantDiff((r?.p ?? 0.5) - 0.1));
    if (qs.length) add({ kind: 'practice', ref_id: f.skill_id, label: `${tax.skillName(f.skill_id)}: ${qs.length} fresh questions after the fix`, minutes: minutesFor(qs), question_ids: qs.map((q) => q.id), tag: 'new', why: 'New items only, so this measures understanding rather than memory.' });
    why.push('Plan changed: checkpoint failed, so a review lesson and fresh items were inserted.');
  }

  // ---- 4. main block: lesson -> checkpoint -> practice on the best skill(s) ----
  const lead = top[0];
  if (lead && !(progress.checkpointFailed ?? []).length) {
    const next = lessons.filter((l) => l.skill_id === lead.id && ['concept', 'examples', 'traps'].includes(l.kind) && !done.has(l.id)).sort((a, b) => ['concept', 'examples', 'traps'].indexOf(a.kind) - ['concept', 'examples', 'traps'].indexOf(b.kind))[0];
    if (next) {
      add({ kind: 'lesson', ref_id: next.id, label: `Lesson: ${next.title}`, minutes: next.target_minutes ?? 10, recorded: !!next.video_ref, why: `${lead.name} is your biggest point opportunity (mastery ${Math.round(lead.p * 100)}%, target ${Math.round(req[lead.section] * 100)}%).` });
      const cp = pick(lead.id, D.checkpoint_size, 3);
      if (cp.length) add({ kind: 'checkpoint', ref_id: lead.id, label: `Checkpoint: ${cp.length} questions (pass ${Math.ceil(cp.length * ADAPT_CFG.checkpoint_pass_ratio)}/${cp.length})`, minutes: minutesFor(cp), question_ids: cp.map((q) => q.id), why: 'Proves the lesson worked. Failing it triggers a targeted review, not a repeat.' });
    }
  }
  // ---- 5. fixed daily habits ----
  const vocabN = progress.vocabDue ?? 15;
  add({ kind: 'vocab', ref_id: 'vocab', label: `Vocabulary: 10 new + ${vocabN} due`, minutes: D.vocab_minutes, why: 'Words in context is the biggest Reading & Writing lever for most students.' });
  add({ kind: 'mistakes', ref_id: 'mistakes', label: "Retry yesterday's misses cold", minutes: D.mistake_minutes, why: 'A miss is only fixed when you get it right later without help.' });
  const timedReserve = D.timed_minutes;

  // ---- 6. fill with targeted practice until the budget is reached (rotate skills, max 2 blocks per skill) ----
  const perSkill = new Map();
  for (const r of top) {
    if (used() + timedReserve >= budget) break;
    if ((perSkill.get(r.id) ?? 0) >= (fl.compress ? 1 : 2)) continue;
    const room = budget - timedReserve - used();
    const n = Math.min(25, Math.max(8, Math.floor(room / 1.7)));
    const qs = pick(r.id, n, wantDiff(r.p));
    if (qs.length < Math.min(8, n)) pool_alerts.push({ skill_id: r.id, name: r.name, available_unseen: qs.length, note: 'Too few unseen questions: generate more for this skill.' });
    if (qs.length < 6) continue;   // no tiny filler blocks: a thin skill is reported, not padded
    const mins = Math.min(minutesFor(qs), room);
    add({ kind: 'practice', ref_id: r.id, label: `${r.name}: ${qs.length} questions (${r.p < 0.6 ? 'building' : 'stretch'})`, minutes: mins, question_ids: qs.map((q) => q.id), why: `Mastery ${Math.round(r.p * 100)}% vs target ${Math.round(r.tp * 100)}%.` });
    perSkill.set(r.id, (perSkill.get(r.id) ?? 0) + 1);
  }
  if (fl.plateau?.kind === 'stamina' || fl.plateau?.kind === 'timing') why.push(`Plateau fix active: ${fl.plateau.fix}.`);
  if (fl.plateau?.kind === 'careless') why.push(`Plateau fix active: ${fl.plateau.fix}.`);
  if (fl.compress) why.push('Compressed day: only the highest-value work after missed days.');
  add({ kind: 'timed', ref_id: 'timed-set', label: `Timed mini-set (${D.timed_minutes} min, module conditions)`, minutes: fl.plateau?.kind === 'stamina' ? D.timed_minutes + 14 : D.timed_minutes, why: 'Builds stamina. Accuracy in the last third of a module is where many students lose points.' });
  const total = used();
  if (total < D.min_minutes) why.push('The bank is too thin to fill 2 hours with fresh items. See pool_alerts.');
  return { mode: 'normal', target_p: req, minutes_total: total, minimum_met: total >= D.min_minutes, steps, why, pool_alerts, focus: top.slice(0, 5).map((r) => ({ skill_id: r.id, name: r.name, p: +r.p.toFixed(2) })) };
}
