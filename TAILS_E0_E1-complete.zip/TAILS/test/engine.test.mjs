// node test/engine.test.mjs  -> release gate: fake students must produce sensible, deterministic plans.
import fs from 'node:fs';
import { createTaxonomy } from '../src/taxonomy/index.mjs';
import { buildDay, scheduleReview } from '../src/engine/daily.mjs';
import { adapt } from '../src/engine/adapt.mjs';
import { newLog, append, replay, diffDays } from '../src/engine/eventlog.mjs';
import { validateSuggestion, checkNumbers, pickMode, templateExplain } from '../src/engine/advisor.mjs';
import { calibrate } from '../src/engine/itemcal.mjs';
import { sectionScore, accuracyFor, requiredMastery, hoursNeeded, predictScore } from '../src/engine/score.mjs';
import { buildPath } from '../src/engine/path.mjs';
import { keyOf } from '../src/engine/mastery.mjs';
const data = JSON.parse(fs.readFileSync(new URL('../data.json', import.meta.url)));
const tax = createTaxonomy({ skills: data.skills, microskills: data.microskills, traps: data.traps, reasons: data.reasons });
const lessons = data.lessons.lessons, bank = data.questions, NOW = Date.parse('2026-10-22T18:00:00Z');
const mk = (o, d) => new Map(tax.skills.map((s) => { const p = o[s.id] ?? d; return [keyOf(s.id), { skill_id: s.id, level: 'skill', p, variance: p * (1 - p) / 31, n: 30, insufficient: false }]; }));
let pass = 0, fail = 0; const t = (name, ok, extra = '') => { ok ? pass++ : fail++; console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); };
const S = { target_score: 1500, current_score: 1200, days_until_test: 45, minutes_per_day: 130 };
const mB = mk({ 'M.ALG.SYS': 0.48, 'RW.CS.WIC': 0.5, 'RW.SEC.BND': 0.55 }, 0.66);
const day = (extra = {}, m = mB) => buildDay({ tax, mastery: m, lessons, bank, settings: S, now: NOW, progress: extra });

// A: no evidence -> diagnostic, >= 120 min
const A = buildDay({ tax, mastery: new Map(), lessons, bank, settings: { ...S, current_score: null }, now: NOW });
t('A: no evidence -> diagnostic day', A.mode === 'diagnostic' && A.steps.some((s) => s.kind === 'diagnostic'));
t('A: day meets the 2-hour minimum', A.minutes_total >= 120, A.minutes_total);
// B: normal day
const B = day();
t('B: normal day >= 120 min', B.minutes_total >= 120, B.minutes_total);
t('B: plan contains Reading & Writing work', B.steps.some((s) => s.kind === 'practice' && /^RW\./.test(s.ref_id)) || B.steps.some((s) => s.kind === 'checkpoint' && /^RW\./.test(s.ref_id)));
t('B: deterministic (same input, same day)', JSON.stringify(B) === JSON.stringify(day()));
t('B: every question id in the plan exists in the bank', B.steps.flatMap((s) => s.question_ids ?? []).every((id) => bank.some((q) => q.id === id)));
// failed checkpoint -> fix-it lesson, no repeat of the same lesson
const C = day({ checkpointFailed: [{ skill_id: 'M.ALG.SYS', trap_code: 'SIGN-ERROR' }] });
t('C: failed checkpoint inserts a fix-it review lesson', C.steps.some((s) => s.kind === 'lesson' && s.tag === 'review'));
t('C: ...with fresh items tagged new', C.steps.some((s) => s.tag === 'new'));
t('C: ...and no repeat of the concept lesson', !C.steps.some((s) => s.kind === 'checkpoint' && s.ref_id === 'M.ALG.SYS'));
// spaced repetition
t('SR: right answers lengthen the interval', scheduleReview({ stage: 0 }, true, 0).due_at > scheduleReview({ stage: -1 }, true, 0).due_at);
t('SR: a wrong answer resets to stage 0', scheduleReview({ stage: 3 }, false, 0).stage === 0);
// adaptation table
let st = {}; st = adapt(st, { type: 'mock_done', day: 7, actual: 1180, predicted: 1200 }).state; st = adapt(st, { type: 'mock_done', day: 14, actual: 1190, predicted: 1210 }).state;
const pl = adapt(st, { type: 'mock_done', day: 21, actual: 1195, predicted: 1215, signals: { careless_share: 0.55, stamina_drop: 0.05 } });
t('ADAPT: flat score across mocks -> plateau diagnosed', pl.flags.plateau?.kind === 'careless', JSON.stringify(pl.flags));
t('ADAPT: plateau fix shows in the day', day({ flags: pl.flags }).why.some((w) => /Plateau fix/.test(w)));
const ms = adapt({}, { type: 'days_missed', n: 3 });
const D2 = day({ flags: ms.flags });
t('ADAPT: 3 missed days -> compressed day (<= 1 block per skill)', D2.steps.filter((s) => s.kind === 'practice').length <= B.steps.filter((s) => s.kind === 'practice').length && D2.why.some((w) => /Compressed/.test(w)));
t('ADAPT: compressed day is still substantial (>= 90 min)', D2.minutes_total >= 90, D2.minutes_total);
t('ADAPT: ahead of schedule -> harder items', adapt({}, { type: 'progress_check', done_units: 14, planned_units: 10 }).flags.ahead === true);
t('ADAPT: failed checkpoint event stores the trap', adapt({}, { type: 'checkpoint', skill_id: 'M.ALG.SYS', correct: 4, total: 8, trap_code: 'SIGN-ERROR' }).state.checkpointFailed[0].trap_code === 'SIGN-ERROR');
// event log replay reproduces state
const log = newLog(); append(log, 'mock_done', { day: 7, actual: 1180, predicted: 1200 }); append(log, 'days_missed', { n: 3 });
const rp = replay(log, (s, e) => adapt(s, e), {});
t('LOG: replay rebuilds the same state', rp.state.mocks.length === 1 && rp.state.flags.compress === true);
t('LOG: shadow diff of identical engines is empty', diffDays(B, day()).only_a.length === 0 && diffDays(B, day()).only_b.length === 0);
// AI guardrails
const ctx = { skillIds: new Set(tax.skills.map((s) => s.id)), lessons: new Map(lessons.map((l) => [l.id, l])), digestNumbers: [62, 91, 130] };
t('AI: valid suggestion accepted', validateSuggestion({ type: 'add_review', skill_id: 'M.ALG.SYS', text: 'Mastery is 62 and the target is 91.' }, ctx).ok);
t('AI: invented number rejected', !checkNumbers('You will gain 250 points in 9 days', [62, 91]).ok);
t('AI: unknown skill rejected', !validateSuggestion({ type: 'add_review', skill_id: 'M.FAKE.SKILL' }, ctx).ok);
t('AI: removing a prerequisite rejected', !validateSuggestion({ type: 'explain', remove_prerequisite: true }, ctx).ok);
t('AI: degrades full -> cached -> template', pickMode({ aiUp: true }) === 'full' && pickMode({ aiUp: false, cacheHit: true }) === 'cached' && pickMode({ aiUp: false, cacheHit: false }) === 'template');
t('AI: template explanation works with AI off', /minutes/.test(templateExplain(B, null)));
// item calibration
const q0 = bank.find((q) => q.section === 'math'); const at = []; for (let i = 0; i < 60; i++) at.push({ question_id: q0.id, correct: i % 10 === 0 ? 1 : 0, student_p: i % 2 ? 0.9 : 0.5 });
const cal = calibrate([q0], at);
t('CAL: item strong students fail is flagged for key review', cal.get(q0.id).flag === 'ambiguous_or_wrong_key', JSON.stringify(cal.get(q0.id)));
t('CAL: measured difficulty moves up for a hard item', cal.get(q0.id).b > (q0.difficulty - 3) * 0.9);
// score model
t('SCORE: curve is monotonic and invertible', sectionScore(0.5) < sectionScore(0.7) && Math.abs(accuracyFor(sectionScore(0.7)) - 0.7) < 0.01);
t('SCORE: higher targets need more mastery', requiredMastery(1500).rw > requiredMastery(1200).rw);
t('SCORE: last points cost more hours per point', hoursNeeded(1400, 1500) / 100 > hoursNeeded(1000, 1100) / 100 * 0.4 && hoursNeeded(1200, 1500) > hoursNeeded(1200, 1400));
const P = buildPath({ tax, mastery: mB, settings: S, now: NOW });
t('PATH: phases cover every day to the test date', P.phases.at(-1).to_day >= S.days_until_test - 1 && P.phases[0].from_day === 1, JSON.stringify(P.phases.map((p) => [p.from_day, p.to_day])));
t('DATA: bank has no unverified items', bank.every((q) => q.status === 'verified' || q.status === 'approved'));
t('DATA: Reading & Writing bank >= 200', bank.filter((q) => q.section === 'rw').length >= 200, bank.filter((q) => q.section === 'rw').length);
// ---- adaptive testing + vocabulary + mock flow ----
import { startState, nextItem, record, isDone, summarize, estimate } from '../src/engine/adaptive.mjs';
import { review as vReview, buildQueue, makeQuestion } from '../src/engine/vocab.mjs';
const sim = (section, trueTheta) => { let s = startState(section), seen = new Set(), k = 0; while (!isDone(s) && k++ < 40) { const q = nextItem(s, bank, seen); if (!q) break; const b = (q.difficulty - 3) * 0.9, p = 0.25 + 0.75 / (1 + Math.exp(-(trueTheta - b))); s = record(s, q, ((k * 0.6180339) % 1) < p); } return s; };
const hi = sim('math', 2), lo = sim('math', -2);
t('ADAPTIVE: strong student ends with higher ability than weak', hi.theta > lo.theta + 1, `${hi.theta} vs ${lo.theta}`);
t('ADAPTIVE: stops within 10..20 items', hi.asked.length >= 10 && hi.asked.length <= 20 && lo.asked.length <= 20);
t('ADAPTIVE: items get harder after correct answers (strong student)', hi.asked.slice(-4).reduce((s, a) => s + a.b, 0) > hi.asked.slice(0, 4).reduce((s, a) => s + a.b, 0));
t('ADAPTIVE: covers several skills (not one topic)', new Set(hi.asked.map((a) => a.skill)).size >= 6, new Set(hi.asked.map((a) => a.skill)).size);
t('ADAPTIVE: deterministic', JSON.stringify(sim('rw', 0.5)) === JSON.stringify(sim('rw', 0.5)));
const sh = summarize(hi, bank, tax), sl = summarize(lo, bank, tax);
t('ADAPTIVE: strong student scores higher, range is ordered', sh.score > sl.score && sh.low <= sh.score && sh.score <= sh.high, JSON.stringify([sh, sl].map((x) => [x.low, x.score, x.high])));
t('ADAPTIVE: precision improves with items', estimate(hi.asked).se < 1.5);
const words = JSON.parse(fs.readFileSync(new URL('../data/vocab.json', import.meta.url))).words;
t('VOCAB: seed list loaded (>= 50 words)', words.length >= 50, words.length);
const q = buildQueue(words, {}, 100), mq = makeQuestion(words[0], words, 100);
t('VOCAB: first day = 10 new words', q.fresh.length === 10 && q.due.length === 0);
t('VOCAB: question has 4 unique choices and the right answer index', new Set(mq.choices).size === 4 && mq.choices[mq.answer] === words[0].meaning);
let vs = vReview({}, 'mitigate', true, 100); vs = vReview(vs, 'mitigate', true, 101);
t('VOCAB: right answers lengthen the interval, wrong resets', vs.mitigate.due > 101 && vReview(vs, 'mitigate', false, 105).mitigate.stage === 0);
t('VOCAB: due words come before new ones', buildQueue(words, { ambiguous: { stage: 0, due: 99, lapses: 0, seen: 1 } }, 100).queue[0].word === 'ambiguous');
t('CAL: forecast bias is capped (one wild score cannot swing the model)', Math.abs((await import('../src/engine/score.mjs')).calibrateBias([{ predicted: 600, actual: 1400 }, { predicted: 600, actual: 1400 }]).bias) <= 60);
console.log(`\n${pass} passed, ${fail} failed`); process.exitCode = fail ? 1 : 0;
