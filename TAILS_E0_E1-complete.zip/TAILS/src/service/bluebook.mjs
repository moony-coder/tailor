// POST /api/import/bluebook : labels-only import. Writes the same attempts rows as native tests (source='bluebook').
import { makeId, iso } from '../util/misc.mjs';
import { validateBluebookInput, buildBluebookAttempts, studyLinks } from '../bluebook/import.mjs';
import { finalizeAnalysis } from './sessions.mjs';
import { invalid, conflict, assertProfile, assertOwner } from './shared.mjs';

export async function importBluebook(ctx, input, actor) {
  const { db, tax } = ctx;
  await assertProfile(db, input?.profile_id ?? actor); assertOwner({ profile_id: input.profile_id }, actor);
  const v = validateBluebookInput(input, tax);
  if (!v.ok) throw invalid('import rejected', v.errors);
  const dup = (await db.select('bluebook_imports', { profile_id: input.profile_id })).find((r) => r.test_number === String(input.test_number) && r.section === input.section && r.module_index === input.module);
  if (dup) {
    if (!input.replace) throw conflict('this test/section/module was already imported; send "replace": true to overwrite it', { session_id: dup.session_id });
    await db.transaction(async (tx) => { await tx.delete('attempts', { session_id: dup.session_id }); await tx.delete('session_modules', { session_id: dup.session_id }); await tx.delete('sessions', { id: dup.session_id }); await tx.delete('bluebook_imports', { id: dup.id }); });
  }
  const now = ctx.now(), sessionId = makeId('s_', now);
  const { rows, moduleId } = buildBluebookAttempts(input, ctx, { sessionId, now });
  const unanswered = rows.filter((r) => r.unanswered).length, size = rows.length;
  const summary = { section: input.section, module_index: input.module, size, correct: rows.filter((r) => r.is_correct).length, unanswered, accuracy: Math.round(rows.filter((r) => r.is_correct).length / size * 100) / 100, used_fraction: null, expired: false, telemetry: false, difficulty_level: 'std', route_score: null };
  const session = { id: sessionId, profile_id: input.profile_id, test_id: null, started_at: iso(now), ended_at: iso(now), status: 'finished', source: 'bluebook', kind: 'bluebook-import', meta_json: { test_number: String(input.test_number), confidence: 'lower' } };
  await db.transaction(async (tx) => {
    await tx.insert('sessions', session);
    await tx.insert('session_modules', { session_id: sessionId, module_id: moduleId, started_at: iso(now), ended_at: iso(now), routed_to: null, score_json: summary });
    for (const r of rows) await tx.insert('attempts', r);
    await tx.insert('bluebook_imports', { id: makeId('bb_', now), profile_id: input.profile_id, session_id: sessionId, test_number: String(input.test_number), section: input.section, module_index: input.module, entered_at: iso(now), notes: input.notes ?? null, domain_levels_json: input.domain_levels ?? null });
  });
  const { inp } = await finalizeAnalysis(ctx, session, { rebuildPlan: true });
  const weak = [...new Set(inp.levers.map((l) => (l.level === 'domain' ? l.skill_id : l.skill_id.split('.').slice(0, 2).join('.'))))];
  return { session_id: sessionId, confidence: 'lower', confidence_note: 'Imported labels have no timing data and right answers have only estimated domains, so conclusions are less certain than from a native test.', warnings: v.warnings, n_wrong: input.wrong.length, top_levers: inp.levers.map((l) => ({ skill_id: l.skill_id, level: l.level, name: l.name, main_cause: l.main_cause })), study_links: studyLinks(weak, tax) };
}
