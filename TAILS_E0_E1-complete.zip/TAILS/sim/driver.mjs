// Day-by-day simulation of ONE student against ONE engine. Deterministic for a given (persona, seed, engine).
// The app glue that turns engine output into student actions (execute the day, schedule reviews, react to checkpoints and
// mocks) lives in the platform and was not part of the extract, so this driver re-implements it from docs/TAILS-ENGINE.md.
// When E4 moves that glue into the engine, this file shrinks to "call engine.step()".
import { createWorld, trueB } from './world.mjs';
import { rng, iso, DAY_MS } from '../src/util/misc.mjs';
import { newLog, append, replay } from '../src/engine/eventlog.mjs';
import { startState, nextItem, record, isDone, summarize } from '../src/engine/adaptive.mjs';

export const START = Date.parse('2026-10-23T00:00:00Z');
const dayMs = (d) => START + (d - 1) * DAY_MS + 18 * 3600e3;
const bandOf = (d) => (d <= 2 ? 'easy' : d === 3 ? 'medium' : 'hard');
const MOCK_MIN_GAP = 5;

export function runStudent({ persona, data, engine, seed = 1, exposure = 'never' }) {
  const { taxonomy: tax, questions: bank, lessons, config } = data;
  const world = createWorld({ persona, tax, seed }), rand = rng(seed * 104729 + 3), E = engine;
  const qById = new Map(bank.map((q) => [q.id, q])), lessonById = new Map(lessons.map((l) => [l.id, l]));
  const byBand = new Map(); // pool bookkeeping: skill -> ids
  for (const q of bank) (byBand.get(q.skill_id) ?? byBand.set(q.skill_id, []).get(q.skill_id)).push(q.id);
  const attempts = [], log = newLog(), served = new Map(), seen = new Set();
  // exposure policy: 'never' = an item served once is gone (what the engine does today); 'recycle' = blueprint rule: wrong answers return after 14 days, right ones after 45; 'unlimited' = infinite fresh items (what E5 aims for; isolates planner and score-model quality from content volume)
  const REC = { wrong: 14, right: 45 };
  const refreshSeen = (day) => { seen.clear(); if (exposure === 'unlimited') return; for (const [id, s] of served) if (exposure === 'never' || s.day + (s.correct ? REC.right : REC.wrong) > day) seen.add(id); };
  const markServed = (id, day, correct) => served.set(id, { day, correct });
  const progress = { lessonDone: new Set(), checkpointFailed: [], seen, due: [], vocabDue: 15, flags: {}, day: 1, diagnosticDone: false };
  let adaptState = {}, bias = 0, hpp, currentScore = persona.known_score, pairs = [], obs = [], minutesSinceMock = 0, missed = 0, absentLeft = 0, path = null, lastMockDay = -99, lastMockActual = null, pathBase = null;
  const T = { persona: persona.label, engine: E.id, seed, days: [], mocks: [], paths: [], mastery_checks: [], diag: null, final: null, events: 0 };
  const logE = (type, data, t) => { append(log, type, data, t); T.events++; };
  const mastery = (now) => E.computeMastery(attempts, config.thresholds, now);
  let aid = 0;
  const addAttempt = (q, a, day, t, extra = {}) => attempts.push({ id: ++aid, created_at: iso(t), is_correct: a.correct ? 1 : 0, difficulty: q.difficulty, skill_id: q.skill_id, domain: tax.domainOf(q.skill_id), question_id: extra.mock ? null : q.id, question_ref: q.id, micro_skill_ids_json: [],
    source: extra.source ?? 'practice', trap_code: a.trap_code, est_time_sec: q.est_time_sec ?? 75, total_ms: a.total_ms, telemetry: 1, flagged: 0, ...extra.row });

  // ---------- diagnostic (Student A): adaptive test, 10 to 20 items per section ----------
  function runDiagnostic(day) {
    const t0 = dayMs(day); let n = 0, tot = 0; const sec = {};
    for (const section of ['rw', 'math']) {
      let st = startState(section);
      while (!isDone(st)) { const q = nextItem(st, bank, seen); if (!q) break; const a = world.answer(q); st = record(st, q, a.correct); markServed(q.id, day, a.correct); seen.add(q.id); addAttempt(q, a, day, t0 + (n++) * 60e3, { source: 'diagnostic' }); }
      sec[section] = summarize(st, bank, tax);
    }
    tot = sec.rw.score + sec.math.score; T.diag = { rw: sec.rw.score, math: sec.math.score, total: tot, items: n, true_total: world.trueScore().total };
    currentScore = tot; progress.diagnosticDone = true; return n;
  }

  // ---------- a full mock (98 items, module 2 routed by module 1) ----------
  const BP = config.blueprints.modules, MIX = config.blueprints.difficulty_mix;
  function makeModule(sec, level, tag, rnd) {
    const bp = BP[`${sec}_full`], items = [];
    for (const [dom, cnt] of Object.entries(bp.domains)) {
      const ss = tax.skillsByDomain.get(dom);
      for (let i = 0; i < cnt; i++) {
        let r = rnd(), s = ss[0]; for (const x of ss) { if (r < x.skill_share_within_domain) { s = x; break; } r -= x.skill_share_within_domain; }
        const m = MIX[level], u = rnd(), band = u < m.easy ? 'easy' : u < m.easy + m.medium ? 'medium' : 'hard';
        const d = band === 'easy' ? 1 + Math.floor(rnd() * 2) : band === 'medium' ? 3 : 4 + Math.floor(rnd() * 2);
        const id = `MOCK-${tag}-${items.length}`;
        const q = { id, skill_id: s.id, difficulty: d, section: sec, format: 'mcq4', est_time_sec: sec === 'rw' ? 60 : [0, 35, 45, 70, 90, 105][d] };
        q.b = trueB(q); items.push(q);
      }
    }
    return { items, limit: bp.time_limit_sec };
  }
  function takeModule(mod, day, t0, base) {
    let clock = 0; const res = [], n = mod.items.length;
    mod.items.forEach((q, i) => {
      const frac = i / n, fatigue = world.st.stamina * Math.max(0, (frac - 0.6) / 0.4);
      const a = world.answer(q, { fatigue }); let unanswered = false;
      clock += a.total_ms / 1000;
      if (clock > mod.limit) { unanswered = true; a.correct = rand() < 0.25; a.total_ms = 0; }
      res.push({ q, a, unanswered, pos: i + 1 });
      addAttempt(q, a, day, t0 + (base + i) * 30e3, { source: 'mock', mock: true, row: { unanswered: unanswered ? 1 : 0, ran_out_of_time: unanswered ? 1 : 0, position: i + 1, module_size: n } });
    });
    return res;
  }
  function estTheta(items) { // independent MLE (weak prior) from realized answers: the "IRT scoring" of the simulated test
    let th = 0; for (let k = 0; k < 30; k++) { let g = -th / 2.25, h = -1 / 2.25; for (const x of items) { const s = 1 / (1 + Math.exp(-world.W.slope * (th - x.b))), p = 0.25 + 0.75 * s, d = 0.75 * world.W.slope * s * (1 - s); g += (x.c - p) / (p * (1 - p)) * d; h -= d * d / (p * (1 - p)); } const step = g / h; th = Math.max(-4, Math.min(4, th - step)); if (Math.abs(step) < 1e-5) break; } return th;
  }
  function runMock(day, kind) {
    const t0 = dayMs(day), tag = `${kind}${day}`, secs = {}, all = [];
    let off = 0;
    for (const sec of ['rw', 'math']) {
      const m1 = takeModule(makeModule(sec, 'std', `${tag}-${sec}1`, rand), day, t0, off); off += m1.length;
      const acc1 = m1.filter((x) => x.a.correct).length / m1.length, lvl = acc1 >= config.blueprints.routing?.hard_route_threshold ?? 0.65 ? 'hard' : 'easy';
      const m2 = takeModule(makeModule(sec, lvl, `${tag}-${sec}2`, rand), day, t0, off); off += m2.length;
      const rows = [...m1, ...m2]; all.push(...rows);
      const th = estTheta(rows.map((x) => ({ b: x.q.b, c: x.a.correct ? 1 : 0 })));
      const accRef = world.accSkill(th, sec);                // expected std-mix accuracy at the estimated ability, as the test's scaler would report
      secs[sec] = { score: world.mockMapping(accRef), acc1: +acc1.toFixed(2), route: lvl, theta: +th.toFixed(2), m1, m2 };
    }
    const noiseFree = persona.mock_noise === false;
    const actual = noiseFree ? world.trueScore().total : secs.rw.score + secs.math.score, trueNow = world.trueScore().total;
    const third = (mod, a, b) => { const s = mod.slice(Math.floor(mod.length * a), Math.ceil(mod.length * b)); return s.filter((x) => x.a.correct).length / Math.max(1, s.length); };
    const stam = (['rw', 'math'].map((s) => [secs[s].m1, secs[s].m2]).flat().reduce((z, m) => z + third(m, 0, 0.34) - third(m, 0.67, 1), 0)) / 4;
    const wrong = all.filter((x) => !x.a.correct), signals = { stamina_drop: +Math.max(0, stam).toFixed(3), careless_share: +(wrong.filter((x) => x.q.difficulty <= 2 && !x.unanswered).length / Math.max(1, wrong.length)).toFixed(3), time_share: +(all.filter((x) => x.unanswered).length / all.length).toFixed(3) };
    return { actual, trueNow, signals, rw: secs.rw.score, math: secs.math.score, route: [secs.rw.route, secs.math.route] };
  }

  // ---------- path rebuild ----------
  const settingsFor = (day) => ({ target_score: persona.target, current_score: currentScore, days_until_test: persona.days - day + 1, minutes_per_day: persona.minutes });
  function rebuildPath(day, why) {
    const now = dayMs(day), m = mastery(now);
    path = E.buildPath({ tax, mastery: m, settings: settingsFor(day), hpp, bias, now });
    pathBase = { day, current: path.current };
    T.paths.push({ day, why, status: path.status, current: path.current, predicted: path.predicted.total, forecast_at_test: path.forecast_at_test, hours_needed: path.hours_needed, hours_available: path.hours_available, mock_days: path.mock_days, hpp: hpp ?? null });
  }

  // ---------- execute a day plan against the student ----------
  function execute(plan, day, availMin) {
    const t0 = dayMs(day); let left = availMin, done = 0, tt = 0; const kinds = [], qIds = []; let rwQ = 0, mathQ = 0, wasFix = false;
    const ask = (ids, source) => ids.map((id) => { const q = qById.get(id); const a = world.answer(q); addAttempt(q, a, day, t0 + (tt++) * 45e3, { source }); world.learnFrom(q, a.correct, day); markServed(id, day, a.correct); seen.add(id); qIds.push(id); (q.section === 'rw' ? rwQ++ : mathQ++); return { q, a }; });
    for (const s of plan.steps) {
      if (s.minutes > left + 0.01) break;
      left -= s.minutes; done += s.minutes; kinds.push(s.kind);
      if (s.kind === 'diagnostic') { runDiagnostic(day); logE('diagnostic_done', { total: T.diag.total }, t0); }
      else if (s.kind === 'lesson') { const l = lessonById.get(s.ref_id); progress.lessonDone.add(s.ref_id); if (l?.skill_id && ['concept', 'examples', 'traps', 'fixit'].includes(l.kind)) world.lesson(l.skill_id, l.kind, day, l.id); if (s.tag === 'review') wasFix = true; }
      else if (s.kind === 'checkpoint') {
        const r = ask(s.question_ids, 'checkpoint'), c = r.filter((x) => x.a.correct).length, wrong = r.filter((x) => !x.a.correct && x.a.trap_code), cnt = {}; wrong.forEach((x) => (cnt[x.a.trap_code] = (cnt[x.a.trap_code] ?? 0) + 1));
        const trap = Object.entries(cnt).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0];
        const ev = { type: 'checkpoint', skill_id: s.ref_id, correct: c, total: r.length, trap_code: trap }; adaptState = E.adapt(adaptState, ev).state; logE('checkpoint', ev, t0);
        progress.checkpointFailed = adaptState.checkpointFailed ?? [];
        if (c / r.length >= 0.75) { const e = E.scheduleReview(null, true, dayMs(day)); progress.due = progress.due.filter((d) => d.skill_id !== s.ref_id); progress.due.push({ skill_id: s.ref_id, ...e }); }
      } else if (s.kind === 'practice') { const r = ask(s.question_ids, 'practice'); if (s.tag === 'new') wasFix = true; }
      else if (s.kind === 'review' && s.ref_id === 'spaced') {
        const r = ask(s.question_ids, 'review'), bySkill = new Map(); r.forEach((x) => { const e = bySkill.get(x.q.skill_id) ?? { c: 0, n: 0 }; e.n++; e.c += x.a.correct; bySkill.set(x.q.skill_id, e); });
        for (const [sk, e] of bySkill) { const cur = progress.due.find((d) => d.skill_id === sk), nx = E.scheduleReview(cur ?? null, e.c / e.n >= 0.6, dayMs(day)); progress.due = progress.due.filter((d) => d.skill_id !== sk); progress.due.push({ skill_id: sk, ...nx }); }
      } else if (s.kind === 'vocab') world.generic('vocab', day);
      else if (s.kind === 'mistakes') world.generic('mistakes', day);
      else if (s.kind === 'timed') { world.generic('timed', day); if (s.minutes > 16) world.generic('timed', day); }
    }
    if (wasFix) { progress.checkpointFailed = []; adaptState = { ...adaptState, checkpointFailed: [] }; }
    return { done, kinds, qIds, rwQ, mathQ };
  }

  // ======================= the days =======================
  const startTrue = world.trueScore().total;
  let spearmanAcc = [];
  for (let day = 1; day <= persona.days; day++) {
    const now = dayMs(day); progress.day = day;
    // attendance (streaky absences)
    let attends = true;
    if (day > 1 && day < persona.days) { if (absentLeft > 0) { attends = false; absentLeft--; } else if (rand() < (1 - persona.attend) / (persona.absence_run ? (persona.absence_run + 1) / 2 : 1)) { attends = false; absentLeft = persona.absence_run ? Math.floor(rand() * persona.absence_run) : 0; } }
    if (!attends) { missed++; world.endDay(day); T.days.push({ day, attended: false, truth: world.trueScore().total }); continue; }
    if (missed > 0 && day < persona.days) { const ev = { type: 'days_missed', n: missed }; adaptState = E.adapt(adaptState, ev).state; logE('days_missed', ev, now); missed = 0; }
    progress.flags = adaptState.flags ?? {};
    if (day === 1 || (day - 1) % 7 === 0 || !path) rebuildPath(day, day === 1 ? 'start' : 'weekly');
    refreshSeen(day);
    const m = mastery(now), avail = Math.round(persona.minutes * (0.85 + 0.3 * rand()));
    const isMock = path && path.mock_days.includes(day) && day - lastMockDay >= MOCK_MIN_GAP && (m.size > 0 || currentScore != null) && day < persona.days && progress.diagnosticDone !== false && !(persona.known_score == null && !progress.diagnosticDone);
    const isFinal = day === persona.days;
    if (isFinal || isMock) {
      const predicted = E.predictScore(tax, m, E.keyOf, bias), R = runMock(day, isFinal ? 'final' : 'mock'), tr = R.trueNow;
      const rec = { day, kind: isFinal ? 'final' : 'mock', predicted: predicted.total, low: predicted.low, high: predicted.high, actual: R.actual, true_now: tr, signals: R.signals, bias_used: bias, route: R.route };
      T.mocks.push(rec);
      if (!isFinal) {
        const ev = { type: 'mock_done', day, actual: R.actual, predicted: predicted.total, signals: R.signals }; adaptState = E.adapt(adaptState, ev).state; logE('mock_done', ev, now);
        pairs.push({ predicted: predicted.total, actual: R.actual }); bias = E.calibrateBias(pairs).bias;
        if (lastMockActual != null) { obs.push({ hours: minutesSinceMock / 60, points: R.actual - lastMockActual }); hpp = E.calibrateHpp(obs).hpp; }
        if (path && pathBase && path.forecast) { const wk = Math.min(path.forecast.length - 1, Math.round((day - pathBase.day) / 7)), planned = path.forecast[wk].score - pathBase.current; if (planned > 10) { const ev2 = { type: 'progress_check', done_units: Math.max(0, R.actual - pathBase.current), planned_units: planned }; adaptState = E.adapt(adaptState, ev2).state; logE('progress_check', ev2, now); } }
        currentScore = R.actual; lastMockActual = R.actual; lastMockDay = day; minutesSinceMock = 0; progress.flags = adaptState.flags ?? {};
        rebuildPath(day, 'after_mock');
      } else { T.final = { day, actual: R.actual, true_now: tr, predicted: predicted.total, start_true: startTrue }; }
      world.endDay(day);
      T.days.push({ day, attended: true, mock: true, truth: world.trueScore().total, pred: predicted.total });
      continue;
    }
    const settings = settingsFor(day);
    const plan = E.buildDay({ tax, mastery: m, lessons, bank, settings, progress, now });
    const ex = execute(plan, day, avail); minutesSinceMock += ex.done;
    // pool bookkeeping (verified items never seen, per skill)
    const unseen = {}; for (const s of tax.skills) unseen[s.id] = (byBand.get(s.id) ?? []).filter((id) => !seen.has(id)).length;
    const dupInDay = ex.qIds.length - new Set(ex.qIds).size, unknownIds = plan.steps.flatMap((s) => s.question_ids ?? []).filter((id) => !qById.has(id)).length;
    const pr = E.predictScore(tax, mastery(now), E.keyOf, bias);
    T.days.push({ day, attended: true, mode: plan.mode, planned_min: plan.minutes_total, avail_min: avail, done_min: ex.done, min_met: plan.minimum_met, kinds: ex.kinds, q: ex.qIds.length, rw_q: ex.rwQ, math_q: ex.mathQ, dup_in_day: dupInDay, unknown_ids: unknownIds, alerts: (plan.pool_alerts ?? []).map((a) => a.skill_id), focus: (plan.focus ?? []).slice(0, 5).map((f) => f.skill_id), flags: Object.keys(adaptState.flags ?? {}), unseen_min: Math.min(...Object.values(unseen)), exhausted: Object.entries(unseen).filter(([, n]) => n < 8).map(([k]) => k), truth: world.trueScore().total, pred: pr.total, practised: [...new Set(plan.steps.filter((s) => s.kind === 'practice').map((s) => s.ref_id))] });
    // mastery quality, weekly
    if (day % 7 === 0) {
      const mm = mastery(now), rows = tax.skills.map((s) => ({ s: s.id, est: mm.get(E.keyOf(s.id)), tr: world.trueP(s.id) })).filter((r) => r.est && !r.est.insufficient);
      const mae = rows.reduce((a, r) => a + Math.abs(r.est.p - r.tr), 0) / Math.max(1, rows.length);
      const rank = (xs) => xs.map((x, i) => [x, i]).sort((a, b) => a[0] - b[0]).reduce((o, [, i], r) => (o[i] = r, o), []);
      let rho = null; if (rows.length >= 6) { const a = rank(rows.map((r) => r.est.p)), b = rank(rows.map((r) => r.tr)), n = rows.length; rho = 1 - 6 * a.reduce((s, x, i) => s + (x - b[i]) ** 2, 0) / (n * (n * n - 1)); }
      T.mastery_checks.push({ day, skills_with_evidence: rows.length, mae: +mae.toFixed(3), rho: rho == null ? null : +rho.toFixed(2) });
    }
    world.endDay(day);
  }
  // final bookkeeping
  const lastDays = T.days.filter((d) => d.attended && !d.mock && d.day > persona.days - 14).map((d) => d.day);
  const weakEnd = tax.skills.filter((s) => world.trueP(s.id) < 0.6).map((s) => s.id);
  const touchedRecent = new Set(T.days.filter((d) => d.day > persona.days - 14).flatMap((d) => d.practised ?? []));
  T.neglected_weak_at_end = weakEnd.filter((s) => !touchedRecent.has(s));
  T.weak_at_end = weakEnd.length;
  T.final_pool = Object.fromEntries(tax.skills.map((s) => [s.id, (byBand.get(s.id) ?? []).filter((id) => !seen.has(id)).length]));
  T.replay = (() => { const r = replay(log, (s, e) => { const { type, seq, v, t, ...ev } = e; return ['mock_done', 'days_missed', 'progress_check', 'checkpoint', 'settings_changed'].includes(type) ? E.adapt(s, { type, ...ev }) : { state: s, notes: [] }; }, {}); return { ok: JSON.stringify({ m: r.state.mocks ?? [], f: r.state.flags ?? {} }) === JSON.stringify({ m: adaptState.mocks ?? [], f: adaptState.flags ?? {} }), events: log.events.length }; })();
  T.attempts = attempts.length; T.hours = Math.round(T.days.filter((d) => d.attended && !d.mock).reduce((s, d) => s + (d.done_min ?? 0), 0) / 60);
  return T;
}
