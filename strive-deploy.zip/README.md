# Strive SAT, Jamal's International Academy

Static site, no build step. **Run locally:** open THIS folder (the one containing `index.html`) in VS Code and press Go Live, or deploy it to Vercel. All paths are relative, so it also works from any sub-folder. Upload this folder to Vercel (Framework Preset: **Other**, no build command, output directory: root).

## Pages
| URL | File | What |
|---|---|---|
| `/` (`index.html`) | `index.html` | Landing page (`assets/css/landing-v2.css`, `assets/js/landing.js`). Returning students are sent straight to `/app`; add `#home` to the URL to view it anyway |
| `/onboarding` | `onboarding.html` | 6-step setup: name, test date, starting score, goal, daily goal, ready. Live plan panel, always-on clock and test-day countdown |
| `/onboarding?edit` | same | Re-run setup later without losing progress |
| `/app` | `app.html` | The whole app (dashboard, practice, bank, tests, lessons, watch, analytics, review, plan, rewards) |

## Folder
- `assets/css` styles (`icons.css` icon font rules, `app.css`, `onboarding.css`, `fonts.css`)
- `assets/js` app code in load order (`01-core` ... `14-plus-onboarding`, `99-boot`), `config.js` = your settings
- `assets/data` question bank, lessons-era content, SAT dates
- `assets/img`, `assets/fonts` real image/font files (no more base64 inside HTML)

## What's new (read this first)
- **Videos**: one list in `assets/data/videos.js` (35 @marifat_jamal videos). Titles, sections and channel are filled in by the app; videos that can't embed hide themselves. Open `/check-videos` for a green/red report.
- **Parallax**: `assets/css/parallax.css` + `assets/js/18-parallax.js` (scroll + pointer depth, off for reduced-motion). Browser-default scrolling is untouched.
- **Questions**: `assets/data/questions-extra.js` (+110), `QUESTION-FACTORY.md`, `/check-questions`.
- Accounts, sync and payments are intentionally not built yet.

## Video lessons (Watch tab)
Videos are **links only**. Nothing is uploaded or stored. Open `assets/data/videos.js` and add one line per video:

```js
v('https://www.youtube.com/watch?v=XXXXXXXXXXX', 'm', 'math_algebra', 'Title', 'Channel', 'One-line why watch');
```
- Any YouTube link works (watch, youtu.be, shorts, embed, or the bare id). Add `&t=90` to start at 1:30.
- Section: `m` (Math), `rw` (Reading & Writing), `tips` (Strategy). Topic links the video to Practice and Lessons.
- Title and channel can be left as `''`; the site fetches them.
- The player is fully custom (our poster, controls, colours). Nothing from YouTube loads until a student presses play.
- Students' progress and resume position are saved in their browser. Videos also appear under each Lesson and on the Home screen.
- Keys: Space/K play, J/L skip 10s, arrows 5s, M mute, F fullscreen, `<` `>` speed.
- **Check each link before you ship.** Some uploaders switch off embedding; those videos show a friendly "will not play here" card with an "Open original" button. Pick videos that play inside the Watch tab.

## Settings (`assets/js/config.js`)
`checkoutUrl` empty = no paywall, everything free. See "Plus" below.

## Data: what is real
Nothing is pre-filled. A student starts at 0 and every number comes from what they answered. Scores show "—" until 5+ answers in each section.
Progress is saved in the student's own browser (localStorage key `strive_sat_v3`). Clearing browser data, or switching phone/laptop, starts fresh.

## Plus / payments
The old version unlocked Plus for free. That is removed. To sell Plus for real you need accounts + a server that verifies payment (Stripe webhook). Until then keep `checkoutUrl` empty.

## Add questions
Edit `assets/data/questions.js` (`QB`) or `assets/data/content-bank.js` (`BANK`). Keep the same fields as existing items.

## Design layers (added)
- `assets/css/next.css` + `assets/js/16-next.js`: custom select / date / number / range, tooltips, scrollers, confirm, command palette (Ctrl/Cmd+K)
- `assets/css/pro.css` + `assets/js/17-motion.js`: view transitions, staggered entrances, sliding nav pill, card tilt, ripples, hero and mascot finish


## Build notes (merged release)
- Base: the "updated" build (videos, parallax, extra questions, tools) with relative paths so it runs under Live Server, file or Vercel.
- Questions: 25 `g-` Standard English Conventions items merged into `questions-extra.js`; six were rewritten because they had two valid answers, and answer positions were balanced.
- Legal: items in `questions.js` whose explanations read "Choice X is the best answer because..." appear to be College Board text. Replace them before a public launch.


## Latest changes
- Landing page, climb-track dashboard (`20-climb.js`), mobile More menu (`19-more.js`), hero pointer depth only (`18-parallax.js`), Caveat self-hosted.
- The landing page says "Start free". If you set `checkoutUrl` in `config.js`, review that wording.

## Smoothness pass (landing, onboarding, intro)
- Font: Plus Jakarta Sans (`assets/fonts/jakarta.woff2`, family "Jakarta") replaces Geist / Geist Mono on the landing, onboarding and intro only. The app keeps its own fonts.
- Onboarding: content leaves, the card eases to the next step's height (no empty space above Continue), content enters. Mascot crossfades between two preloaded, decoded layers. The score field, "Show later dates" and the hand-off to the intro all animate too.
- Intro: dashboard work now runs hidden before the iris opens (was the freeze). Quality steps down automatically on slow devices (lite / minimal), writes to the DOM are cached, Skip fades out instead of cutting.

## Redesign pass (refine layer)
- `assets/css/refine.css` loads last on the landing page and the app. It holds the utility classes that replaced inline styles in `app.html`, plus layout fixes (climb-track labels, scholar profile avatar, settings rows), sentence-case labels, contrast and empty-state tweaks.
- Shadows are tinted (`#00110b`) instead of pure black, and no rule uses `transition: all`.
- `17-motion.js`: the sliding toggle thumb re-attaches itself after a re-render (fixes the invisible active tab on Watch).
- New pages: `privacy.html`, `terms.html` (linked from the landing footer, listed in `sitemap.xml`). Have them reviewed before launch.
- Question bank: toggles no longer blank the list and question panel (`Motion.swap` in `17-motion.js` repaints in place and eases in); the sliding highlight now moves on the same frame as the click; search bar has a single focus ring (`fixes.css`, `refine.css`).
