// Signals derived from RAW mock items (never trusted from the caller): stamina drop, careless share, time share.
// One implementation, used by the engine reducer and by the legacy adapter, so a replay of the log gives the same numbers.
//
// item: { skill, d (difficulty 1..5), ok (bool), unans (bool), pos (1-based inside its module), n (module size), mod (module index) }

const third = (mod, a, b) => {
  const s = mod.slice(Math.floor(mod.length * a), Math.ceil(mod.length * b));
  return s.filter((x) => x.ok).length / Math.max(1, s.length);
};

/** Group consecutive items by module. Falls back to `mod`, then to position resets. */
export function modulesOf(items) {
  const out = [];
  let cur = null, lastMod = null;
  for (const it of items) {
    const key = it.mod ?? (it.pos === 1 ? `p${out.length}` : lastMod);
    if (cur === null || key !== lastMod) { cur = []; out.push(cur); lastMod = key; }
    cur.push(it);
  }
  return out;
}

export function mockSignals(items) {
  if (!items?.length) return { stamina_drop: 0, careless_share: 0, time_share: 0 };
  const mods = modulesOf(items).filter((m) => m.length >= 3);
  const stam = mods.length ? mods.reduce((z, m) => z + third(m, 0, 0.34) - third(m, 0.67, 1), 0) / mods.length : 0;
  const wrong = items.filter((x) => !x.ok);
  return {
    stamina_drop: +Math.max(0, stam).toFixed(3),
    careless_share: +(wrong.filter((x) => x.d <= 2 && !x.unans).length / Math.max(1, wrong.length)).toFixed(3),
    time_share: +(items.filter((x) => x.unans).length / items.length).toFixed(3),
  };
}
