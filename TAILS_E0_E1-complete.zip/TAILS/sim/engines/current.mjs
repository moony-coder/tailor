// Adapter: the engine under test. The harness talks to the engine ONLY through this object, so a new engine version
// (E3 planner v3, E4 student model v3, ...) is tested by writing another adapter with the same shape and running
//   node sim/run.mjs --compare sim/engines/<new>.mjs
import { buildDay, feasibility, scheduleReview } from '../../src/engine/daily.mjs';
import { buildPath } from '../../src/engine/path.mjs';
import { computeMastery, keyOf } from '../../src/engine/mastery.mjs';
import { predictScore, calibrateBias, calibrateHpp } from '../../src/engine/score.mjs';
import { adapt } from '../../src/engine/adapt.mjs';
import { ENGINE_VERSION } from '../../src/engine/eventlog.mjs';

export default { id: 'tails-current', version: ENGINE_VERSION, buildDay, buildPath, feasibility, scheduleReview, computeMastery, keyOf, predictScore, calibrateBias, calibrateHpp, adapt };
