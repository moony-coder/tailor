// In-browser "server". The whole audit engine runs inside the page, so the site is 100% static (works on a Vercel drop, no backend).
// Student data is kept in this browser (localStorage). The Groq key comes from assets/js/config.js (groqApiKey).
import { MemoryDb } from './src/db/memory.mjs';
import { createContext, seedDb } from './src/context.mjs';
import { createTaxonomy } from './src/taxonomy/index.mjs';
import { dispatch } from './src/api/routes.mjs';
import { createLlm } from './src/llm/factory.mjs';
import { iso } from './src/util/misc.mjs';

export const ME = 'me';
const LS_KEY = 'strive_sat_db_v1';
// seeded from data.json on every load, so we never store them
const STATIC_TABLES = new Set(['skills', 'micro_skills', 'trap_codes', 'reasons', 'questions', 'question_micro_skills', 'lessons']);

const store = {
  read() { try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch { return null; } },
  write(snap) {
    const put = (s) => localStorage.setItem(LS_KEY, JSON.stringify(s));
    try { put(snap); return; } catch { /* quota: drop the bulkiest, least useful tables and retry */ }
    try { put({ ...snap, events: [], ai_usage_log: [], skill_mastery_history: (snap.skill_mastery_history || []).slice(-200) }); } catch { /* storage unavailable: keep working in memory */ }
  },
};

let ready = null;
export function boot({ groqApiKey = '', dataUrl, name = 'Student' } = {}) {
  return (ready ??= (async () => {
    const data = await (await fetch(dataUrl)).json();
    const taxonomy = createTaxonomy({ skills: data.skills, microskills: data.microskills, traps: data.traps, reasons: data.reasons });
    const saved = store.read();
    let timer = null;
    const persist = (snap) => {                                   // debounced so a burst of events is one write
      clearTimeout(timer);
      timer = setTimeout(() => store.write(Object.fromEntries(Object.entries(snap).filter(([t]) => !STATIC_TABLES.has(t)))), 400);
    };
    const db = new MemoryDb({ snapshot: saved || undefined, persist });
    const ctx = createContext({ db, seed: (Date.now() % 2147483647) || 1, data: { taxonomy, questions: data.questions, lessons: data.lessons.lessons, config: { thresholds: data.thresholds, blueprints: data.blueprints, routing: data.routing } } });
    await seedDb(ctx);
    ctx.auditEnabled = true;
    // Groq straight from the browser. fetch must not be called as a method of the provider (Illegal invocation), hence the wrapper.
    ctx.llm = createLlm(ctx.config.routing, { GROQ_API_KEY: groqApiKey }, { fetchImpl: (...a) => fetch(...a) });
    if (!(await db.get('profiles', ME))) await db.insert('profiles', { id: ME, display_name: name, role: 'student', settings_json: { minutes_per_day: 45, horizon_days: 7 }, created_at: iso(Date.now()) });
    window.addEventListener('pagehide', () => { clearTimeout(timer); store.write(Object.fromEntries(Object.entries(db.snapshot()).filter(([t]) => !STATIC_TABLES.has(t)))); });
    return { ctx, db };
  })());
}

/** Same contract as the old HTTP API: resolves {status, body}. */
export async function call(method, path, body) {
  const { ctx } = await ready;
  const u = new URL(path, 'http://local');
  return dispatch(ctx, { method, path: u.pathname, query: Object.fromEntries(u.searchParams), body: body ?? null, actor: ME });
}
export async function setName(name) { const { db } = await ready; await db.update('profiles', { id: ME }, { display_name: name }); }
export async function resetAll() { try { localStorage.removeItem(LS_KEY); } catch { /* */ } }
