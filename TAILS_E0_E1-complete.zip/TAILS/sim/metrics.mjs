// Trace -> numbers. Every metric has a direction (lower/higher is better) so runs can be compared and gated.
const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : null);
const r = (x, d = 1) => (x == null ? null : +x.toFixed(d));

export function summarize(T, persona, data) {
  const att = T.days.filter((d) => d.attended && !d.mock && d.mode), normal = att.filter((d) => d.mode === 'normal');
  const final = T.final, start = final.start_true, endTrue = final.true_now, gain = endTrue - start, gap = persona.target - start;
  // --- forecast quality ---
  const ms = T.mocks.filter((m) => m.kind === 'mock' || m.kind === 'final'), err = ms.map((m) => m.predicted - m.true_now);
  const EARLY = 14, errE = ms.filter((m) => m.kind === 'mock' && m.day < EARLY).map((m) => m.predicted - m.true_now), errM = ms.filter((m) => m.kind !== 'mock' || m.day >= EARLY).map((m) => m.predicted - m.true_now);
  const hz = (lo, hi) => T.paths.filter((p) => p.forecast_at_test != null && persona.days - p.day >= lo && persona.days - p.day < hi).map((p) => Math.abs(p.forecast_at_test - endTrue));
  const firstStatus = T.paths[0].status, reached = endTrue >= persona.target;
  // --- plan sanity ---
  const jac = (a, b) => { const A = new Set(a), B = new Set(b), i = [...A].filter((x) => B.has(x)).length, u = new Set([...A, ...B]).size; return u ? i / u : 1; };
  const churn = []; for (let i = 1; i < normal.length; i++) if (normal[i].focus.length && normal[i - 1].focus.length) churn.push(1 - jac(normal[i].focus, normal[i - 1].focus));
  const rw = normal.reduce((s, d) => s + d.rw_q, 0), mq = normal.reduce((s, d) => s + d.math_q, 0);
  const firstShort = normal.find((d) => d.planned_min < 120)?.day ?? null;
  const bankN = {}; for (const q of data.questions) bankN[q.skill_id] = (bankN[q.skill_id] ?? 0) + 1;
  const runDry = Object.entries(T.final_pool).filter(([k, n]) => n < 8 && (bankN[k] ?? 0) >= 8).length;
  const mc = T.mastery_checks.slice(-2);
  const diagDays = att.filter((d) => d.mode === 'diagnostic').length;
  return {
    persona: persona.label, engine: T.engine, seed: T.seed,
    start_true: start, end_true: endTrue, gain, target: persona.target, gap_closed: r(gap > 0 ? gain / gap : null, 2), reached: reached ? 1 : 0, final_actual: final.actual, hours: T.hours, pts_per_hour: r(T.hours ? gain / T.hours : null, 2),
    nowcast_mae: r(mean(err.map(Math.abs))), nowcast_early: r(mean(errE.map(Math.abs))), nowcast_mature: r(mean(errM.map(Math.abs))), nowcast_bias: r(mean(err)), nowcast_last_err: r(err.at(-1)),
    forecast_mae_far: r(mean(hz(35, 999))), forecast_mae_mid: r(mean(hz(15, 35))), forecast_mae_near: r(mean(hz(0, 15))),
    day1_verdict: firstStatus, verdict_wrong: (firstStatus === 'at_risk' && reached) || (firstStatus === 'on_track' && !reached) ? 1 : 0,
    attended_days: att.length, short_days: att.filter((d) => d.mode === 'normal' && d.planned_min < 120).length, short_share: r(normal.length ? normal.filter((d) => d.planned_min < 120).length / normal.length : 0, 3),
    first_short_day: firstShort, diag_days: diagDays, diag_repeat: Math.max(0, diagDays - 1),
    over_avail_share: r(att.length ? att.filter((d) => d.planned_min > d.avail_min * 1.05).length / att.length : 0, 3),
    stated_below_min: persona.minutes < 120 && normal.some((d) => d.planned_min > persona.minutes * 1.05) ? 1 : 0,
    dup_in_day: att.reduce((s, d) => s + d.dup_in_day, 0), unknown_ids: att.reduce((s, d) => s + d.unknown_ids, 0),
    rw_share_q: r(rw + mq ? rw / (rw + mq) : null, 2), churn: r(mean(churn), 2),
    neglected_weak: T.neglected_weak_at_end.length, weak_at_end: T.weak_at_end,
    run_dry_skills: runDry, empty_skills: Object.entries(bankN).length < data.taxonomy.skills.length ? data.taxonomy.skills.length - Object.entries(bankN).length : 0,
    mastery_mae: mc.length ? r(mean(mc.map((x) => x.mae)), 3) : null, mastery_rho: mc.length ? r(mean(mc.map((x) => x.rho).filter((x) => x != null)), 2) : null,
    replay_ok: T.replay.ok ? 1 : 0, events: T.events,
  };
}

/** Metric registry: direction, tolerance for the regression gate, and the TARGET the later engine phases must reach (null = no target yet). */
export const METRICS = [
  { key: 'gain', dir: 'higher', floor: 8, tol: 8, target: null, label: 'true score gain (pts)' },
  { key: 'gap_closed', dir: 'higher', floor: 0.05, tol: 0.05, target: null, label: 'share of target gap closed' },
  { key: 'nowcast_mae', dir: 'lower', floor: 8, tol: 8, target: 40, label: 'score-model error vs truth (pts)' },
  { key: 'nowcast_early', dir: 'lower', floor: 30, tol: 30, target: 80, label: 'score-model error, mocks before day 14 (pts)' },
  { key: 'nowcast_mature', dir: 'lower', floor: 10, tol: 10, target: 40, label: 'score-model error, mocks from day 14 (pts)' },
  { key: 'forecast_mae_far', dir: 'lower', floor: 12, tol: 12, target: 80, label: 'forecast error, >35 days out' },
  { key: 'forecast_mae_mid', dir: 'lower', floor: 12, tol: 12, target: 60, label: 'forecast error, 15-35 days out' },
  { key: 'short_share', dir: 'lower', floor: 0.04, tol: 0.04, target: 0.05, label: 'days shorter than the 2h promise' },
  { key: 'diag_repeat', dir: 'lower', floor: 0.5, tol: 0.5, target: 0, label: 'diagnostic repeated after day 1' },
  { key: 'over_avail_share', dir: 'lower', floor: 0.05, tol: 0.05, target: 0.1, label: 'plan longer than the time the student has' },
  { key: 'run_dry_skills', dir: 'lower', floor: 1, tol: 1, target: 0, label: 'skills whose pool ran dry' },
  { key: 'neglected_weak', dir: 'lower', floor: 1, tol: 1, target: 1, label: 'weak skills untouched in the last 14 days' },
  { key: 'mastery_mae', dir: 'lower', floor: 0.015, tol: 0.015, target: 0.06, label: 'mastery estimate error' },
  { key: 'mastery_rho', dir: 'higher', floor: 0.08, tol: 0.08, target: 0.6, label: 'rank agreement, estimated vs true skill' },
  { key: 'verdict_wrong', dir: 'lower', floor: 0.1, tol: 0.1, target: 0.1, label: 'day-1 feasibility verdict wrong' },
];
export const HARD = [ // invariants: must hold exactly on every run
  { key: 'dup_in_day', max: 0 }, { key: 'unknown_ids', max: 0 }, { key: 'replay_ok', min: 1 },
];

export function aggregate(rows) {
  const keys = Object.keys(rows[0]).filter((k) => typeof rows[0][k] === 'number'), out = { n: rows.length, persona: rows[0].persona, engine: rows[0].engine };
  for (const k of keys) { const v = rows.map((x) => x[k]).filter((x) => x != null); out[k] = v.length ? r(mean(v), 3) : null; }
  out.day1_verdict = rows.map((x) => x.day1_verdict).join('/');
  return out;
}
