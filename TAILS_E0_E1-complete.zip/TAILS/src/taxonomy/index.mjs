// Taxonomy loader/validator. Input = the four JSON files in data/taxonomy (already parsed).
export const ROOT_CAUSES = ['CONTENT_GAP', 'COMPREHENSION', 'VOCAB', 'CARELESS', 'STRATEGY', 'TIMING', 'GUESS', 'OVERTHINK', 'TOOL', 'UNKNOWN'];
export const DIFFICULTY_DRIVERS = ['ABSTRACT-VOCAB', 'DENSE-SYNTAX', 'MULTI-STEP', 'HIDDEN-CONSTRAINT', 'PLAUSIBLE-DISTRACTORS', 'DATA-COMPLEXITY',
  'REPRESENTATION-SWITCH', 'PARAMETRIC', 'ASK-DIFFERENT-THING', 'RARE-SENSE-OF-WORD', 'SUBTLE-LOGIC', 'TWO-TEXT-RELATION', 'LONG-SETUP-WORD-PROBLEM', 'TOOL-DEPENDENT'];

export function createTaxonomy({ skills, microskills, traps, reasons }) {
  const domains = skills.domains;
  const domainById = new Map(domains.map((d) => [d.id, d]));
  const skillById = new Map(skills.skills.map((s) => [s.id, s]));
  const microById = new Map(microskills.map((m) => [m.id, m]));
  const trapByCode = new Map(traps.map((t) => [t.code, t]));
  const reasonByCode = new Map(reasons.map((r) => [r.code, r]));
  const skillsByDomain = new Map();
  for (const s of skills.skills) { if (!skillsByDomain.has(s.domain)) skillsByDomain.set(s.domain, []); skillsByDomain.get(s.domain).push(s); }
  const microBySkill = new Map();
  for (const m of microskills) { if (!microBySkill.has(m.skill_id)) microBySkill.set(m.skill_id, []); microBySkill.get(m.skill_id).push(m); }
  return { domains, skills: skills.skills, microskills, traps, reasons, domainById, skillById, microById, trapByCode, reasonByCode, skillsByDomain, microBySkill,
    sectionOf: (skillOrDomainId) => (String(skillOrDomainId).startsWith('RW') ? 'rw' : 'math'),
    domainOf: (skillId) => skillId.split('.').slice(0, 2).join('.'),
    skillName: (id) => skillById.get(id)?.name ?? domainById.get(id)?.name ?? id };
}

export function validateTaxonomy(t) {
  const errors = [];
  for (const sec of ['rw', 'math']) {
    const total = t.domains.filter((d) => d.section === sec).reduce((s, d) => s + d.share, 0);
    if (Math.abs(total - 1) > 1e-6) errors.push(`domain shares for ${sec} sum to ${total}, expected 1`);
  }
  for (const s of t.skills) {
    if (!t.domainById.has(s.domain)) errors.push(`skill ${s.id}: unknown domain ${s.domain}`);
    if (!s.id.startsWith(s.domain + '.')) errors.push(`skill ${s.id}: id does not start with domain ${s.domain}`);
  }
  for (const [d, list] of t.skillsByDomain) {
    const total = list.reduce((s, x) => s + x.skill_share_within_domain, 0);
    if (Math.abs(total - 1) > 0.01) errors.push(`skill shares in ${d} sum to ${total.toFixed(3)}`);
  }
  for (const m of t.microskills) {
    if (!t.skillById.has(m.skill_id)) errors.push(`micro-skill ${m.id}: unknown skill`);
    if (!m.id.startsWith(m.skill_id + '#')) errors.push(`micro-skill ${m.id}: id must be SKILLID#CODE`);
  }
  for (const tr of t.traps) if (!ROOT_CAUSES.includes(tr.root_cause_hint)) errors.push(`trap ${tr.code}: bad root_cause_hint ${tr.root_cause_hint}`);
  for (const r of t.reasons) if (![...ROOT_CAUSES, 'REPORT'].includes(r.root_cause)) errors.push(`reason ${r.code}: bad root_cause ${r.root_cause}`);
  return errors;
}
