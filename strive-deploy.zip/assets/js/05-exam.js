/* ============================================================
   EXAM ENGINE (Bluebook-style shell, used by practice and full test)
   ============================================================ */
let X = null;
const isMathQ = q => q._topic.indexOf('math')===0;
const W_DIFF = {Easy:.85, Medium:1, Hard:1.2};

function tagTopics(keys){ const out=[]; keys.forEach(k => BANK[k].forEach(q => out.push(Object.assign({_topic:k}, q)))); return out; }
function newMod(label, kind, qs, minutes, title){ return { label, kind, qs, minutes, title, ans:{}, flags:{}, strikes:{}, hl:{}, checked:{} }; }

function startPractice(topic){
  let qs;
  if(topic==='mixed') qs = shuffle(tagTopics(Object.keys(TOPICS))).slice(0,10);
  else qs = shuffle(tagTopics([topic])).slice(0, Math.min(TOPICS[topic].n, BANK[topic].length));
  launch({ mode:'practice', topic, title:'Practice: '+(topic==='mixed'?'Mixed set':TOPICS[topic].short), mods:[newMod('Practice', topic==='mixed'?'mixed':TOPICS[topic].sec, qs, null, 'Practice')] });
}
function startRetry(){
  const qs = state.missed.slice(0,10).map(m => Object.assign({_topic:m.topic}, m.q));
  if(!qs.length){ toast('Nothing to re-try yet','ph-check-circle'); return; }
  launch({ mode:'practice', topic:'retry', title:'Practice: Missed questions', mods:[newMod('Practice','mixed',qs,null,'Practice')] });
}
function testPlan(){   // real Digital SAT: R&W 2 x 27 q / 32 min, Math 2 x 22 q / 35 min = 98 questions, 2 h 14 min
  const rwN = BANK.rw_craft.length+BANK.rw_info.length+BANK.rw_conv.length, mN = BANK.math_algebra.length+BANK.math_adv.length;
  const rw1 = Math.min(27, Math.floor(rwN/2)), m1 = Math.min(22, Math.floor(mN/2));
  return { rw1, rw2:rw1, m1, m2:m1, rwMin:32, mMin:35 };
}
function startFullTest(){
  const P = testPlan();
  const rwPool = shuffle(tagTopics(['rw_craft','rw_info','rw_conv'])), mPool = shuffle(tagTopics(['math_algebra','math_adv']));
  const t = { mode:'test', title:'Full practice test', pools:{rw:rwPool, m:mPool}, P, stage:0, mods:[] };
  t.mods.push(newMod('Reading and Writing','rw', rwPool.splice(0,P.rw1), P.rwMin, 'Section 1, Module 1: Reading and Writing'));
  launch(t);
}
function buildNext(prev){   // adaptive: second module depends on first-module performance
  const P = X.P, kind = prev.kind;
  const ok = prev.qs.filter((q,i)=>isCorrect(q, prev.ans[i])).length / prev.qs.length;
  const strong = ok >= .65;
  const pool = X.pools[kind];
  const n = kind==='rw' ? P.rw2 : P.m2;
  const sorted = pool.map(q=>({q,r:diffRank(q.diff)+Math.random()*.9})).sort((a,b)=>a.r-b.r).map(o=>o.q);
  const pick = strong ? sorted.slice(-n) : sorted.slice(0,n);
  pick.forEach(q => pool.splice(pool.indexOf(q),1));
  const m = newMod(prev.label, kind, shuffle(pick), kind==='rw'?P.rwMin:P.mMin, 'Section '+(kind==='rw'?1:2)+', Module 2: '+prev.label);
  m.level = strong ? 'higher' : 'lower';
  return m;
}
function launch(sess){
  X = Object.assign({ mi:0, qi:0, phase: sess.mode==='test'?'inter':'q', elapsed:0, hideTimer:false, elimOn:false, dirOpen:false, mapOpen:false, startTs:Date.now(), stage:0 }, sess);
  X.left = X.mods[0].minutes ? X.mods[0].minutes*60 : 0;
  document.body.classList.add('lock');
  const ex = $('#exam'); ex.classList.remove('hidden');
  buildShell(); renderPhase(); if(X.mode==='practice'){ X.run=0; coachSay('m_listen','Keep going.'); }
  clearInterval(X.timer); X.timer = setInterval(tick, 1000);
  document.addEventListener('keydown', onExamKey);
  document.addEventListener('pointerup', onHlPointer);
}
function closeExam(){
  if(!X) return;
  clearInterval(X.timer);
  document.removeEventListener('keydown', onExamKey);
  document.removeEventListener('pointerup', onHlPointer);
  hideHlPop();
  const w=$('#dwin'); if(w) w.classList.add('hidden');
  $('#exam').classList.add('hidden'); $('#exam').innerHTML='';
  document.body.classList.remove('lock');
  X = null;
}
function exitExam(){
  const m = openModal('<h2>Leave this session?</h2><p>'+(X.mode==='test'?'Your progress in this test will not be saved.':'Questions you already checked are saved to your progress.')+'</p><div class="acts"><button class="btn ghost" id="xStay">Keep going</button><button class="btn danger" id="xLeave">Leave</button></div>');
  m.querySelector('#xStay').onclick=()=>m.remove();
  m.querySelector('#xLeave').onclick=()=>{ m.remove(); const secs=X.elapsed || (Date.now()-X.startTs)/1000; const did = X.mode==='practice' && X.mods[0].checkedCount; closeExam(); if(did) endSession(secs); go(currentView); };
}
function cur(){ return X.mods[X.mi]; }
function isCorrect(q, a){
  if(a===undefined || a===null || a==='') return false;
  if(q.spr){
    const n = parseNum(a); if(n===null) return false;
    return q.ans.some(s => { const t=parseNum(s); return t!==null && Math.abs(t-n)<1e-6; });
  }
  return a===q.a;
}
function parseNum(s){
  s = String(s).trim(); if(!s) return null;
  const f = s.match(/^(-?\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/); if(f){ const d=parseFloat(f[2]); return d? parseFloat(f[1])/d : null; }
  return /^-?\d*\.?\d+$/.test(s) ? parseFloat(s) : null;
}

/* ---------- shell ---------- */
function buildShell(){
  $('#exam').innerHTML =
  '<div class="xhead"><div class="xtitle"><b id="xTitle"></b><button class="dirbtn" id="xDirBtn">Directions<i class="ph ph-caret-down"></i></button></div>'+
  '<div class="xtimer"><div class="tm mono" id="xTm">00:00</div><button id="xTmBtn"><i class="ph ph-eye-slash"></i><span>Hide</span></button></div>'+
  '<div class="xtools" id="xTools"></div></div>'+
  '<div class="xbody" id="xbody"></div>'+
  '<div class="xfoot" id="xfoot"><div class="xname" id="xName"></div><button class="qpill" id="xPill"></button><div class="xnav" id="xNav"></div></div>';
  $('#xDirBtn').onclick = () => { X.dirOpen=!X.dirOpen; paintDirections(); };
  $('#xTmBtn').onclick = () => { X.hideTimer=!X.hideTimer; paintTimer(); };
  $('#xPill').onclick = () => { X.mapOpen=!X.mapOpen; paintMap(); };
}
function paintDirections(){
  $('#xDirBtn').classList.toggle('open', X.dirOpen);
  let p = $('#xDir'); if(p) p.remove();
  if(!X.dirOpen) return;
  const m = cur(), q = X.phase==='q' ? m.qs[X.qi] : null;
  const math = q ? isMathQ(q) : m.kind==='m';
  const html = math
    ? '<b>Math directions.</b> Solve each problem and choose the best answer, or type your answer in the box when a question asks you to. Figures are drawn to scale unless noted. Variables and expressions represent real numbers, and a function is defined for every real input unless the question says otherwise. For typed answers, use digits, a decimal point, a minus sign or a fraction such as 3/4, with no spaces.'
    : '<b>Reading and Writing directions.</b> Each question is based on a short text or sentence. Read it carefully, then choose the one best answer from the four choices. Use Highlights to mark evidence in the passage and the ABC button to cross out choices you have ruled out.';
  p = document.createElement('div'); p.className='dirpanel'; p.id='xDir'; p.innerHTML = html;
  $('.xhead').appendChild(p);
}
function fmtTime(s){ s=Math.max(0,s); const m=Math.floor(s/60); return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); }
function paintTimer(){
  const t=$('#xTm'), b=$('#xTmBtn'); if(!t) return;
  const test = X.mode==='test', secs = test ? X.left : X.elapsed;
  t.classList.toggle('low', test && X.left<=60 && X.phase!=='inter');
  if(X.phase==='inter' || X.phase==='done'){ t.textContent = X.phase==='inter' && test && !X.breakNext ? fmtTime(X.left) : '--:--'; }
  else t.textContent = X.hideTimer ? '' : fmtTime(secs);
  if(X.hideTimer && X.phase!=='inter' && X.phase!=='done') t.innerHTML = '<i class="ph ph-clock" style="font-size:20px;color:var(--mut)"></i>';
  b.innerHTML = X.hideTimer ? '<i class="ph ph-eye"></i><span>Show</span>' : '<i class="ph ph-eye-slash"></i><span>Hide</span>';
  b.style.visibility = (X.phase==='done') ? 'hidden':'visible';
}
function tick(){
  if(!X) return;
  if(X.phase==='q' || X.phase==='check'){
    if(X.mode==='test'){
      X.left--;
      if(X.left===300 && X.hideTimer){ X.hideTimer=false; toast('5 minutes remaining in this module','ph-clock'); }
      if(X.left<=0){ toast('Time is up for this module','ph-clock'); submitModule(); return; }
    } else X.elapsed++;
    paintTimer();
  }
}

/* ---------- phases ---------- */
function renderPhase(){
  hideHlPop(); X.mapOpen=false; paintMap(); X.dirOpen=false; paintDirections();
  const foot = $('#xfoot');
  foot.style.display = (X.phase==='q') ? '' : 'none';
  $('#xTitle').textContent = X.mode==='test' ? cur().title : X.title;
  $('#xbody').className='xbody';
  if(X.phase==='inter') renderInter();
  else if(X.phase==='check') renderCheck();
  else if(X.phase==='done') renderDone();
  else renderQuestion();
  paintTimer();
}
function renderInter(){
  const m = cur(), b = $('#xbody'); $('#xTools').innerHTML='';
  const first = X.mi===0, brk = X.breakNext;
  const box = brk
    ? '<img class="mas" data-mood="wink" src="'+IMG.m_wink+'" alt=""><h2>Take a 10-minute break</h2><div class=\"brk\" id=\"xBrk\" role=\"timer\">10:00</div><p>Reading and Writing is done. Stretch, drink water, rest your eyes. Math is next, with the Desmos calculator and the reference sheet. Testing resumes when the timer ends, or sooner if you are ready.</p><button class="btn pri lg" id="xGo">Resume testing<i class="ph ph-arrow-right"></i></button>'
    : '<img class="mas" data-mood="listen" src="'+IMG.m_listen+'" alt=""><h2>'+esc(m.title)+'</h2><p>'+m.qs.length+' questions, '+m.minutes+' minutes. '+(first?'Your second module adapts to how you do in the first. You can go back and forth inside a module, and flag questions to revisit.':'You cannot return to the previous module once you start.')+'</p><button class="btn pri lg" id="xGo">Start module<i class="ph ph-arrow-right"></i></button>';
  b.innerHTML = '<div class="interstitial"><div class="box">'+box+'</div></div>';
  clearInterval(X.brkT);
  if(brk){ let left = 600; const el = $('#xBrk'); X.brkT = setInterval(() => { if(!el || !el.isConnected){ clearInterval(X.brkT); return; } left--; el.textContent = fmtTime(left); if(left <= 0){ clearInterval(X.brkT); $('#xGo').click(); } }, 1000); }
  $('#xGo').onclick = () => { clearInterval(X.brkT); if(brk){ X.breakNext=false; renderPhase(); return; } X.phase='q'; X.qi=0; renderPhase(); };
}
function paintTools(q){
  const t=$('#xTools'); const math = q ? isMathQ(q) : cur().kind==='m';
  let h='';
  if(math){
    h += '<button class="tool'+(!$('#dwin')||$('#dwin').classList.contains('hidden')?'':' on')+'" id="tCalc"><i class="ph ph-calculator"></i><span>Calculator</span></button><button class="tool" id="tRef"><i class="ph ph-ruler"></i><span>Reference</span></button>';
  } else h += '<button class="tool" id="tHl"><i class="ph ph-highlighter-circle"></i><span>Highlights</span></button>';
  h += '<button class="tool" id="tExit"><i class="ph ph-sign-out"></i><span>Exit</span></button>';
  t.innerHTML=h;
  if(math){ $('#tCalc').onclick=()=>toggleCalc(); $('#tRef').onclick=openReference; if(X.mode==='test' || true){} }
  else { $('#tHl').onclick=()=>toast('Select text in the passage to highlight it','ph-highlighter-circle'); }
  $('#tExit').onclick=exitExam;
  if(!math){ const w=$('#dwin'); if(w) w.classList.add('hidden'); }
}

function renderQuestion(){
  const m = cur(), q = m.qs[X.qi], math = isMathQ(q), i = X.qi;
  paintTools(q);
  const split = !!q.passage || math;
  const body = $('#xbody'); body.className = 'xbody'+(split?' split':'');
  body.classList.toggle('elimon', false);
  const qbar = '<div class="qbar"><span class="qnumbox">'+(i+1)+'</span><button class="flagbtn" id="xFlag"></button>'+(q.spr?'':'<button class="elimtoggle" id="xElim" title="Cross out answer choices"><s>ABC</s></button>')+'</div>';
  let opts;
  if(q.spr){
    opts = '<div class="spr"><input id="xSpr" inputmode="decimal" autocomplete="off" maxlength="8" placeholder="Your answer" aria-label="Your answer"><div class="prev" id="xPrev"></div><div class="hint">Type a number, a decimal or a fraction like 3/4.</div></div>';
  } else {
    opts = '<div class="xopts" id="xOpts">'+q.opts.map((o,k)=>'<div class="xopt" data-i="'+k+'"><button class="o"><span class="k">'+String.fromCharCode(65+k)+'</span><span class="t">'+(math?mx(o):esc(o))+'</span></button><button class="x" aria-label="Cross out choice '+String.fromCharCode(65+k)+'"></button></div>').join('')+'</div>';
  }
  if(q.passage){
    body.innerHTML = '<div class="pane left"><div class="passage" id="xPassage"></div></div><div class="pane"><div class="wrap">'+qbar+'<div class="stem">'+(math?mxq(q.q):esc(q.q))+'</div>'+opts+'<div id="xExp"></div></div></div>';
    const p=$('#xPassage'); if(m.hl[i]) p.innerHTML=m.hl[i]; else p.textContent=q.passage;
  } else if(math){
    body.innerHTML = '<div class="pane left"><div class="stem">'+(math?mxq(q.q):esc(q.q))+'</div></div><div class="pane"><div class="wrap">'+qbar+opts+'<div id="xExp"></div></div></div>';
  } else {
    body.innerHTML = '<div class="pane"><div class="wrap" style="max-width:780px;margin:0 auto">'+qbar+'<div class="stem serif">'+(math?mxq(q.q):esc(q.q))+'</div>'+opts+'<div id="xExp"></div></div></div>';
  }
  $('#xFlag').onclick = () => { m.flags[i]=!m.flags[i]; paintFlag(); paintMap(); };
  if($('#xElim')) $('#xElim').onclick = () => { X.elimOn=!X.elimOn; paintOptions(); };
  if(q.spr){
    const inp=$('#xSpr'); if(m.ans[i]!==undefined) inp.value=m.ans[i];
    inp.oninput = () => { inp.value = inp.value.replace(/[^0-9./-]/g,''); const v=inp.value.trim(); if(v) m.ans[i]=v; else delete m.ans[i]; paintOptions(); paintFoot(); paintMap(); };
    inp.onkeydown = e => { if(e.key==='Enter') primaryAction(); };
    if(!m.checked[i]) setTimeout(()=>inp.focus({preventScroll:true}),50);
  } else {
    $$('#xOpts .xopt').forEach(row => {
      const k = +row.dataset.i;
      row.querySelector('.o').onclick = () => pick(k);
      row.querySelector('.x').onclick = () => strike(k);
    });
  }
  paintFlag(); paintOptions(); paintFoot(); paintMap(); paintExplain();
  const r=$('#xbody'); $$('#xbody .pane').forEach(p=>p.scrollTop=0);
}
function paintFlag(){
  const m=cur(), f=!!m.flags[X.qi], b=$('#xFlag'); if(!b) return;
  b.classList.toggle('on', f);
  b.innerHTML = '<i class="ph'+(f?'-fill':'')+' ph-flag"></i><span>'+(f?'Marked for review':'Mark for review')+'</span>';
}
function paintOptions(){
  const m=cur(), q=m.qs[X.qi], i=X.qi, locked = X.mode==='practice' && m.checked[i];
  if(q.spr){
    const v=m.ans[i], prev=$('#xPrev'), inp=$('#xSpr');
    if(prev) prev.textContent = v ? 'Answer preview: '+v : '';
    if(inp){ inp.disabled = !!locked; if(locked){ inp.style.borderColor = isCorrect(q,v)?'var(--good)':'var(--bad)'; } }
    return;
  }
  $('#xbody').classList.toggle('elimon', X.elimOn && !locked);
  const el=$('#xElim'); if(el) el.classList.toggle('on', X.elimOn);
  const str = m.strikes[i] || [];
  $$('#xOpts .xopt').forEach(row => {
    const k=+row.dataset.i, o=row.querySelector('.o'), x=row.querySelector('.x');
    const struck = str.indexOf(k)>-1;
    o.classList.toggle('sel', m.ans[i]===k && !locked);
    o.classList.toggle('elim', struck);
    o.classList.toggle('locked', !!locked);
    o.classList.toggle('correct', !!locked && k===q.a);
    o.classList.toggle('wrong', !!locked && m.ans[i]===k && k!==q.a);
    x.innerHTML = struck ? '<i class="ph ph-arrow-counter-clockwise"></i>' : '<i class="ph ph-x"></i>';
  });
}
function pick(k){
  const m=cur(), i=X.qi; if(X.mode==='practice' && m.checked[i]) return;
  if((m.strikes[i]||[]).indexOf(k)>-1) return;
  if(m.ans[i]===k) delete m.ans[i]; else m.ans[i]=k;
  paintOptions(); paintFoot(); paintMap();
}
function strike(k){
  const m=cur(), i=X.qi, s=m.strikes[i]=m.strikes[i]||[], at=s.indexOf(k);
  if(at>-1) s.splice(at,1); else { s.push(k); if(m.ans[i]===k) delete m.ans[i]; }
  paintOptions(); paintFoot(); paintMap();
}
function paintExplain(){
  const m=cur(), q=m.qs[X.qi], i=X.qi, box=$('#xExp'); if(!box) return;
  if(X.mode==='practice' && m.checked[i]){
    const ok = isCorrect(q, m.ans[i]);
    box.innerHTML = '<div class="explain"><b class="'+(ok?'ok':'no')+'">'+(ok?'Correct.':'Not quite.')+'</b> '+(q.spr && !ok ? 'The answer is '+esc(q.ans[0])+'. ':'')+(isMathQ(q)?mx(q.why):esc(q.why))+'</div>';
  } else box.innerHTML='';
}
function paintFoot(){
  if(X.phase!=='q') return;
  const m=cur(), n=m.qs.length, i=X.qi, test=X.mode==='test';
  $('#xName').textContent = (state.profile.name||'').toUpperCase();
  $('#xPill').innerHTML = 'Question '+(i+1)+' of '+n+'<i class="ph ph-caret-up"></i>';
  $('#xPill').classList.toggle('open', X.mapOpen);
  const nav=$('#xNav'); nav.innerHTML='';
  const back=document.createElement('button'); back.className='btn'; back.innerHTML='<i class="ph ph-arrow-left"></i>Back'; back.disabled = i===0; back.onclick=()=>goQ(i-1); nav.appendChild(back);
  const nx=document.createElement('button'); nx.className='btn acc'; nx.id='xPrimary'; nx.onclick=primaryAction;
  let label, dis=false;
  if(!test){
    if(!m.checked[i]){ label='Check answer<i class="ph ph-check"></i>'; dis = m.ans[i]===undefined; }
    else label = i===n-1 ? 'See results<i class="ph ph-arrow-right"></i>' : 'Next<i class="ph ph-arrow-right"></i>';
  } else label = i===n-1 ? 'Review<i class="ph ph-arrow-right"></i>' : 'Next<i class="ph ph-arrow-right"></i>';
  nx.innerHTML=label; nx.disabled=dis; nav.appendChild(nx);
}
function primaryAction(){
  if(!X || X.phase!=='q') return;
  const m=cur(), i=X.qi, q=m.qs[i], n=m.qs.length;
  if(X.mode==='practice'){
    if(!m.checked[i]){
      if(m.ans[i]===undefined) return;
      m.checked[i]=true; m.checkedCount=(m.checkedCount||0)+1;
      const ok = isCorrect(q, m.ans[i]); recordAttempt(q._topic, ok, q, m.ans[i]); saveState();
      paintOptions(); paintExplain(); paintFoot(); paintMap();
      coachForAnswer(q, ok);
      setTimeout(()=>{ const e=$('#xExp'); if(e) e.scrollIntoView({behavior:'smooth',block:'nearest'}); },60);
      return;
    }
    if(i===n-1){ finishPractice(); return; }
    goQ(i+1);
  } else {
    if(i===n-1){ X.phase='check'; renderPhase(); } else goQ(i+1);
  }
}
function goQ(i){ const m=cur(); if(i<0||i>=m.qs.length) return; X.qi=i; X.phase='q'; renderPhase(); }

/* ---------- question map ---------- */
function mapHtml(filterMode){
  const m=cur(); let h='<div class="qgrid">';
  m.qs.forEach((q,i)=>{
    const ans = m.ans[i]!==undefined, flg = !!m.flags[i];
    if(filterMode==='un' && ans) return;
    if(filterMode==='fl' && !flg) return;
    const c = [];
    if(i===X.qi && X.phase==='q') c.push('cur');
    if(X.mode==='practice' && m.checked[i]) c.push(isCorrect(q,m.ans[i])?'right':'wrong'); else if(ans) c.push('ans');
    h+='<button class="'+c.join(' ')+'" data-q="'+i+'">'+(i+1)+(flg?'<i class="ph-fill ph-flag fl"></i>':'')+'</button>';
  });
  return h+'</div>';
}
function paintMap(){
  let el=$('#xMap'); if(el) el.remove();
  const pill=$('#xPill'); if(pill) pill.classList.toggle('open', X.mapOpen);
  if(!X.mapOpen || X.phase!=='q') return;
  const mf = X.mapFilter || 'all';
  el=document.createElement('div'); el.className='qmap'; el.id='xMap';
  el.innerHTML='<div class="row" style="justify-content:space-between;margin-bottom:10px"><h4>'+esc(cur().title||'Questions')+'</h4><div class="pr-pills"><button type="button" class="pr-pill'+(mf==='all'?' on':'')+'" data-mf="all">All</button><button type="button" class="pr-pill'+(mf==='un'?' on':'')+'" data-mf="un">Unanswered</button><button type="button" class="pr-pill'+(mf==='fl'?' on':'')+'" data-mf="fl">For review</button></div></div><div class="legend"><span><i class="sw cur"></i>Current</span><span><i class="sw"></i>Unanswered</span><span><i class="sw ans"></i>Answered</span><span><i class="ph-fill ph-flag" style="color:var(--warn)"></i>For review</span></div>'+mapHtml(mf)+(X.mode==='test'?'<div style="text-align:center;margin-top:18px"><button class="btn sm" id="xToReview">Go to review page<i class="ph ph-arrow-right"></i></button></div>':'');
  $('#exam').appendChild(el);
  el.querySelectorAll('[data-mf]').forEach(b=>b.onclick=()=>{ X.mapFilter=b.dataset.mf; paintMap(); });
  el.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>{ X.mapOpen=false; goQ(+b.dataset.q); });
  const r=$('#xToReview'); if(r) r.onclick=()=>{ X.phase='check'; renderPhase(); };
}
function renderCheck(){
  const m=cur(), n=m.qs.length; $('#xTools').innerHTML='<button class="tool" id="tExit"><i class="ph ph-sign-out"></i><span>Exit</span></button>'; $('#tExit').onclick=exitExam;
  const un = m.qs.filter((q,i)=>m.ans[i]===undefined).length, fl = Object.keys(m.flags).filter(k=>m.flags[k]).length;
  $('#xbody').innerHTML='<div class="pane"><div class="checkscreen"><h2>Check your work</h2><p>'+(un?'You have '+un+' unanswered question'+(un>1?'s':'')+'. ':'You answered every question. ')+(fl?fl+' marked for review. ':'')+'Tap a number to go back to it. Once you submit, you cannot return to this module.</p>'+mapHtml()+'<div class="row" style="justify-content:center"><button class="btn lg" id="xBackQ"><i class="ph ph-arrow-left"></i>Back to questions</button><button class="btn acc lg" id="xSubmit">Submit module<i class="ph ph-arrow-right"></i></button></div></div></div>';
  $$('#xbody [data-q]').forEach(b=>b.onclick=()=>goQ(+b.dataset.q));
  $('#xBackQ').onclick=()=>goQ(n-1);
  $('#xSubmit').onclick=submitModule;
}

/* ---------- finish ---------- */
function submitModule(){
  if(!X || X.mode!=='test' || X.phase==='done' || X.phase==='inter') return;
  const m = cur();
  m.qs.forEach((q,i)=>{ const a=m.ans[i]; recordAttempt(q._topic, isCorrect(q,a), q, a===undefined?-1:a); });
  saveState();
  const s = X.stage, P = X.P;
  if(s===0) X.mods.push(buildNext(m));
  else if(s===1){ X.mods.push(newMod('Math','m', X.pools.m.splice(0,P.m1), P.mMin, 'Section 2, Module 1: Math')); X.breakNext=true; }
  else if(s===2) X.mods.push(buildNext(m));
  else { finishTest(); return; }
  X.stage++; X.mi++;
  X.left = cur().minutes*60; X.phase='inter'; X.qi=0; renderPhase();
}
function wscore(mods){
  let sum=0,n=0; mods.forEach(m=>m.qs.forEach((q,i)=>{ n++; if(isCorrect(q,m.ans[i])) sum+=W_DIFF[q.diff]||1; })); return n? sum/n : 0;
}
function finishTest(){
  clearInterval(X.timer); X.phase='done';
  const rwM = X.mods.filter(m=>m.kind==='rw'), mM = X.mods.filter(m=>m.kind==='m');
  const rw = accToScore(wscore(rwM)), mt = accToScore(wscore(mM)), total = rw+mt;
  let c=0,t=0; X.mods.forEach(m=>m.qs.forEach((q,i)=>{ t++; if(isCorrect(q,m.ans[i])) c++; }));
  const secs = Math.round((Date.now()-X.startTs)/1000);
  state.lastTest = { score:total, rw, m:mt, correct:c, total:t, ts:Date.now() };
  state.testsDone = (state.testsDone||0)+1;
  endSession(secs);
  const hh=Math.floor(secs/3600), mm=Math.floor(secs%3600/60);
  X.result = { total, rw, mt, c, t, time:(hh?hh+'h ':'')+mm+'m', range:[total-40,total+40], lv: X.mods.filter(m=>m.level).map(m=>m.kind+':'+m.level) };
  renderPhase();
}
function doneScreen({title, sub, pct, ringLabel, stats, art, script, btns}){
  $('#xTools').innerHTML=''; $('#xfoot').style.display='none'; { const co=$('#coach'); if(co) co.remove(); }
  const b=$('#xbody'); b.className='xbody'; b.style.background='var(--side)';
  b.innerHTML='<div class="xdone"><div class="donebox"><div><img class="lm" src="'+IMG.logo+'" alt="Jamal\'s International Academy"><h1>'+title+'</h1><p>'+sub+'</p><div class="dring" id="dRing"><div><b id="dN">0%</b><span>'+ringLabel+'</span></div></div>'+(stats?'<div class="dstats">'+stats+'</div>':'')+'<div class="donebtns" id="dBtns"></div></div><div class="art"><div class="script">'+script+'</div><img data-mood="'+moodOf(art)+'" src="'+IMG[art]+'" alt=""></div></div></div>';
  const t0=performance.now();
  (function tick(now){ const p=REDUCED?1:Math.min((now-t0)/1500,1), e=1-Math.pow(1-p,3), v=Math.round(e*pct); const r=$('#dRing'); if(!r) return; r.style.setProperty('--v',v); $('#dN').textContent=v+'%'; if(p<1) requestAnimationFrame(tick); })(t0);
  const box=$('#dBtns');
  btns.forEach(([label,cls,fn])=>{ const x=document.createElement('button'); x.className='btn lg '+cls; x.innerHTML=label; x.onclick=fn; box.appendChild(x); });
  const bar=$('.xhead'); if(bar) bar.style.display='none';
}
function renderDone(){
  if(X.mode!=='test') return;
  const r=X.result, pct=Math.round(r.c/r.t*100);
  doneScreen({ title:'Test complete', sub:'You are one step closer to your goal.', pct, ringLabel:'Correct',
    stats:'<div><span>Estimated score</span><b>'+r.total+'</b></div><div><span>Reading &amp; Writing</span><b>'+r.rw+'</b></div><div><span>Math</span><b>'+r.mt+'</b></div><div><span>Time</span><b>'+r.time+'</b></div>',
    art: moodForScore(pct).art, script: moodForScore(pct).script,
    btns:[['View results<i class="ph ph-arrow-right"></i>','acc',()=>{ closeExam(); go('review'); }],['Try again','line',()=>{ closeExam(); startFullTest(); }],['Back to dashboard','ghost',()=>{ closeExam(); go('dash'); }]] });
}
function finishPractice(){
  clearInterval(X.timer); X.phase='done';
  const m=cur(), c=m.qs.filter((q,i)=>isCorrect(q,m.ans[i])).length, n=m.qs.length, pct=Math.round(c/n*100), secs=X.elapsed, topic=X.topic;
  endSession(secs);
  renderPhase();
  doneScreen({ title:'Set complete', sub:c+' of '+n+' correct in '+esc(X.title.replace('Practice: ',''))+'. Keep the streak going.', pct, ringLabel:'Accuracy', stats:null,
    art: moodForScore(pct).art, script: moodForScore(pct).script,
    btns:[['Practice again<i class="ph ph-arrows-clockwise"></i>','acc',()=>{ closeExam(); topic==='retry'?startRetry():startPractice(topic); }],['Back to dashboard','line',()=>{ closeExam(); go('dash'); }]] });
}

/* ---------- keyboard ---------- */
function onExamKey(e){
  if(!X) return;
  if(e.key==='Escape'){ X.mapOpen=false; X.dirOpen=false; paintMap(); paintDirections(); hideHlPop(); return; }
  if(X.phase!=='q') return;
  const tag=(e.target.tagName||'').toLowerCase(); if(tag==='input'||tag==='textarea') return;
  if(e.metaKey||e.ctrlKey||e.altKey) return;
  if(e.key==='ArrowRight'){ primaryAction(); }
  else if(e.key==='ArrowLeft'){ goQ(X.qi-1); }
  else { const k='abcd'.indexOf(e.key.toLowerCase()); const k2='1234'.indexOf(e.key); const kk=k>-1?k:k2; const q=cur().qs[X.qi]; if(kk>-1 && !q.spr && kk<q.opts.length) pick(kk); }
}

/* ---------- highlights (passage annotation) ---------- */
function hideHlPop(){ const p=$('#hlpop'); if(p) p.remove(); }
function onHlPointer(e){
  if(!X || X.phase!=='q') return;
  if(e.target.closest && e.target.closest('#hlpop')) return;
  const p=$('#xPassage'); if(!p){ hideHlPop(); return; }
  setTimeout(()=>{
    const sel=getSelection();
    if(!sel || sel.isCollapsed || !p.contains(sel.anchorNode) || !p.contains(sel.focusNode)){ hideHlPop(); return; }
    const r=sel.getRangeAt(0), rect=r.getBoundingClientRect();
    hideHlPop();
    const pop=document.createElement('div'); pop.id='hlpop';
    pop.innerHTML='<button data-c="y" title="Yellow"><span class="dotc" style="background:#f0c04a"></span></button><button data-c="b" title="Blue"><span class="dotc" style="background:#35c7e6"></span></button><button data-c="p" title="Violet"><span class="dotc" style="background:#9a82ff"></span></button><button data-c="u" title="Underline"><i class="ph ph-text-underline"></i></button><button data-c="x" title="Remove highlight"><i class="ph ph-eraser"></i></button>';
    document.body.appendChild(pop);
    pop.style.left=Math.max(8,Math.min(innerWidth-pop.offsetWidth-8, rect.left+rect.width/2-pop.offsetWidth/2))+'px';
    pop.style.top=Math.max(8,rect.top-pop.offsetHeight-10)+'px';
    pop.onpointerdown=ev=>ev.preventDefault();
    pop.querySelectorAll('button').forEach(b=>b.onclick=()=>applyHl(b.dataset.c, r));
  },0);
}
function applyHl(c, range){
  const p=$('#xPassage'), m=cur();
  if(c==='x'){
    p.querySelectorAll('mark').forEach(mk=>{ if(range.intersectsNode(mk)){ while(mk.firstChild) mk.parentNode.insertBefore(mk.firstChild, mk); mk.remove(); } });
  } else {
    const mk=document.createElement('mark'); mk.className=c;
    try{ mk.appendChild(range.extractContents()); range.insertNode(mk); }catch(err){ return; }
  }
  p.normalize(); m.hl[X.qi]=p.innerHTML; getSelection().removeAllRanges(); hideHlPop();
}

