// Question validation (Part C1 rules). Pure: takes a parsed question + taxonomy, returns {errors, warnings}.
import { DIFFICULTY_DRIVERS } from '../taxonomy/index.mjs';
import { parseNumber } from '../util/misc.mjs';

const KEYS = ['A', 'B', 'C', 'D'];
const CONTEXTS = ['none', 'finance', 'science', 'business', 'everyday', 'geometry', 'statistics', 'literature', 'history', 'humanities', 'social-science', 'natural-science'];
const VISUAL_KINDS = ['table', 'bar', 'line', 'scatter', 'geometry'];
const bandOf = (d) => (d <= 2 ? 'easy' : d === 3 ? 'medium' : 'hard');
const wc = (t) => t.replace(/•/g, ' ').split(/\s+/).filter(Boolean).length;

export function validateQuestion(q, tax, opts = {}) {
  const errors = [], warnings = [];
  const err = (m) => errors.push(m), warn = (m) => warnings.push(m);
  const need = (cond, m) => { if (!cond) err(m); return cond; };

  if (!need(q && typeof q === 'object', 'not an object')) return { errors, warnings };
  need(/^(RW|M)-[A-Z0-9]+(-[A-Z0-9]+)*-\d{4}$/.test(q.id ?? ''), `bad id format: ${q.id}`);
  need(Number.isInteger(q.version) && q.version >= 1, 'version must be a positive integer');
  need(['rw', 'math'].includes(q.section), 'section must be rw|math');
  need((q.id ?? '').startsWith(q.section === 'rw' ? 'RW-' : 'M-'), 'id prefix does not match section');

  const skill = tax.skillById.get(q.skill_id);
  if (need(skill, `unknown skill_id ${q.skill_id}`)) {
    need(skill.section === q.section, `skill ${q.skill_id} is ${skill.section}, question says ${q.section}`);
    need(q.domain === skill.domain, `domain ${q.domain} != skill domain ${skill.domain}`);
    const idMid = q.id.replace(/^(RW|M)-/, '').replace(/-\d{4}$/, '').replace(/-/g, '.');
    need(q.skill_id.replace(/^(RW|M)\./, '') === idMid, `id ${q.id} does not match skill ${q.skill_id}`);
  }
  need(Array.isArray(q.micro_skills) && q.micro_skills.length >= 1, 'needs >= 1 micro_skills');
  for (const m of q.micro_skills ?? []) {
    const ms = tax.microById.get(m);
    if (!ms) err(`unknown micro-skill ${m}`); else if (ms.skill_id !== q.skill_id) err(`micro-skill ${m} does not belong to ${q.skill_id}`);
  }
  need(Number.isInteger(q.difficulty) && q.difficulty >= 1 && q.difficulty <= 5, 'difficulty must be integer 1..5');
  need(q.difficulty_band === bandOf(q.difficulty), `difficulty_band ${q.difficulty_band} inconsistent with difficulty ${q.difficulty}`);
  for (const d of q.difficulty_drivers ?? []) if (!DIFFICULTY_DRIVERS.includes(d)) err(`unknown difficulty driver ${d}`);
  for (const h of q.hypothesis_tags ?? []) if (!/^H\.[A-Z-]+$/.test(h)) err(`bad hypothesis tag ${h}`);
  need(CONTEXTS.includes(q.context), `unknown context ${q.context}`);
  need(typeof q.stem === 'string' && q.stem.length > 5, 'stem missing');
  need(Number.isInteger(q.est_time_sec) && q.est_time_sec > 0, 'est_time_sec must be a positive integer');
  if (q.est_time_sec) { // authoring guidance (E2.8): warnings only
    const [lo, hi] = q.section === 'math' ? { easy: [30, 50], medium: [60, 90], hard: [90, 150] }[q.difficulty_band] : [30, 75];
    if (q.est_time_sec < lo || q.est_time_sec > hi) warn(`est_time_sec ${q.est_time_sec} outside guidance ${lo}-${hi}`);
  }
  need(['draft', 'verified', 'approved'].includes(q.status), `bad status ${q.status}`);
  need(['pending', 'approved', 'rejected'].includes(q.verification?.teacher_review), 'bad verification.teacher_review');
  need(['pass', 'fail', 'unrun'].includes(q.verification?.result), 'bad verification.result');
  if (q.status === 'verified' || q.status === 'approved') need(q.verification?.result === 'pass', `status ${q.status} but verification.result is ${q.verification?.result}`);
  if (q.status === 'approved') need(q.verification?.teacher_review === 'approved', 'status approved needs teacher_review approved');

  // format-specific
  if (q.format === 'mcq4') {
    const ch = q.choices;
    if (need(Array.isArray(ch) && ch.length === 4, 'mcq4 needs exactly 4 choices')) {
      need(ch.every((c, i) => c.key === KEYS[i]), 'choice keys must be A,B,C,D in order');
      need(ch.filter((c) => c.is_correct).length === 1, 'exactly one choice must be correct');
      need(new Set(ch.map((c) => c.text.trim().toLowerCase())).size === 4, 'choice texts must be unique');
      for (const c of ch) {
        need(typeof c.text === 'string' && c.text.length > 0, `choice ${c.key} has no text`);
        if (c.is_correct) { need(c.trap_code === null, `correct choice ${c.key} must have trap_code null`); need(!!c.why_right, `choice ${c.key} needs why_right`); }
        else {
          const trap = tax.trapByCode.get(c.trap_code);
          if (!trap) err(`choice ${c.key}: unknown trap_code ${c.trap_code}`);
          else if (trap.section !== q.section) err(`choice ${c.key}: trap ${c.trap_code} is a ${trap.section} trap`);
          need(!!c.why_wrong && !!c.student_thinking, `choice ${c.key} needs why_wrong and student_thinking`);
        }
      }
    }
    need(q.spr === null || q.spr === undefined, 'mcq4 must have spr null');
  } else if (q.format === 'spr') {
    need(q.section === 'math', 'spr is math only');
    need(Array.isArray(q.spr?.accepted) && q.spr.accepted.length >= 1, 'spr needs spr.accepted');
    for (const a of q.spr?.accepted ?? []) need(parseNumber(a) !== null, `spr accepted value not numeric: ${a}`);
    need((q.choices ?? []).length === 0, 'spr must have no choices');
  } else err(`bad format ${q.format}`);

  // section-specific
  if (q.section === 'rw') {
    if (need(q.passage && typeof q.passage.text === 'string', 'RW needs a passage')) {
      const n = wc(q.passage.text);
      need(Math.abs(n - q.passage.word_count) <= 1, `passage.word_count ${q.passage.word_count} != actual ${n}`);
      if (!['cross-text', 'notes'].includes(q.passage.type)) need(n >= 25 && n <= 150, `RW passage has ${n} words (25-150)`);
      need(['single', 'cross-text', 'notes'].includes(q.passage.type), 'bad passage.type');
    }
    const em = q.evidence_map;
    if (need(em && em.correct_evidence && em.disqualifiers, 'RW needs a full evidence_map')) {
      const wrong = (q.choices ?? []).filter((c) => !c.is_correct).map((c) => c.key).sort().join();
      need(Object.keys(em.disqualifiers).sort().join() === wrong, 'evidence_map.disqualifiers must cover exactly the wrong choices');
    }
    for (const v of q.vocabulary_terms ?? []) need(v.term && v.meaning, 'vocabulary_terms need term + meaning');
  } else {
    need(q.passage === null, 'math questions have passage null');
    need(typeof q.verification?.code === 'string' && /computed|ANSWER/.test(q.verification.code), 'math needs runnable verification.code (defines computed or ANSWER)');
  }
  if (q.visual) { need(VISUAL_KINDS.includes(q.visual.kind), 'bad visual.kind'); need(!!q.visual.alt_text, 'visual needs alt_text'); }
  const sol = q.solution;
  if (need(sol && Array.isArray(sol.steps) && sol.steps.length >= 1 && sol.steps.length <= 6, 'solution.steps must be 1-6 steps')) need(!!sol.fast_method, 'solution.fast_method required');
  if (q.section === 'math' && sol && !sol.desmos_method && (q.difficulty_drivers ?? []).includes('TOOL-DEPENDENT')) warn('TOOL-DEPENDENT question without desmos_method');
  if (opts.lessonIds) for (const l of q.lesson_ids ?? []) if (!opts.lessonIds.has(l)) err(`unknown lesson id ${l}`);
  return { errors, warnings };
}

export function validateBank(questions, tax, opts = {}) {
  const results = [], seen = new Set();
  let errorCount = 0, warningCount = 0;
  for (const q of questions) {
    const r = validateQuestion(q, tax, opts);
    if (seen.has(q.id)) r.errors.push('duplicate id');
    seen.add(q.id);
    errorCount += r.errors.length; warningCount += r.warnings.length;
    results.push({ id: q.id, ...r });
  }
  return { results, errorCount, warningCount };
}
