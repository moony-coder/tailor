// Item calibration from real attempts (blueprint phase 5): replace guessed difficulty with measured difficulty,
// flag ambiguous or broken items. Elo/Rasch-lite, dependency-free, deterministic.
const logit = (p) => Math.log(Math.min(0.99, Math.max(0.01, p)) / (1 - Math.min(0.99, Math.max(0.01, p))));
const sig = (x) => 1 / (1 + Math.exp(-x));
export const bFromDifficulty = (d) => (d - 3) * 0.9;           // prior from the 1..5 label
export const difficultyFromB = (b) => Math.min(5, Math.max(1, Math.round(b / 0.9 + 3)));
/** attempts: [{question_id, correct:0|1, student_p}] in time order. Returns Map(id -> {b, n, acc, hi_n, hi_acc, flag, label}). */
export function calibrate(bank, attempts, { k = 0.35, min_n = 30 } = {}) {
  const st = new Map(bank.map((q) => [q.id, { b: bFromDifficulty(q.difficulty), n: 0, c: 0, hi_n: 0, hi_c: 0, d0: q.difficulty }]));
  for (const a of attempts) { const it = st.get(a.question_id); if (!it) continue; const th = logit(a.student_p), e = sig(th - it.b), kk = k / Math.sqrt(1 + it.n / 20); it.b += kk * (e - a.correct); it.n++; it.c += a.correct; if (a.student_p >= 0.8) { it.hi_n++; it.hi_c += a.correct; } }
  const out = new Map();
  for (const [id, it] of st) { const acc = it.n ? it.c / it.n : null, hi = it.hi_n ? it.hi_c / it.hi_n : null; let flag = null;
    if (it.n >= min_n && it.hi_n >= 10 && hi < 0.45) flag = 'ambiguous_or_wrong_key';   // strong students fail it: review the key
    else if (it.n >= min_n && acc > 0.97) flag = 'too_easy';
    out.set(id, { b: +it.b.toFixed(2), n: it.n, acc: acc == null ? null : +acc.toFixed(2), hi_acc: hi == null ? null : +hi.toFixed(2), flag, label: it.n >= min_n ? difficultyFromB(it.b) : it.d0 }); }
  return out;
}
