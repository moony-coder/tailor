// Framework-neutral API: a route table + one dispatch(). Any host (node:http, Cloudflare Worker, Express) just calls dispatch(ctx, req).
//   req = { method, path, query:{}, body:any, actor:string|null }   ->   { status, body }
// `actor` is the signed-in profile id. In the testing phase the local profile switcher supplies it (header x-profile-id).
// When real auth arrives, only the code that computes `actor` changes. Every service already checks ownership against it.
import * as S from '../service/sessions.mjs';
import * as R from '../service/review.mjs';
import * as P from '../service/plan.mjs';
import * as K from '../service/skills.mjs';
import { getAudit } from '../service/audit.mjs';
import { importBluebook } from '../service/bluebook.mjs';
import { ApiError, invalid } from '../service/shared.mjs';
import { AssemblyError } from '../questions/assembler.mjs';
import { studyLinks } from '../bluebook/import.mjs';
import { AiCache } from '../llm/cache.mjs';

const need = (v, name) => { if (!v) throw invalid(`${name} is required`); return v; };

/** [method, pattern, handler(ctx, {params, query, body, actor}) ]  */
export const ROUTES = [
  ['POST', '/api/sessions', (c, r) => S.createSession(c, r.body, r.actor)],
  ['GET', '/api/sessions/:id', (c, r) => S.getSessionState(c, r.params.id, r.actor)],
  ['POST', '/api/sessions/:id/events', (c, r) => S.ingestEvents(c, r.params.id, r.body, r.actor)],
  ['POST', '/api/sessions/:id/modules/:m/submit', (c, r) => S.submitModule(c, r.params.id, r.params.m, r.body, r.actor)],
  ['POST', '/api/sessions/:id/finish', (c, r) => S.finishSession(c, r.params.id, r.body, r.actor)],
  ['GET', '/api/sessions/:id/review-queue', (c, r) => R.getReviewQueue(c, r.params.id, r.actor)],
  ['POST', '/api/reviews/:attemptId', (c, r) => R.submitReview(c, r.params.attemptId, r.body, r.actor)],
  ['GET', '/api/second-chance', (c, r) => R.listSecondChances(c, need(r.query.profile_id ?? r.actor, 'profile_id'), r.actor)],
  ['POST', '/api/second-chance/:id/answer', (c, r) => R.answerSecondChance(c, r.params.id, r.body, r.actor)],
  // only staff may force a fresh LLM narrative: students re-reading an audit always hit the cache, so nobody can burn the daily quota
  ['GET', '/api/audit/:sessionId', async (c, r) => getAudit(c, r.params.sessionId, r.actor, { force: r.query.refresh === '1' && !!r.actor && (await K.isStaff(c, r.actor)) })],
  ['GET', '/api/plan', (c, r) => P.getPlan(c, need(r.query.profile_id ?? r.actor, 'profile_id'), r.actor)],
  ['PATCH', '/api/plan-items/:id', (c, r) => P.patchPlanItem(c, r.params.id, r.body, r.actor)],
  ['POST', '/api/import/bluebook', (c, r) => importBluebook(c, r.body, r.actor)],
  ['GET', '/api/sessions/:id/traps', async (c, r) => { const rows = await c.db.select('attempts', { session_id: r.params.id }); const t = {}; for (const a of rows) if (!a.is_correct && a.trap_code) t[a.trap_code] = (t[a.trap_code] ?? 0) + 1; return { traps: Object.entries(t).sort((a, b) => b[1] - a[1]).map(([code, n]) => ({ code, n })) }; }],
  ['GET', '/api/skills/mastery', (c, r) => K.getMasteryMap(c, need(r.query.profile_id ?? r.actor, 'profile_id'), r.actor)],
  ['POST', '/api/questions/:id/report', (c, r) => R.reportQuestion(c, r.params.id, r.body, r.actor)],
  ['GET', '/api/admin/questions', (c, r) => K.listAdminQuestions(c, r.query, r.actor)],
  ['GET', '/api/admin/questions/:id', (c, r) => K.getAdminQuestion(c, r.params.id, r.actor)],
  ['PATCH', '/api/admin/questions', (c, r) => K.patchAdminQuestion(c, r.body, r.actor)],
  // helpers the demo UI needs (not part of the product contract in G4, listed in INTEGRATION.md under "extras")
  ['GET', '/api/profiles', (c) => K.listProfiles(c)],
  ['POST', '/api/profiles', (c, r) => K.createProfile(c, r.body)],
  ['GET', '/api/sessions', async (c, r) => { const pid = need(r.query.profile_id ?? r.actor, 'profile_id'); if (r.actor && r.actor !== pid) throw new ApiError(403, 'forbidden', 'not your sessions'); return { sessions: (await c.db.select('sessions', { profile_id: pid }, { orderBy: 'started_at', desc: true })).map((s) => ({ id: s.id, kind: s.kind, status: s.status, source: s.source, started_at: s.started_at })) }; }],
  ['GET', '/api/taxonomy', (c) => ({ domains: c.tax.domains.map((d) => ({ id: d.id, name: d.name, section: d.section, skills: c.tax.skillsByDomain.get(d.id).map((s) => ({ id: s.id, name: s.name })) })), reasons: c.tax.reasons.map((r) => ({ code: r.code, label: r.label, section: r.section })) })],
  ['GET', '/api/admin/ai-usage', async (c, r) => { await K.listAdminQuestions(c, {}, r.actor); return new AiCache(c.db, c.now).usageToday(); }],
  ['GET', '/api/health', (c) => ({ ok: true, questions: c.bank.length, verified: c.bank.filter((q) => q.status !== 'draft').length, llm: c.llm?.provider ? (c.config.routing.provider?.name ?? c.llm.provider.name) : 'off', audit_enabled: c.auditEnabled !== false, tests: S.feasibleKinds(c) })],
];

const compiled = ROUTES.map(([method, pattern, handler]) => ({ method, handler, keys: [...pattern.matchAll(/:(\w+)/g)].map((m) => m[1]), re: new RegExp(`^${pattern.replace(/:\w+/g, '([^/]+)')}$`) }));

export function matchRoute(method, path) {
  const allowed = new Set();
  for (const r of compiled) { const m = r.re.exec(path); if (!m) continue; allowed.add(r.method); if (r.method === method) return { route: r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) }; }
  return { allowed: [...allowed] };
}

export async function dispatch(ctx, req) {
  const { method, path, query = {}, body = null, actor = null } = req;
  const hit = matchRoute(method, path);
  if (!hit.route) return hit.allowed?.length ? { status: 405, body: { error: { code: 'method_not_allowed', message: `use ${hit.allowed.join(' or ')}` } } } : { status: 404, body: { error: { code: 'not_found', message: `no route ${method} ${path}` } } };
  try {
    return { status: 200, body: await hit.route.handler(ctx, { params: hit.params, query, body, actor }) };
  } catch (e) {
    if (e instanceof ApiError) return { status: e.status, body: { error: { code: e.code, message: e.message, details: e.details ?? undefined } } };
    if (e instanceof AssemblyError) return { status: 422, body: { error: { code: 'bank_too_small', message: e.message, details: e.missing } } };
    console.error('[api] unexpected', method, path, e);                     // never leaks the stack to the client
    return { status: 500, body: { error: { code: 'internal', message: 'unexpected error; it was logged' } } };
  }
}
