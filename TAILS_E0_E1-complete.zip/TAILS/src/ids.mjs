// The ONE ID scheme (see docs/ID-SCHEME.md). Every id in data.json must match one of these.
// Dots separate hierarchy in skills; hyphens are used inside item/lesson ids so ids are safe as file names and URL parts.
export const ID = {
  domain: /^(RW|M)\.[A-Z0-9]+$/,                               // M.ALG
  skill: /^(RW|M)\.[A-Z0-9]+\.[A-Z0-9]+(\.[A-Z0-9]+)?$/,       // M.ALG.LIN1, RW.II.CEV.T
  micro: /^(RW|M)\.[A-Z0-9]+\.[A-Z0-9]+(\.[A-Z0-9]+)?#[A-Z0-9-]+$/, // M.ALG.LIN1#ISOLATE
  item: /^(RW|M)-[A-Z0-9]+(-[A-Z0-9]+)+-\d{4}$/,               // M-ALG-LIN1-0011
  lessonSkill: /^L-(RW|M)-[A-Z0-9]+(-[A-Z0-9]+)+-([CET]|\d{2})$/,  // L-M-ALG-SYS-C (C/E/T) or L-RW-CS-WIC-01 (numbered). The `kind` field is authoritative, never parse it from the id.
  lessonFix: /^F-[A-Z0-9]+(-[A-Z0-9]+)*$/,                     // F-SIGN-ERROR
  lessonGeneral: /^[OSDTPV]-\d{2}$/,                           // O orientation, S strategy, D, T tool, P pacing, V vocab
  trap: /^[A-Z0-9]+(-[A-Z0-9]+)*$/,                            // SIGN-ERROR
  reason: /^[A-Z0-9]+(-[A-Z0-9]+)*$/,
};
export const isLessonId = (id) => ID.lessonSkill.test(id) || ID.lessonFix.test(id) || ID.lessonGeneral.test(id);
/** Item id <-> skill id. M-ALG-LIN1-0011 <-> M.ALG.LIN1 */
export const skillOfItemId = (id) => id.replace(/-\d{4}$/, '').replace(/^(RW|M)-/, (m) => m.slice(0, -1) + '.').replace(/-/g, '.');
export const itemIdFor = (skillId, seq) => `${skillId.replace(/\./g, '-')}-${String(seq).padStart(4, '0')}`;

/** Check every id in a loaded bundle. Returns a list of problems (empty = clean). */
export function checkIds(b) {
  const bad = [], need = (ok, m) => { if (!ok) bad.push(m); };
  for (const d of b.skills.domains) need(ID.domain.test(d.id), `domain id ${d.id}`);
  const skills = new Set(b.skills.skills.map((s) => s.id));
  for (const s of b.skills.skills) { need(ID.skill.test(s.id), `skill id ${s.id}`); need(s.id.startsWith(s.domain + '.'), `skill ${s.id} not under domain ${s.domain}`); }
  for (const m of b.microskills) { need(ID.micro.test(m.id), `micro id ${m.id}`); need(skills.has(m.skill_id) && m.id.startsWith(m.skill_id + '#'), `micro ${m.id} not under its skill`); }
  for (const t of b.traps) need(ID.trap.test(t.code), `trap code ${t.code}`);
  for (const r of b.reasons) need(ID.reason.test(r.code), `reason code ${r.code}`);
  const lessons = new Set();
  for (const l of b.lessons.lessons) {
    need(isLessonId(l.id), `lesson id ${l.id}`); need(!lessons.has(l.id), `duplicate lesson id ${l.id}`); lessons.add(l.id);
    if (l.skill_id) need(skills.has(l.skill_id), `lesson ${l.id}: unknown skill ${l.skill_id}`);
  }
  const traps = new Set(b.traps.map((t) => t.code)), seen = new Set();
  for (const q of b.questions) {
    need(ID.item.test(q.id), `item id ${q.id}`); need(!seen.has(q.id), `duplicate item id ${q.id}`); seen.add(q.id);
    need(skills.has(q.skill_id), `item ${q.id}: unknown skill ${q.skill_id}`);
    need(skillOfItemId(q.id) === q.skill_id, `item ${q.id} does not encode skill ${q.skill_id}`);
    for (const l of q.lesson_ids ?? []) need(lessons.has(l), `item ${q.id}: unknown lesson ${l}`);
    for (const c of q.choices ?? []) if (c.trap_code) need(traps.has(c.trap_code), `item ${q.id}: unknown trap ${c.trap_code}`);
    for (const m of q.micro_skills ?? []) need(b.microskills.some((x) => x.id === m), `item ${q.id}: unknown micro ${m}`);
  }
  return bad;
}
