// Beta mastery model. PURE. Recomputed from the attempt log, so it is idempotent and order-independent.
import { DAY_MS } from '../util/misc.mjs';
import { isGuessedCorrect } from './rootcause.mjs';

export const keyOf = (skill, micro = '') => `${skill}|${micro}`;

/**
 * attempts: rows (attempts table shape; micro_skill_ids_json already an array). Returns Map key -> {skill_id, micro_skill_id, level, alpha, beta, p, variance, n, n_eff, last_attempt_at, insufficient}
 * level: 'skill' | 'micro' | 'domain'. Domain rows use skill_id = domain id and micro ''.
 */
export function computeMastery(attempts, cfg, nowMs) {
  const m = cfg.mastery, acc = new Map();
  const seenQ = new Map();
  const ordered = attempts.slice().sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)));
  const bump = (key, level, skill_id, micro_skill_id, weight, correct, at) => {
    let r = acc.get(key);
    if (!r) { r = { skill_id, micro_skill_id, level, a: 0, b: 0, n: 0, last: null }; acc.set(key, r); }
    if (correct) r.a += weight; else r.b += weight;
    r.n++; if (!r.last || at > r.last) r.last = at;
  };
  for (const at of ordered) {
    const correct = !!at.is_correct;
    const ageDays = Math.max(0, (nowMs - Date.parse(at.created_at)) / DAY_MS);
    const decay = Math.pow(0.5, ageDays / m.half_life_days);
    let w = (correct ? m.difficulty_weight_correct : m.difficulty_weight_wrong)[String(at.difficulty ?? 3)] ?? 1;
    if (correct && isGuessedCorrect(at, cfg)) w = m.guessed_correct_weight;
    if (at.source === 'bluebook') w *= m.bluebook_weight;
    const qkey = at.question_id ?? at.question_ref;
    if (at.question_id) { const c = seenQ.get(qkey) ?? 0; if (c > 0) w *= m.repeat_question_weight; seenQ.set(qkey, c + 1); }
    w *= decay;
    if (at.domain) bump(keyOf(at.domain), 'domain', at.domain, '', w, correct, at.created_at);
    if (at.skill_id && !at.domain_estimated) {
      // Bluebook imports list the WRONG questions with a skill, so skill-level evidence there is negative-only: damp it
      const ws = at.source === 'bluebook' && !correct ? w * m.bluebook_skill_negative_only_factor : w;
      bump(keyOf(at.skill_id), 'skill', at.skill_id, '', ws, correct, at.created_at);
      for (const mi of at.micro_skill_ids_json ?? []) bump(keyOf(at.skill_id, mi), 'micro', at.skill_id, mi, ws, correct, at.created_at);
    }
  }
  const out = new Map();
  for (const [key, r] of acc) {
    const alpha = m.prior_alpha + r.a, beta = m.prior_beta + r.b, s = alpha + beta;
    const need = r.level === 'micro' ? m.min_attempts_micro : r.level === 'domain' ? m.domain_only_min_attempts : m.min_attempts_skill;
    out.set(key, { skill_id: r.skill_id, micro_skill_id: r.micro_skill_id, level: r.level, alpha, beta, p: alpha / s, variance: (alpha * beta) / (s * s * (s + 1)), n: r.n, n_eff: r.a + r.b, last_attempt_at: r.last, insufficient: r.n < need });
  }
  return out;
}

/** Readiness band 1..7 from p. Not a score prediction. */
export function readinessBand(p, cuts) { let b = 1; for (const c of cuts) if (p >= c) b++; return b; }

export const skillP = (mastery, skillId) => mastery.get(keyOf(skillId))?.p ?? null;
export const skillN = (mastery, skillId) => mastery.get(keyOf(skillId))?.n ?? 0;

/** DB rows for skill_mastery. */
export function masteryRows(profileId, mastery, nowIso) {
  return [...mastery.values()].map((r) => ({ profile_id: profileId, skill_id: r.skill_id, micro_skill_id: r.micro_skill_id, p_mastery: r.p, alpha: r.alpha, beta: r.beta, n_attempts: r.n, last_attempt_at: r.last_attempt_at, updated_at: nowIso }));
}
