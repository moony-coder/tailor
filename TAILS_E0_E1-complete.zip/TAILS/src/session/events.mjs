// Telemetry event vocabulary + validation. Events carry interaction FACTS only: no keystroke content, no free text, no media.
export const EVENT_TYPES = [
  'module_started', 'question_shown', 'answer_selected', 'answer_cleared', 'answer_changed', 'option_eliminated', 'flag_set', 'flag_cleared',
  'navigate', 'calculator_opened', 'calculator_closed', 'highlight_added', 'notes_opened', 'tab_blurred', 'tab_focused',
  'idle_started', 'idle_ended', 'module_submitted', 'time_expired',
];
// Allowed payload keys per type (anything else is dropped by sanitizeEvent). `choice` values are validated as short tokens.
const PAYLOAD_KEYS = {
  answer_selected: ['choice', 'rem'], answer_changed: ['from', 'to', 'rem'], option_eliminated: ['choice'], navigate: ['from', 'to'],
  module_started: ['limit_ms'], module_submitted: ['rem'], time_expired: [], idle_started: [], idle_ended: [],
};
const TOKEN = /^[A-Za-z0-9_.,\-/ ]{0,24}$/;   // choice letters or an SPR number; never prose
const MAX_BATCH = 500;

export function sanitizeEvent(e) {
  const errors = [];
  if (!e || typeof e !== 'object') return { ok: false, errors: ['event is not an object'] };
  if (!EVENT_TYPES.includes(e.type)) errors.push(`unknown type ${e.type}`);
  if (!Number.isInteger(e.seq) || e.seq < 1) errors.push('seq must be a positive integer');
  if (!Number.isFinite(e.t_ms) || e.t_ms <= 0) errors.push('t_ms must be epoch milliseconds');
  if (e.question_id != null && !/^[A-Za-z0-9_.\-#]{1,64}$/.test(e.question_id)) errors.push('bad question_id');
  const payload = {};
  for (const k of PAYLOAD_KEYS[e.type] ?? []) {
    const v = e.payload?.[k];
    if (v === undefined || v === null) continue;
    if (k === 'rem' || k === 'limit_ms') { if (!Number.isFinite(v)) errors.push(`${k} must be a number`); else payload[k] = Math.round(v); }
    else if (k === 'choice' || k === 'from' || k === 'to') { if (typeof v === 'number') payload[k] = v; else if (typeof v !== 'string' || !TOKEN.test(v)) errors.push(`${k} must be a short token`); else payload[k] = v; }
  }
  if (errors.length) return { ok: false, errors };
  return { ok: true, event: { seq: e.seq, type: e.type, t_ms: Math.round(e.t_ms), module_id: e.module_id ?? null, question_id: e.question_id ?? null, payload } };
}
export function sanitizeBatch(events) {
  if (!Array.isArray(events)) return { good: [], bad: [{ index: -1, errors: ['events must be an array'] }] };
  const good = [], bad = [];
  events.slice(0, MAX_BATCH).forEach((e, index) => { const r = sanitizeEvent(e); if (r.ok) good.push(r.event); else bad.push({ index, errors: r.errors }); });
  if (events.length > MAX_BATCH) bad.push({ index: MAX_BATCH, errors: [`batch truncated at ${MAX_BATCH}`] });
  return { good, bad };
}
