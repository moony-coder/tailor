/* ============================================================
   DEMO STUDENT. The whole app opens as a student who has already put in the work:
   answers across every topic, a rising score trend, full tests, a streak,
   missed questions to review, finished lessons and videos, and every badge unlocked.
   Seeded once per browser (guard.js creates the demo profile, this fills in the rest).
   Real students who finish /onboarding are never touched (profile.demo is only set by guard.js).
   ============================================================ */
(function(){
  if(!state.profile || !state.profile.demo || state.demoSeeded) return;
  const now = Date.now(), H = 3600000;
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const pick = a => a[Math.floor(rnd() * a.length)];
  const day0 = new Date(); day0.setHours(0, 0, 0, 0); const startToday = day0.getTime();
  const e = E();

  /* ---- profile ---- */
  const tdate = new Date(now + 75 * DAY);
  while(tdate.getDay() !== 6) tdate.setDate(tdate.getDate() + 1);          /* next Saturday ~11 weeks out */
  Object.assign(state.profile, { name:'Aisha', goal:1560, testDate:ymd(tdate), startScore:1180, onboarded:true, demo:true });

  /* ---- answers per topic: attempts / correct (about 84% overall) ---- */
  const T = { math_algebra:[64,55], math_adv:[58,46], rw_craft:[52,43], rw_info:[61,51], rw_conv:[47,41] };
  state.byTopic = {}; state.answered = 0; state.correct = 0;
  Object.keys(T).forEach(k => { state.byTopic[k] = { attempts:T[k][0], correct:T[k][1] }; state.answered += T[k][0]; state.correct += T[k][1]; });

  /* ---- history (last 21 days, newest last) ---- */
  state.history = [];
  const pool = []; Object.keys(T).forEach(k => { for(let i = 0; i < T[k][0]; i++) pool.push({ topic:k, correct:i < T[k][1] }); });
  for(let i = pool.length - 1; i > 0; i--){ const j = Math.floor(rnd() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
  const hist = pool.slice(0, 140);
  hist.forEach((h, i) => state.history.push({ topic:h.topic, correct:h.correct, ts:now - (hist.length - 1 - i) * (21 * DAY / hist.length) }));

  /* ---- detailed log from REAL questions, so Review / Plan / Analytics agree with each other ---- */
  const qs = []; Object.keys(BANK).forEach(t => BANK[t].forEach(q => qs.push(Object.assign({ _t:t }, q))));
  const byD = d => qs.filter(q => q.diff === d);
  e.log = []; e.seen = {};
  const wkStartTs = startToday - todayIdx() * DAY;
  const perDay = [14, 11, 16, 9, 13, 12, 10];            /* last 7 days, oldest first; today is the last */
  for(let d = 6; d >= 0; d--){
    const n = d === 0 ? 12 : perDay[6 - d];
    for(let i = 0; i < n; i++){
      const q = pick(rnd() < .22 ? byD('Hard') : rnd() < .5 ? byD('Medium') : qs);
      const ok = rnd() < (q.diff === 'Hard' ? .66 : .86) ? 1 : 0;
      let ts = d === 0 ? Math.max(startToday + 60000, now - (n - i) * 7 * 60000) : startToday - d * DAY + 15 * H + i * 6 * 60000;
      e.log.push({ k:keyOf(q), tp:q._t, sk:q.skill || '', d:q.diff, ok, t:Math.round(35 + rnd() * 80), ts });
      e.seen[keyOf(q)] = ok ? 'ok' : 'miss';
    }
  }
  /* guarantee the hard-question badge condition and this week's challenge numbers */
  const hardOk = () => e.log.filter(x => x.d === 'Hard' && x.ok).length;
  for(let i = 0; hardOk() < 8 && i < e.log.length; i++) if(e.log[i].d === 'Hard') e.log[i].ok = 1;

  /* ---- missed questions to review, with reasons tagged on some ---- */
  state.missed = []; e.tags = {}; e.tagTs = {};
  const missedQs = []; const seenK = {};
  qs.filter(q => e.seen[keyOf(q)] === 'miss' && !seenK[keyOf(q)] && (seenK[keyOf(q)] = 1)).slice(0, 9).forEach(q => missedQs.push(q));
  if(missedQs.length < 6) qs.filter(q => !seenK[keyOf(q)]).slice(0, 6 - missedQs.length).forEach(q => { missedQs.push(q); e.seen[keyOf(q)] = 'miss'; });
  const tagKeys = TAGS.map(t => t[0]);
  missedQs.forEach((q, i) => {
    const clean = Object.assign({}, q); delete clean._t;
    state.missed.push({ q:clean, chosen:q.spr ? '0' : (q.a + 1 + (i % 3)) % q.opts.length, topic:q._t, ts:now - (i + 1) * 5 * H });
    if(i < 6){ e.tags[keyOf(q)] = tagKeys[i % tagKeys.length]; e.tagTs[keyOf(q)] = Math.max(wkStartTs, now - i * 3 * H); }
  });

  /* ---- bookmarks, diagnostic, practice extras ---- */
  e.bmk = {}; qs.filter(q => q.diff === 'Hard').slice(0, 5).forEach(q => { e.bmk[keyOf(q)] = 1; });
  const by = {}; Object.keys(T).forEach(k => { const n = 8; by[k] = { n, c:Math.round(n * (k === 'math_adv' ? .5 : k === 'rw_conv' ? .75 : .63)) }; });
  e.diag = { ts:now - 40 * DAY, by, pct:Math.round(Object.values(by).reduce((a, b) => a + b.c, 0) / 40 * 100) };
  e.timed = 4; e.perfect = 1; e.goal = 10; e.goalDay = ymd(now); e.goalDays = 9; e.freeze = 2; e.xp = 2840;

  /* ---- streak, study time (only up to today), score trend, tests ---- */
  state.streak = 16; state.lastDay = ymd(now);
  state.weekStart = monday();
  const mins = [48, 62, 35, 55, 41, 78, 30]; state.studyMin = mins.map((m, i) => i <= todayIdx() ? m : 0);
  const tr = [1180, 1210, 1240, 1275, 1310, 1350, 1390, 1425, 1470, 1510];
  state.trend = tr.map((s, i) => ({ ts:now - (tr.length - 1 - i) * 6 * DAY, score:s }));
  state.base = { rw:600, m:580 };
  state.testsDone = 3;
  state.lastTest = { score:1490, rw:750, m:740, correct:80, total:98, ts:now - 4 * DAY };

  /* ---- lessons and videos ---- */
  state.lessonDone = {}; (typeof LESSONS !== 'undefined' ? LESSONS : []).slice(0, 5).forEach(l => { state.lessonDone[l.id] = true; });
  e.vid = {};
  const ids = (window.VIDEOS || []).map(v => (String(v.link).match(/[\w-]{11}/) || [])[0]).filter(Boolean);
  ids.slice(0, 12).forEach((id, i) => { e.vid[id] = { t:0, d:420 + i * 37, done:true, ts:now - (i + 1) * 9 * H }; });
  if(ids[12]) e.vid[ids[12]] = { t:212, d:603, done:false, ts:now - 2 * H };
  if(ids[13]) e.vid[ids[13]] = { t:96, d:511, done:false, ts:now - 30 * H };

  /* ---- every badge unlocked, spread over the past weeks ---- */
  e.badges = {}; BADGES.forEach((b, i) => { e.badges[b[0]] = now - (BADGES.length - i) * 38 * H; });

  state.welcomeDay = ymd(now); state.demoSeeded = true;
  saveState();
})();
