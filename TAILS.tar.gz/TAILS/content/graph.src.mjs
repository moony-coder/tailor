// TAILS content graph (E2): prerequisites, rule cards, difficulty bands and planning priors for all 30 skills.
// This is curated knowledge, not code. Edit here, then `npm run graph:build` validates it and writes it into data.json (key `graph`).
//
//  prereqs        HARD prerequisites. The planner will not teach/drill the skill while a prerequisite is KNOWN to be weak (p < gate).
//  soft           helpful but not blocking (used for ordering ties and for the "why" text)
//  recoverability share of the headroom a motivated student can realistically recover (prior; E7 re-fits from real students)
//  hours_to_fix   study hours to take a typical student from ~50% to the target mastery on this skill (prior; E7 re-fits)
//  bands          what easy / medium / hard MEAN for this skill (authoring guide + shown to the teacher; band -> difficulty labels is global)
//  rule_card      3 to 6 lines + one example + one common trap. Shown before the first practice on the skill and as a hint after a miss.
//
// Item difficulty labels 1..5 map to bands globally: easy = 1-2, medium = 3, hard = 4-5.

export const GRAPH_VERSION = 1;

export const GATE = { prereq_p: 0.5, min_evidence: 4 };            // a prerequisite blocks only when we KNOW it is weak
export const LADDER = { window: 12, min_n: 6, promote_acc: 0.72, demote_acc: 0.45, mix: { current: 0.6, up: 0.25, down: 0.15 } };

export const BAND_OF_DIFFICULTY = { 1: 'easy', 2: 'easy', 3: 'medium', 4: 'hard', 5: 'hard' };

// Generic one-line hints per trap code, shown after a wrong answer when the skill has no specific wording.
export const TRAP_HINTS = {
  'SIGN-ERROR': 'Check every minus sign. Distributing a negative flips every term inside the brackets.',
  'ARITH-SLIP': 'The method was right; the arithmetic slipped. Redo the last calculation slowly.',
  'WRONG-VARIABLE': 'You solved for a different letter than the one asked. Underline what the question wants.',
  'STOPPED-EARLY': 'You found an intermediate value. Re-read the question: is that the thing being asked?',
  'ASKED-DIFFERENT': 'You answered a nearby question. Write down exactly what is asked before you start.',
  'WRONG-FORMULA': 'The formula does not fit this situation. Name the quantity first, then pick the formula.',
  'UNIT-ERROR': 'Units or percent versus decimal got mixed. Convert everything first, then calculate.',
  'PERCENT-OF-VS-CHANGE': 'A percent OF something is not a percent CHANGE. Say which base the percent uses.',
  'SLOPE-INTERCEPT-SWAP': 'Slope is the rate of change (per one x). The intercept is the value when x = 0.',
  'MISREAD-GRAPH': 'Read the axis labels and units before reading any point.',
  'DOUBLE-HALF': 'Diameter versus radius, or a missed factor of 2. Check which one the problem gave.',
  'EXTRANEOUS-KEPT': 'Plug each solution back into the ORIGINAL equation; squaring and denominators create fakes.',
  'ORDER-OF-OPS': 'Brackets, then exponents, then multiply and divide, then add and subtract. Redo in that order.',
  'ROUNDING': 'Round only at the very end, and check whether the question wants the largest or smallest whole value.',
  'IGNORED-CONSTRAINT': 'A condition in the question (positive, integer, at least, only) rules out some answers.',
  'PARTIAL-CREDIT-SOLUTION': 'The work is half done: the expression is not yet in the form asked for.',
  'TOO-EXTREME': 'Words like always, never, only, all are rarely supported. Find the line that proves it.',
  'OUT-OF-SCOPE': 'The text never says this. Keep only what you can point to in the passage.',
  'OPPOSITE': 'This reverses the passage. Check the direction of the claim, especially around "but" and "although".',
  'TRUE-BUT-NOT-ANSWER': 'A true statement is not automatically the answer. Does it answer THIS question?',
  'WORD-MATCH': 'It repeats words from the passage but changes the meaning. Match ideas, not words.',
  'PARTIAL': 'One half is right, the other half is wrong. The whole choice must be correct.',
  'TOO-NARROW': 'This covers one detail, not the whole text.',
  'TOO-BROAD': 'This goes beyond what the passage covers.',
  'WRONG-REFERENT': 'It credits the idea to the wrong person or thing. Re-check who said or did what.',
  'WRONG-RELATIONSHIP': 'The logical link is wrong. Name the relationship (contrast, cause, example, addition) first.',
  'GRAMMAR-LOOKS-RIGHT': 'It sounds natural but breaks a rule. Identify the rule being tested, then apply it mechanically.',
  'TONE-MISMATCH': 'The attitude is too strong, too weak or the wrong kind for the passage.',
  'DETAIL-AS-MAIN-IDEA': 'A supporting detail, not the point of the whole text.',
  'NEARBY-MEANING': 'Close in meaning, wrong in degree or connotation. Test it in the sentence.',
};

const card = (id, title, lines, example, trap) => ({ id: `RC.${id}`, title, lines, example, trap });

export const SKILLS = {
  // ===================================================== MATH: ALGEBRA
  'M.ALG.LIN1': {
    prereqs: [], soft: ['M.PSDA.RATIO'], recoverability: 0.92, hours_to_fix: 3,
    bands: { easy: 'One-step or two-step equations with integers.', medium: 'Variables on both sides, distribution, fractions; word problems that need an equation.', hard: 'Parameters ("for what value of k..."), no-solution / infinitely-many conditions, expressions to evaluate instead of x.' },
    rule_card: card('M.ALG.LIN1', 'Linear equations in one variable', [
      'Do the same thing to both sides until the variable is alone.',
      'Clear brackets first, then collect the variable on one side.',
      'Fractions: multiply every term by the common denominator.',
      'No solution = the variable cancels and the numbers disagree. Infinitely many = both sides become identical.',
      'Always answer what is asked (sometimes 3x + 1, not x).',
    ], { problem: 'Solve 3(x - 2) = 12', answer: 'x - 2 = 4, so x = 6' }, { code: 'SIGN-ERROR', text: 'Writing 3x - 2 instead of 3x - 6: the 3 multiplies BOTH terms.' }),
  },
  'M.ALG.LIN2': {
    prereqs: ['M.ALG.LIN1'], soft: [], recoverability: 0.9, hours_to_fix: 4,
    bands: { easy: 'Find y for a given x on y = mx + b, read slope or intercept.', medium: 'Standard form to slope-intercept, build an equation from two facts, interpret slope and intercept in context.', hard: 'Parallel and perpendicular lines with a condition, unknown coefficients, intercepts of a line given in standard form.' },
    rule_card: card('M.ALG.LIN2', 'Linear equations in two variables', [
      'y = mx + b: m is the change in y for each +1 in x; b is y when x = 0.',
      'Standard form Ax + By = C: set x = 0 for the y-intercept, y = 0 for the x-intercept.',
      'Parallel lines share a slope; perpendicular slopes multiply to -1.',
      'In a word problem, the slope carries the unit "per" (dollars per hour), the intercept is the starting amount.',
    ], { problem: 'A plumber charges $40 plus $25 per hour. Equation?', answer: 'y = 25x + 40' }, { code: 'SLOPE-INTERCEPT-SWAP', text: 'Putting the fixed fee as the slope and the hourly rate as the intercept.' }),
  },
  'M.ALG.LFUNC': {
    prereqs: ['M.ALG.LIN2'], soft: ['M.ALG.LIN1'], recoverability: 0.88, hours_to_fix: 4,
    bands: { easy: 'Evaluate f(x) at a number; read a value from a table.', medium: 'Find the rate of change from two points, build f from a table, interpret f(a) = b.', hard: 'Compose or transform linear functions, solve f(x) = g(x), parameters inside f.' },
    rule_card: card('M.ALG.LFUNC', 'Linear functions', [
      'f(a) means: replace x by a everywhere, then calculate.',
      'Rate of change = (change in f) / (change in x), the same between any two points of a line.',
      'f(a) = b means the point (a, b) is on the graph.',
      'To build f(x) = mx + b: get m from two points, then use one point to find b.',
    ], { problem: 'f(2) = 7 and f(5) = 16. Find f(x).', answer: 'm = 9/3 = 3; b = 7 - 6 = 1; f(x) = 3x + 1' }, { code: 'STOPPED-EARLY', text: 'Finding the slope and stopping, when the question asked for f(10).' }),
  },
  'M.ALG.SYS': {
    prereqs: ['M.ALG.LIN2'], soft: ['M.ALG.LIN1'], recoverability: 0.88, hours_to_fix: 4,
    bands: { easy: 'Substitution when one variable is already isolated.', medium: 'Elimination, word problems that produce two equations.', hard: 'No-solution / infinite-solution conditions with a parameter, asked for x + y or 2x - y without solving for each.' },
    rule_card: card('M.ALG.SYS', 'Systems of two linear equations', [
      'Substitution: isolate one variable, plug it into the other equation.',
      'Elimination: scale the equations so one variable has opposite coefficients, then add.',
      'Same slope, different intercept = no solution. Same slope and intercept = infinitely many.',
      'Read the question: sometimes it asks for x + y, which you can get by adding the equations without solving.',
    ], { problem: 'x + y = 10, x - y = 4. Find x.', answer: 'Add: 2x = 14, so x = 7' }, { code: 'ASKED-DIFFERENT', text: 'Solving for x and y correctly, then answering with y when x was asked.' }),
  },
  'M.ALG.INEQ': {
    prereqs: ['M.ALG.LIN1'], soft: [], recoverability: 0.9, hours_to_fix: 3,
    bands: { easy: 'Solve a one-step or two-step inequality.', medium: 'Flip the sign on a negative, translate "at least / at most", compound inequalities.', hard: 'Systems of inequalities and the allowed region, largest or smallest whole-number value, context with a budget.' },
    rule_card: card('M.ALG.INEQ', 'Linear inequalities', [
      'Solve like an equation, but multiplying or dividing by a NEGATIVE flips the sign.',
      '"At least" is >=, "at most" is <=, "more than" is >.',
      'If the answer must be a whole number, check the boundary value before you round.',
      'For a budget, write cost <= budget, then solve for the count.',
    ], { problem: '-2x + 3 > 11', answer: '-2x > 8, so x < -4' }, { code: 'SIGN-ERROR', text: 'Dividing by -2 and keeping the > sign.' }),
  },
  // ===================================================== MATH: ADVANCED
  'M.ADV.EQUIV': {
    prereqs: ['M.ALG.LIN1'], soft: ['M.ALG.INEQ'], recoverability: 0.85, hours_to_fix: 5,
    bands: { easy: 'Expand a single bracket, combine like terms, simple exponent rules.', medium: 'Factor trinomials, multiply binomials, rational expressions with one step.', hard: 'Complete the square, rationalize, nested radicals / fractional exponents, divide polynomials.' },
    rule_card: card('M.ADV.EQUIV', 'Equivalent expressions', [
      'Same base: multiply = add exponents, divide = subtract, power of a power = multiply.',
      'FOIL every term: (x + a)(x + b) = x^2 + (a + b)x + ab.',
      'Factoring is the reverse: find two numbers with product c and sum b.',
      'Quick check: plug in x = 1 or x = 2 into the original and the answer choices.',
    ], { problem: 'Factor x^2 - 5x + 6', answer: '(x - 2)(x - 3)' }, { code: 'SIGN-ERROR', text: '(x + 2)(x + 3): both numbers must be negative because the product is positive and the sum is negative.' }),
  },
  'M.ADV.NLEQ': {
    prereqs: ['M.ADV.EQUIV'], soft: ['M.ALG.SYS'], recoverability: 0.8, hours_to_fix: 6,
    bands: { easy: 'Solve a quadratic that factors cleanly.', medium: 'Quadratic formula, linear-quadratic systems, simple rational or radical equations.', hard: 'Discriminant conditions, extraneous solutions, circle equations, exponential equations with a parameter.' },
    rule_card: card('M.ADV.NLEQ', 'Nonlinear equations and systems', [
      'Set one side to 0, factor, then set each factor to 0.',
      'Quadratic formula: x = (-b +/- sqrt(b^2 - 4ac)) / 2a. The discriminant b^2 - 4ac decides: >0 two answers, =0 one, <0 none.',
      'Radical or rational equations: ALWAYS plug solutions back; squaring and denominators create fake answers.',
      'Line meets parabola: substitute, solve the quadratic, then find y for each x.',
    ], { problem: 'sqrt(x + 6) = x', answer: 'x + 6 = x^2 gives x = 3 or -2. Only x = 3 works.' }, { code: 'EXTRANEOUS-KEPT', text: 'Keeping x = -2, which makes the left side positive and the right side negative.' }),
  },
  'M.ADV.NLFUNC': {
    prereqs: ['M.ADV.NLEQ', 'M.ALG.LFUNC'], soft: ['M.ADV.EQUIV'], recoverability: 0.75, hours_to_fix: 7,
    bands: { easy: 'Read a value or a vertex from a quadratic in a clear form.', medium: 'Exponential growth/decay with a rate, zeros and factors, transformations of a graph.', hard: 'Compose functions, polynomial end behaviour and remainder, parameters in vertex or factored form.' },
    rule_card: card('M.ADV.NLFUNC', 'Nonlinear functions', [
      'y = a(x - h)^2 + k has its vertex at (h, k). Zeros of a factored form are where each factor is 0.',
      'Exponential: y = a(1 + r)^t grows by r each step; (1 - r) decays.',
      'f(x - h) shifts RIGHT by h; f(x) + k shifts UP by k.',
      'Compose from the inside: f(g(2)) means compute g(2) first.',
    ], { problem: 'A value of $500 grows 4% per year. After t years?', answer: '500(1.04)^t' }, { code: 'PERCENT-OF-VS-CHANGE', text: 'Writing 500(0.04)^t: the multiplier is 1.04, not 0.04.' }),
  },
  // ===================================================== MATH: PSDA
  'M.PSDA.RATIO': {
    prereqs: [], soft: ['M.ALG.LIN1'], recoverability: 0.9, hours_to_fix: 3,
    bands: { easy: 'One-step unit conversion or a simple proportion.', medium: 'Rates with two quantities, multi-step conversions, unit rates in context.', hard: 'Multi-stage dimensional analysis (speed to feet per second), density-type problems, scale and similarity in word form.' },
    rule_card: card('M.PSDA.RATIO', 'Ratios, rates and units', [
      'Write units next to every number and make them cancel (dimensional analysis).',
      'A proportion pairs like with like: miles/hours = miles/hours.',
      'Convert in stages: hours to minutes, then minutes to seconds.',
      'Rate x time = amount. Rearrange for whichever is unknown.',
    ], { problem: '60 miles per hour is how many feet per minute? (5280 ft = 1 mile)', answer: '60 x 5280 / 60 = 5280 ft per minute' }, { code: 'UNIT-ERROR', text: 'Multiplying by 60 when the conversion needed dividing by 60.' }),
  },
  'M.PSDA.PCT': {
    prereqs: ['M.PSDA.RATIO'], soft: [], recoverability: 0.9, hours_to_fix: 3,
    bands: { easy: 'Find a percent of a number.', medium: 'Percent increase or decrease, find the original from the final.', hard: 'Successive changes, percent of a percent, compound growth, reverse percent in context.' },
    rule_card: card('M.PSDA.PCT', 'Percentages', [
      'Percent means "per hundred": 35% = 0.35.',
      'Increase by p%: multiply by (1 + p/100). Decrease: multiply by (1 - p/100).',
      'To find the ORIGINAL, divide the final by the multiplier. Do not "undo" the percent.',
      'Successive changes multiply; they do not add.',
    ], { problem: 'After a 20% discount a jacket costs $48. Original price?', answer: '48 / 0.80 = $60' }, { code: 'PERCENT-OF-VS-CHANGE', text: 'Adding 20% of $48 back (= $57.60). The 20% was taken from the original, not the sale price.' }),
  },
  'M.PSDA.ONEVAR': {
    prereqs: [], soft: [], recoverability: 0.88, hours_to_fix: 3,
    bands: { easy: 'Mean, median, mode, range of a short list.', medium: 'Read a frequency table or histogram; compare spread of two data sets.', hard: 'Effect of an outlier or an added value on mean, median and standard deviation; missing value for a target mean.' },
    rule_card: card('M.PSDA.ONEVAR', 'One-variable data', [
      'Mean = sum / count. Median = middle value of the SORTED list. Mode = most frequent.',
      'An outlier moves the mean a lot and the median a little.',
      'Standard deviation measures spread around the mean: more spread out = larger.',
      'Target mean: total needed = mean x count; subtract the total you have.',
    ], { problem: 'Mean of 4 numbers is 10. A fifth number makes the mean 12. What is it?', answer: '5 x 12 - 4 x 10 = 20' }, { code: 'IGNORED-CONSTRAINT', text: 'Taking the median of the unsorted list.' }),
  },
  'M.PSDA.TWOVAR': {
    prereqs: ['M.ALG.LIN2'], soft: ['M.PSDA.ONEVAR'], recoverability: 0.85, hours_to_fix: 4,
    bands: { easy: 'Read a point on a scatterplot or a value from the line of best fit.', medium: 'Predict from the model, interpret slope and intercept of the fit.', hard: 'Residuals, choosing a linear versus exponential model, what the model cannot say outside the data.' },
    rule_card: card('M.PSDA.TWOVAR', 'Two-variable data', [
      'The line of best fit is a model: use its equation to predict, but only inside the data range.',
      'Residual = actual value - predicted value. Above the line is positive.',
      'Slope in context: change in the y-quantity for each +1 in the x-quantity, with units.',
      'Curved scatter that grows by a constant ratio suggests an exponential, not a line.',
    ], { problem: 'Fit: y = 3x + 10. The point (4, 25) has what residual?', answer: 'Predicted 22; residual = 25 - 22 = 3' }, { code: 'MISREAD-GRAPH', text: 'Reading predicted minus actual and getting -3.' }),
  },
  'M.PSDA.PROB': {
    prereqs: ['M.PSDA.RATIO'], soft: ['M.PSDA.PCT'], recoverability: 0.88, hours_to_fix: 3,
    bands: { easy: 'Probability from a simple count.', medium: 'Complement, "or" and "and" with independent events.', hard: 'Conditional probability from a two-way table; the denominator is the GIVEN group.' },
    rule_card: card('M.PSDA.PROB', 'Probability', [
      'Probability = favourable / total, always between 0 and 1.',
      'Complement: P(not A) = 1 - P(A).',
      'Independent events: P(A and B) = P(A) x P(B).',
      'Conditional ("given that ..."): restrict to the given group first; that group is your denominator.',
    ], { problem: 'Of 40 students, 10 play chess and 6 of those play piano. P(piano | chess)?', answer: '6 / 10 = 0.6' }, { code: 'WRONG-VARIABLE', text: 'Dividing by all 40 students instead of the 10 chess players.' }),
  },
  'M.PSDA.INF': {
    prereqs: ['M.PSDA.ONEVAR'], soft: ['M.PSDA.PCT'], recoverability: 0.85, hours_to_fix: 2.5,
    bands: { easy: 'Say which population a sample result applies to.', medium: 'Read a margin of error as a range around a sample estimate.', hard: 'Whether a sample is random and large enough to generalize; effect of sample size on the margin.' },
    rule_card: card('M.PSDA.INF', 'Inference from samples', [
      'A result generalizes only to the population the sample was randomly drawn from.',
      'Estimate +/- margin of error gives the plausible range for the population value.',
      'A bigger random sample shrinks the margin of error.',
      'A biased (non-random) sample cannot be rescued by size.',
    ], { problem: '58% of a random sample favour a plan, margin of error 3%. Plausible range?', answer: '55% to 61%' }, { code: 'IGNORED-CONSTRAINT', text: 'Generalizing a survey of one school club to the whole city.' }),
  },
  'M.PSDA.CLAIMS': {
    prereqs: ['M.PSDA.INF'], soft: [], recoverability: 0.85, hours_to_fix: 2,
    bands: { easy: 'Spot a conclusion the data does not support.', medium: 'Correlation versus causation in a described study.', hard: 'Random assignment versus random selection and what each allows you to conclude.' },
    rule_card: card('M.PSDA.CLAIMS', 'Evaluating statistical claims', [
      'Random SELECTION lets you generalize to the population.',
      'Random ASSIGNMENT to groups lets you claim cause and effect.',
      'Without random assignment, two things moving together is only an association.',
      'Choose the answer that claims exactly as much as the study design allows.',
    ], { problem: 'Volunteers chose a diet and then lost weight. Can we say the diet caused it?', answer: 'No: no random assignment, so only an association.' }, { code: 'IGNORED-CONSTRAINT', text: 'Treating a volunteer sample as if it were randomly assigned.' }),
  },
  // ===================================================== MATH: GEOMETRY / TRIG
  'M.GT.AREAVOL': {
    prereqs: [], soft: ['M.PSDA.RATIO'], recoverability: 0.9, hours_to_fix: 3,
    bands: { easy: 'Area or volume from a given formula and dimensions.', medium: 'Composite figures, work backwards from a volume to a dimension.', hard: 'Scale factor effects (lengths x k, area x k^2, volume x k^3), units that need converting.' },
    rule_card: card('M.GT.AREAVOL', 'Area and volume', [
      'Rectangle lw, triangle bh/2, circle pi r^2. Box lwh, cylinder pi r^2 h, sphere (4/3) pi r^3.',
      'Composite shapes: split into pieces, add (or subtract a hole).',
      'Scale lengths by k: areas scale by k^2, volumes by k^3.',
      'Check units before calculating; cubic units for volume.',
    ], { problem: 'A cylinder has r = 3 and h = 5. Volume?', answer: 'pi x 9 x 5 = 45 pi' }, { code: 'WRONG-FORMULA', text: 'Using 2 pi r h (a side area idea) instead of pi r^2 h.' }),
  },
  'M.GT.LINES': {
    prereqs: [], soft: [], recoverability: 0.88, hours_to_fix: 4,
    bands: { easy: 'Angles on a line, in a triangle, vertical angles.', medium: 'Parallel lines cut by a transversal, isosceles triangles.', hard: 'Similar triangles with a missing side, triangle inequality, angle chasing across several steps.' },
    rule_card: card('M.GT.LINES', 'Lines, angles and triangles', [
      'Angles on a straight line add to 180. Angles in a triangle add to 180.',
      'Parallel lines: alternate and corresponding angles are equal.',
      'Similar triangles have equal angles and proportional sides: match corresponding sides.',
      'Triangle inequality: any side is shorter than the sum of the other two.',
    ], { problem: 'Two similar triangles: sides 3 and 5 correspond. A side of 6 in the small one matches?', answer: '6 x 5/3 = 10' }, { code: 'WRONG-VARIABLE', text: 'Matching the wrong pair of sides (not corresponding).' }),
  },
  'M.GT.TRIG': {
    prereqs: ['M.GT.LINES'], soft: [], recoverability: 0.88, hours_to_fix: 4,
    bands: { easy: 'Pythagorean theorem, special right triangles.', medium: 'SOH-CAH-TOA with a given angle or two sides.', hard: 'Radians and degrees, sin(x) = cos(90 - x), unit-circle values, trig in a similar-triangle setup.' },
    rule_card: card('M.GT.TRIG', 'Right triangles and trigonometry', [
      'Pythagoras: a^2 + b^2 = c^2, c is the hypotenuse. Common triples: 3-4-5, 5-12-13.',
      'sin = opposite / hypotenuse, cos = adjacent / hypotenuse, tan = opposite / adjacent.',
      'sin(x) = cos(90 - x): complementary angles swap sine and cosine.',
      'pi radians = 180 degrees: multiply degrees by pi/180.',
    ], { problem: 'Right triangle, hypotenuse 10, angle 30 degrees. Opposite side?', answer: '10 x sin(30) = 5' }, { code: 'WRONG-FORMULA', text: 'Using cos (adjacent) when the side asked for is opposite the angle.' }),
  },
  'M.GT.CIRCLE': {
    prereqs: ['M.GT.AREAVOL', 'M.GT.LINES'], soft: ['M.ADV.EQUIV'], recoverability: 0.85, hours_to_fix: 4,
    bands: { easy: 'Circumference and area from a radius.', medium: 'Arc length and sector area as a fraction of the circle.', hard: 'Central versus inscribed angles, tangent and chord facts, equation of a circle (complete the square).' },
    rule_card: card('M.GT.CIRCLE', 'Circles', [
      'C = 2 pi r, A = pi r^2. The diameter is 2r.',
      'A sector or arc is a fraction (angle / 360) of the whole circle.',
      'An inscribed angle is half the central angle on the same arc.',
      'Circle equation (x - h)^2 + (y - k)^2 = r^2: centre (h, k), radius r (take the square root).',
    ], { problem: 'Arc of a circle r = 6 with central angle 60 degrees: length?', answer: '(60/360) x 2 pi x 6 = 2 pi' }, { code: 'DOUBLE-HALF', text: 'Using the diameter as the radius, or forgetting the inscribed angle is HALF the central angle.' }),
  },
  // ===================================================== READING AND WRITING
  'RW.II.CID': {
    prereqs: [], soft: [], recoverability: 0.65, hours_to_fix: 5,
    bands: { easy: 'The main idea is stated in one sentence.', medium: 'The main idea combines two sentences; one distractor is a true detail.', hard: 'The idea is built from a contrast or implied in a literary excerpt; every distractor is tempting.' },
    rule_card: card('RW.II.CID', 'Central ideas and details', [
      'Ask: what is the ONE point of the whole passage, not of one sentence?',
      'Look for the turn: "but", "however", "yet" usually mark the real claim.',
      'Wrong answers are usually too narrow (a detail), too broad, or true but off-topic.',
      'Prove your choice with a phrase from the text before you lock it in.',
    ], { problem: 'Passage: researchers long assumed X, but new data show Y. Main idea?', answer: 'The one that states Y as a correction of X.' }, { code: 'DETAIL-AS-MAIN-IDEA', text: 'Choosing an interesting example instead of the overall point.' }),
  },
  'RW.II.CEV.T': {
    prereqs: ['RW.II.CID'], soft: ['RW.II.INF'], recoverability: 0.65, hours_to_fix: 6,
    bands: { easy: 'The claim and the support match on one obvious variable.', medium: 'Choose the finding that strengthens or weakens a claim.', hard: 'The claim has two parts or a condition; distractors support half of it or the opposite group.' },
    rule_card: card('RW.II.CEV.T', 'Command of evidence: textual', [
      'First restate the claim in your own words, including every condition in it.',
      'The right choice matches EVERY part of the claim, not just the topic.',
      'To weaken: pick the evidence that contradicts the link, not just something different.',
      'Discard choices that are true but about a different group or variable.',
    ], { problem: 'Claim: birds in cities sing at higher pitch. Which finding supports it?', answer: 'Urban birds sing at higher pitch than rural birds of the same species.' }, { code: 'PARTIAL', text: 'Evidence about noise levels that never mentions pitch.' }),
  },
  'RW.II.CEV.Q': {
    prereqs: ['RW.II.CID'], soft: ['M.PSDA.ONEVAR'], recoverability: 0.7, hours_to_fix: 4,
    bands: { easy: 'Read one value off the table or graph.', medium: 'Compare two categories on one variable.', hard: 'Compare across two variables; a distractor states a true data fact that does not address the claim.' },
    rule_card: card('RW.II.CEV.Q', 'Command of evidence: quantitative', [
      'Read the title, axis labels and units first.',
      'Re-read the sentence to complete: what exact comparison does it need?',
      'The correct choice is both TRUE in the data and RELEVANT to the claim.',
      'Check qualifiers: "most", "only", "increased" against the actual numbers.',
    ], { problem: 'Table of plant growth by light level. Claim: more light, more growth.', answer: 'The choice that cites growth rising at each higher light level.' }, { code: 'TRUE-BUT-NOT-ANSWER', text: 'A true number from the table that does not speak to the claim.' }),
  },
  'RW.II.INF': {
    prereqs: ['RW.II.CID'], soft: [], recoverability: 0.65, hours_to_fix: 6,
    bands: { easy: 'The conclusion follows from one stated fact.', medium: 'Combine two statements to reach the conclusion.', hard: 'Choose the only claim that MUST be true; others are plausible but extreme or unsupported.' },
    rule_card: card('RW.II.INF', 'Inferences', [
      'The answer must follow from the text. If you need outside knowledge, it is wrong.',
      'Prefer the modest choice: "some", "may", "often" beat "all", "always", "never".',
      'Signal words: "therefore", "thus", "which suggests" point to the conclusion slot.',
      'Test each choice by asking: could the text be true and this choice false?',
    ], { problem: 'All of the surveyed cafes use local beans. A cafe on the survey is Mila. What follows?', answer: 'Mila uses local beans.' }, { code: 'TOO-EXTREME', text: 'Choosing "all cafes everywhere" when only the surveyed ones were covered.' }),
  },
  'RW.CS.WIC': {
    prereqs: [], soft: [], recoverability: 0.6, hours_to_fix: 10,
    bands: { easy: 'Everyday vocabulary with one clear context clue.', medium: 'Multi-meaning words and precise degree (slightly vs greatly).', hard: 'Rare senses of common words and abstract academic vocabulary; contrast clues.' },
    rule_card: card('RW.CS.WIC', 'Words in context', [
      'Cover the options and predict a word from the context first.',
      'Find the clue: a contrast ("although"), an example, or a definition nearby.',
      'Test each option in the sentence; wrong ones are often a close meaning with the wrong degree or tone.',
      'Build your word list: every unknown word from a miss goes on the deck.',
    ], { problem: 'The results were ____, so the team repeated the test. (doubtful / conclusive)', answer: 'The repeat implies the first result was doubtful or inconclusive.' }, { code: 'NEARBY-MEANING', text: 'A word that is positive in tone when the sentence is negative.' }),
  },
  'RW.CS.TSP': {
    prereqs: ['RW.II.CID'], soft: [], recoverability: 0.65, hours_to_fix: 5,
    bands: { easy: 'Say what one sentence does (gives an example, states a claim).', medium: 'Describe the structure of the whole text.', hard: 'Purpose plus attitude; the order of ideas as a sequence (problem, then response, then result).' },
    rule_card: card('RW.CS.TSP', 'Text structure and purpose', [
      'Ask HOW the text is built, not what it says: claim, example, counterpoint, conclusion.',
      'Use verbs: introduces, challenges, illustrates, concedes, resolves.',
      'A function question: reread the sentence before and after it.',
      'Wrong answers describe content that is in the text but not the function being asked.',
    ], { problem: 'Why does the author mention the 1990 study?', answer: 'To give evidence for the claim made in the previous sentence.' }, { code: 'OUT-OF-SCOPE', text: 'A purpose the passage never serves, such as "to criticise the methodology".' }),
  },
  'RW.CS.CTC': {
    prereqs: ['RW.CS.TSP'], soft: ['RW.II.CID'], recoverability: 0.65, hours_to_fix: 5,
    bands: { easy: 'One text clearly agrees or disagrees with the other.', medium: 'Text 2 qualifies or extends Text 1.', hard: 'Predict how the author of Text 2 would respond to a specific claim of Text 1.' },
    rule_card: card('RW.CS.CTC', 'Cross-text connections', [
      'Summarize Text 1 in one line, then Text 2 in one line.',
      'Name the relationship: agrees, disagrees, qualifies, offers an example, shifts the focus.',
      'Answer from Text 2\'s point of view when asked how its author would respond.',
      'Beware of choices that fit only one of the two texts.',
    ], { problem: 'Text 1 praises remote work. Text 2 notes it weakens mentoring. Relationship?', answer: 'Text 2 qualifies Text 1 by naming a cost.' }, { code: 'OPPOSITE', text: 'Saying Text 2 rejects remote work entirely when it only adds a caution.' }),
  },
  'RW.SEC.BND': {
    prereqs: [], soft: ['RW.SEC.FSS'], recoverability: 0.88, hours_to_fix: 5,
    bands: { easy: 'A comma or period between two clearly complete sentences.', medium: 'Semicolon, colon and FANBOYS comma; nonessential phrases.', hard: 'Dash pairs, appositives, comma versus none after long subjects; fragment versus clause traps.' },
    rule_card: card('RW.SEC.BND', 'Boundaries (punctuation)', [
      'Complete sentence + complete sentence needs a period, a semicolon, or a comma with FANBOYS (for, and, nor, but, or, yet, so).',
      'A comma alone between two sentences is a comma splice.',
      'A colon follows a complete sentence and introduces an explanation or list.',
      'Nonessential info is wrapped in a PAIR (commas or dashes); never one comma between a subject and its verb.',
    ], { problem: 'The museum opened early, ___ the line was already long.', answer: 'Use "; " or ", and": two complete sentences.' }, { code: 'GRAMMAR-LOOKS-RIGHT', text: 'A single comma between two full sentences sounds natural but is a splice.' }),
  },
  'RW.SEC.FSS': {
    prereqs: [], soft: [], recoverability: 0.85, hours_to_fix: 8,
    bands: { easy: 'Simple subject-verb agreement and verb tense.', medium: 'Pronoun agreement, plural versus possessive, intervening phrases.', hard: 'Modifier placement, parallelism, comparisons, inverted sentences, relative pronouns.' },
    rule_card: card('RW.SEC.FSS', 'Form, structure and sense', [
      'Find the real subject (ignore phrases between it and the verb) and match the verb to it.',
      'Pronouns must match their noun in number and use the right case (who / whom, I / me).',
      'A modifier belongs next to the thing it describes; a dangling opener needs the right subject right after the comma.',
      'Items in a list must have the same grammatical form (parallelism).',
    ], { problem: 'The box of old photographs ___ on the shelf.', answer: '"box" is the subject: "is"' }, { code: 'GRAMMAR-LOOKS-RIGHT', text: 'Matching the verb to "photographs", the noun closest to it.' }),
  },
  'RW.EOI.RS': {
    prereqs: ['RW.II.CID'], soft: ['RW.EOI.TRN'], recoverability: 0.7, hours_to_fix: 4,
    bands: { easy: 'Pick the note that states the goal directly.', medium: 'Select details for a specific audience.', hard: 'Combine two notes to compare or contrast; emphasis on a specific feature.' },
    rule_card: card('RW.EOI.RS', 'Rhetorical synthesis', [
      'Read the GOAL in the question first (introduce, compare, emphasize, explain).',
      'Then scan the notes only for what serves that goal.',
      'The right answer uses the needed facts and nothing off-goal.',
      'True and in the notes is not enough: it must do the job asked.',
    ], { problem: 'Goal: emphasize the project\'s cost saving. Which sentence?', answer: 'The one that states the saving amount, not the schedule.' }, { code: 'TRUE-BUT-NOT-ANSWER', text: 'A correct fact from the notes that serves a different goal.' }),
  },
  'RW.EOI.TRN': {
    prereqs: [], soft: ['RW.II.CID'], recoverability: 0.85, hours_to_fix: 3,
    bands: { easy: 'A clear contrast or addition between two short sentences.', medium: 'Cause and effect, example, sequence.', hard: 'Concession, restatement, emphasis when the relationship is implied.' },
    rule_card: card('RW.EOI.TRN', 'Transitions', [
      'Cover the transition. Name the relationship between the two sentences in one word.',
      'Contrast: however, yet, in contrast. Addition: moreover, also. Cause: therefore, as a result. Example: for instance.',
      'Choose the transition that matches the relationship, not the one that sounds smartest.',
      'Remember direction: "Similarly" needs two ideas that point the same way.',
    ], { problem: 'Sales fell in June. ___, the team launched a new ad.', answer: 'Therefore / As a result (cause and effect).' }, { code: 'WRONG-RELATIONSHIP', text: '"However" when the second sentence is a reaction, not a contrast.' }),
  },
};

// Optional: facts about the whole graph that the validator enforces.
export const EXPECT = { skills: 30, rule_card_lines: [3, 6] };
