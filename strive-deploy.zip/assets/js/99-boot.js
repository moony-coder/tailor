/* Boot: runs after every other script has loaded, so all feature patches are in place.
   The cinematic intro plays the first time only. #skip / reduced-motion / Esc bypass it.
   Returning visits fade in (Motion.boot) instead of popping; the intro path keeps the app
   fully visible underneath so the iris reveal still works. */
(function(){
  const e = E(), seen = !!e.introSeen;
  /* come back to the page you were on (reload, or returning from Terms/Privacy) */
  try{ const v = sessionStorage.getItem('strive_view'); if(v && v !== 'dash' && typeof go === 'function') go(v); }catch(err){}
  if(matchMedia('(prefers-reduced-motion:reduce)').matches || location.hash==='#skip' || seen){
    finish();
    if(window.Motion) Motion.boot(); else document.documentElement.classList.remove('booting');
  } else {
    document.documentElement.classList.remove('booting');
    scrollTo(0,0); e.introSeen = Date.now(); saveState();
  }
  document.addEventListener('keydown', ev => {
    if(ev.key==='Escape' && !document.body.classList.contains('done')){
      const i = $('#intro'); if(i && i._skip) i._skip(); else finish();
    }
  });
})();
