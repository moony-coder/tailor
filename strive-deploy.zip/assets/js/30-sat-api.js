/* ============================================================
   TAILORED PRACTICE (audit engine). The engine runs inside the page (assets/engine/), so the site is fully static:
   no server, no sign-in, no teacher. Student data is kept in this browser. Settings live in assets/js/config.js:
     SAT_AUDIT_ENABLED  true/false   switch the whole feature off
     groqApiKey         'gsk_...'    Groq key used to word the audit (without it the audit uses template wording)
   ============================================================ */
(function(){
  'use strict';
  const CFG = window.STRIVE_CONFIG || {};
  const K_ACTIVE = 'strive_sat_active_v1';
  const ls = {
    get(k){ try{ return JSON.parse(localStorage.getItem(k) || 'null'); }catch(e){ return null; } },
    set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} },
    del(k){ try{ localStorage.removeItem(k); }catch(e){} }
  };

  class ApiError extends Error {
    constructor(status, code, message, details){ super(message); this.name = 'ApiError'; this.status = status; this.code = code; this.details = details; }
  }

  const A = {
    base: '',
    enabled: CFG.SAT_AUDIT_ENABLED !== false,
    online: false,
    health: null,
    ApiError,
    ls, K_ACTIVE,
    url(p){ return new URL(String(p).replace(/^\//, ''), document.baseURI).href; },
    isAdmin(){ return false; },
    session(){ const n = (window.state && state.profile && !state.profile.demo && state.profile.name) || 'Student'; return { profile: { id: 'me', display_name: String(n), role: 'student' } }; },
    active(){ return ls.get(K_ACTIVE); },
    setActive(v){ if(v) ls.set(K_ACTIVE, v); else ls.del(K_ACTIVE); },
    signOut(){ ls.del(K_ACTIVE); }
  };

  let engine = null;
  function loadEngine(){
    return engine || (engine = (async () => {
      const base = new URL('assets/engine/', document.baseURI).href;
      const mod = await import(base + 'local.mjs');
      let name = (window.state && state.profile && !state.profile.demo && state.profile.name) ? String(state.profile.name).replace(/[<>]/g, '').slice(0, 40) : '';
      await mod.boot({ groqApiKey: String(CFG.groqApiKey || '').trim(), dataUrl: base + 'data.json', name: name || 'Student' });
      return mod;
    })().catch(e => { engine = null; throw e; }));
  }
  /** One call into the in-page engine. Same shape as the old HTTP API: resolves the body, throws ApiError on 4xx/5xx. */
  async function raw(method, path, body){
    let m;
    try{ m = await loadEngine(); }
    catch(e){ throw new ApiError(0, 'engine', 'Tailored practice could not start in this browser. Reload the page and try again.'); }
    const r = await m.call(method, path, body === undefined ? null : body);
    if(r.status >= 400){
      const er = (r.body && r.body.error) || {};
      throw new ApiError(r.status, er.code || 'http_' + r.status, er.message || ('Request failed (' + r.status + ').'), er.details);
    }
    return r.body;
  }
  /** Calls an API route; straight into the in-page engine (no sign-in). */
  A.call = function(method, path, body, o){ return raw(method, path, body); };
  A.get = (p, o) => A.call('GET', p, undefined, o);
  A.post = (p, b, o) => A.call('POST', p, b === undefined ? {} : b, o);
  A.patch = (p, b, o) => A.call('PATCH', p, b, o);

  /* ---------- profile: one student per browser, no sign-in ---------- */
  A.ensureProfile = async function(){ await loadEngine(); return { id: 'me', display_name: (window.state && state.profile && state.profile.name) || 'Student', role: 'student' }; };

  /* ---------- feature flag + boot ---------- */
  A.init = async function(){
    if(!A.enabled) return false;
    try{
      const h = await raw('GET', '/api/health');
      A.health = h;
      A.online = !!(h && h.ok);
    }catch(e){ A.online = false; }
    document.documentElement.classList.toggle('sat-on', A.online);
    document.querySelectorAll('.sat-nav').forEach(el => el.classList.toggle('hidden', !A.online));
    document.dispatchEvent(new CustomEvent('sat:ready', { detail: { online: A.online } }));
    return A.online;
  };

  window.SATAPI = A;
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => A.init());
  else A.init();
})();
