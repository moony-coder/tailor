// Behaviour and pacing detection. PURE. Works on attempt rows + module summaries.
import { groupBy, round, mean } from '../util/misc.mjs';

/** Late-module decay: accuracy in last 25% vs first 75% for each module with enough telemetry. */
export function lateDecay(attempts, cfg) {
  const t = cfg.telemetry, minQ = cfg.behaviors.late_min_questions;
  const mods = groupBy(attempts.filter((a) => a.module_id && a.module_size && a.position), (a) => `${a.session_id}|${a.module_id}`);
  const rows = [];
  for (const [key, list] of mods) {
    const cut = list[0].module_size * (1 - t.rushed_last_fraction);
    const late = list.filter((a) => a.position > cut), early = list.filter((a) => a.position <= cut);
    if (late.length < minQ || !early.length) continue;
    const accL = mean(late.map((a) => a.is_correct)), accE = mean(early.map((a) => a.is_correct));
    rows.push({ key, section: list[0].section, module_index: list[0].module_index, acc_late: round(accL), acc_early: round(accE), decay: accE - accL >= t.late_decay_points });
  }
  return { modules: rows, flagged: rows.some((r) => r.decay), n_modules: rows.length };
}

/** Pacing per module from module summaries ({unanswered, size, used_fraction, section, module_index}). */
export function pacing(moduleSummaries, attempts, cfg) {
  const t = cfg.telemetry;
  const overspend = moduleSummaries.filter((m) => m.used_fraction >= t.overspend_time_used && m.size && (m.unanswered / m.size) > t.overspend_unanswered);
  const withT = attempts.filter((a) => a.telemetry && a.total_ms != null && a.est_time_sec > 0);
  const ratio = withT.length ? withT.reduce((s, a) => s + a.total_ms, 0) / withT.reduce((s, a) => s + a.est_time_sec * 1000, 0) : null;
  const byModule = {};
  for (const m of moduleSummaries) { if (m.unanswered) byModule[`${m.section}_m${m.module_index}`] = (byModule[`${m.section}_m${m.module_index}`] ?? 0) + m.unanswered; }
  // rushing: the last quarter of a module answered much faster than the first three quarters
  const rushedMods = [];
  for (const [key, list] of groupBy(withT.filter((a) => a.module_size), (a) => `${a.session_id}|${a.module_id}`)) {
    const cut = list[0].module_size * (1 - t.rushed_last_fraction);
    const late = list.filter((a) => a.position > cut), early = list.filter((a) => a.position <= cut);
    if (late.length >= cfg.behaviors.late_min_questions && early.length) {
      const rl = mean(late.map((a) => a.total_ms / (a.est_time_sec * 1000))), re = mean(early.map((a) => a.total_ms / (a.est_time_sec * 1000)));
      if (rl < t.rushed_ratio && re > rl * 1.5) rushedMods.push({ section: list[0].section, module_index: list[0].module_index, late_ratio: round(rl), early_ratio: round(re) });
    }
  }
  return { avg_time_vs_target: ratio == null ? null : round(ratio), overspend_modules: overspend.length, unanswered_by_module: byModule, rushed_modules: rushedMods, rushes_late: rushedMods.length > 0 };
}

/** Behaviour counts. Everything is derived from attempts, so it works for any window. */
export function behaviorStats(attempts, cfg) {
  const tel = attempts.filter((a) => a.telemetry);
  const changed = tel.filter((a) => a.answer_changes > 0);
  const r2w = attempts.filter((a) => a.changed_right_to_wrong).length;
  const wrong = attempts.filter((a) => !a.is_correct);
  const guessLike = attempts.filter((a) => a.root_cause === 'GUESS').length;
  return {
    n_attempts: attempts.length, n_telemetry: tel.length,
    changed_right_to_wrong: r2w, changed_any: changed.length, change_rate: tel.length ? round(changed.length / tel.length) : null,
    guess_rate: wrong.length ? round(guessLike / wrong.length) : 0,
    careless_rate: wrong.length ? round(wrong.filter((a) => a.root_cause === 'CARELESS').length / wrong.length) : 0,
  };
}

/** Top-2 behaviours to show. Each = {code, label, evidence, severity}. Only reported with enough evidence. */
export function topBehaviors(attempts, mods, cfg) {
  const min = cfg.behaviors.min_attempted_count ?? cfg.behaviors.min_attributed_count;
  const b = behaviorStats(attempts, cfg), p = pacing(mods, attempts, cfg), ld = lateDecay(attempts, cfg);
  const wrong = attempts.filter((a) => !a.is_correct);
  const out = [];
  const careless = wrong.filter((a) => a.root_cause === 'CARELESS').length;
  if (careless >= min) out.push({ code: 'CARELESS', label: 'Careless execution errors', count: careless, severity: careless / Math.max(1, wrong.length) });
  const timing = wrong.filter((a) => a.root_cause === 'TIMING').length;
  if (timing >= min || p.overspend_modules > 0 || p.rushes_late || ld.flagged) out.push({ code: 'PACING', label: 'Pacing (running short or rushing late)', count: timing + p.overspend_modules + (ld.flagged ? 1 : 0), severity: Math.min(1, (timing + p.overspend_modules * 2) / Math.max(1, wrong.length)) });
  if (b.changed_right_to_wrong >= min) out.push({ code: 'OVERTHINK', label: 'Changing right answers to wrong', count: b.changed_right_to_wrong, severity: b.changed_right_to_wrong / Math.max(1, wrong.length) });
  const guess = wrong.filter((a) => a.root_cause === 'GUESS').length;
  if (guess >= min) out.push({ code: 'GUESSING', label: 'Fast guessing', count: guess, severity: guess / Math.max(1, wrong.length) });
  out.sort((x, y) => y.severity - x.severity);
  return out.slice(0, cfg.levers.top_behaviors);
}
