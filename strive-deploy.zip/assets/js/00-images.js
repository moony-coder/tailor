const WING="assets/img/mark.png", ERR="assets/img/err.webp";
/* Mascot system: dedicated eagle pose for every mood and event */
const IMG={
 "m_wink": "assets/img/m_welcome.webp",
 "m_welcome": "assets/img/m_welcome.webp",
 "m_thumbs": "assets/img/m_thumbs.webp",
 "m_cheer": "assets/img/m_cheer.webp",
 "m_trophy": "assets/img/m_trophy.webp",
 "m_think": "assets/img/m_think.webp",
 "m_study": "assets/img/m_study.webp",
 "m_listen": "assets/img/m_listen.webp",
 "m_confused": "assets/img/m_confused.webp",
 "m_headache": "assets/img/m_headache.webp",
 "m_cry": "assets/img/m_headache.webp",
 "avatar": "assets/img/avatar.webp",
 "logo": "assets/img/logo.png",
 "hero": "assets/img/hero.webp",
 "mark": WING
};
