// 7-day study plan. PURE: same inputs -> same plan. Code, not LLM.
// input: { levers, behaviors, causeMix, mastery(Map), lessons[], tax, cfg, settings:{minutes_per_day,horizon_days,days_until_test}, vocabulary_terms[], bankCount(skill)->n, lessonProgress:Set<id> }
import { keyOf } from './mastery.mjs';

const LESSON_BY_CAUSE = { CARELESS: ['S-03'], TIMING: ['S-01', 'S-02'], OVERTHINK: ['S-04'], STRATEGY: ['S-06'], VOCAB: ['V-01', 'V-02', 'V-04'], TOOL: ['D-01', 'D-04'] };
const kindMinutes = (cfg, n) => Math.ceil(n * 75 / 60 * cfg.plan.seconds_per_question_overhead);

export function lessonsFor(lessons, { skill_id, cause, trapCodes = [] }) {
  const out = [];
  const by = (f) => lessons.filter(f);
  if (cause === 'CONTENT_GAP' || cause === 'COMPREHENSION' || !cause) {
    out.push(...by((l) => l.skill_id === skill_id && l.kind === 'concept').slice(0, 1), ...by((l) => l.skill_id === skill_id && l.kind === 'examples').slice(0, 1));
  }
  if (cause === 'STRATEGY') out.push(...by((l) => l.skill_id === skill_id && l.kind === 'traps').slice(0, 1));
  if (cause === 'VOCAB') out.push(...by((l) => l.kind === 'vocab').slice(0, 2));
  for (const id of LESSON_BY_CAUSE[cause] ?? []) { const l = lessons.find((x) => x.id === id); if (l && !out.includes(l)) out.push(l); }
  for (const t of trapCodes) { const f = lessons.find((l) => l.trap_code === t && l.kind === 'fixit'); if (f && !out.includes(f)) out.push(f); }
  return [...new Set(out)];
}

export function buildPlan(inp) {
  const { levers, behaviors = [], lessons, cfg, mastery, bankCount, lessonProgress = new Set(), vocabulary_terms = [] } = inp;
  const domainCount = inp.domainBankCount ?? (() => 0);
  const P = cfg.plan, horizon = Math.min(inp.settings?.horizon_days ?? P.horizon_days, inp.settings?.days_until_test ?? 99);
  const perDay = inp.settings?.minutes_per_day ?? P.minutes_per_day;
  const days = Array.from({ length: horizon }, (_, i) => ({ day_index: i + 1, items: [], used: 0 }));
  const notes = [];
  const place = (item, from = 1) => {
    for (let d = from - 1; d < horizon; d++) { if (days[d].used + item.minutes <= perDay || days[d].items.length === 0) { days[d].items.push(item); days[d].used += item.minutes; return d + 1; } }
    return null;   // does not fit in the horizon
  };
  const skillOfFocus = [];

  // sequence: each lever becomes a chain. Lever i starts on day i+1 so skills interleave across days.
  levers.slice(0, cfg.levers.top_levers).forEach((lv, i) => {
    const cause = lv.main_cause, p = mastery.get(keyOf(lv.skill_id))?.p ?? lv.p ?? 0.5;
    const start = i + 1 <= horizon ? i + 1 : 1;
    let day = start;
    const isDomain = lv.level === 'domain';
    let lessonList = isDomain
      ? [...(cause === 'CONTENT_GAP' || cause === 'COMPREHENSION' ? lessons.filter((l) => l.skill_id?.startsWith(lv.skill_id + '.') && l.kind === 'concept').slice(0, 1) : []), ...lessonsFor(lessons, { skill_id: null, cause, trapCodes: lv.traps?.map((t) => t.code) })]
      : lessonsFor(lessons, { skill_id: lv.skill_id, cause, trapCodes: lv.traps?.map((t) => t.code) });
    lessonList = [...new Set(lessonList)].filter((l) => P.include_unrecorded_lessons || l.video_ref);
    for (const l of lessonList) {
      if (lessonProgress.has(l.id)) continue;
      const d = place({ kind: 'lesson', ref_id: l.id, label: l.title, minutes: l.target_minutes ?? Math.ceil((l.duration_sec ?? 480) / 60), meta: { skill_id: lv.skill_id, status: l.status, recorded: !!l.video_ref } }, day);
      if (d) day = d;
    }
    // Thin bank: if the skill alone cannot fill a drill, drill its whole domain (said openly in the label + notes)
    const domain = lv.skill_id.split('.').slice(0, 2).join('.'), skillAvail = isDomain ? domainCount(domain) : bankCount(lv.skill_id);
    const scope = !isDomain && skillAvail >= 3 ? 'skill' : (domainCount(domain) >= 3 ? 'domain' : null);
    const available = scope === 'skill' ? skillAvail : scope === 'domain' ? domainCount(domain) : skillAvail;
    const size = Math.min(P.drill_size, available);
    if (scope) {
      const where = scope === 'domain' && !isDomain ? `${lv.name} (mixed ${domain} practice)` : lv.name;
      const timed = cause === 'TIMING';
      const label = cause === 'CARELESS' ? `${where}: ${size} questions with a 30-second answer check` : timed ? `${where}: ${size} timed questions` : cause === 'OVERTHINK' ? `${where}: ${size} questions, flag and return (no changing without evidence)` : `${where}: ${size}-question drill`;
      const d = place({ kind: 'drill', ref_id: lv.skill_id, label, minutes: kindMinutes(cfg, size), meta: { skill_id: lv.skill_id, scope, domain, size, p_mastery: Math.round(p * 100) / 100, start: p < 0.55 ? 'easy-medium' : 'medium-hard', timed, cause } }, day);
      if (scope === 'domain' && !isDomain) notes.push(`${lv.name}: only ${skillAvail} question(s) exist for this exact skill, so the drill uses the wider ${domain} domain.`);
      if (d) {
        day = d;
        const rs = Math.min(P.retest_size, available);
        P.retest_offsets_days.forEach((off, k) => place({ kind: 'retest', ref_id: lv.skill_id, label: `${lv.name}: ${rs}-question retest (day +${off})`, minutes: kindMinutes(cfg, rs), meta: { skill_id: lv.skill_id, scope, domain, size: rs, stage: k + 1, offset_days: off } }, d + off));
      }
    } else notes.push(`${lv.name}: the question bank has only ${skillAvail} question(s) for this skill and too few in its domain, so no drill was scheduled. Ask the teacher to add questions.`);
    if (cause === 'VOCAB' && vocabulary_terms.length) place({ kind: 'review', ref_id: 'vocab-list', label: `Review your word list (${vocabulary_terms.length} words)`, minutes: 10, meta: { words: vocabulary_terms.slice(0, 20) } }, start);
    skillOfFocus.push(lv.skill_id);
  });

  // behaviours -> short habit items
  behaviors.forEach((b, i) => {
    const map = { CARELESS: 'S-03', PACING: 'S-01', OVERTHINK: 'S-04', GUESSING: 'S-04' };
    const l = lessons.find((x) => x.id === map[b.code]);
    if (l && !lessonProgress.has(l.id) && !days.some((d) => d.items.some((it) => it.ref_id === l.id))) place({ kind: 'pacing', ref_id: l.id, label: l.title, minutes: l.target_minutes ?? 7, meta: { behavior: b.code } }, 1 + i);
  });

  // one mini-mock per week
  if (horizon >= P.mock_day_index) place({ kind: 'mock', ref_id: 'mini-mock', label: 'Mini-mock (one RW + one Math module), then review mistakes', minutes: P.mini_mock_minutes, meta: {} }, P.mock_day_index);

  // never more than N consecutive same-skill items in a day
  for (const d of days) d.items = limitRuns(d.items, P.max_consecutive_same_skill);
  const items = [];
  days.forEach((d) => d.items.forEach((it, k) => items.push({ ...it, day_index: d.day_index, sort_order: k })));
  return { horizon_days: horizon, minutes_per_day: perDay, items, notes, total_minutes: items.reduce((s, x) => s + x.minutes, 0) };
}

const skillKey = (it) => it.meta?.skill_id ?? it.ref_id;
export function limitRuns(items, maxRun) {
  const left = items.slice(), out = [];
  while (left.length) {
    let idx = 0;
    const run = out.length >= maxRun && out.slice(-maxRun).every((x) => skillKey(x) === skillKey(out[out.length - 1]));
    if (run) { const alt = left.findIndex((x) => skillKey(x) !== skillKey(out[out.length - 1])); if (alt >= 0) idx = alt; }
    out.push(left.splice(idx, 1)[0]);
  }
  return out;
}
