# TAILS ID scheme (frozen in E0)

One scheme, used everywhere. The engine's scheme is canonical; the blueprint's examples (`M.ALG.LIN.01`, `Q.…`, `TRAP.SIGN_FLIP`) are retired.
`src/ids.mjs` holds the regexes and `checkIds()`; `npm run bank:check` and `npm test` fail if any id in `data.json` breaks them.

| Thing | Format | Example | Notes |
|---|---|---|---|
| Domain | `<SEC>.<DOM>` | `M.ALG`, `RW.II` | SEC = `M` or `RW` |
| Skill | `<DOMAIN>.<SKILL>[.<SUB>]` | `M.ALG.LIN1`, `RW.II.CEV.T` | the unit the planner ranks |
| Micro-skill | `<SKILL>#<CODE>` | `M.ALG.LIN1#ISOLATE` | |
| Item (question) | `<SKILL with - for .>-<NNNN>` | `M-ALG-LIN1-0011` | skill is recoverable from the id; the 4-digit number is never reused |
| Lesson (per skill) | `L-<SKILL with ->-<C\|E\|T\|NN>` | `L-M-ALG-SYS-C`, `L-RW-CS-WIC-01` | **the `kind` field is authoritative**; never parse the kind from the id |
| Fix-it lesson | `F-<TRAP CODE>` | `F-SIGN-ERROR` | one per trap code that has a review video |
| General lesson | `<O\|S\|D\|T\|P\|V>-NN` | `O-01` | orientation, strategy, drills, tools, pacing, vocab |
| Trap code | `UPPER-KEBAB` | `SIGN-ERROR` | section is stored on the trap, not in the code |
| Vocabulary word | the word itself (lower case) | `ephemeral` | the planned `V.00231` form is not needed while words are keyed by spelling |
| Plan block / event | `seq` number inside the log | `seq: 41` | see `src/engine/eventlog.mjs` |

Why hyphens in items and lessons: the ids end up as file names, URL parts and video titles, and dots in the middle of those cause trouble. Skills keep dots because they are hierarchical and are used as keys in every table.

Mapping from the blueprint:

| Blueprint | Engine |
|---|---|
| `M.ALG.LIN.01` | `M.ALG.LIN1` |
| `Q.M.ALG.LIN.01.E.0042` | `M-ALG-LIN1-0042` (band is the `difficulty_band` field, not part of the id) |
| `L.M.ALG.LIN.01.v1` | `L-M-ALG-LIN1-C` |
| `TRAP.SIGN_FLIP` | `SIGN-ERROR` |
| `V.00231` | the word itself |

Rule for the filming list: each video title starts with the lesson id (`L-M-ALG-SYS-C Systems of two linear equations`). Lesson ids already in `data.json` do not change.
