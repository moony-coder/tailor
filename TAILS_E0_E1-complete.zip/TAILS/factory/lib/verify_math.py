#!/usr/bin/env python3
"""Math answer verifier for the TAILS question factory.

Reads a JSON array of math questions on stdin, writes a JSON array of results on stdout.
Each question's verification.code is run with sympy pre-imported (as sp) and must define:
  computed  -> the true answer (sympy expression or number)
  choices   -> (mcq4 only) {'A': expr, 'B': expr, ...} the values shown in the choices
Optional:
  trap_checks -> {'A': expr, ...} the value a student gets by making that choice's trap mistake.
                 Each must equal choices[key] - this proves the distractor is a real mistake, not noise.

Checks:
  1. code runs (2 s budget per item)
  2. mcq4: exactly ONE choice equals `computed`, and it is the key marked is_correct
     spr:  computed equals every accepted value
  3. trap_checks reproduce the distractors
  4. best effort: the displayed choice text parses to the same value as choices[key]
"""
import json, re, sys, signal

import sympy as sp
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor

TRANSFORMS = standard_transformations + (implicit_multiplication_application, convert_xor)
SAFE_BUILTINS = {k: __builtins__.__dict__[k] if hasattr(__builtins__, '__dict__') else __builtins__[k]
                 for k in ('abs', 'min', 'max', 'round', 'range', 'len', 'sum', 'int', 'float', 'list', 'dict', 'tuple', 'set', 'pow', 'sorted', 'enumerate', 'zip', 'map', 'any', 'all', 'str', 'True', 'False', 'None')
                 if (hasattr(__builtins__, '__dict__') and k in __builtins__.__dict__) or (isinstance(__builtins__, dict) and k in __builtins__)}


_ALLOWED_IMPORTS = {'math', 'sympy', 'fractions', 'statistics', 'itertools', 'decimal', 'functools'}
_real_import = __import__


def _safe_import(name, *a, **k):
    if name.split('.')[0] not in _ALLOWED_IMPORTS:
        raise ImportError(f'import of {name} is not allowed in verification code')
    return _real_import(name, *a, **k)


SAFE_BUILTINS['__import__'] = _safe_import


class Timeout(Exception):
    pass


def _alarm(*_):
    raise Timeout()


def same(a, b):
    try:
        a, b = sp.sympify(a), sp.sympify(b)
        if isinstance(a, (sp.Set, sp.Tuple)) or isinstance(b, (sp.Set, sp.Tuple)):
            return a == b
        d = sp.simplify(a - b)
        if d == 0:
            return True
        # numeric fallback (radicals, trig)
        fs = (a - b).free_symbols
        if not fs:
            return abs(complex(sp.N(a - b, 30))) < 1e-9
        import random
        for _ in range(6):
            sub = {s: sp.Rational(random.randint(-50, 50), random.randint(1, 9)) for s in fs}
            v = complex(sp.N((a - b).subs(sub), 30))
            if abs(v) > 1e-7:
                return False
        return True
    except Exception:
        return False


def text_value(text):
    """Turn a displayed choice like '$14x - 15$' or '\\frac{3}{4}' or '12.5%' into a sympy value (best effort)."""
    t = str(text).strip()
    if not t:
        return None
    t = t.replace('$', '').replace('\\left', '').replace('\\right', '').replace('\\cdot', '*').replace('\\times', '*')
    t = t.replace('−', '-').replace('–', '-').replace('\\pi', 'pi').replace('π', 'pi').replace('°', '')
    t = re.sub(r'\\d?frac\{([^{}]+)\}\{([^{}]+)\}', r'((\1)/(\2))', t)
    t = re.sub(r'\\sqrt\{([^{}]+)\}', r'sqrt(\1)', t)
    t = re.sub(r'√\(?([0-9a-z]+)\)?', r'sqrt(\1)', t)
    t = t.replace('{', '(').replace('}', ')').replace('\\', '')
    t = t.replace(',', '') if re.fullmatch(r'[-\d,\.]+', t) else t
    pct = t.endswith('%')
    t = t.rstrip('%')
    if re.search(r'[a-wyz]{3,}', t.replace('sqrt', '').replace('pi', '')):
        return None  # prose answer, cannot parse
    if '=' in t or '<' in t or '>' in t:
        return None
    try:
        v = parse_expr(t, transformations=TRANSFORMS, local_dict={'x': sp.Symbol('x'), 'y': sp.Symbol('y'), 'a': sp.Symbol('a'), 'b': sp.Symbol('b'), 'k': sp.Symbol('k'), 't': sp.Symbol('t'), 'n': sp.Symbol('n')})
        return v / 100 if pct and False else v
    except Exception:
        return None


def _rounded_match(text, value):
    """Displayed decimal like '$87.97$' is the value rounded to the shown number of places (money, measurements)."""
    t = str(text).replace('$', '').replace('\\', '').replace(',', '').replace('%', '').strip()
    if not re.fullmatch(r'-?\d+\.\d{1,3}', t):
        return False
    places = len(t.split('.')[1])
    try:
        return abs(float(t) - float(sp.N(value, 20))) <= 0.5 * 10 ** (-places) + 1e-12
    except Exception:
        return False


def _grid_ok(a, computed):
    """Digital SAT grid-in: a non-terminating decimal must fill the space (5 chars positive, 6 negative), truncated or rounded."""
    if '.' not in a:
        return False
    full = 6 if a.startswith('-') else 5
    if len(a) < full:
        return False
    places = len(a.split('.')[1])
    try:
        return abs(float(a) - float(sp.N(computed, 20))) < 10 ** (-places)
    except Exception:
        return False


def verify(q):
    res = {'id': q.get('id'), 'ok': False, 'errors': [], 'notes': []}
    code = (q.get('verification') or {}).get('code')
    if not code:
        res['errors'].append('no verification.code')
        return res
    ns = {'sp': sp, 'sympy': sp, 'Rational': sp.Rational, 'sqrt': sp.sqrt, 'pi': sp.pi, 'Symbol': sp.Symbol, 'symbols': sp.symbols,
          'solve': sp.solve, 'expand': sp.expand, 'factor': sp.factor, 'simplify': sp.simplify, 'S': sp.S, 'Eq': sp.Eq,
          'sin': sp.sin, 'cos': sp.cos, 'tan': sp.tan, 'N': sp.N, 'nsimplify': sp.nsimplify, 'math': __import__('math'),
          '__builtins__': SAFE_BUILTINS}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(3)
    try:
        exec(code, ns)
    except Timeout:
        res['errors'].append('verification.code timed out')
        return res
    except Exception as e:
        res['errors'].append(f'verification.code crashed: {type(e).__name__}: {e}')
        return res
    finally:
        signal.alarm(0)
    if 'computed' not in ns and 'ANSWER' in ns:
        ns['computed'] = ns['ANSWER']
    if 'computed' not in ns:
        res['errors'].append('code does not define computed')
        return res
    computed = ns['computed']
    res['computed'] = str(computed)

    if q.get('format') == 'spr':
        acc = (q.get('spr') or {}).get('accepted') or []
        if not acc:
            res['errors'].append('spr has no accepted values')
        for a in acc:
            try:
                v = sp.nsimplify(str(a).replace(',', ''), rational=True)
            except Exception:
                res['errors'].append(f'accepted value {a} not numeric'); continue
            if not (same(v, computed) or _grid_ok(str(a), computed)):
                res['errors'].append(f'accepted {a} != computed {computed}')
    else:
        choices = ns.get('choices')
        if not isinstance(choices, dict) or sorted(choices) != ['A', 'B', 'C', 'D']:
            res['errors'].append("mcq4 code must define choices = {'A':..,'B':..,'C':..,'D':..}")
            return res
        matches = [k for k, v in choices.items() if same(v, computed)]
        marked = [c['key'] for c in q.get('choices', []) if c.get('is_correct')]
        if len(matches) != 1:
            res['errors'].append(f'{len(matches)} choices equal the computed answer {computed} (need exactly 1): {matches}')
        elif marked != matches:
            res['errors'].append(f'key says {marked} but math says {matches}')
        traps = ns.get('trap_checks') or {}
        okt = 0
        for k, v in traps.items():
            if k in choices and same(v, choices[k]):
                okt += 1
            else:
                res['errors'].append(f'trap_checks[{k}] = {v} does not reproduce choice {k} = {choices.get(k)}')
        res['notes'].append(f'traps checked {okt}/{len(traps)}')
        # displayed text vs code
        shown = {c['key']: c.get('text', '') for c in q.get('choices', [])}
        matched = unparsed = 0
        for k, v in choices.items():
            tv = text_value(shown.get(k, ''))
            if tv is None:
                unparsed += 1
            elif same(tv, v) or _rounded_match(shown.get(k, ''), v):
                matched += 1
            else:
                res['errors'].append(f'choice {k} text "{shown.get(k)}" does not match code value {v}')
        res['notes'].append(f'displayed text matched code for {matched}/4' + (f' ({unparsed} prose, not parsed)' if unparsed else ''))
    res['ok'] = not res['errors']
    return res


def main():
    items = json.load(sys.stdin)
    out = [verify(q) for q in items]
    json.dump(out, sys.stdout)


if __name__ == '__main__':
    main()
