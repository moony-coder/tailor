// Template narrative: the product works with the LLM completely off. Same JSON shape as the LLM output; built only from digest numbers.
const CAUSE_TEXT = {
  CONTENT_GAP: ['you are missing the method for this topic', 'Watch the concept lesson, then do the drill.'],
  COMPREHENSION: ['you are misreading what the question or passage says', 'Restate the question in your own words before choosing.'],
  VOCAB: ['unknown or multi-meaning words are costing you points', 'Build a word list from the questions you missed and review it daily.'],
  CARELESS: ['you know this, but slips are costing you points', 'Add a 30-second answer check at the end of each question.'],
  STRATEGY: ['you are falling for tempting wrong answers', 'Prove your answer with a line from the text before you choose it.'],
  TIMING: ['time pressure is the problem here', 'Practise with a time target for each question.'],
  GUESS: ['quick guesses are costing you points', 'Eliminate at least two choices before you pick.'],
  OVERTHINK: ['you change right answers to wrong ones', 'Change an answer only when you can point to evidence.'],
  TOOL: ['the calculator or Desmos is slowing you down', 'Practise the Desmos shortcuts for this topic.'],
  UNKNOWN: ['the reason is not clear yet', 'Complete the mistake review so we can find the reason.'],
};
const pct = (x) => `${Math.round(x * 100)}%`;
const BEHAVIOR_TEXT = { CARELESS: 'Careless slips: add the 30-second answer check.', PACING: 'Pacing: you run short of time or rush at the end of a module.', OVERTHINK: 'You changed right answers to wrong ones. Trust your first logical answer unless you find evidence.', GUESSING: 'Several answers looked like fast guesses. Eliminate two choices first.' };

export function templateNarrative(digest) {
  const dq = digest.data_quality ?? {}, levers = digest.top_levers ?? [];
  const secs = Object.entries(digest.section_scores ?? {}).map(([k, v]) => `${k === 'rw' ? 'Reading & Writing' : 'Math'}: ${pct(v.acc)} correct`);
  const headline = levers.length ? `Your biggest chance to improve is ${levers[0].name ?? levers[0].skill}.` : 'We need more answered questions before naming your biggest chance.';
  const thin = dq.n_attempts != null && dq.n_attempts < 20 || dq.has_telemetry === false || levers.some((l) => l.low_data);
  return {
    headline,
    snapshot: `${secs.join('. ')}${secs.length ? '. ' : ''}You answered ${dq.n_attempts ?? 0} questions and got ${dq.n_wrong ?? 0} wrong.`,
    levers: levers.map((l) => { const [why, fix] = CAUSE_TEXT[l.main_cause] ?? CAUSE_TEXT.UNKNOWN; return { skill: l.skill, why: `${l.name ?? l.skill} (mastery ${l.p}): ${why}.`, fix }; }),
    behaviors: (digest.behaviors?.top ?? []).slice(0, 2).map((c) => BEHAVIOR_TEXT[c] ?? c),
    plan_note: levers.length ? `Start with ${levers[0].name ?? levers[0].skill}: do the first item in your 7-day plan today.` : 'Take one more mini-mock so the plan can focus on your real weak spots.',
    caution: thin ? 'This picture is not certain yet: there is little data or no timing information. Treat it as a first guess.' : 'These results come from practice questions, not from the real test.',
    source: 'template',
  };
}
