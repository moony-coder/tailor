// AI Advisor contract (blueprint layer 6). AI may only EXPLAIN or SUGGEST. Every output is checked by code; on any failure the
// engine falls back to template text. AI never edits the plan directly: suggestions are validated, logged, then (maybe) applied by the engine.
const SUG_TYPES = ['explain', 'tutor_hint', 'pattern_note', 'tone', 'add_review', 'extra_practice', 'swap_lesson'];
const nums = (t) => (String(t).match(/\d+(?:\.\d+)?/g) ?? []).map(Number);

/** Every number the AI writes must exist in the digest the engine gave it (or be a tiny count word). */
export function checkNumbers(text, digestNumbers, tol = 0.5) {
  const allowed = digestNumbers.map(Number), bad = nums(text).filter((n) => n > 12 && !allowed.some((a) => Math.abs(a - n) <= tol));
  return { ok: !bad.length, invented: bad };
}
export function validateSuggestion(sug, ctx) { // ctx: { skillIds:Set, lessons:Map(id->{skill_id,kind}), digestNumbers:[] }
  const why = [];
  if (!sug || !SUG_TYPES.includes(sug.type)) why.push(`type must be one of ${SUG_TYPES.join(', ')}`);
  if (sug?.skill_id && !ctx.skillIds.has(sug.skill_id)) why.push(`unknown skill ${sug.skill_id}`);
  if (sug?.lesson_id) { const l = ctx.lessons.get(sug.lesson_id); if (!l) why.push(`unknown lesson ${sug.lesson_id}`); else if (sug.skill_id && l.skill_id !== sug.skill_id) why.push('lesson does not belong to that skill'); }
  if (['add_review', 'extra_practice', 'swap_lesson'].includes(sug?.type) && !sug.skill_id) why.push('plan suggestions need skill_id');
  if (sug?.type === 'swap_lesson' && ctx.lessons.get(sug.lesson_id)?.kind === 'orientation') why.push('cannot swap in an orientation lesson');
  if (sug?.remove_prerequisite) why.push('AI may not remove a prerequisite');
  if (sug?.text) { const c = checkNumbers(sug.text, ctx.digestNumbers ?? []); if (!c.ok) why.push(`invented numbers: ${c.invented.join(', ')}`); }
  return { ok: !why.length, reasons: why };
}
/** Degradation ladder: full -> cached -> template. The student never sees an AI error. */
export function pickMode({ aiUp, cacheHit }) { return aiUp ? 'full' : cacheHit ? 'cached' : 'template'; }
export function templateExplain(day, path) {
  const f = (day.focus ?? [])[0], fix = day.steps.find((s) => s.tag === 'review');
  const parts = [`Today is ${day.minutes_total} minutes.`];
  if (day.mode === 'diagnostic') parts.push('You have no results yet, so the first job is the diagnostic that sets your starting point.');
  else if (f) parts.push(`Your biggest opportunity is ${f.name} (mastery ${Math.round(f.p * 100)}%).`);
  if (fix) parts.push(fix.why);
  if (path?.status && path.status !== 'unknown') parts.push(path.note);
  return parts.join(' ');
}
