// Deep audit (Part C8): after every Nth finished mock, look at the TREND across mocks and detect a plateau. PURE.
import { groupBy, round, mean } from '../util/misc.mjs';

const MOCK_KINDS = new Set(['mini-mock', 'native-mock']);

/** sessions = session rows of the profile; attempts = all attempt rows of the profile. */
export function deepAudit(sessions, attempts, cfg) {
  const every = cfg.deep_audit?.every_n_mocks ?? 3, range = cfg.deep_audit?.plateau_range ?? 0.03;
  const mocks = sessions.filter((s) => MOCK_KINDS.has(s.kind) && s.status === 'finished' && s.source !== 'bluebook').sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const by = groupBy(attempts, (a) => a.session_id);
  const series = mocks.map((s) => {
    const rows = by.get(s.id) ?? [], acc = (r) => (r.length ? round(mean(r.map((a) => a.is_correct))) : null);
    return { session_id: s.id, started_at: s.started_at, n: rows.length, acc: acc(rows), rw: acc(rows.filter((a) => a.section === 'rw')), math: acc(rows.filter((a) => a.section === 'math')) };
  }).filter((p) => p.n > 0);
  const n = series.length, due = n > 0 && n % every === 0;
  const last = series.slice(-every);
  const plateau = last.length >= every && Math.max(...last.map((p) => p.acc)) - Math.min(...last.map((p) => p.acc)) <= range;
  const change = n >= 2 ? round(series[n - 1].acc - series[0].acc) : null;
  // per-domain movement between the first and the last mock of the window
  const dom = [];
  if (last.length >= 2) {
    const dAcc = (sid) => { const m = new Map(); for (const [d, rows] of groupBy((by.get(sid) ?? []).filter((a) => a.domain), (a) => a.domain)) m.set(d, { acc: mean(rows.map((a) => a.is_correct)), n: rows.length }); return m; };
    const a0 = dAcc(last[0].session_id), a1 = dAcc(last[last.length - 1].session_id);
    for (const [d, v] of a1) { const p = a0.get(d); if (p && p.n >= (cfg.trend?.min_questions ?? 3) && v.n >= (cfg.trend?.min_questions ?? 3)) dom.push({ domain: d, delta_points: Math.round((v.acc - p.acc) * 100) }); }
    dom.sort((x, y) => Math.abs(y.delta_points) - Math.abs(x.delta_points));
  }
  return { mocks_count: n, every_n_mocks: every, due, next_deep_in: due ? every : every - (n % every), series, change_since_first: change, plateau: due && plateau, plateau_range: range, domain_moves: dom.slice(0, 4),
    advice: !due ? null : plateau ? 'Your last mocks are about the same. More of the same practice will not move you: change what you do (new lessons, timed sets, review your repeated mistakes).' : (change ?? 0) > 0 ? 'You are improving across mocks. Keep the plan and the weekly mock.' : 'Results went down or sideways overall. Check the top lever and whether you finished the plan.' };
}
