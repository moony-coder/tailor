/* /onboarding: six short steps that become the student's profile.
   Data contract with the app is unchanged: profile {name, goal, testDate, startScore, onboarded}
   and ext.goal (questions a day), all in localStorage 'strive_sat_v3'. Nothing leaves the browser.
   Motion: no scroll listeners. Step changes use WAAPI (cancelable): content leaves, the card eases to the new height
   (no empty space above the button), content enters, the mascot crossfades between two preloaded layers. */
const STORE_KEY = 'strive_sat_v3';
const DRAFT_KEY = 'strive_ob_draft_v1';
const DAY = 86400000;
const ymd = d => { const x = new Date(d); return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0'); };
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

(function(){
  'use strict';
  const params = new URLSearchParams(location.search);
  const EDIT = params.has('edit');
  const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const EASE = 'cubic-bezier(.23,1,.32,1)';

  let saved = null;
  try{ saved = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); }catch(e){}
  if(saved && saved.profile && saved.profile.onboarded && !EDIT){ location.replace('app.html'); return; }
  if(EDIT) $('#cancel').hidden = false;

  /* ---------------- state ---------------- */
  const P = (saved && saved.profile) || {};
  const d = {
    name: P.name || '', testDate: P.testDate || '', unsure: false,
    haveScore: P.startScore ? true : (P.startScore === 0 ? false : null),
    startScore: P.startScore || '', goal: P.goal || 1400,
    daily: (saved && saved.ext && saved.ext.goal) || 10
  };
  let i = 0, showAll = false;

  /* a half-finished setup survives a reload (new setups only) */
  if(!EDIT){
    try{
      const dr = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
      if(dr && dr.d){ Object.assign(d, dr.d); i = Math.min(Math.max(+dr.i || 0, 0), 5); }
    }catch(e){}
  }
  const saveDraft = () => { if(!EDIT){ try{ sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ d, i })); }catch(e){} } };

  /* ---------------- helpers ---------------- */
  const DAILY = [[5,'Light'],[10,'Steady'],[20,'Serious'],[30,'All in']];
  const mins = n => Math.round(n * 1.5);
  const upcoming = () => SAT_DATES.filter(x => x.d >= ymd(Date.now()));
  const daysTo = s => Math.ceil((satAt(s) - Date.now()) / DAY);
  const rel = s => { const n = daysTo(s); return n <= 0 ? 'today' : n === 1 ? 'tomorrow' : 'in ' + n + ' days'; };
  const regNote = x => {
    if(x.est) return 'Dates anticipated';
    const t = ymd(Date.now());
    if(t <= x.r) return 'Register by ' + satShort(x.r);
    if(t <= x.l) return 'Late registration only';
    return 'Registration closed';
  };
  const pickOpen = () => { const u = upcoming(); return (u.find(x => !x.est && ymd(Date.now()) <= x.l) || u[0] || {}).d || ''; };
  /* a sensible default so the date step is never a dead end: the next date still open for registration */
  if(!d.testDate && !EDIT) d.testDate = pickOpen();
  const hasStart = () => d.haveScore === true && +d.startScore >= 400 && +d.startScore <= 1600;
  const p01 = s => Math.min(1, Math.max(0, (s - 400) / 1200));
  const daysLeft = () => d.testDate ? Math.max(1, daysTo(d.testDate)) : 60;

  function optRow(v, title, meta, end, checked, tab){
    return '<button type="button" class="opt" role="radio" data-v="'+esc(v)+'" aria-checked="'+checked+'" tabindex="'+(tab?0:-1)+'">'
      + '<i class="rad" aria-hidden="true"></i><span><b>'+title+'</b>'+(meta?'<small>'+meta+'</small>':'')+'</span>'
      + (end ? '<span class="end">'+end+'</span>' : '<span></span>') + '</button>';
  }
  /* roving radiogroup: click, arrows, Home/End */
  function radios(root, pick){
    const all = () => [...root.querySelectorAll('[role=radio]')];
    const set = el => { all().forEach(x => { const on = x === el; x.setAttribute('aria-checked', on); x.tabIndex = on ? 0 : -1; }); pick(el.dataset.v, el); };
    root.addEventListener('click', e => { const el = e.target.closest('[role=radio]'); if(el) set(el); });
    root.addEventListener('keydown', e => {
      const list = all(), at = list.indexOf(document.activeElement); if(at < 0) return;
      const k = { ArrowDown:1, ArrowRight:1, ArrowUp:-1, ArrowLeft:-1 }[e.key];
      let to = k ? list[(at + k + list.length) % list.length] : e.key === 'Home' ? list[0] : e.key === 'End' ? list[list.length-1] : null;
      if(to){ e.preventDefault(); to.focus(); set(to); }
    });
  }
  const setErr = t => { $('#err').textContent = t || ''; };
  function shake(el){
    if(reduce || !el || !el.animate) return;
    el.animate([{transform:'translateX(0)'},{transform:'translateX(-6px)'},{transform:'translateX(5px)'},{transform:'translateX(-3px)'},{transform:'translateX(0)'}], { duration:280, easing:'ease-out' });
  }

  /* ---------------- card height morph ----------------
     Any change that alters the card's height (new step, score field appearing, more dates) goes through
     morph(): measure, change, measure, ease between. The card always hugs its content. */
  const card = $('.card');
  let hAnim = null;
  function morph(change, ms = 460){
    const h0 = card.offsetHeight;
    if(hAnim){ hAnim.cancel(); hAnim = null; card.classList.remove('morph'); }
    const before = card.offsetHeight;
    change();
    const h1 = card.offsetHeight;
    if(reduce || !card.animate || Math.abs(h1 - before) < 2) return;
    card.classList.add('morph');
    hAnim = card.animate([{ height: before + 'px' }, { height: h1 + 'px' }], { duration: ms, easing: EASE });
    const done = () => { if(hAnim === a){ hAnim = null; } card.classList.remove('morph'); };
    const a = hAnim;
    a.onfinish = done; a.oncancel = () => card.classList.remove('morph');
    return h0;
  }

  /* ---------------- steps ---------------- */
  const STEPS = [
    { title:()=>'Welcome to <em>Strive</em>. What should we call you?',
      sub:()=>'A few quick questions and your SAT plan builds itself.',
      render(b){ b.innerHTML = '<div class="field"><label for="fName">First name</label><input class="inp" id="fName" maxlength="20" placeholder="Your first name" autocomplete="off" autocapitalize="words" spellcheck="false" value="'+esc(d.name)+'"></div>'
        + '<div class="peek"><span class="lbl">Coming up, about a minute</span><div class="pchips"><span>Test date</span><span>Starting score</span><span>Goal</span><span>Daily routine</span></div></div>'; },
      bind(b){ const f = $('#fName'); f.addEventListener('input', () => { d.name = f.value.replace(/\s+/g,' ').trimStart(); f.removeAttribute('aria-invalid'); setErr(''); saveDraft(); }); },
      focus:'#fName',
      read(){ d.name = $('#fName').value.trim().replace(/\s+/g,' '); },
      check(){ return !d.name ? 'Please type your first name.' : d.name.length > 20 ? 'Keep it to 20 characters.' : ''; },
      bad:'#fName' },

    { title:()=>'When is your <em>test day</em>?',
      sub:()=>'Pick the College Board date you are aiming for. We use it to pace your plan.',
      render(b){
        const all = upcoming();
        if(!all.length){ b.innerHTML = '<div class="field"><label for="fDate">Test date</label><input class="inp" id="fDate" type="date" min="'+ymd(Date.now())+'" value="'+esc(d.testDate)+'"></div>'; return; }
        const rows = all.slice();
        if(d.testDate && !rows.some(x => x.d === d.testDate)) rows.unshift({ d:d.testDate, mine:true });
        if(d.testDate && !d.unsure && rows.findIndex(x => x.d === d.testDate) > 2) showAll = true;
        const list = showAll ? rows : rows.slice(0, 3);
        const first = d.unsure ? -1 : list.findIndex(x => x.d === d.testDate);
        b.innerHTML = '<div class="opts" role="radiogroup" aria-label="Test date">'
          + list.map((x, k) => optRow(x.d, satLong(x.d), x.mine ? 'Your current date' : regNote(x), rel(x.d), !d.unsure && d.testDate === x.d, k === (first < 0 ? (d.unsure ? 99 : 0) : first))).join('')
          + optRow('unsure', 'Not sure yet', 'We will use the next open date.', '', d.unsure, d.unsure)
          + '</div>' + (!showAll && rows.length > 3 ? '<button type="button" class="more" id="moreD">Show later dates</button>' : '');
      },
      bind(b){
        const g = b.querySelector('.opts');
        if(g) radios(g, v => { setErr(''); if(v === 'unsure'){ d.unsure = true; d.testDate = pickOpen(); } else { d.unsure = false; d.testDate = v; } saveDraft(); });
        const m = $('#moreD'); if(m) m.onclick = () => { showAll = true; morph(() => paint(0, true)); const rows = [...$('#body').querySelectorAll('.opt')].slice(3); rows.forEach((el, k) => el.animate && !reduce && el.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'none'}], { duration:360, delay:k*35, easing:EASE, fill:'backwards' })); };
        const f = $('#fDate'); if(f) f.addEventListener('input', () => { d.testDate = f.value; d.unsure = false; saveDraft(); });
      },
      read(){ const f = $('#fDate'); if(f) d.testDate = f.value; },
      check(){ return !d.testDate ? 'Choose your test date.' : d.testDate < ymd(Date.now()) ? 'That date has already passed.' : ''; } },

    { title:()=>'Have you taken the SAT <em>before</em>?',
      sub:()=>'A real score gives your plan a true starting point. If you have none, your first diagnostic sets one.',
      render(b){
        b.innerHTML = '<div class="opts" role="radiogroup" aria-label="Previous SAT score">'
          + optRow('yes', 'Yes, I have a score', 'An official score or a full practice test', '', d.haveScore === true, d.haveScore !== false)
          + optRow('no', 'Not yet', 'I will find out inside Strive', '', d.haveScore === false, d.haveScore === false)
          + '</div><div class="reveal field" id="scoreWrap" '+(d.haveScore === true ? '' : 'hidden')+'><label for="fScore">Latest total score</label>'
          + '<input class="inp" id="fScore" type="number" inputmode="numeric" min="400" max="1600" step="10" placeholder="400 to 1600" value="'+esc(d.startScore)+'"></div>';
      },
      bind(b){
        radios(b.querySelector('.opts'), v => {
          d.haveScore = v === 'yes'; setErr('');
          const w = $('#scoreWrap');
          morph(() => { w.hidden = !d.haveScore; });
          if(d.haveScore){ if(!reduce && w.animate) w.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'none'}], { duration:360, delay:90, easing:EASE, fill:'backwards' }); setTimeout(() => $('#fScore').focus({ preventScroll:true }), reduce ? 0 : 160); }
          saveDraft();
        });
        const f = $('#fScore'); f.addEventListener('input', () => { d.startScore = f.value.trim(); f.removeAttribute('aria-invalid'); setErr(''); saveDraft(); });
      },
      read(){ const f = $('#fScore'); if(f && d.haveScore) d.startScore = f.value.trim(); },
      check(){
        if(d.haveScore === null) return 'Choose one so we know where to start.';
        if(d.haveScore){ const n = +d.startScore; if(!d.startScore || !Number.isFinite(n) || n < 400 || n > 1600) return 'Enter a score between 400 and 1600.'; }
        return '';
      },
      bad:'#fScore' },

    { title:()=>'What score are you <em>climbing</em> to?',
      sub:()=>'Out of 1600. Pick something ambitious but real. You can raise it later.',
      render(b){
        b.innerHTML = '<div class="big"><b id="gv">'+d.goal+'</b><span>/ 1600</span></div><p class="delta" id="gd"></p>'
          + '<input class="range" id="gr" type="range" min="800" max="1600" step="10" value="'+d.goal+'" aria-label="Goal score" aria-describedby="gd">'
          + '<div class="range-ends mono"><span>800</span><span>1600</span></div>'
          + '<div class="chips picks" role="group" aria-label="Quick picks">'+[1200,1300,1400,1500,1600].map(v => '<button type="button" class="chip" data-q="'+v+'" aria-pressed="'+(d.goal === v)+'">'+v+'</button>').join('')+'</div>';
        goalUI();
      },
      bind(b){
        const r = $('#gr');
        r.addEventListener('input', () => { d.goal = +r.value; goalUI(); saveDraft(); });
        b.querySelectorAll('[data-q]').forEach(c => c.onclick = () => { d.goal = +c.dataset.q; r.value = d.goal; goalUI(); saveDraft(); });
      },
      read(){}, check(){ return d.goal >= 400 && d.goal <= 1600 ? '' : 'Goal must be between 400 and 1600.'; } },

    { title:()=>'How much can you do <em>each day</em>?',
      sub:()=>'Consistency beats cramming. This sets your daily goal and your streak.',
      render(b){
        const n = daysLeft();
        b.innerHTML = '<div class="opts" role="radiogroup" aria-label="Daily goal">'
          + DAILY.map(x => optRow(x[0], x[0]+' questions a day', x[1]+', about '+mins(x[0])+' min', d.testDate ? 'up to '+(n*x[0]).toLocaleString('en-US')+' by test day' : '', d.daily === x[0], d.daily === x[0])).join('') + '</div>';
      },
      bind(b){ radios(b.querySelector('.opts'), v => { d.daily = +v; setErr(''); saveDraft(); }); },
      read(){}, check(){ return DAILY.some(x => x[0] === d.daily) ? '' : 'Pick a daily goal.'; } },

    { last:true,
      title:()=>'You are set, <em>'+esc(d.name)+'</em>.',
      sub:()=>'Your plan is ready. Everything starts empty and fills with what you actually do.',
      render(b){
        const gain = hasStart() ? d.goal - (+d.startScore) : null;
        b.innerHTML = '<div class="recap">'
          + '<div><i class="tick"></i><span>Test day</span><b>'+esc(satLong(d.testDate))+'</b></div>'
          + '<div><i class="tick"></i><span>Starting point</span><b>'+(hasStart() ? (+d.startScore) : 'Set by your diagnostic')+'</b></div>'
          + '<div><i class="tick"></i><span>Goal</span><b>'+d.goal+(gain > 0 ? ' (+'+gain+')' : '')+'</b></div>'
          + '<div><i class="tick"></i><span>Daily routine</span><b>'+d.daily+' questions, about '+mins(d.daily)+' min</b></div></div>'
          + '<div class="next-up"><p><span><b>Take the diagnostic.</b> 20 questions across your five skill areas, about '+mins(20)+' minutes.</span></p>'
          + '<p><span><b>See your plan.</b> Weak skills ranked by the points they cost you.</span></p>'
          + '<p><span><b>Practice daily.</b> Your streak starts with the first session.</span></p></div>';
      },
      read(){}, check(){ return ''; } }
  ];

  function goalUI(){
    const r = $('#gr'); if(!r) return;
    $('#gv').textContent = d.goal;
    r.style.setProperty('--p', ((d.goal - 800) / 800 * 100) + '%');
    const gain = hasStart() ? d.goal - (+d.startScore) : null;
    $('#gd').textContent = gain == null ? 'Your first diagnostic sets your baseline.'
      : gain > 0 ? '+' + gain + ' points from your ' + (+d.startScore) : gain === 0 ? 'That matches your latest score. Aim higher?' : 'That is below your latest score. Raise it?';
    document.querySelectorAll('[data-q]').forEach(c => c.setAttribute('aria-pressed', +c.dataset.q === d.goal));
  }

  /* ---------------- dots ---------------- */
  const dotsEl = $('#dots'), N = STEPS.length;
  dotsEl.setAttribute('aria-valuemax', N);
  for(let k = 0; k < N; k++){
    if(k) dotsEl.appendChild(Object.assign(document.createElement('i'), { className:'link' }));
    const dt = document.createElement('i'); dt.className = 'dot'; dt.dataset.k = k; dotsEl.appendChild(dt);
  }
  dotsEl.addEventListener('click', e => {
    const dt = e.target.closest('.dot'); if(!dt || moving) return;
    const k = +dt.dataset.k; if(k < i){ STEPS[i].read(); i = k; paint(-1); }
  });
  function paintDots(){
    const dts = dotsEl.querySelectorAll('.dot'), lks = dotsEl.querySelectorAll('.link');
    dts.forEach((el, k) => { el.className = 'dot' + (k < i ? ' done' : k === i ? ' now' : ''); el.setAttribute('aria-label', k < i ? 'Go back to step ' + (k+1) : ''); });
    lks.forEach((el, k) => el.classList.toggle('done', k < i));
    dotsEl.setAttribute('aria-valuenow', i + 1); dotsEl.setAttribute('aria-valuetext', 'Step ' + (i+1) + ' of ' + N);
  }

  /* ---------------- mascot: two layers, crossfaded ----------------
     The next pose is fully decoded before it is shown, so there is never a blank frame, a half-loaded
     image or a layout jump. Interrupt-safe: only the latest request wins. */
  const POSE = ['m_welcome','m_think','m_listen','m_cheer','m_study','m_trophy'];
  const SIZE = { m_welcome:[720,474], m_think:[720,677], m_listen:[720,678], m_cheer:[720,677], m_study:[720,682], m_trophy:[720,604] };
  const layers = [$('#mas0'), $('#mas1')];
  let front = 0, shown = POSE[0], poseReq = 0;
  const pre = {};
  POSE.forEach(k => { const im = new Image(); im.decoding = 'async'; im.src = 'assets/img/' + k + '.webp'; pre[k] = im.decode ? im.decode().catch(() => {}) : Promise.resolve(); });
  function pose(){
    const k = POSE[i]; if(k === shown) return;
    const req = ++poseReq, src = 'assets/img/' + k + '.webp';
    (pre[k] || Promise.resolve()).then(() => {
      if(req !== poseReq) return;
      const from = layers[front], to = layers[1 - front];
      to.src = src; to.width = SIZE[k][0]; to.height = SIZE[k][1];
      const go = () => {
        if(req !== poseReq) return;
        shown = k; front = 1 - front;
        to.classList.remove('off'); to.classList.add('on');
        from.classList.remove('on'); from.classList.add('off');
        setTimeout(() => { if(req === poseReq || from !== layers[front]) from.classList.remove('off'); }, 460);
      };
      (to.decode ? to.decode().catch(() => {}) : Promise.resolve()).then(() => requestAnimationFrame(go));
    });
  }

  /* ---------------- paint a step ---------------- */
  let running = [], moving = false, moveTok = 0;
  const parts = () => [$('#title'), $('#sub'), ...$('#body').children];
  function enter(dir){
    running.forEach(a => a.cancel()); running = [];
    if(!document.body.animate) return;
    parts().forEach((el, k) => {
      const frames = reduce ? [{ opacity:0 }, { opacity:1 }] : [{ opacity:0, transform:'translate3d(' + (dir * 26) + 'px,0,0)' }, { opacity:1, transform:'translate3d(0,0,0)' }];
      running.push(el.animate(frames, { duration: reduce ? 160 : 480, delay: reduce ? 0 : 60 + k * 55, easing:EASE, fill:'backwards' }));
    });
  }
  function leave(dir){
    running.forEach(a => a.cancel()); running = [];
    if(reduce || !document.body.animate) return Promise.resolve();
    const els = parts();
    const all = els.map((el, k) => el.animate([{ opacity:1, transform:'translate3d(0,0,0)' }, { opacity:0, transform:'translate3d(' + (-dir * 18) + 'px,0,0)' }], { duration:170, delay:k * 14, easing:'cubic-bezier(.4,0,1,1)', fill:'forwards' }));
    running = all;
    return Promise.all(all.map(a => a.finished.catch(() => {})));
  }
  function content(keepFocus){
    const s = STEPS[i], body = $('#body');
    $('#title').innerHTML = s.title(); $('#sub').textContent = s.sub();
    s.render(body); if(s.bind) s.bind(body);
    paintDots();
    $('#stepNo').textContent = 'Step ' + (i + 1) + ' of ' + N;
    $('#back').disabled = i === 0;
    $('#nextL').textContent = s.last ? (EDIT ? 'Save changes' : 'Start climbing') : 'Continue';
    $('#fine').style.visibility = i > 0 && !s.last ? 'hidden' : '';
    $('#fine').textContent = s.last ? 'Saved on this device. Change any of this later in Settings.' : 'Saved on this device. No account needed.';
    setErr('');
    saveDraft();
  }
  function focusStep(){
    const s = STEPS[i], f = s.focus && $(s.focus);
    if(f) f.focus({ preventScroll:true }); else $('#title').focus({ preventScroll:true });
  }
  /* dir: 1 forward, -1 back, 0 no motion (first paint / in-place repaint) */
  function paint(dir = 1, keepFocus = false){
    if(dir === 0){ content(keepFocus); pose(); if(!keepFocus) focusStep(); return; }
    const tok = ++moveTok; moving = true;
    leave(dir).then(() => {
      if(tok !== moveTok) return;
      morph(() => { content(keepFocus); });
      pose(); enter(dir);
      moving = false;
      if(!keepFocus) setTimeout(focusStep, reduce ? 0 : 220);
    });
  }

  /* ---------------- save + navigation ---------------- */
  function save(){
    let cur = {};
    try{ cur = JSON.parse(localStorage.getItem(STORE_KEY) || '{}') || {}; }catch(e){ cur = {}; }
    cur.v = 3; cur.createdAt = cur.createdAt || Date.now();
    cur.profile = Object.assign({}, cur.profile, {
      name: d.name, goal: d.goal, testDate: d.testDate,
      startScore: hasStart() ? +d.startScore : 0, onboarded: true, onboardedAt: (cur.profile && cur.profile.onboardedAt) || Date.now()
    });
    cur.ext = Object.assign({}, cur.ext, { goal: d.daily });
    localStorage.setItem(STORE_KEY, JSON.stringify(cur));
    try{ sessionStorage.removeItem(DRAFT_KEY); }catch(e){}
  }
  $('#form').addEventListener('submit', e => {
    e.preventDefault();
    if(moving) return;
    const s = STEPS[i]; s.read(); const msg = s.check();
    if(msg){
      setErr(msg);
      const bad = s.bad && $(s.bad);
      if(bad){ bad.setAttribute('aria-invalid', 'true'); bad.focus({ preventScroll:true }); shake(bad); }
      else { const g = $('#body').querySelector('.opts'); shake(g); const f = $('#body').querySelector('[role=radio]'); if(f) f.focus({ preventScroll:true }); }
      return;
    }
    if(s.last){
      try{ save(); }catch(err){ setErr('Your browser blocked saving. Turn off private mode or allow site storage, then try again.'); return; }
      const nx = $('#next'); nx.disabled = true; nx.classList.add('busy');
      document.body.classList.add('leaving');
      setTimeout(() => { location.href = 'app.html'; }, reduce ? 0 : 400);
      return;
    }
    i++; paint(1);
  });
  $('#back').addEventListener('click', () => { if(i > 0 && !moving){ STEPS[i].read(); i--; paint(-1); } });

  paint(0);
  const show = () => { document.body.classList.add('ready'); enter(1); };
  if(document.fonts && document.fonts.ready) Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 400))]).then(() => requestAnimationFrame(show)); else show();

  /* warm the app shell in idle time so the intro starts instantly after the last step */
  const warm = () => ['app.html','assets/css/app.css','assets/js/11-intro.js','assets/img/logo.png'].forEach(u => { const l = document.createElement('link'); l.rel = 'prefetch'; l.href = u; document.head.appendChild(l); });
  (window.requestIdleCallback || (f => setTimeout(f, 1500)))(warm);
})();
