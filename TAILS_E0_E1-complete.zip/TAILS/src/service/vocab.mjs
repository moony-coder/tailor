// Vocabulary gaps (Part C9 "Vocabulary gaps (word list)" + C8 vocab plan): words from missed RW questions, deduplicated.
// A word counts when the student missed a question that targets it AND the miss looks vocabulary-related
// (root cause VOCAB, or a Words-in-Context miss). Meanings come from our own authored questions only.
export function vocabularyGaps(ctx, attempts, { sessionId = null, limit = 40 } = {}) {
  const words = new Map();
  for (const a of attempts) {
    if (a.is_correct || !a.question_id) continue;
    const q = ctx.qById.get(a.question_id);
    if (!q?.vocabulary_terms?.length) continue;
    if (!(a.root_cause === 'VOCAB' || a.skill_id === 'RW.CS.WIC' || a.trap_code === 'NEARBY-MEANING')) continue;
    for (const v of q.vocabulary_terms) {
      const w = words.get(v.term.toLowerCase()) ?? { term: v.term, meaning: v.meaning, missed: 0, in_this_session: false, question_ids: [] };
      w.missed++; if (sessionId && a.session_id === sessionId) w.in_this_session = true;
      if (!w.question_ids.includes(q.id)) w.question_ids.push(q.id);
      words.set(v.term.toLowerCase(), w);
    }
  }
  return [...words.values()].sort((a, b) => Number(b.in_this_session) - Number(a.in_this_session) || b.missed - a.missed || a.term.localeCompare(b.term)).slice(0, limit);
}
